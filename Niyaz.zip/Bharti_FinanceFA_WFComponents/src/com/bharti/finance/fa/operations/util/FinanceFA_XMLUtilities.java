/*
 * Created on 26/09/2006 Author HCL
 */
package com.bharti.finance.fa.operations.util;

import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.finance.fa.operations.util.dto.NotificationDTO;
import com.bharti.finance.fa.operations.util.dto.MilestoneDTO;

//import com.bharti.finance.fa.operations.util.dto.TaskDTO;

/**
 * @viz.diagram XMLUtil.tpx
 */
public class FinanceFA_XMLUtilities extends Utilities {
	private static Logger log = Logger.getLogger(FinanceFA_XMLUtilities.class);

	public FinanceFA_XMLUtilities() {

	}

	public static MilestoneDTO getMilestoneDetailsFromXML(
			String milestoneDetailsXMLString, int milestonePointer) {
		//	MilestoneDTO milestoneDTO = null;
		Document milestoneDetailsXMLDoc = null;
		MilestoneDTO milestoneDTO = new MilestoneDTO();
		//i.create document object of milestoneDetailsXML
		log.debug("Entry getMilestoneDetailsFromXML()");

		try {
			milestoneDetailsXMLDoc = getDocumentInstance(milestoneDetailsXMLString);
			log.debug("xml document to be edited ["
					+ convertDOMtoString(milestoneDetailsXMLDoc) + "]");
			Element milestonesElement = milestoneDetailsXMLDoc
					.getDocumentElement();
			Node nodeFound = fetchRequiredNodeFromXML(milestonesElement,
					milestonePointer, FinanceFA_Constants.STRMILESTONE);
			if (nodeFound == null) {
				log.debug("milestone not found with pointer ["
						+ milestonePointer + "]in the milestone details XML ["+milestoneDetailsXMLString+"]");
				return null;
			}

			milestoneDTO = (MilestoneDTO) populateNodeListInBean(
					(NodeList) nodeFound, milestoneDTO);
			/*
			 * fetch the attribute ScenarioMilestoneID value and set it in the
			 * milestoneDTO.
			 */
			String currentMilestoneID = nodeFound.getAttributes().getNamedItem(
					FinanceFA_Constants.STR_SCENARIO_MILESTONE_ID)
					.getNodeValue();
			log.debug("currentMilestoneID:" + currentMilestoneID);
			milestoneDTO.setScenariomilestoneid(currentMilestoneID);
			log.debug("scenario id from the bean:"
					+ milestoneDTO.getScenariomilestoneid());

		} catch (Exception e) {
			log.error("Error occured in fetching milestone details: "
					+ e.getMessage(), e);
		}

		log.debug("Exit getMilestoneDetailsFromXML()");

		return milestoneDTO;

	}

	/**
	 * This method parses the input xmlString and finds the matching node with
	 * the input notification pointer
	 * 
	 * 
	 * @param xmlString
	 *            -string form the input XML
	 * @param nodePointer -
	 *            node from which details has to be fetched
	 * @param attribute -
	 *            key search attribute to fetch the node
	 * @param objBean -
	 *            empty bean object to be populated with fetched node details
	 * @return Object - bean object with node deatials populated
	 * @throws Exception
	 */
	public static Object getNodeDetailsFromXML(String xmlString,
			int nodePointer, Object objBean) {
		//String xmlDetails[]=null;
		//NotificationDTO Bean=new NotificationDTO();
		Document xmlDoc = null;
		HashMap hm = new HashMap();
		log.debug("Entry getNodeDetailsFromXML()");

		try {
			xmlDoc = getDocumentInstance(xmlString);
		} catch (Exception e) {
			log.error("Exception occured : " + e.getMessage(), e);
		}
		Node nodeFetched = fetchRequiredNodeFromXML(xmlDoc, nodePointer, "SID");
		NodeList childNodeList = nodeFetched.getChildNodes();
		int maxofChild = childNodeList.getLength();

		log.debug("child nodes :[" + nodeFetched.getChildNodes().getLength()+"]");
		//doc.get

		for (int child = 0; child < maxofChild; child++) {
			//childNodeList.item(child).getNodeName();
			System.out.println("node name :"
					+ childNodeList.item(child).getNodeName());
			String name = childNodeList.item(child).getNodeName();
			String value = getNodeValue(childNodeList.item(child));

			hm.put(name.toLowerCase(), value);
			FinanceFA_Utilities.populateBean(objBean, hm);

		}
		log.debug("objBean [ " + objBean+"]");
		log.debug("hm: " + hm);

		log.debug("Exit getNodeDetailsFromXML()");

		return objBean;
	}

	/**
	 * This method parses the input xmlString and finds the matching node with
	 * the input notification pointer
	 * 
	 * 
	 * @param xmlString
	 *            -string form the input XML
	 * @param nodePointer -
	 *            node from which details has to be fetched
	 * @param attribute -
	 *            key search attribute to fetch the node
	 * @param objBean -
	 *            empty bean object to be populated with fetched node details
	 * @return Object - bean object with node deatials populated
	 * @throws Exception
	 */
	public static Object getNodeDetailsFromXML(String xmlString,
			int cScenarioMilestoneID, int nodePointer, Object objBean)
			throws Exception {
		
		Document xmlDoc = null;
		NodeList foundNodeList = null;
		NodeList notificationList = null;
		Node notificatonFound = null;
		NotificationDTO notificationBean = null;

		try {

			log.debug("Entry getNodeDetailsFromXML()");

			/*
			 * get the document object of the input xmlString
			 */
			try {
				xmlDoc = getDocumentInstance(xmlString);
				log.debug("xml document to be edited ["
						+ convertDOMtoString(xmlDoc) + "]");
			} catch (Exception e) {
				log.error("Exception occured : " + e.getMessage(), e);
			}
			/*
			 * search the root node attribute if its category is Process then
			 * get Notification nodelist. if its category is Milestone parse and
			 * get Milestone nodelist and in the milestone nodelist get the
			 * notification nodelist
			 *  
			 */

			log.debug("Root element "
					+ xmlDoc.getDocumentElement().getNodeName());
			Element rootElement = xmlDoc.getDocumentElement();
			String category = rootElement
					.getAttribute(FinanceFA_Constants.STR_CATEGORY);
			if (category == null || category.equalsIgnoreCase("")) {
				log.info("attribute [" + FinanceFA_Constants.STR_CATEGORY
						+ "] not found");

			}
			log.info("attribute [" + FinanceFA_Constants.STR_CATEGORY
					+ "] found ,and its value  is [" + category + "]");
		

			if (category.equalsIgnoreCase(FinanceFA_Constants.STRPROCESS)) {
				log.debug("fetching  notification details  is of Process..");
				notificationList = rootElement
						.getElementsByTagName("Notification");

			}
			if (category.equalsIgnoreCase(FinanceFA_Constants.STRMILESTONE)) {
				Node milestoneFound = null;

				log.debug("fetching notificatio details of Milestone ..");
				NodeList milestoneList = rootElement
						.getElementsByTagName("Milestone");
				log.debug("Total number of milestones in the xml ["
						+ milestoneList.getLength() + "]");
				milestoneFound = fetchRequiredNode(milestoneList,
						cScenarioMilestoneID, "ScenarioMilestoneID");
				//NodeList notificationList=(NodeList)nodeFound;
				Element milestoneElement = (Element) milestoneFound;
				NodeList milestone_notificationList = milestoneElement
						
				.getElementsByTagName(FinanceFA_Constants.STR_NOTIFICATION);

				notificationList = milestone_notificationList;
			}

			/*
			 * below code is common for Process and Milestone
			 * 
			 * find the isTimerExpired attribute and make it's value to true.
			 */
			log.debug("Total number of notification nodes in the xml[ "
					+ notificationList.getLength() + "]");

			notificatonFound = fetchRequiredNode(notificationList, nodePointer,
					"SID");
			Element notificationElement = (Element) notificatonFound;
			log.debug("IsTimerExpried of the fetched notification node [ "
					+ 
					getNodeValue(notificationElement.getElementsByTagName(
							FinanceFA_Constants.STR_IS_TIMER_EXPIRED).item(0)) + "]");

			Element old_IsTimerExpired = (Element) notificationElement
					.getElementsByTagName(FinanceFA_Constants.STR_IS_TIMER_EXPIRED)
					.item(0);
			Element new_isTimerElement = (Element) xmlDoc
					.createElement(FinanceFA_Constants.STR_IS_TIMER_EXPIRED);
			new_isTimerElement.appendChild(xmlDoc.createTextNode("true"));
			notificatonFound.replaceChild(new_isTimerElement,
					old_IsTimerExpired);
			log.info("isTimerExpired value is set true and the modified xml is"
					+ "populated in the notification bean as an attribute");
			foundNodeList = (NodeList) notificatonFound;
			String modifiedxmlString = convertDOMtoString(xmlDoc);
			log.debug("new  xml string :" + modifiedxmlString);
			log
					.debug("populating the found nodelist into notification bean...");
			notificationBean = (NotificationDTO) populateNodeListInBean(
					foundNodeList, objBean);
			//			set modifiedxml string in notification bean
			notificationBean.setCategory(category);
			notificationBean.setModifiedXMLString(modifiedxmlString);
			log.debug("modified xml :["
					+ notificationBean.getModifiedXMLString() + "]");
			/*
			 * log.debug("notification details to be returned..[" +
			 * notificationBean.getIstimerexpired() + "]");
			 */
			log.debug("Exit getNodeDetailsFromXML");

		} catch (Exception e) {

			log.error("Exception occured in getting node details from xml:"
					+ e.getMessage(), e);
		}

		return notificationBean;
	}

	
	/*
	 * private static String nodeListToString(NodeList nodeList){ return ; }
	 */
	public static Object populateNodeListInBean(NodeList nodeList,
			Object objBean) {
		log.debug("[Enter populateNodeListInBean]");
		int maxOfChild = 0;
		String name = "";
		String value = "";
		HashMap hm = new HashMap();

		log.debug("Populating the bean with the node details...");
		maxOfChild = nodeList.getLength();
		for (int child = 0; child < maxOfChild; child++) {
			Node eachNode = nodeList.item(child);
			if (eachNode.getNodeType() == Node.ELEMENT_NODE) {
				name = nodeList.item(child).getNodeName();
				value = FinanceFA_XMLUtilities.getNodeValue(eachNode);
				//value = nodeList.item(child).getTextContent();
				//if(value !)
				log.debug("Property name [" + name + "] value [" + value + "]");
				hm.put(name.toLowerCase(), value);
			}
		}
		FinanceFA_Utilities.populateBean(objBean, hm);
		log.debug("[Exit populateNodeListInBean]");
		return objBean;

	}

	public static String getNodeValue(Node node) {
		Element element = (Element) node;
		String value = null;
		NodeList childNodeList = element.getChildNodes();

		if (((Node) childNodeList.item(0)) != null) {
			value = ((Node) childNodeList.item(0)).getNodeValue();
		}
		return value;
	}

	/**
	 * @param nodeList-
	 *            nodeList whose child list has to populate in bean as key-value
	 */

	private static Node fetchRequiredNode(NodeList nodeList, int nodePointer,
			String keyAttribute) {
		log.debug("Entry fetchRequiredNode()");
		String eachTempId = "";
		Node nodeFound = null;
		Node eachNode = null;
		int maxofChild = nodeList.getLength();
		for (int child = 0; child < maxofChild; child++) {
			eachNode = nodeList.item(child);
			eachTempId = eachNode.getAttributes().getNamedItem(keyAttribute)
					.getNodeValue();
			log.debug("eachTempId:" + eachTempId);
			Integer tempScenarioMSID = new Integer(eachTempId);
			if (nodePointer == tempScenarioMSID.intValue()) {
				nodeFound = eachNode;
				break;
			}
		}
		log.debug("Exit fetchRequiredNode()");
		return nodeFound;
	}

	public static Node fetchRequiredNode(NodeList nodeList,
			String attributeName, String attributeValue) {
		log.debug("[Enter fetchRequiredNode:: nodeList ["
				+ nodeList.item(0).getNodeName() + "] attributeName ["
				+ attributeName + "] attributeValue [" + attributeValue + "]");

		String eachAttributeValue = "";
		Node nodeFound = null;
		Node eachNode = null;

		if (nodeList != null) {
			int maxofChild = nodeList.getLength();
			log.debug("Node List length is :" + maxofChild);
			for (int child = 0; child < maxofChild; child++) {
				eachNode = nodeList.item(child);
				Element eachElement = (Element) eachNode;
				eachAttributeValue = eachElement.getAttribute(attributeName);

				log.debug("Node [" + (child + 1) + "] Attribute Value:"
						+ eachAttributeValue);
				if (attributeValue.equalsIgnoreCase(eachAttributeValue)) {
					log.debug("Node with attribute name [" + attributeName
							+ "] value [" + attributeValue + "] found.");
					nodeFound = eachNode;
					break;
				}
			}
		}
		log.debug("[Exit fetchRequiredNode:: nodeList ["
				+ nodeList.item(0).getNodeName() + "] attributeName ["
				+ attributeName + "] attributeValue [" + attributeValue + "]");
		return nodeFound;
	}

	private static Node fetchRequiredNodeFromXML(Element element,
			int nodePointer, String tagName) {
		log.debug("[Enter fetchRequiredNodeFromXML:: element ["
				+ element.getNodeName() + "] nodePointer [" + nodePointer
				+ "] tagName [" + tagName + "]");
		Node nodeFetched = null;
		Node eachNode = null;
		log.info("root node name:" + element.getNodeName());
		// NodeList eachNodeList = rootElement.getChildNodes();

		NodeList eachNodeList = element.getElementsByTagName(tagName);
		int nodeListlength = eachNodeList.getLength();
		log.debug("total number of available [" + tagName
				+ "]s  in the element [" + element.getNodeName() + "]is :["
				+ nodeListlength + "]");
		if (nodePointer <= 0 || nodePointer > nodeListlength) {
			log.debug("There is no node at position =" + nodePointer);
			return null;
		}

		int nodeCounter = 1;
		for (int i = 0; i < eachNodeList.getLength(); i++, nodeCounter++) {
			log.debug("nodePointer [" + nodePointer + "],nodeCounter [ "
					+ nodeCounter + "]");
			eachNode = eachNodeList.item(i);
			// log.debug("eachNode: " + eachNode);

			if (nodePointer == nodeCounter) {
				log.info("Required node for[" + tagName + "]found at pointer ["
						+ nodeCounter + "]");
				nodeFetched = eachNode;
				/*
				 * log.debug("Scenario id :" +
				 * eachNodeList.item(i).getAttributes().getNamedItem(
				 * "ScenarioMilestoneID"));
				 */
				break;

			}

		}

		log.debug("[Exit fetchRequiredNodeFromXML:: element ["
				+ element.getNodeName() + "] nodePointer [" + nodePointer
				+ "] tagName [" + tagName + "]");
		return nodeFetched;

	}

	public static NotificationDTO fetchRequiredNodeFromXML(Element element,
			int nodePointer, String tagName, String keyAttribute)
			throws Exception {

		Node nodeFetched = null;
		Node eachNode = null;
		NotificationDTO notificationDTO = null;

		NodeList eachNodeList = element.getElementsByTagName(tagName);
		log.debug("Available Notifications are [" + eachNodeList.getLength()+"]");
		int length = eachNodeList.getLength();
		if (nodePointer <= 0 || nodePointer > length) {
			log.debug("There is no node at position [" + nodePointer+"]");
			return null;
		}
		for (int i = 0; i < eachNodeList.getLength(); i++) {
			eachNode = eachNodeList.item(i);

			log.debug(eachNode.getNodeName());
			log.info("value of "
					+ keyAttribute
					+ "is ["
					+ eachNode.getAttributes().getNamedItem(keyAttribute)
							.getNodeValue() + "]");
			String eachNodePointer = eachNode.getAttributes().getNamedItem(
					keyAttribute).getNodeValue();
			if (nodePointer == Integer.parseInt(eachNodePointer)) {
				log.info("notification pointer found at [ " + eachNodePointer
						+ "]");
				nodeFetched = eachNode;
				notificationDTO = new NotificationDTO();
				Element elementFetched = (Element) nodeFetched;
				String offset = getNodeValue(elementFetched.getElementsByTagName("Offset")
						.item(0));
				
				
				log.debug("offset value is [" + offset+" ] from notification node ]");

				populateNodeListInBean(elementFetched.getChildNodes(),
						notificationDTO);
				break;
			}
		}
		return notificationDTO;
	}

	/**
	 * This method created instance of DOM Object from String.
	 * 
	 * @param docStr
	 *            String
	 * @return Document
	 * @throws Exception
	 */
	public static Document getDocumentInstance(String docStr) throws Exception {
		log.debug("Entry getDocumentInstance");
		StringReader sr = new StringReader(docStr);
		InputSource ip = new InputSource(sr);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = null;
		try {
			doc = db.parse(ip);
		} catch (SAXException e) {
			// TODO Auto-generated catch block
			log.error("Exception occured " + e.getMessage(), e);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			log.error("Exception occured " + e.getMessage(), e);
		}
		log.debug("Exit getDocumentInstance");
		return doc;
	}

	public static Document getDocumentInstance() throws Exception {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory
				.newDocumentBuilder();
		Document document = documentBuilder.newDocument();
		return document;
	}

	/**
	 * Method getRootElement
	 * 
	 * @param doc
	 *            Document
	 * @return Element
	 */
	public static Element getRootElement(Document doc) {
		return doc.getDocumentElement();
	}

	/**
	 * This method creates element Node. For example
	 * createElementNode(doc,"value"); It will create element like <value/>
	 * 
	 * @param doc
	 *            Node
	 * @param elementName
	 *            String
	 * @return Node
	 */
	public static Node createElementNode(Document doc, String elementName) {
		Element element = doc.createElement(elementName);
		return element;
	}

	/**
	 * This method created element text node.
	 * 
	 * createElementNode(doc,"value","7"); will create <value>7 </value>
	 * 
	 * @param doc
	 *            Node
	 * @param elementName
	 *            Element Name
	 * @param elementText
	 *            Element Text
	 * @return Node
	 */
	public static Node createElementNode(Document doc, String elementName,
			String elementText) {

		Element element = doc.createElement(elementName);
		Node txtNode = doc.createTextNode(elementText);
		element.appendChild(txtNode);
		return element;

	}

	/*
	 * CachedXPathApi cudn't read the latest version of Document. So used
	 * XPathApi for getfilter method.
	 */

	/**
	 * This method returns Node from DOM specified by XPath.
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @return Node
	 * @throws Exception
	 */
	public static Node getNode(Node contextNode, String xpath) throws Exception {
		return XPathAPI.selectSingleNode(contextNode, xpath);
	}

	/**
	 * This method returns group of Nodes from DOM specified by XPath.
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @return NodeList
	 * @throws Exception
	 */
	public static NodeList getNodes(Node contextNode, String xpath)
			throws Exception {
		return XPathAPI.selectNodeList(contextNode, xpath);
	}

	/**
	 * This method adds a Node to DOM object as specified by XPath.
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @param newNode
	 *            Node
	 * @return Node
	 * @throws Exception
	 */
	public static Node addNode(Node contextNode, String xpath, Node newNode)
			throws Exception {
		Node node = getNode(contextNode, xpath);
		if (node != null)
			node.appendChild(newNode);
		return newNode;
	}

	public static Document addNode(Document document, String name)
			throws Exception {
		Element rootElement = document.createElement(name);
		document.appendChild(rootElement);
		return document;
	}

	/**
	 * This method removes a Node from DOM Object
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @return Node
	 * @throws Exception
	 */
	public static Node removeNode(Node contextNode, String xpath)
			throws Exception {
		Node node = getNode(contextNode, xpath);
		if (node != null) {
			Node parent = node.getParentNode();

			if (parent != null)
				parent.removeChild(node);
		}
		return node;
	}

	/**
	 * This method created Element with Attribute node
	 * 
	 * createAttributeNode(doc,"queue","name","Sale") will create <queue
	 * name="Sale"/>
	 * 
	 * @param doc
	 *            Document
	 * @param elementName
	 *            Element Node Name
	 * @param attributeName
	 *            Attribute Name
	 * @param attributeValue
	 *            Attribute Value
	 * @return Node
	 */
	public static Node createAttributeNode(Document doc, String elementName,
			String attributeName, String attributeValue) {

		Element element = (Element) createElementNode(doc, elementName);
		element.setAttribute(attributeName, attributeValue);
		return element;
	}

	/**
	 * This method converts DOM Object to String
	 * 
	 * @param doc
	 *            Document
	 * @return String
	 * @throws Exception
	 */
	public static String convertDOMtoString(Document doc) throws Exception {
		String processedXML = null;

		// Transform the DOM tree into XML String
		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer = transFactory.newTransformer();
		DOMSource dSource = new DOMSource(doc);
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(dSource, sr);
		StringWriter anotherSW = (StringWriter) sr.getWriter();
		StringBuffer sBuffer = anotherSW.getBuffer();
		processedXML = sBuffer.toString();
		return processedXML;
	}

	// public static String toString(Document newDoc)
	// {
	// String strDocument = "";
	// if(newDoc != null)
	// {
	// try
	// {
	// OutputFormat format = new OutputFormat(newDoc);
	// StringWriter strOut = new StringWriter();
	// XMLSerializer XMLSerial = new
	// org.apache.xml.serialize.XMLSerializer(strOut,format);
	// XMLSerial.serialize(newDoc.getDocumentElement());
	// strDocument = strOut.toString();
	//
	// }
	// catch (Exception exp)
	// {
	// log.error("Error Converting XML to String : ", exp);
	// }
	// }
	// return strDocument;
	// }
	//		
	// Added by Rajni 26 Feb 2008 10:00 PM

	private static Node createValueNode(Document responseDoc, Node node,

	String fieldName, String value) throws Exception {

		Element attr = (Element) FinanceFA_XMLUtilities.createAttributeNode(
				responseDoc,

				"Value", "Field", fieldName);

		attr.setAttribute("Name", value);

		Node txtNode = responseDoc.createTextNode(value);

		attr.appendChild(txtNode);

		node.appendChild(attr);

		return node;

	}

	private static Node createItemNode(Document responseDoc) throws Exception {

		Node item = FinanceFA_XMLUtilities.createElementNode(responseDoc,
				"Item");

		FinanceFA_XMLUtilities.addNode(responseDoc, "//Items", item);

		return item;

	}

	private static Node createHeaderNode(org.w3c.dom.Document responseDoc,

	String[] attributes) throws Exception {

		Node header = FinanceFA_XMLUtilities.createElementNode(responseDoc,
				"Header");

		FinanceFA_XMLUtilities.addNode(responseDoc, "/Items", header);

		for (int i = 0; i < attributes.length; i++) {

			Node val = FinanceFA_XMLUtilities.createElementNode(responseDoc,
					"Value",

					attributes[i]);

			FinanceFA_XMLUtilities.addNode(responseDoc, "//Header", val);

		}

		return responseDoc;

	}

	public static Document getDocumentRequesterCountry(ArrayList alUsersCFS,

	Hashtable htFields) throws Exception {

		log.debug("List in country is:" + alUsersCFS);

		// String

		// pwID=((Attribute)((Hashtable)alUsersCFS.get(0)).get(Constants.LDAP_ATTRIBUTE_PWID)).get(0).toString();

		// String

		// country=((Attribute)((Hashtable)alUsersCFS.get(0)).get(Constants.LDAP_ATTRIBUTE_COUNTRY)).get(0).toString();

		// String

		// userName=((Attribute)((Hashtable)alUsersCFS.get(0)).get(Constants.LDAP_ATTRIBUTE_NAME)).get(0).toString();

		// log.debug("pw is is:"+pwID);

		log.debug("XML conversion Method:");

		org.w3c.dom.Document doc = getDocumentInstance("<Items LimitExceeded='0'></Items>");

		/*
		 * 
		 * Node header = createElementNode(doc, "Header"); XMLUtil.addNode(doc,
		 * 
		 * "/Items", header); Node val = createElementNode(doc,
		 * 
		 * "Value","PeopleWiseId"); XMLUtil.addNode(doc, "//Header", val); val =
		 * 
		 * createElementNode(doc, "Value","User Name"); XMLUtil.addNode(doc,
		 * 
		 * "//Header", val); val = createElementNode(doc, "Value","Country");
		 * 
		 * XMLUtil.addNode(doc, "//Header", val);
		 * 
		 */

		// for displaying values
		// createHeaderNode(doc, new String[] { "PeopleWiseId", "User
		// Name","Country" });
		// createHeaderNode(doc, new String[] { "User Name","Country" });
		createHeaderNode(doc, new String[] { "PeopleWiseId", "User Name",
				"Country" });
		// createHeaderNode(doc, new String[] { "User Name","Country" });
		// Create Item Nodes.....
		if (alUsersCFS != null && alUsersCFS.size() > 0) {
			Hashtable htFieldValues = (Hashtable) alUsersCFS.get(0);

			Set keySet = htFields.keySet();
			Iterator it = keySet.iterator();

			// int i = 0;
			Node node = createItemNode(doc);
			while (it.hasNext()) {

				String key = (String) it.next();
				String element = (String) htFields.get(key);
				String value = htFieldValues.get(key).toString();

				log.debug("element :" + element);
				log.debug("value :" + value);

				createValueNode(doc, node, element, (value.substring(value
						.indexOf(":") + 1)).trim());

			}

		}

		// Node itemNode = XMLUtil.createElementNode(doc, "Item");

		// XMLUtil.addNode(doc, "//Items", itemNode);

		//    

		// Element attr = (Element) XMLUtil.createAttributeNode(doc,"Value",

		// "Field", "CD_peoplewiseidofdocumentrequestor");

		// attr.setAttribute("Name", pwID);

		// Node txtNode = doc.createTextNode(pwID);

		// attr.appendChild(txtNode);

		// itemNode.appendChild(attr);

		//          

		// log.debug("pwid is:"+itemNode.appendChild(attr));

		//          

		// attr = (Element) XMLUtil.createAttributeNode(doc,"Value", "Field",

		// "CD_nameofdocumentrequestor");

		// attr.setAttribute("Name", userName);

		// txtNode = doc.createTextNode(userName);

		// attr.appendChild(txtNode);

		// itemNode.appendChild(attr);

		//          

		// log.debug("userName is :"+itemNode.appendChild(attr));

		//          

		// attr = (Element) XMLUtil.createAttributeNode(doc,"Value", "Field",

		// "CD_nameofdocumentrequestor");

		// attr.setAttribute("Name", country);

		// txtNode = doc.createTextNode(country);

		// attr.appendChild(txtNode);

		// itemNode.appendChild(attr);

		//          

		// log.debug("country is :"+itemNode.appendChild(attr));

		return doc;

	}

	// public static boolean prepareTasksXML(ScenarioDTO scenarioDTO,
	// LinkedHashMap milestoneTasksMap) {
	// log.debug("[Enter prepareTasksXML] ");
	// boolean success = false;
	// Element rootElement = null;
	// try {
	//
	// /* Create the task details xml */
	// Document taskDetailsDoc = null;
	//
	// /* Add the root element */
	// taskDetailsDoc = FinanceFA_XMLUtilities.getDocumentInstance();
	// rootElement = taskDetailsDoc.createElement("TaskDetails");
	// taskDetailsDoc.appendChild(rootElement);
	//
	// Iterator iterator = milestoneTasksMap.entrySet().iterator();
	//
	// while (iterator.hasNext()) {
	// Map.Entry entry = (Map.Entry) iterator.next();
	// Integer scenarioMilestoneId = (Integer) entry.getKey();
	//
	// Element milestoneElement = (Element) taskDetailsDoc
	// .createElement("Milestone");
	// milestoneElement.setAttribute("ScenarioMilestoneID",
	// scenarioMilestoneId + "");
	//
	// Element taskElement = null;
	// Object obj = entry.getValue();
	// if (obj instanceof ArrayList) {
	// ArrayList tasksList = (ArrayList) obj;
	//
	// for (int i = 0; i < tasksList.size(); i++) {
	// TaskDTO taskDTO = (TaskDTO) tasksList.get(i);
	// log.debug("each task dto :" + taskDTO);
	//
	// taskElement = (Element) taskDetailsDoc
	// .createElement("Task");
	//						
	// /* Add attribute */
	// taskElement.setAttribute("sid", (i + 1) + "");
	//
	// /* Add Node Id */
	// Element element = (Element) taskDetailsDoc
	// .createElement("Id");
	// element
	// .appendChild(taskDetailsDoc
	// .createTextNode((taskDTO.getTask_id() == null ? ""
	// : taskDTO.getTask_id())
	// + ""));
	// taskElement.appendChild(element);
	//
	// /* Add Node Name */
	// element = (Element) taskDetailsDoc
	// .createElement("Name");
	// element
	// .appendChild(taskDetailsDoc
	// .createCDATASection((taskDTO
	// .getTask_name() == null ? ""
	// : taskDTO.getTask_name())));
	// taskElement.appendChild(element);
	//
	// /* Add Node Order */
	// element = (Element) taskDetailsDoc
	// .createElement("Order");
	// element
	// .appendChild(taskDetailsDoc
	// .createTextNode((taskDTO
	// .getTask_order() == null ? ""
	// : (taskDTO.getTask_order() + ""))));
	// taskElement.appendChild(element);
	//
	// /* Add Node Description */
	// element = (Element) taskDetailsDoc
	// .createElement("Description");
	// element.appendChild(taskDetailsDoc
	// .createCDATASection((taskDTO
	// .getTask_description() == null ? ""
	// : taskDTO.getTask_description())));
	// taskElement.appendChild(element);
	//
	// /* Add Node ScenarioId */
	// element = (Element) taskDetailsDoc
	// .createElement("ScenarioId");
	// element
	// .appendChild(taskDetailsDoc
	// .createTextNode(taskDTO
	// .getScenario_id() == null ? ""
	// : (taskDTO.getScenario_id() + "")));
	// taskElement.appendChild(element);
	//
	// /* Add Node Status */
	// element = (Element) taskDetailsDoc
	// .createElement("Status");
	// element.appendChild(taskDetailsDoc
	// .createCDATASection(""));
	// taskElement.appendChild(element);
	//
	// /* Add Node LastUpdatedDate */
	// element = (Element) taskDetailsDoc
	// .createElement("LastUpdatedDate");
	// element.appendChild(taskDetailsDoc
	// .createCDATASection(""));
	//						
	// /* Add to task element node */
	// taskElement.appendChild(element);
	//
	// /* Add task element node to milestone element node */
	// milestoneElement.appendChild(taskElement);
	// }
	// } else {
	// log.error("Scenario Id value is not an instance of ArrayList");
	// return false;
	// }
	//				
	// /* Add task element node to milestone element node */
	// milestoneElement.appendChild(taskElement);
	//				
	// /* Add milestone element node to root element node*/
	// rootElement.appendChild(milestoneElement);
	// }
	// String taskDetailsXML =
	// FinanceFA_XMLUtilities.convertDOMtoString(taskDetailsDoc);
	// log.debug("Task details XML is [" + taskDetailsXML + "]");
	// scenarioDTO.setTaskDetailsXML(taskDetailsXML);
	// success = true;
	// } catch (Exception ex) {
	// log.error(
	// "Exception occured while preparing the tasks xml for scenario id "
	// + scenarioDTO.getScenario_id(), ex);

	// }
	// return success;
	// }
	private static NodeList fetchNodeListFromXMLDocument(Document doc,
			String keyAttribute) {
		NodeList nodeList = null;

		return nodeList;

	}

	/*
	 * 
	 */
	public static Node fetchRequiredNodeFromXML(Document xmlDoc,
			int nodePointer, String keyAttribute) {
		Node nodeFetched = null;
		Node eachNode = null;

		NodeList eachNodeList = xmlDoc.getChildNodes().item(0).getChildNodes();
		log.debug("Node length=" + eachNodeList.getLength());
		int length = eachNodeList.getLength();
		if (nodePointer > length) {
			log.debug("There is no node at position=" + nodePointer);
			return null;
		}
		for (int i = 0; i < eachNodeList.getLength(); i++) {
			eachNode = eachNodeList.item(i);

			log.debug(eachNode.getNodeName());
			log.info("SID :["
					+ eachNode.getAttributes().getNamedItem(keyAttribute)
							.getNodeValue() + "]");
			String eachNodePointer = eachNode.getAttributes().getNamedItem(
					keyAttribute).getNodeValue();
			if (nodePointer == Integer.parseInt(eachNodePointer)) {
				log.info("notification pointer found");
				nodeFetched = eachNode;
				break;

			} // doc.getChildNodes()

		}

		return nodeFetched;

		// return fetchedNode;
	}

	/*
	 * public static Object getNodeDetailsFromXML(String xmlString, int
	 * nodePointer, Object objBean) {
	 */

	public static void main(String args[]) {

		try {
			MilestoneDTO milestoneDTO = FinanceFA_XMLUtilities
					.getMilestoneDetailsFromXML(
							"<MilestoneDetails><Milestone ScenarioMilestoneID='11'><Name>Input Files Recieved</Name><Type>Normal</Type><Order>1</Order><ID>1</ID><OwnerSSFID>B0000657</OwnerSSFID><OwnerRole>RR Executive - IUC</OwnerRole><RestSLA>0</RestSLA><Offset>60</Offset><ScenarioMilestoneDesc></ScenarioMilestoneDesc></Milestone ><Milestone ScenarioMilestoneID='12'></Milestone></MilestoneDetails>",
							1);
			log.debug(milestoneDTO);
		} catch (Exception e) {
			log.error("error" + e.getMessage(), e);
		}
		if (false) {
			FinanceFA_XMLUtilities.fetchNodeListFromXMLDocument(null, "");
		}
	}

}