package com.bharti.finance.fa.operations.util;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Utilities;


public class FinanceFA_Utilities extends Utilities{

	public static Logger log = Logger.getLogger(FinanceFA_Utilities.class);
	/** 
	 *  This utility method splits the timer name and  
	 *  returns an array of the following details:
	 *  Array[0] = "Notification Category"
	 *  Array[1] = "Notification Type"
	 *  Array[2] = "Scenario MilestoneId"
	 *  Array[3] = "Notification Level"
	 */
	public static String[] splitTimerName(String currentTimerName)
	{
	    log.debug("Timer name : " + currentTimerName);
	    
		String strType = null;
		String strCategory = null;
		String strM = null;
		String strE = null;
		String scanMilestonedelimiter = null;
		// String scansecMilestonedelimiter = null;
		String subStrMilestone = null;
	    String[] returnArray = new String[4];
	    
		for (int i = 0; i < currentTimerName.length(); i++) {
			char charM = currentTimerName.charAt(i);
			strM = String.valueOf(charM);
			if (strM.equals(FinanceFA_Constants.MILESTONE))
				break;
			else if (strM.equals(FinanceFA_Constants.PROCESS)) {
				break;
			}

		}

		if (strM.equals(FinanceFA_Constants.MILESTONE)) {
			strCategory = "Milestone";
			scanMilestonedelimiter = "[M]";
		} else {
			strCategory = "Process";
			scanMilestonedelimiter = "[P]";
		}
		returnArray[0] = strCategory; // Notification Category
		log.debug("strCategory : " + strCategory);

		String[] tokens = currentTimerName.split(scanMilestonedelimiter);
		subStrMilestone = tokens[1];

		for (int i = 0; i < subStrMilestone.length(); i++) {
			char charE = subStrMilestone.charAt(i);
			strE = String.valueOf(charE);
			if (strE.equals(FinanceFA_Constants.ESCALATION))
				break;
			else if (strE.equals(FinanceFA_Constants.REMINDER)) {
				break;
			}
		}
		log.debug("E or R : " + strE);

		if (strE.equals(FinanceFA_Constants.ESCALATION)) {
			strType = "Escalation";
			scanMilestonedelimiter = "[E]";
		} else if (strE.equals(FinanceFA_Constants.REMINDER)) {
			strType = "Reminder";
			scanMilestonedelimiter = "[R]";
		}
		returnArray[1] = strType; // Notification Type
		
		String[] token = subStrMilestone.split(scanMilestonedelimiter);
		returnArray[2] = token[0]; // Scenario MilestoneId
		returnArray[3] = token[1]; // Notification Level
		log.debug("Final Splited Array : "+FinanceFA_Utilities.displayArray(returnArray));
	    return returnArray;
	}

	/**
	 * 
	 * @param date - date ,which has to changed to string form
	 * @return string- string form of input date
	 */
	public static String dateToString(Date date,String dateFormat)
	{
	    String stringDate = null;
	    try {    
    
	 		SimpleDateFormat formatter = new SimpleDateFormat(dateFormat);
	 		stringDate = (String)formatter.format(date); 
	 		log.debug("DateToString(): Converted date is " +stringDate);
	    	}
	    catch (Exception e)
	    {
	        log.error("Exception while converting date, Exception is: "+e);    
	    } 
   		return stringDate;
	}

	/**
	 * Scans the input array and if any element in the array is null then it
	 * replaces it with empty string. This method will be called while returning
	 * any array to workflow from any components to ensure no null pointer
	 * exception is thrown
	 * 
	 * @param returnArray
	 *            array to check
	 * @return array with all its element containing null replaced with empty
	 *         string
	 */
	public static String[] removeNullFromArray(String[] returnArray) {
		if (returnArray != null) {
			int size = returnArray.length;
			for (int i = 0; i < size; i++) {
				if (returnArray[i] == null) {
					returnArray[i] = "";
				}
			}
		}
		return returnArray;
	}

	public static void displayArrayWithIndex(Object[] arr) {
		if (arr != null) {
			log.debug("The array length is "+arr.length);
			for (int i = 0; i < arr.length; i++) {
				log.info("Index [" + i + "] value [" + arr[i] + "]");
			}
		}
	}
}

