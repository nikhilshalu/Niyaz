/*
 * Created on Sep 7, 2009
 * @author Gaurav Jain IBM
 * 
 */
package com.bharti.finance.fa.operations.util.beans;

import java.util.ArrayList;

/**
 * The purpose of this class is to cache the user details
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserDetailsBean {
    
    public String Bp8UserId;
    public String UserSSFId;
    public String UserName;
    public String UserMailId;
    public ArrayList UserRoleName;
    public String ShiftStartTime;
    public String ShiftEndTime;
    public String SupervisorSSFId;
    public String SupervisorName;
    public String SupervisorMailId;
    public String SupervisorRoleName;
    
    
    
    public String toString() {
		StringBuffer buf = new StringBuffer().append(
				"Bp8UserId:[" + getBp8UserId() + "] ").append(
				"UserSSFId:[" + getUserSSFId() + "] ").append(
				"UserName:[" + getUserName() + "] ").append(
				"UserMailId:[" + getUserMailId() + "] ").append(
				"UserRoleName:[" + getUserRoleName() + "] ").append(
				"SupervisorSSFId:[" + getSupervisorSSFId() + "] ").append(
				"SupervisorName:[" + getSupervisorName() + "] ").append(
				"SupervisorMailId:[" + getSupervisorMailId() + "] ").append(
				"SupervisorRoleName:[" + getSupervisorRoleName() + "]");
		return buf.toString();
	}
	/**
     * @return Returns the supervisorMailId.
     */
    public String getSupervisorMailId() {
        return SupervisorMailId;
    }
    /**
     * @param supervisorMailId The supervisorMailId to set.
     */
    public void setSupervisorMailId(String supervisorMailId) {
        SupervisorMailId = supervisorMailId;
    }
    /**
     * @return Returns the supervisorName.
     */
    public String getSupervisorName() {
        return SupervisorName;
    }
    /**
     * @param supervisorName The supervisorName to set.
     */
    public void setSupervisorName(String supervisorName) {
        SupervisorName = supervisorName;
    }
    /**
     * @return Returns the supervisorRoleName.
     */
    public String getSupervisorRoleName() {
        return SupervisorRoleName;
    }
    /**
     * @param supervisorRoleName The supervisorRoleName to set.
     */
    public void setSupervisorRoleName(String supervisorRoleName) {
        SupervisorRoleName = supervisorRoleName;
    }
    /**
     * @return Returns the supervisorSSFId.
     */
    public String getSupervisorSSFId() {
        return SupervisorSSFId;
    }
    /**
     * @param supervisorSSFId The supervisorSSFId to set.
     */
    public void setSupervisorSSFId(String supervisorSSFId) {
        SupervisorSSFId = supervisorSSFId;
    }
    /**
     * @return Returns the userMailId.
     */
    public String getUserMailId() {
        return UserMailId;
    }
    /**
     * @param userMailId The userMailId to set.
     */
    public void setUserMailId(String userMailId) {
        UserMailId = userMailId;
    }
    /**
     * @return Returns the userName.
     */
    public String getUserName() {
        return UserName;
    }
    /**
     * @param userName The userName to set.
     */
    public void setUserName(String userName) {
        UserName = userName;
    }
    /**
     * @return Returns the userRoleName.
     */
    public ArrayList getUserRoleName() {
        return UserRoleName;
    }
    /**
     * @param userRoleName The userRoleName to set.
     */
    public void setUserRoleName(ArrayList userRoleName) {
        UserRoleName = userRoleName;
    }
    /**
     * @return Returns the userSSFId.
     */
    public String getUserSSFId() {
        return UserSSFId;
    }
    /**
     * @param userSSFId The userSSFId to set.
     */
    public void setUserSSFId(String userSSFId) {
        UserSSFId = userSSFId;
    }
    
    
    /**
     * @return Returns the bp8UserId.
     */
    public String getBp8UserId() {
        return Bp8UserId;
    }
    /**
     * @param bp8UserId The bp8UserId to set.
     */
    public void setBp8UserId(String bp8UserId) {
        Bp8UserId = bp8UserId;
    }
    /**
     * @return Returns the shiftEndTime.
     */
    public String getShiftEndTime() {
        return ShiftEndTime;
    }
    /**
     * @param shiftEndTime The shiftEndTime to set.
     */
    public void setShiftEndTime(String shiftEndTime) {
        ShiftEndTime = shiftEndTime;
    }
    /**
     * @return Returns the shiftStartTime.
     */
    public String getShiftStartTime() {
        return ShiftStartTime;
    }
    /**
     * @param shiftStartTime The shiftStartTime to set.
     */
    public void setShiftStartTime(String shiftStartTime) {
        ShiftStartTime = shiftStartTime;
    }
}
