package com.bharti.finance.fa.operations.util.manager;

import com.bharti.fa.common.operations.util.manager.EmailManager;

public class FinanceFA_EmailManager extends EmailManager {

}
