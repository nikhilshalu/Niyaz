/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations.util.manager;

import java.net.MalformedURLException;
import java.util.Hashtable;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.manager.PEManager;
import com.filenet.api.events.Subscription;

import filenet.vw.api.VWException;

/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class FinanceFA_PEManager extends PEManager {
	public static Logger log = Logger.getLogger(FinanceFA_PEManager.class);

	/**
	 * @param application
	 * @param userId
	 * @param password
	 * @param sub
	 * @throws VWException
	 * @throws MalformedURLException
	 * @throws ClassNotFoundException
	 */
	public FinanceFA_PEManager(int application, String userId, String password,
			Subscription sub) throws VWException, MalformedURLException,
			ClassNotFoundException {
		super(application, userId, password, sub);
		
	}

	public void setPEFields(int caseId, Hashtable htFields) throws Exception {
		log.debug("[Enter setPEFields]: caseId [" + caseId + "] ");
		try {
			setVWFieldValue(caseId, htFields);
		} catch (Exception e) {
			log.error("Error in setting fields ", e);
			throw e;
		}
		log.debug("[Exit setPEFields]");
	}

}
