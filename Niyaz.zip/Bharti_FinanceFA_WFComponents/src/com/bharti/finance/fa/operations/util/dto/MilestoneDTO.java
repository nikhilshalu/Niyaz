/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations.util.dto;


/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class MilestoneDTO {
	
	private String name;
	private String type;
	private Integer order = new Integer(-1);
	private Integer id = new Integer(-1);
	private String ownerssfid;
	private String ownerrole;
	private String restsla;
	private String offset;
	private String scenariomilestonedesc;
	private String scenariomilestoneid;
	
	
	/**
	 * @return Returns the id.
	 */
	public Integer getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(Integer id) {
		this.id = id;
	}
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return Returns the offset.
	 */
	public String getOffset() {
		return offset;
	}
	/**
	 * @param offset The offset to set.
	 */
	public void setOffset(String offset) {
		this.offset = offset;
	}
	/**
	 * @return Returns the order.
	 */
	public Integer getOrder() {
		return order;
	}
	/**
	 * @param order The order to set.
	 */
	public void setOrder(Integer order) {
		this.order = order;
	}
	/**
	 * @return Returns the ownerrole.
	 */
	public String getOwnerrole() {
		return ownerrole;
	}
	/**
	 * @param ownerrole The ownerrole to set.
	 */
	public void setOwnerrole(String ownerrole) {
		this.ownerrole = ownerrole;
	}
	/**
	 * @return Returns the ownerssfid.
	 */
	public String getOwnerssfid() {
		return ownerssfid;
	}
	/**
	 * @param ownerssfid The ownerssfid to set.
	 */
	public void setOwnerssfid(String ownerssfid) {
		this.ownerssfid = ownerssfid;
	}
	/**
	 * @return Returns the restsla.
	 */
	public String getRestsla() {
		return restsla;
	}
	/**
	 * @param restsla The restsla to set.
	 */
	public void setRestsla(String restsla) {
		this.restsla = restsla;
	}
	/**
	 * @return Returns the scenariomilestonedesc.
	 */
	public String getScenariomilestonedesc() {
		return scenariomilestonedesc;
	}
	/**
	 * @param scenariomilestonedesc The scenariomilestonedesc to set.
	 */
	public void setScenariomilestonedesc(String scenariomilestonedesc) {
		this.scenariomilestonedesc = scenariomilestonedesc;
	}
	/**
	 * @return Returns the scenariomilestoneid.
	 */
	public String getScenariomilestoneid() {
		return scenariomilestoneid;
	}
	/**
	 * @param scenariomilestoneid The scenariomilestoneid to set.
	 */
	public void setScenariomilestoneid(String scenariomilestoneid) {
		this.scenariomilestoneid = scenariomilestoneid;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("scenario_milestone_id:[" + getScenariomilestoneid() + "] ")
							.append("Name:[" + getName() + "] ")
							.append("Type:[" + getType() + "] ")
							.append("Order:[" + getOrder() + "] ")
							.append("ID:[" + getId() + "] ")
							.append("OwnerSSFID:[" + getOwnerssfid() + "] ")
							.append("OwnerRole:[" + getOwnerrole() + "] ")
							.append("RestSLA:[" + getRestsla() + "] ")
							.append("Offset:[" + getOffset() + "] ")
							.append("ScenarioMilestoneDesc:[" + getScenariomilestonedesc() + "] ")
							 ;
/*		if(notificationList != null) {
			buf.append("\nNotification List: Size:"+notificationList.size()+"\n");
			for(int i=0; i<notificationList.size(); i++) {
				buf.append("\tDTO["+i+"]:" + notificationList.get(i) + "\n");
			}
		}
*/		return buf.toString();
	}
	
	}
