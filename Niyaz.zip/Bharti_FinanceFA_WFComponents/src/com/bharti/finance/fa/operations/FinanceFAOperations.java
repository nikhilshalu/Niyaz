/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.fa.common.operations.util.manager.BPFManager;
import com.bharti.fa.common.operations.util.manager.EscalationManager;
import com.bharti.finance.fa.ci.operations.FinanceFA_CIOperations;
import com.bharti.finance.fa.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.operations.util.FinanceFA_Utilities;
import com.bharti.finance.fa.operations.util.FinanceFA_XMLUtilities;
import com.bharti.finance.fa.operations.util.beans.UserDetailsBean;
import com.bharti.finance.fa.operations.util.dto.MilestoneDTO;
import com.bharti.finance.fa.operations.util.dto.NotificationDTO;
import com.bharti.finance.fa.operations.util.manager.FinanceFA_EmailManager;
import com.bharti.finance.fa.operations.util.manager.FinanceFA_ExternalDBManager;
import com.bharti.finance.fa.operations.util.manager.FinanceFA_PEManager;

import filenet.vw.api.VWAttachment;

/**
 * @author Harisha, Niyaz and Ambika
 *  
 */

public class FinanceFAOperations {

	public static Logger log = Logger.getLogger(FinanceFAOperations.class);

	private static String file_separator;

	/* Contains last Log4j property file reloaded date */
	private static Calendar lastLog4jPropertiesReloadedOn = null;

	/* Contains last custom property file reloaded date */
	private static Calendar lastCustomPropertiesReloadedOn = null;

	/* Contains last xml file reloaded date */
	private static Calendar lastMailModesXMLFileReloadedOn = null;

	private static String filePath = null;

	private static String HOME_PATH = null;

	public static Hashtable ORG_HIERARCHY = null;

	private String outputMessage = null;

	/* Map holds all the mailMode tags of XML file */
	private static HashMap outerMap = null;

	/* Map holds mailMode attributes(like subject,body ) */
	private static HashMap innerMap = null;

	/* This Sets contains the Email To, Cc and Bcc Address */
	private LinkedHashSet toAddressSet = new LinkedHashSet();

	private LinkedHashSet ccAddressSet = new LinkedHashSet();

	private LinkedHashSet bccAddressSet = new LinkedHashSet();

	/**
	 * Contains mail modes for which html special characters should not be
	 * handled by the sendMail component; as it is handled from the BPF
	 */
	private Integer[] mailModesNotToFilterHTMLSpecialCharacters = new Integer[] {
			new Integer(14), new Integer(15), new Integer(16), new Integer(17),
			new Integer(18), new Integer(19) };

	/**
	 * Contains the mail mode of the current request
	 */
	private Integer mode = new Integer(0);

	private BPFManager bpfMgr = null;

	/**
	 *  
	 */
	public FinanceFAOperations() {
		log.debug("[Enter Constructor block]");

		/* Get the classpath and add "config" folder path to it. */
		String class_path = System.getProperty("java.class.path");

		/* Get the path.separator system variable */
		String path_separator = System.getProperty("path.separator");
		file_separator = System.getProperty("file.separator");
		StringTokenizer tokenizer = new StringTokenizer(class_path,
				path_separator);

		String folderName = "fa_config";
		while (tokenizer.hasMoreTokens()) {
			String pathString = tokenizer.nextToken();

			/* Get the path of "fa_config" folder. */
			String eachFolder = pathString.substring((pathString.length())
					- folderName.length(), pathString.length());
			if (eachFolder.equals(folderName)) {
				HOME_PATH = pathString;
				break;
			}
		}
		if (HOME_PATH == null) {
			log.error("[Inside Constructor block]: Unable to find the ["
					+ folderName + "] folder. Please check "
					+ "the Classpath(required libraries)");
		}

		init();

		log.debug("Loading Organization Hierarchy...");
		try {
			loadOrganizationHierarchy();
		} catch (Exception e) {
			log.error(
					"Exception occurred while loading the organization hierarchy."
							+ e.getMessage(), e);
		}
		log.debug("[Exit Constructor block]");
	}

	private void init() {

		/*
		 * Load the Log4j property file only if it is modified since it has been
		 * last loaded. If the variable "lastLog4jPropertiesReloadedOn" is null
		 * or the date present in the variable "lastLog4jPropertiesReloadedOn"
		 * is before the last modified date of the log4j property file then read
		 * the property file; Otherwise don't read it.
		 */
		filePath = HOME_PATH + file_separator + "xml" + file_separator
				+ "CompanyHolidays.xml";

		String propPath = HOME_PATH + file_separator + "properties"
				+ file_separator + "FinanceFA_log4j.properties";

		File fin = new File(propPath);
		Calendar lastModCal = Calendar.getInstance();
		lastModCal.setTimeInMillis(fin.lastModified());

		if (!(lastLog4jPropertiesReloadedOn == null)) {
			log.debug("Log4j property file last loaded on:["
					+ lastLog4jPropertiesReloadedOn.getTime() + "] "
					+ "Log4j property file " + "last modified on:["
					+ lastModCal.getTime() + "]");
		}

		if ((lastLog4jPropertiesReloadedOn == null)
				|| lastLog4jPropertiesReloadedOn.before(lastModCal)) {

			/* Load Log4j property file */
			PropertyLoader.loadLog4jProperties(propPath);

			/* update the variable to last modified date */
			lastLog4jPropertiesReloadedOn = lastModCal;
			log
					.debug("Reloaded the Log4j property file as it has been modified since "
							+ "its last loaded time");
		} else {
			log
					.debug("Log4j property file is not modified since its last reload; "
							+ "hence not reading the file");
		}

		/*
		 * Load the custom property file only if it is modified since it has
		 * been last loaded. If the variable "lastCustomPropertiesReloadedOn" is
		 * null or the date present in the variable
		 * "lastCustomPropertiesReloadedOn" is before the last modified date of
		 * the custom property file then read the property file; Otherwise don't
		 * read it.
		 */
		propPath = HOME_PATH + file_separator + "properties" + file_separator
				+ "FinanceFA_Components.properties";
		fin = new File(propPath);
		lastModCal = Calendar.getInstance();
		lastModCal.setTimeInMillis(fin.lastModified());

		if (!(lastCustomPropertiesReloadedOn == null)) {
			log.debug("Custom property file last loaded on:["
					+ lastCustomPropertiesReloadedOn.getTime() + "] "
					+ "Custom property file " + "last modified on:["
					+ lastModCal.getTime() + "]");
		}

		if ((lastCustomPropertiesReloadedOn == null)
				|| lastCustomPropertiesReloadedOn.before(lastModCal)) {

			/* Load custom property file */
			Properties prop = PropertyLoader.loadPropertiesFromFile(propPath);
			if (prop == null) {
				log.error("Unable to load Custom property file");
			} else {
				/* update the variable to last modified date */
				lastCustomPropertiesReloadedOn = lastModCal;
			}
			log.debug("Reloaded the Custom property file[" + propPath
					+ "] as it "
					+ "has been modified since its last loaded time");
		}
	}

	private boolean loadOrganizationHierarchy() throws Exception {
		log.debug("[Enter loadOrganizationHierarchy]");
		ORG_HIERARCHY = new Hashtable();
		boolean success = false;
		FinanceFA_ExternalDBManager dbManager = new FinanceFA_ExternalDBManager(
				Constants.APPLICATION_STANDALONE);
		Connection dbconn = dbManager.getDbConnection();
		String strQuery = "Select role_name , role_supervisor from FN_FA_TBL_ORGANIZATION_MAPPING";
		log.debug("QUERY of Organisation :: " + strQuery);
		try {
			Statement stmt = dbconn.createStatement();
			ResultSet rs = null;
			rs = stmt.executeQuery(strQuery);
			while (rs.next()) {
				String roleName = ((rs.getString("role_name") != null) ? rs
						.getString("role_name") : "");
				String roleSupervisor = ((rs.getString("role_supervisor") != null) ? rs
						.getString("role_supervisor")
						: "");
				ORG_HIERARCHY.put(roleName, roleSupervisor);
			}
			log.debug("Organisation hashtable :: " + ORG_HIERARCHY.toString());
			success = true;
		} catch (Exception ex) {
			log.error("Database Exception : " + ex.getMessage(), ex);
			success = false;
			throw ex;
		} finally {
			if (dbconn != null)
				dbconn.close();
		}

		log.debug("Exit FinanceOperations : loadOrganizationHierarchy method ");
		return success;
	}

	/**
	 * This method will return array of tagged user and his supervisiors. This
	 * method takes currentuserSSFID and currentUserRole and will return array
	 * whcih contains Roles corresponding to mileStonesUsersSSFID given.
	 * 
	 * @param currentUser,
	 *            the current user tagged
	 * @param currentUserRole
	 *            the current role of the user tagged
	 * @param milestoneRoles
	 * @param mileStonesUsers
	 * @return
	 */
	public String[] updateUserArray_LA(String currentUserSSFID,
			String currentUserRole, String[] milestoneRoles,
			String[] mileStonesUsersSSFID, int currentMilestoneNo, int caseId)
			throws Exception {
		init();
		MDC.put("CASEID", new Integer(caseId));
		log
				.debug("********************[Enter updateUserArray]********************");
		log.debug("currentUserSSFID is : " + currentUserSSFID
				+ " currentUserRole is : " + currentUserRole
				+ " milestoneRoles is : " + milestoneRoles
				+ " mileStonesUsersSSFID is : " + mileStonesUsersSSFID
				+ " currentMilestoneNo is : " + currentMilestoneNo);

		if (currentUserSSFID == null || currentUserSSFID.equals("")
				|| currentUserRole == null || currentUserRole.equals("")) {
			log
					.error("Input parameters (currentUserSSFID/currentUserRole) are blank or null.Kindly check the input parameters in the above log ");
			throw new IllegalArgumentException(
					"Input parameters (currentUserSSFID/currentUserRole) are blank or null.Kindly check the input parameters in the above log ");
		}
		FinanceFA_ExternalDBManager dbManager = new FinanceFA_ExternalDBManager(
				Constants.APPLICATION_STANDALONE);
		dbManager.getDbConnection();
		boolean success = false;
		if (currentUserSSFID != null) {
			try {

				dbManager.updateUserArray(currentUserSSFID, currentUserRole,
						milestoneRoles, mileStonesUsersSSFID,
						currentMilestoneNo);

				if (log.isDebugEnabled()) {
					for (int l = 0; l < milestoneRoles.length; l++) {
						log.debug("Roles Array = " + milestoneRoles[l]);
						log.debug("SSFID Array = " + mileStonesUsersSSFID[l]);
					}
				}
				success = true;
				// Users from DB.
			} catch (Exception sqlEx) {
				log.error("EXCEPTION INSIDE updateUserArray"
						+ sqlEx.getMessage(), sqlEx);
				sqlEx.printStackTrace();
				success = false;
				throw sqlEx;
			} finally {
				dbManager.closeDbConnection();
			}
		}
		log
				.debug("Exit FinanceOperations : updateUserArray method and success is  "
						+ success);
		MDC.remove("CASEID");
		return mileStonesUsersSSFID;
	}

	/**
	 * This method sets the user and his supervisior details to a case. It takes
	 * user SSFID and CaseID as input, retrieves the SSFID,Full Name and Email
	 * Id of user and his Supervisior. Then it sets the PE feilds of that CaseID
	 * 
	 * @param userSSFID
	 * @param Bp8CaseId
	 * @return
	 * @throws Exception
	 */
	public void getUserDetails_LA(String userSSFID, int Bp8CaseId)
			throws Exception {
		init();
		MDC.put("CASEID", "" + Bp8CaseId);
		log
				.debug("********************Entry FinanceOperations : getUserDetails method ********************");

		boolean success = false;
		Hashtable htWFFields = new Hashtable();
		FinanceFA_ExternalDBManager dbManager = new FinanceFA_ExternalDBManager(
				Constants.APPLICATION_STANDALONE);
		dbManager.getDbConnection();
		log.debug("User SSFID : " + userSSFID);
		log.debug("Bp8CaseID : " + Bp8CaseId);

		try {
			if (userSSFID != null) {

				htWFFields = dbManager.getUserDetails(userSSFID);
				// Set values to PE
				FinanceFA_PEManager finPEManager = new FinanceFA_PEManager(
						Constants.APPLICATION_COMPONENT_MANAGER, null, null,
						null);
				finPEManager.setPEFields(Bp8CaseId, htWFFields);
				success = true;
			}

		} catch (Exception ex) {
			log.error("Database Exception : " + ex.getMessage(), ex);
			success = false;
			throw ex;
		} finally {
			dbManager.closeDbConnection();
			log.debug("Execution Status of Query:" + success);
		}

		log.debug("Exit FinanceOperations : getUserDetails method ");
		MDC.remove("CASEID");
	}

	/**
	 * This method gives the pointer of next timer. It checks
	 * isTimerNotificationFiredArray and sets the pointer of first false in the
	 * array. If the corresponding timer from AllTimerDateArray is valid then it
	 * returs that pointer, else it checks for next false. If no valid timer is
	 * found then the method returns -1
	 * 
	 * @param allTimerNameArray -
	 *            Contains array of all timers. This array of the format
	 * 
	 * <pre>
	 * 
	 *  
	 *   
	 *    
	 *     
	 *      
	 *       
	 *        
	 *         
	 *          
	 *           
	 *            
	 *                        {&quot;M1E1&quot;,&quot;M1R1&quot;,&quot;M2E2&quot;,&quot;M2R1&quot;,&quot;PE1&quot;....}
	 *                        Where 
	 *                        M / P = Milestone / Process 
	 *                        1 / 2 = Milestone Scenario ID 
	 *                        E / R = Escalation / Reminder 
	 *                        1 / 2 = Level 1 / Level 2
	 *                        
	 *            
	 *           
	 *          
	 *         
	 *        
	 *       
	 *      
	 *     
	 *    
	 *   
	 *  
	 * </pre>
	 * 
	 * @param currentMilestoneLevel -
	 *            Pointer to milestoneIDArray, which tells the current Milestone
	 * @param milestoneIDArray -
	 *            Array of Milestone Secnario ID
	 * @param isTimerNotificationFiredArray -
	 *            Contains array of all timers whcih have been fired and mails
	 *            are sent or not.
	 * @return
	 */
	public int getNextQualifyingTimer_LA(String[] allTimerNameArray,
			int currentMilestoneLevel, int[] milestoneIDArray,
			boolean[] isTimerNotificationFiredArray, int caseId) {
		init();
		MDC.put("CASEID", new Integer(caseId));
		log
				.debug("********************[Enter getNextQualifyingTimer]********************");

		int arrayPointer = -1;
		boolean isValidTimer = false;

		log.debug("current milestone level : " + currentMilestoneLevel);
		if (log.isDebugEnabled()) {
			for (int i = 0; i < allTimerNameArray.length; i++)
				log.debug("All timer name array : " + allTimerNameArray[i]);
			for (int i = 0; i < milestoneIDArray.length; i++)
				log.debug("Scenario mailestone array : " + milestoneIDArray[i]);
			for (int i = 0; i < isTimerNotificationFiredArray.length; i++)
				log.debug("Timer Fired : " + isTimerNotificationFiredArray[i]);
		}

		for (int i = 0; i < isTimerNotificationFiredArray.length; i++) {
			log.debug("Notification Fired Array at pointer :: " + (i + 1)
					+ " is : " + isTimerNotificationFiredArray[i]);
			if (isTimerNotificationFiredArray[i] == false) {
				arrayPointer = i + 1;
				log.debug("ArrayPointer is at " + arrayPointer);
				isValidTimer = isTimerValid(currentMilestoneLevel,
						milestoneIDArray, arrayPointer, allTimerNameArray);
				log.debug("Is valid for pointer " + (i + 1) + " is : "
						+ isValidTimer);
				if (isValidTimer) {
					log
							.debug("Exit FinanceOperations : getNextQualifyingTimer method as "
									+ isValidTimer
									+ " and pointer is "
									+ arrayPointer);
					break;
				} else {
					log.debug("valid timer is  " + isValidTimer
							+ " and pointer is " + arrayPointer);
					arrayPointer = -1;
				}
			}
		}

		log.debug("Exit FinanceOperations : getNextQualifyingTimer method as "
				+ isValidTimer + " and pointer is " + arrayPointer);
		MDC.remove("CASEID");
		return arrayPointer;
	}

	/**
	 * Retrieves the next timer to be launched in workflow.
	 * 
	 * <pre>
	 * 
	 *  If the notification xml is of Process(the root element attribute is &quot;Process&quot;) then 
	 *  	Increment the timerPointer
	 *  	Get the notification node at position timerPointer, 
	 *  	If exists then 
	 *  		read the offset and calculate timer date with respect to 
	 * <code>
	 * relativeDate
	 * </code>
	 * 
	 *  	Else
	 *  		return no timer
	 *  Else if the notification xml is of Milestone(the root element attribute is &quot;Milestone&quot;) then 
	 *  	Get the node whose scenario milestone id = 
	 * <code>
	 * currentScenarioMilestoneId
	 * </code>
	 * 
	 *  	For all child nodes 
	 *  		If isTimerFired=false
	 *  			pointer=pointer+1
	 *  			and calculate timer date with respect to 
	 * <code>
	 * relativeDate
	 * </code>
	 * 
	 *  			found=true
	 *  		
	 *  	If found=false
	 *  		return no timer
	 * 	
	 * </pre>
	 * 
	 * @param notificationTimerXML
	 *            notification xml
	 * @param timerPointer
	 *            for process notification xml it contains the current
	 *            notification level of running timer for milestone notification
	 *            xml it will be -1
	 * @param currentScenarioMilestoneId
	 *            for milestone notification xml it contains the current
	 *            milestone's scenario milestone id for process notification xml
	 *            it will be -1
	 * @param relativeDate
	 *            either milestone sla date or process sla date
	 * @param slaTypeId
	 * @param slaCalculationId
	 * @param officeStartTime
	 * @param officeEndTime
	 * @param caseId
	 * @return
	 * @throws Exception
	 */
	public String[] getNextQualifyingTimer_LR(String notificationTimerXML,
			int timerPointer, int currentScenarioMilestoneId,
			Date relativeDate, int slaTypeId, int slaCalculationId,
			String officeStartTime, String officeEndTime, int caseId)
			throws Exception {

		/* Initialize the log4j system and read custom property file */
		init();

		/* Insert MDC */
		MDC.put("CASEID", new Integer(caseId));
		if (log.isDebugEnabled()) {
			log
					.debug("********************[Enter getNextQualifyingTimer_LR]: timerPointer: ["
							+ timerPointer
							+ "] currentScenarioMilestoneId: ["
							+ currentScenarioMilestoneId
							+ "] relativeDate: ["
							+ relativeDate
							+ "] slaTypeId: ["
							+ slaTypeId
							+ "] slaCalculationId: ["
							+ slaCalculationId
							+ "] "
							+ "officeStartTime: ["
							+ officeStartTime
							+ "] officeEndTime: ["
							+ officeEndTime
							+ "] "
							+ "caseId: ["
							+ caseId
							+ "] "
							+ "notificationTimerXML: ["
							+ notificationTimerXML
							+ "] ********************");
		}

		String[] returnArray = new String[3];
		Utilities.initializeEmptyArray(returnArray);
		String message;
		try {

			/* Prepare the XML DOM object from the xml string */
			Document notificationDoc = FinanceFA_XMLUtilities
					.getDocumentInstance(notificationTimerXML);
			if (notificationDoc == null) {
				message = "Error occurred while parsing the xml string.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}

			/* Get the root element */
			Element rootElement = FinanceFA_XMLUtilities
					.getRootElement(notificationDoc);
			log.debug("Root element " + rootElement.getNodeName());

			/* Get the Category attribute of root element */
			String category = rootElement.getAttribute("Category");
			log.debug("Root element: Category value " + category);

			NotificationDTO notificationDTO = null;
			boolean found = false;

			/*
			 * If Category attribute is Process then check the next qualifying
			 * process timer. Increment the timer_pointer, get the next
			 * notification node from the xml. If no node exists at position
			 * timer_pointer, then it returns: returnArray[0] = "false"
			 * returnArray[1] = "" returnArray[2] = ""
			 */
			if (category.equalsIgnoreCase(FinanceFA_Constants.STRPROCESS)) {
				log.debug("Request is for Process Timer");
				timerPointer = timerPointer + 1;
				notificationDTO = FinanceFA_XMLUtilities
						.fetchRequiredNodeFromXML(rootElement, timerPointer,
								FinanceFA_Constants.STR_NOTIFICATION, "SID");
				if (notificationDTO == null) {
					found = false;
				} else {
					found = true;
				}

			} else if (category
					.equalsIgnoreCase(FinanceFA_Constants.STRMILESTONE)) {

				/*
				 * If Category attribute is Milestone then check the next
				 * qualifying milestone timer
				 */
				log.debug("Request is for Milestone Timer");
				log
						.debug("Searching the milestone node whose scenario milestone id is ["
								+ currentScenarioMilestoneId + "]");
				Node milestoneNode = FinanceFA_XMLUtilities
						.fetchRequiredNode(
								rootElement
										.getElementsByTagName(FinanceFA_Constants.STRMILESTONE),
								FinanceFA_Constants.STR_SCENARIO_MILESTONE_ID,
								currentScenarioMilestoneId + "");

				if (milestoneNode == null) {
					message = "The Milestone node with scenario milestone id[ "
							+ currentScenarioMilestoneId
							+ "] does not found in the notification xml ,please check the input XML .";
					log.error(message);
					throw new IllegalArgumentException(message);

				} else {

					/* Milestone node found with the scenario milestone id */
					Element milestoneElement = (Element) milestoneNode;
					NodeList notificationList = milestoneElement
							.getElementsByTagName(FinanceFA_Constants.STR_NOTIFICATION);

					int notificationLength = notificationList.getLength();

					log
							.debug("Searching the first notification node whose timer is not expired");
					for (int i = 0; i < notificationLength; i++) {
						Element eachNotification = (Element) notificationList
								.item(i);
						/*
						 * String eachExpiration = eachNotification
						 * .getElementsByTagName(
						 * FinanceFA_Constants.STR_IS_TIMER_EXPIRED)
						 * .item(0).getTextContent();
						 */
						Node isTimerExpired = eachNotification
								.getElementsByTagName(
										FinanceFA_Constants.STR_IS_TIMER_EXPIRED)
								.item(0);
						String eachExpiration = FinanceFA_XMLUtilities
								.getNodeValue(isTimerExpired);

						log.debug("Node [" + (i + 1) + "] Timer expiration ["
								+ eachExpiration + "]");
						if (eachExpiration.equalsIgnoreCase("false")) {
							timerPointer = i + 1;
							log
									.info("The first notification node whose timer not expired found at position ["
											+ timerPointer + "]");
							notificationDTO = new NotificationDTO();
							FinanceFA_XMLUtilities.populateNodeListInBean(
									eachNotification.getChildNodes(),
									notificationDTO);
							log.debug("Notification details is ["
									+ notificationDTO + "]");
							found = true;
							break;
						}
					}
				}
			} else {
				message = "The notification xml is not well formed. The category attribute of root element is neither Process nor Milestone";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			if (found) {

				/* If a valid timer exists */
				if (FinanceFA_Constants.STRING_SLA.equalsIgnoreCase(notificationDTO.getType())) {
					log
							.info("The next qualifying timer is the milestone SLA; hence we are not calculating the milestone sla date once again instead returning the input parameter relative date(which is the milestone sla date) value ["
									+ relativeDate + "]");
					returnArray[1] = FinanceFA_Utilities
							.dateToString(relativeDate);
				} else {
					log.debug("The next qualifying timer is not milestone SLA");
					String timerOffset = notificationDTO.getOffset() + "";
					Date[] timedate = calculateSLA(timerOffset, relativeDate,
							slaTypeId, slaCalculationId, officeStartTime,
							officeEndTime, caseId);
					returnArray[1] = FinanceFA_Utilities
							.dateToString(timedate[0]);
				}
				returnArray[0] = "true";
				returnArray[2] = timerPointer + "";
			} else {

				/* No timer exists */
				log.info("No more notification exists to start.");
				returnArray[0] = "false";
			}

		} catch (Exception ex) {
			log.error("Error occured while getting the Next Qualifying timer ",
					ex);
			throw ex;
		}
		
		/* Remove null from array */
		log.debug("Removing null value from return array");
		FinanceFA_Utilities.removeNullFromArray(returnArray);
		log.debug("The output array is :");
		FinanceFA_Utilities.displayArrayWithIndex(returnArray);
		log.debug("[Exit getNextQualifyingTimer_LR]");
		return returnArray;
	}

	/**
	 * This method is called from getNextQualifyingTimer. This method checks
	 * whether a particular timer is valid or not.
	 * 
	 * @param currentMilestoneLevel
	 * @param milestoneIDArray
	 * @param currentTimerLevel
	 * @param allTimerNameArray
	 * @return
	 */
	public boolean isTimerValid(int currentMilestoneLevel,
			int[] milestoneIDArray, int currentTimerLevel,
			String[] allTimerNameArray) {
		log.debug("[Entry isTimerValid]");

		boolean isValid = false;
		String strmilestoneTimerID = null;
		String strmilestoneTimerLevel = null;
		String strType = null;
		String strCategory = null;
		String strM = null;
		String strE = null;
		String scanMilestonedelimiter = null;
		// String scansecMilestonedelimiter = null;
		String subStrMilestone = null;
		int currentMilestoneTimerPointer = -1;
		// int currrentMilestoneID = milestoneIDArray[currentMilestoneLevel -
		// 1];
		String currentTimerName = allTimerNameArray[currentTimerLevel - 1];
		log.debug("Timer name : " + currentTimerName);

		for (int i = 0; i < currentTimerName.length(); i++) {
			char charM = currentTimerName.charAt(i);
			strM = String.valueOf(charM);
			if (strM.equals(Constants.MILESTONE))
				break;
			else if (strM.equals(Constants.PROCESS)) {
				break;
			}

		}

		if (strM.equals(Constants.MILESTONE)) {
			strCategory = "Milestone";
			scanMilestonedelimiter = "[M]";
		} else {
			strCategory = "Process";
			scanMilestonedelimiter = "[P]";
		}
		log.debug("M or P : " + strM);
		log.debug("strCategory : " + strCategory);

		int[] limits1 = { 0 };
		for (int limit1 = 0; limit1 < limits1.length; limit1++) {
			String[] tokens = currentTimerName.split(scanMilestonedelimiter,
					limit1);
			String[] token = tokens;
			for (int i = 0; i < token.length; i++) {
				subStrMilestone = token[1];
			}
		}

		for (int i = 0; i < subStrMilestone.length(); i++) {
			char charE = subStrMilestone.charAt(i);
			strE = String.valueOf(charE);
			if (strE.equals(Constants.ESCALATION))
				break;
			else if (strE.equals(Constants.REMINDER)) {
				break;
			}

		}
		log.debug("E or R : " + strE);

		if (strE.equals(Constants.ESCALATION)) {
			strType = "Escalation";
			scanMilestonedelimiter = "[E]";
		} else if (strE.equals(Constants.REMINDER)) {
			strType = "Reminder";
			scanMilestonedelimiter = "[R]";
		}
		log.debug("strType : " + strType);
		log.debug("Delimiter E or R  : " + scanMilestonedelimiter);
		int[] limits = { 0 };
		for (int limit11 = 0; limit11 < limits.length; limit11++) {
			String[] tokens = subStrMilestone.split(scanMilestonedelimiter,
					limit11);

			String[] token = tokens;
			if (strCategory.equalsIgnoreCase("Milestone")) {
				strmilestoneTimerID = token[0];
				strmilestoneTimerLevel = token[1];
			} else if (strCategory.equalsIgnoreCase("Process")) {
				strmilestoneTimerLevel = token[1];
			}
			log.debug("strmilestoneTimerID  : " + strmilestoneTimerID);
			log.debug("strmilestoneTimerLevel  : " + strmilestoneTimerLevel);
		}

		if (strCategory.equalsIgnoreCase("Process")) {
			log.debug("Returning true");
			isValid = true;
		} else {
			// Check whether strmilestoneTimerID is present in milestoneIDArray
			for (int k = currentMilestoneLevel - 1; k < milestoneIDArray.length; k++) {
				if (milestoneIDArray[k] == (Integer
						.parseInt(strmilestoneTimerID))) {
					currentMilestoneTimerPointer = k + 1;
					log.debug("Milestone ID is present and located at :: "
							+ currentMilestoneTimerPointer);
				}

			}

			// If Present then set the related fields in PE
			if (currentMilestoneTimerPointer != -1) {
				log.debug("Returning true");
				isValid = true;
			}
		}
		log.debug("[Exit isTimerValid]");
		return isValid;
	}

	/**
	 * Sends an Email to given <code>mailTo</code>,<code>mailCC</code> and
	 * <code>mailBcc</code> recepients based on the <code>mailMode</code>.
	 * <p>
	 * It reads the subject line of the mail and html template name from the
	 * MailModes.xml based on the mail mode. It replaces all the macros present
	 * in the subject line and html file with its corresponding values. It also
	 * attaches file(s) to the mail if necessary. It calls the generic sendEmail
	 * method to send the email.
	 * 
	 * @param mailMode
	 *            indicates the type of the mail to be send. <blockquote>
	 * 
	 * <pre>
	 * 
	 *  
	 *   
	 *    
	 *     
	 *      
	 *                    Mail Mode 1: Process L1 Escalation Mail (Auto)
	 *                    Mail Mode 2: Process L2 Escalation Mail (Auto)
	 *                    Mail Mode 3: Process Reminder Mail (Auto)
	 *                    Mail Mode 4: Milestone L1 Escalation Mail (Auto)
	 *                    Mail Mode 5: Milestone L2 Escalation Mail (Auto)
	 *                    Mail Mode 6: Milestone Reminder Mail (Auto)
	 *                    Mail Mode 7: Query Response L1 Escalation Mail (Auto)
	 *                    Mail Mode 8: Query Response L2 Escalation Mail (Auto)
	 *                    Mail Mode 9: Query Response Reminder Mail (Auto)
	 *                    Mail Mode 10: Query Closure L1 Escalation Mail (Auto)
	 *                    Mail Mode 11: Query Closure L2 Escalation Mail (Auto)
	 *                    Mail Mode 12: Query Closure Reminder Mail (Auto)
	 *                    Mail Mode 13: Malfunction Exception mail (Auto)
	 *                    Mail Mode 14: Process Seek Clarification Mail (Manual)
	 *                    Mail Mode 15: Process Escalate Mail (Manual)
	 *                    Mail Mode 16: Process Notification Mail (Manual)
	 *                    Mail Mode 17: Query Seek Clarification Mail(Manual)
	 *                    Mail Mode 18: Query Escalate Mail (Manual)
	 *                    Mail Mode 19: Query Notification Mail (Manual)
	 *                    Mail Mode 20: Query Send To ExternalSME Mail (Manual)
	 *       
	 *      
	 *     
	 *    
	 *   
	 *  
	 * </pre>
	 * 
	 * </blockquote>
	 * 
	 * @param mailTo
	 *            mail to address list seperated by comma
	 * @param mailCC
	 *            mail cc address list seperated by comma
	 * @param mailBcc
	 *            mail bcc address list seperated by comma
	 * @param mailFields
	 *            each mail field will be sent in the form of {"MAILFIELDNAME",
	 *            FIELDVALUE} in a single array.
	 */
	public String[] sendMail(int mailMode, String mailTo, String mailCC,
			String mailBcc, String mailFields[]) {

		init();

		// Remove the previous MDC value
		MDC.remove("CASEID");
		log.debug("********************[Enter sendMail]: mailMode: ["
				+ mailMode + "] mailTo: [" + mailTo + "] mailCC: [" + mailCC
				+ "] mailBcc: [" + mailBcc + "] mailFields: ["
				+ Utilities.displayArray(mailFields) + "]********************");

		// Initializing the data struture
		mode = new Integer(mailMode);
		toAddressSet = new LinkedHashSet();
		ccAddressSet = new LinkedHashSet();
		bccAddressSet = new LinkedHashSet();

		String[] strTo = null;
		String[] strCC = null;
		String[] strBCC = null;

		boolean isMailAllowed = false;

		try {

			/* Get the case id */
			int caseId = 0;
			String idStr = getMacroValue(mailFields, "BP8CASE_ID");
			if (idStr != null) {
				try {
					caseId = Integer.parseInt(idStr);
				} catch (NumberFormatException e) {
					log.error("Unable to parse the case id string [" + idStr
							+ "] to integer");
				}
			}
			MDC.put("CASEID", new Integer(caseId));

			isMailAllowed = isMailAllowed(mailMode);
			log.debug("The status of isMailAllowed flag is " + isMailAllowed);
			log.info("The mail mode [" + mailMode + "] is "
					+ (isMailAllowed ? "allowed" : "not allowed"));
			if (isMailAllowed) {
				if (mailMode == 13) {

					/*
					 * If the mail request is for workflow exception then check
					 * the SEND_WORKFLOW_EXCEPTION_MAIL flag; if it is false
					 * then do not send a mail otherwise read the recepient
					 * address from the property file and send mail
					 */
					log.debug("It is an workflow exception mailmode ["
							+ mailMode + "]");

					/* Check the flag */
					String sendWorkflowException = PropertyLoader.props
							.getProperty("SEND_WORKFLOW_EXCEPTION_MAIL");
					if (!(sendWorkflowException.equalsIgnoreCase("TRUE"))) {
						outputMessage = "Email not sent, as the SEND_WORKFLOW_EXCEPTION_MAIL parameter in property file ["
								+ sendWorkflowException
								+ "] is not set to true.";
						log.info(outputMessage);
						log.debug("[Exit sendMail]");
						MDC.remove("CASEID");
						return new String[] { outputMessage };
					}

					/* Read the recepients address */
					log
							.debug("SEND_WORKFLOW_EXCEPTION_MAIL flag is set to true");
					log.debug("Reading the recepients list from property file");
					mailTo = PropertyLoader.props
							.getProperty("mail.workflow.exception.to");
					log
							.debug("The value of [mail.workflow.exception.to] from the properties file is ["
									+ mailTo + "]");
					mailCC = PropertyLoader.props
							.getProperty("mail.workflow.exception.cc");
					log
							.debug("The value of [mail.workflow.exception.cc] from the properties file is ["
									+ mailCC + "]");
				}

				/* Validate each email address */
				if (mailTo != null && !mailTo.equals("")) {
					checkValidityThenAdd(mailTo, toAddressSet, false);
				}
				if (mailCC != null && !mailCC.equals("")) {
					checkValidityThenAdd(mailCC, ccAddressSet, false);
				}
				if (mailBcc != null && !mailBcc.equals("")) {
					checkValidityThenAdd(mailBcc, bccAddressSet, false);
				}

				/*
				 * If no valid addresses are specified then log and return
				 */
				if (toAddressSet.size() == 0 && ccAddressSet.size() == 0
						&& bccAddressSet.size() == 0) {
					outputMessage = "Unable to send mail. No valid receipients specified; as Email To, CC and BCC addresses list are empty.";
					log.info(outputMessage);
					log.debug("[Exit sendMail]");
					MDC.remove("CASEID");
					return new String[] { outputMessage };
				}

				// Read the xml file
				try {
					readMailModesXMLFile();
				} catch (Exception e1) {
					outputMessage = "Unable to read the MailModes.xml file."
							+ e1.getMessage();
					log.error(outputMessage, e1);
					log.debug("[Exit sendMail]");
					MDC.remove("CASEID");
					return new String[] { outputMessage };
				}

				/*
				 * Read the html mail template file name of the corresponding
				 * mailMode and subject line
				 */
				String template = "";
				StringBuffer subject = null;
				String result = "";

				if (!outerMap.containsKey(new Integer(mailMode))) {
					outputMessage = "Invalid mailMode["
							+ mailMode
							+ "] specified. Input mail mode is not configured in the MailModes.xml. Please specify mail mode in the range of 1-"
							+ outerMap.size();
					log.error(outputMessage);
					log.debug("[Exit sendMail]");
					MDC.remove("CASEID");
					return new String[] { outputMessage };
				}
				innerMap = (HashMap) outerMap.get(new Integer(mailMode));
				subject = new StringBuffer(innerMap.get("subject").toString());
				template = innerMap.get("template").toString();

				/* Filter the Email subject line */
				subject = filterMessage(subject, mailFields);

				/* Read the content of the html file */
				StringBuffer msgBody = new StringBuffer();
				try {
					BufferedReader reader = new BufferedReader(new FileReader(
							HOME_PATH + file_separator + "msg" + file_separator
									+ template));
					while ((result = reader.readLine()) != null) {
						msgBody.append(result);
					}
					reader.close();
					result = "";
				} catch (IOException e) {
					log.error("Error occured while reading the [" + template
							+ "] html file in directory [" + HOME_PATH
							+ file_separator + "msg" + "]. " + e.getMessage(),
							e);
				}

				/* Filter the Email message body */
				msgBody = filterMessage(msgBody, mailFields);

				/* Read the mail parameters from the property file */
				String from = PropertyLoader.props.getProperty("mail.from");

				strTo = new String[toAddressSet.size()];
				toAddressSet.toArray(strTo);
				strCC = new String[ccAddressSet.size()];
				ccAddressSet.toArray(strCC);
				strBCC = new String[bccAddressSet.size()];
				bccAddressSet.toArray(strBCC);

				BodyPart messageBodyPart = new MimeBodyPart();
				messageBodyPart.setContent(msgBody.toString(), "text/html");
				Multipart multipart = new MimeMultipart();
				multipart.addBodyPart(messageBodyPart);

				Map fileNameMap = attachDocument(multipart, mailMode, caseId);
				FinanceFA_EmailManager emailMgr = new FinanceFA_EmailManager();

				log.debug("Sending email...");

				emailMgr.sendEmail(PropertyLoader.props, from, strTo, strCC,
						strBCC, subject.toString(), multipart);

				/*
				 * Check wether fileNameMap is null and the size is zero. If
				 * fileNameMap is not null and the size is not zero, some files
				 * are present in the temp directory. Then deletes the files
				 * from temp directory.
				 */

				if (fileNameMap != null && fileNameMap.size() != 0) {
					Set setList = fileNameMap.keySet();
					String[] attachFileNames = new String[setList.size()];
					setList.toArray(attachFileNames);
					int deletedFileCount = deleteTempFiles(attachFileNames);
					log.info(deletedFileCount
							+ " temporary  files are deleted.");
				}
			} else {
				outputMessage = "Mail mode ["
						+ mailMode
						+ "] not allowed to send mail in property file. Mail not sent";
				log.debug(outputMessage);
			}
		} catch (MessagingException mex) {
			outputMessage = "Error occured while sending mail."
					+ mex.getMessage();
			log.error(outputMessage, mex);
		} catch (Exception e) {
			outputMessage = "Error occured while sending mail."
					+ e.getMessage();
			log.error(outputMessage, e);
		} catch (Throwable t) {
			outputMessage = "Throwable Error occured while sending mail."
					+ t.getMessage();
			log.error(outputMessage, t);
		}
		if (outputMessage == null) {
			outputMessage = "Mail successfully sent to To:["
					+ Utilities.displayArray(strTo) + "] Cc:["
					+ Utilities.displayArray(strCC) + "] Bcc:["
					+ Utilities.displayArray(strBCC) + "].";
		}
		log.debug("[Exit sendMail]");
		MDC.remove("CASEID");
		return new String[] { outputMessage };
	}

	/**
	 * @param mailMode
	 * @return
	 */
	private boolean isMailAllowed(int mailMode) {

		boolean isAllowed = false;
		String mailModes = PropertyLoader.props
				.getProperty("ALLOWED_MAIL_MODE");
		log
				.debug("The value of ALLOWED_MAIL_MODE from the properties file is ["
						+ mailModes + "]");

		String[] tokens = mailModes.split(",");
		for (int i = 0; i < tokens.length; i++) {
			if (Integer.parseInt(tokens[i]) == mailMode) {
				isAllowed = true;
			}
		}
		log.debug("Status of execution ["+isAllowed+"]");
		return isAllowed;
	}

	/**
	 * This method deletes all temporary files used while sending mail to
	 * employee
	 * 
	 * @param fileNames
	 *            contains names of temporary Files to be deleted
	 * @return the number of files successfully deleted
	 */
	private int deleteTempFiles(String[] fileNames) {

		/*
		 * This will contain the parent directory path in which to store
		 * temporary files
		 */
		String parentDir = System.getProperty("java.io.tmpdir");

		/* Get the number of files to be deleted */
		int numberOfFiles = fileNames.length;
		int deletedFileCount = 0;
		for (int i = 0; i < numberOfFiles; i++) {
			try {
				File delFile = new File(parentDir + file_separator
						+ fileNames[i]);
				boolean isdeleted = delFile.delete();
				if (isdeleted == false) {
					log.info("Unable to delete temporary file " + fileNames[i]
							+ ".");
				} else {
					deletedFileCount++;
				}
			} catch (SecurityException se) {
				log.error("Exception occured while deleting temporay "
						+ "files." + se.getMessage(), se);
			}
		}
		log
				.info(deletedFileCount
						+ " temporary files are deleted successfully");
		return deletedFileCount;
	}

	/**
	 * Validates all the given mail ids in the <code>mailAddress</code>. If
	 * it is valid then adds to addressSet otherwise not. It does not allow to
	 * add duplicate values to the list.
	 * 
	 * @param mailAddress
	 * @param addressSet
	 * @param checkDomainFlag
	 */
	private void checkValidityThenAdd(String[] mailAddress,
			LinkedHashSet addressSet, boolean checkDomainFlag) {
		log.debug("[Enter checkValidityThenAdd]");
		if (mailAddress != null) {
			for (int i = 0; i < mailAddress.length; i++) {
				checkValidityThenAdd(mailAddress[i], addressSet,
						checkDomainFlag);
			}
		}
		log.debug("[Exit checkValidityThenAdd]");
	}

	/**
	 * Validates the given mail id. If it is valid then adds to addressSet
	 * otherwise does not adds. It does not allow to add duplicate values to the
	 * list.
	 * 
	 * @param mailId
	 *            mailId to be validated
	 * @param addressSet
	 *            address list to which mailId should be added
	 * @param checkDomainFlag
	 *            if true, then <code>mailId</code> will be verified for valid
	 *            domains listed in properties file
	 */
	private void checkValidityThenAdd(String mailId, LinkedHashSet addressSet,
			boolean checkDomainFlag) {

		log.debug("[Enter checkValidityThenAdd]");
		boolean isInserted;
		log.debug("For " + mailId + ": Verifying the Email Id.");

		/* Check whether Email To-address is empty */
		if (mailId == null) {
			log.error("For " + mailId + ": Email Id is null; hence not "
					+ "added to sending address list.");
			log.debug("[Exit checkValidityThenAdd]");
			return;
		}

		/* Check whether Email To-address is empty */
		if (mailId.equals("")) {
			log.error("For " + mailId + ": Email Id is empty; hence not "
					+ "added to sending address list.");
			log.debug("[Exit checkValidityThenAdd]");
			return;
		}

		// change for multiple address seperated by ","
		String singleID;

		StringTokenizer mailIdSeperator = new StringTokenizer(mailId, ",");
		while (mailIdSeperator.hasMoreTokens()) {
			singleID = mailIdSeperator.nextToken();
			if (singleID.indexOf("@") == -1) {
				log
						.error("For "
								+ singleID
								+ ": Email Id["
								+ singleID
								+ "] is invalid. "
								+ "It should be of the format abc@airtel.in; hence not added to sending address list.");
				continue;
			}

			/* Check the domain only if checkDomainFlag is true */
			if (checkDomainFlag) {
				boolean flag = checkDomain(singleID);
				if (flag == false) {
					log
							.error("For "
									+ singleID
									+ ": Email Id["
									+ singleID
									+ "] is invalid. "
									+ "Domain name is not allowed; hence not added to sending address list.");
					continue;
				}
			}

			isInserted = addressSet.add(singleID);
			if (isInserted) {
				log.debug("For " + singleID
						+ ": Added to sending address list.");
			} else {
				log.debug("For " + singleID
						+ ": Email Id is ignored as same id is "
						+ "already present in sending address list.");
			}
		}
	}

	/**
	 * Verifies whether the given mail id's domain is valid to send mail or not.
	 * 
	 * @param singleID
	 *            mail id to check
	 * @return true, if mail id's domain is valid otherwise false
	 */
	private boolean checkDomain(String singleID) {
		log.debug("Checking the domain name of email id " + singleID);

		String domain;
		String mail_to_domain_name = singleID.substring(
				(singleID.indexOf("@") + 1), singleID.length());
		String domainNames = PropertyLoader.props.getProperty("mail.domains");
		StringTokenizer st = new StringTokenizer(domainNames, "|");
		boolean flag = false;
		while (st.hasMoreTokens()) {
			domain = st.nextToken();
			if (domain.equalsIgnoreCase(mail_to_domain_name)) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	private Map attachDocument(Multipart multipart, int mailMode, int caseId) {

		return null;
	}

	/**
	 * Returns the value of the macro <code>macroName</code> in the mailFields
	 * array
	 * 
	 * @param mailFields
	 *            each mail field will be sent in the form of {"MAILFIELDNAME",
	 *            FIELDVALUE} in a single array.
	 * @param macroName
	 *            name of the macro whose value to be returned
	 * @return value of the macro or null if not found one in the mailFields
	 *         array
	 */
	private String getMacroValue(String[] mailFields, String macroName) {

		/* Get the value of the macro from the input mail fields */
		String macroValue = null;
		if (mailFields == null) {
			log
					.info("Unable to find value of macro "
							+ macroName
							+ ".Input parameter mailFields array is null. It should be of the format "
							+ "{MACRO_NAME, MACRO_VALUE, ...}");
			return null;
		}
		try {
			for (int i = 0; i < mailFields.length; i++) {
				String key = mailFields[i];
				String value = mailFields[++i];
				if (key.equalsIgnoreCase(macroName)) {
					macroValue = value;
					break;
				}
			}
		} catch (ArrayIndexOutOfBoundsException e) {
			log
					.error(
							"Input parameter mailFields array ["
									+ Utilities.displayArray(mailFields)
									+ "] does not contain sufficient parameters. It should be of the format "
									+ "{MACRO_NAME, MACRO_VALUE, ...}"
									+ e.getMessage(), e);
		} catch (Exception e) {
			log.error(
					"Exception occurred parsing the mailFields array. Unable to "
							+ "get the group name" + e.getMessage(), e);
		}
		log.debug("The Macro name " + macroName + " Value is [" + macroValue
				+ "]");
		return macroValue;
	}

	/**
	 * Filters the given text by replacing all the macros present in it.
	 * 
	 * @param msgBuf
	 *            text to be filtered
	 * @param mailFields
	 *            each mail field will be sent in the form of {"MAILFIELDNAME",
	 *            FIELDVALUE} in a single array.
	 * @return filtered message body
	 */
	private StringBuffer filterMessage(StringBuffer msgBuf, String[] mailFields) {
		log.debug("[Enter filterMessageBody]");
		log.debug("Filtering Macros from message body.");

		/*
		 * Replace all the MACROs present in the text field with its
		 * corresponding value
		 */

		/* Parse the mailFields array and replace the macro field with its value */
		if (mailFields == null) {
			log.info("Mail fields array is null.");
		} else {
			try {
				/*
				 * Check whether html special characters should be handled for
				 * this mail mode request
				 */
				List modeList = Arrays
						.asList(mailModesNotToFilterHTMLSpecialCharacters);
				boolean filterHTMLSpecialCharFlag = !(modeList.contains(mode));
				log.debug("HTML special characters should "
						+ (filterHTMLSpecialCharFlag ? "" : "not ")
						+ "be handled.");

				for (int i = 0; i < mailFields.length; i++) {
					String macroKey = mailFields[i];
					String macroValue = mailFields[++i];

					/* If the Employee Name is not provided then use "Sir/Madam" */
					String macroName = "$" + macroKey;
					if (macroName.equalsIgnoreCase("$NAME")) {
						if (macroValue == null || macroValue.trim().equals("")) {
							log
									.info("The "
											+ macroKey
											+ " mail field is not set, "
											+ "hence using \"Sir/Madam\" to address the person");
							Utilities.replaceMacro(msgBuf, macroName,
									"Sir/Madam", filterHTMLSpecialCharFlag);
						} else {
							Utilities.replaceMacro(msgBuf, macroName,
									macroValue, filterHTMLSpecialCharFlag);
						}
					} else {

						/* For other fields */
						if (macroValue == null || macroValue.trim().equals("")) {
							log
									.info("The "
											+ macroKey
											+ " mail field is not set, hence using \"\" (blank)");
							Utilities.replaceMacro(msgBuf, macroName, "",
									filterHTMLSpecialCharFlag);
						} else {
							Utilities.replaceMacro(msgBuf, macroName,
									macroValue, filterHTMLSpecialCharFlag);
						}
					}
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				log.error(
						"Input parameter mailFields array is in invalid format."
								+ e.getMessage(), e);
			} catch (Exception e) {
				log.error("Exception occured while filtering the message body."
						+ e.getMessage(), e);
			}
		}
		log.debug("[Exit filterMessageBody]");
		return msgBuf;
	}

	/**
	 * Filters the Email subject line by replacing all the macros present in it.
	 * 
	 * @param subject
	 *            subject to be filtered
	 * @param caseId
	 *            caseId of the case
	 * @return filtered subject line
	 */
	private StringBuffer filterSubjectLine(StringBuffer subject, int caseId) {
		log.debug("Filtering Macros from subject line.");

		/*
		 * Replace all the MACROs present in the mail subject field(macros from
		 * mailsMode.xml file) with its corresponding value
		 */
		Utilities.replaceMacro(subject, "$BP8CASEID", caseId + "");
		return subject;
	}

	/**
	 * Reads the <i>MailModes.xml </i> file when ever it is modified and stores
	 * it in an map. The structure of xml file looks like:
	 * 
	 * <pre>
	 * 
	 *  
	 *   
	 *    
	 *     
	 *      
	 *       
	 *        
	 *         
	 *          
	 *           
	 *            
	 *               &lt;mailsMode&gt;
	 *              	 &lt;mailMode id=&quot;1&quot;
	 *              	 	subject=&quot;Process L$LEVEL Escalation for (Case ID:$BP8CASE_ID)($SCENARIO_MILESTONE_ID_$ACTION_DETAILS_ID) has been breached&quot;
	 *              	 	template=&quot;ProcessL1EscalationMail.html&quot;&gt;
	 *              	 &lt;/mailMode&gt;
	 *              	 &lt;mailMode id=&quot;2&quot;
	 *              	 	subject=&quot;Process L$LEVEL Escalation for the (Case ID:$BP8CASE_ID)($SCENARIO_MILESTONE_ID_$ACTION_DETAILS_ID) has been breached&quot;
	 *              		template=&quot;ProcessL2EscalationMail.html&quot;&gt;
	 *              	 &lt;/mailMode&gt;
	 *               &lt;/mailsMode&gt;
	 *             
	 *            
	 *           
	 *          
	 *         
	 *        
	 *       
	 *      
	 *     
	 *    
	 *   
	 *  
	 * </pre>
	 * 
	 * @throws IOException -
	 *             if unable to parse the xml file
	 * @throws SAXException -
	 *             if xml file is not well-formed
	 */
	private void readMailModesXMLFile() throws SAXException, IOException {
		log.debug("[Enter readMailModesXMLFile]");

		/* Get the xml file path */
		String xmlFilePath = HOME_PATH + file_separator + "xml"
				+ file_separator + "MailModes.xml";

		log
				.debug("Checking the last modified date of the Work allocation details "
						+ "xml file [" + xmlFilePath + "]");
		File fin = new File(xmlFilePath);
		Calendar lastModCal = Calendar.getInstance();
		lastModCal.setTimeInMillis(fin.lastModified());

		if (lastMailModesXMLFileReloadedOn != null) {
			log.debug("Mail Modes xml file last loaded on:["
					+ lastMailModesXMLFileReloadedOn.getTime() + "] "
					+ "It is last modified on:[" + lastModCal.getTime() + "]");
		}

		if ((lastMailModesXMLFileReloadedOn == null)
				|| lastMailModesXMLFileReloadedOn.before(lastModCal)) {
			log.debug("Mail Modes xml file has been modified since its last "
					+ "reload; hence reading the file");

			/* Load XML file */
			Document docMailsMode = parseXMLFile(xmlFilePath);
			if (docMailsMode == null) {
				log.error("Error occurred while parsing the xml file.");
				return;
			}

			/* Returns a list of all mailMode elements in docmailsMode Document */
			NodeList mailModelist = docMailsMode
					.getElementsByTagName("mailMode");
			outerMap = new HashMap();

			/* Check each mailModeList */
			for (int i = 0; i < mailModelist.getLength(); i++) {
				Node mailMode = (Node) mailModelist.item(i);

				/* Retrieving values of the attributes */
				Integer id = Integer.valueOf(mailMode.getAttributes()
						.getNamedItem("id").getNodeValue());
				String subject = mailMode.getAttributes().getNamedItem(
						"subject").getNodeValue();
				String template = mailMode.getAttributes().getNamedItem(
						"template").getNodeValue();

				/* Strore mailMode's attribute data into innerMap */
				innerMap = new HashMap();
				innerMap.put("subject", subject);
				innerMap.put("template", template);

				/* Mapping each id */
				outerMap.put(id, innerMap);
			}

			/* Update the variable to last modified date */
			lastMailModesXMLFileReloadedOn = lastModCal;
			log.debug("Successfully reloaded the Mail modes xml file");
		} else {
			log.debug("Mail modes xml file is not modified since its last "
					+ "reload; hence not reading the file");
		}
		log.debug("[Exit readMailModesXMLFile]");
	}

	/**
	 * Parses XML file and returns XML document.
	 * 
	 * @param filePath
	 *            XML file to parse(in absolute or relative path)
	 * @return XML document or <B>null </B> if error occurred
	 * @throws SAXException -
	 *             if xml file is not well-formed
	 * @throws IOException -
	 *             if unable to parse the xml file
	 */
	public Document parseXMLFile(String filePath) throws SAXException,
			IOException {
		log.debug("[Enter parseFile]");
		log.debug("Parsing XML file... " + filePath);
		DOMParser parser = new DOMParser();
		Document doc = null;
		try {
			parser.parse(filePath);
			log.debug(filePath + " is well-formed.");

			/* Stores the tree object in a variable of Document type */
			doc = parser.getDocument();

		} catch (SAXException sax) {
			log.error(filePath + " is not well-formed.", sax);
			throw sax;
		} catch (IOException ex) {
			log.error("Due to an IOException, the parser could not check "
					+ filePath, ex);
			throw ex;
		}
		log.debug("[Exit parseFile]");
		return doc;
	}

	/**
	 * Calculates the exact SLA expiration time for the given
	 * <code>slaMins</code> with respect to <code>relativeDate</code>,
	 * where SLA means Service Level Agreement in terms of hours.
	 * 
	 * <p>
	 * If <code>slaTypeId</code> is
	 * 
	 * <pre>
	 * 
	 *  
	 *   
	 *    
	 *     
	 *      
	 *       
	 *        
	 *         
	 *          
	 *           
	 *            
	 *                       1: (Absolute) It checks the input date slaMins  whether it is 
	 *                       	within office working time; if not returns the next office working day.
	 *                       	The slaMins should be in the format of &lt;b&gt;yyyy-MM-dd HH:mm:ss&lt;/b&gt;
	 *                       	For example: slaTypeId=1 and slaMins=&quot;2009-07-20 08:00:00&quot;
	 *                       
	 *                       2: (Relative) It returns the exact time of the day relative to relativeDate	date 
	 *                       	after slaMins number of minutes. Multiple sla minutes will be seperated 
	 *                       	by &quot;|&quot; delimeter. It can contain both positive(for escalation) and 
	 *                       	negative(for reminder) number. 
	 *                       	For example: slaTypeId=2 and slaMins=65|-100|35;
	 *             
	 *            
	 *           
	 *          
	 *         
	 *        
	 *       
	 *      
	 *     
	 *    
	 *   
	 *  
	 * </pre>
	 * 
	 * The SLA calculation process depends on the <code>slaCalculationId</code>
	 * which indicates whether Saturday or Sunday or Company holidays are
	 * consider as office working day. It can contain following values:
	 * 
	 * <pre>
	 * 
	 *  
	 *   
	 *    
	 *     
	 *      
	 *       
	 *        
	 *         
	 *          
	 *           
	 *            
	 *                  		&lt;b&gt;Value&lt;/b&gt;   &lt;b&gt;Office working days&lt;/b&gt;
	 *                   		1		Working Days
	 *                  	 	2		Working Days+Saturday
	 *                  	 	3		Working Days+Sunday
	 *                  	 	4		Working Days+ Holidays
	 *                  	 	5		Working Days+Saturday+Sunday
	 *                  	 	6		Working Days+Saturday+Holidays
	 *                  	 	7		Working Days+Sunday+Holidays
	 *                  	 	8		Working Days+Saturday+Sunday+Holidays
	 *             
	 *            
	 *           
	 *          
	 *         
	 *        
	 *       
	 *      
	 *     
	 *    
	 *   
	 *  
	 * </pre>
	 * 
	 * 
	 * @see com.bharti.fa.common.operations.util.manager.EscalationManager#calculateSLA()
	 * 
	 * @param slaMins
	 *            If slaTypeId is 1 then it contains the date whose next working
	 *            office time need to be calculated; Else if slaTypeId is 2 then
	 *            it contains sla offsets in terms of minutes need to be added
	 *            to relative date. Multiple sla minutes will be seperated by
	 *            &quot;|&quot; delimeter. It can contain both positive(for
	 *            escalation) and negative(for reminder) number.
	 * 
	 * @param relativeDate
	 *            contains either
	 *            <ul>
	 *            <li>relative date: then consider this to add the sla offset
	 *            <li>null or empty string: then consider current system time
	 *            to add the sla offset
	 *            </ul>
	 * 
	 * @param slaTypeId
	 *            if value is 1; it indicates <code>slaMins</code> is an
	 *            absolute date else if value is 2; it indicates
	 *            <code>slaMins</code> is an sla offset value.
	 * 
	 * @param slaCalculationId
	 *            indicates whether Saturday or Sunday or Company holidays
	 *            should be consider as office working day or not.
	 * 
	 * @param officeStartTime
	 *            Office start time. For night shift timings office start time
	 *            will be greater than the office end time. office time would be
	 *            represented in hh:mm:ss format; where hh=hours in 24 office
	 *            format mm=minutes and ss=seconds
	 * 
	 * @param officeEndTime
	 *            Office end time. For night shift timings office start time
	 *            will be greater than the office end time. office time would be
	 *            represented in hh:mm:ss format; where hh=hours in 24 office
	 *            format mm=minutes and ss=seconds
	 * 
	 * @return If slaTypeId is 1 then it returns the next working office
	 *         time(date array of size=1) with respect to <code>slaMins</code>;
	 *         Else if slaTypeId is 2 then it returns the exact sla expiration
	 *         time (date array of size=number of "|" seperated offset in
	 *         slaMins parameter) with respect to <code>slaMins</code>;
	 */
	public Date[] calculateSLA(String slaMins, Date relativeDate,
			int slaTypeId, int slaCalculationId, String officeStartTime,
			String officeEndTime, int caseId) {

		init();
		MDC.put("CASEID", new Integer(caseId));
		log.debug("************[Enter calculateSLA]: slaMins [" + slaMins
				+ "] relativeDate [" + relativeDate + "] slaTypeId ["
				+ slaTypeId + "] slaCalculationId [" + slaCalculationId
				+ "] officeStartTime [" + officeStartTime + "] officeEndTime ["
				+ officeEndTime + "]************");

		String filePath = HOME_PATH + file_separator + "xml" + file_separator
				+ "CompanyHolidays.xml";
		EscalationManager escMng = new EscalationManager();
		Date[] slaExactDate = escMng.calculateSLA(slaMins, relativeDate,
				slaTypeId, slaCalculationId, officeStartTime, officeEndTime,
				filePath);
		MDC.remove("CASEID");
		return slaExactDate;
	}

	/**
	 * This method checks current timer whether it is a valid timer or not. This
	 * method takes allTimerNameArray and fetch the current timer from this. It
	 * then checks against milestoneIDArray, whether the milestone ID of current
	 * timer is present in the default milestone ID array i.e,milestoneIDArray
	 * If the milestone ID of Current timer is not found in default milestone ID
	 * array then it returns -1 else the pointer of milestoneIDArray where the
	 * MileStoneId is located in milestoneIDArray
	 * 
	 * @param currentMilestoneLevel -
	 *            Pointer to milestoneIDArray, which tells the current Milestone
	 * @param milestoneIDArray
	 *            milestoneIDArray - Array of Milestone Secnario ID
	 * @param currentTimerLevel -
	 *            Pointer to allTimerNameArray, which tells the current timer
	 *            running
	 * @param allTimerNameArray -
	 *            Contains array of all timers. This array is of the format
	 * 
	 * <pre>
	 * 
	 *  
	 *   
	 *    
	 *     
	 *      
	 *       
	 *        
	 *         
	 *          
	 *           
	 *            
	 *                        {&quot;M1E1&quot;,&quot;M1R1&quot;,&quot;M2E2&quot;,&quot;M2R1&quot;,&quot;PE1&quot;....}
	 *                        Where 
	 *                        M / P = Milestone / Process 
	 *                        1 / 2 = Milestone Scenario ID 
	 *                        E / R = Escalation / Reminder 
	 *                        1 / 2 = Level 1 / Level 2
	 *                        
	 *            
	 *           
	 *          
	 *         
	 *        
	 *       
	 *      
	 *     
	 *    
	 *   
	 *  
	 * </pre>
	 * 
	 * @param Bp8CaseId -
	 *            caseID of the case
	 */
	public int isValidTimer_LA(int currentMilestoneLevel,
			int[] milestoneIDArray, int currentTimerLevel,
			String[] allTimerNameArray, int Bp8CaseId) throws Exception {
		init();
		log.debug("************[Enter isValidTimer]************");
		MDC.put("CASEID", "" + Bp8CaseId);
		String strmilestoneTimerID = null;
		String strmilestoneTimerLevel = null;
		String strType = null;
		String strCategory = null;
		String strM = null;
		String strE = null;
		String scanMilestonedelimiter = null;
		// String scansecMilestonedelimiter = null;
		String subStrMilestone = null;
		// int currrentMilestoneID = milestoneIDArray[currentMilestoneLevel -
		// 1];
		String currentTimerName = allTimerNameArray[currentTimerLevel - 1];
		int currentMilestoneTimerPointer = -1;

		try {
			log.debug("currentMilestoneLevel pointer : "
					+ currentMilestoneLevel);
			if (log.isDebugEnabled()) {
				for (int i = 0; i < milestoneIDArray.length; i++)
					log.debug("milestoneIDArray scenario milestone id : "
							+ milestoneIDArray[i]);
				log.debug("Current timer Pointer : " + currentTimerLevel);
				for (int i = 0; i < allTimerNameArray.length; i++)
					log.debug("All Timer name array : " + allTimerNameArray[i]);
			}
			log.debug("BpCaseID : " + Bp8CaseId);

			log.debug("Current Timer name : " + currentTimerName);

			for (int i = 0; i < currentTimerName.length(); i++) {
				char charM = currentTimerName.charAt(i);
				strM = String.valueOf(charM);
				if (strM.equals(Constants.MILESTONE))
					break;
				else if (strM.equals(Constants.PROCESS)) {
					break;
				}

			}

			if (strM.equals(Constants.MILESTONE)) {
				strCategory = "Milestone";
				scanMilestonedelimiter = "[M]";
			} else {
				strCategory = "Process";
				scanMilestonedelimiter = "[P]";
			}
			log.debug("M or P : " + strM);
			log.debug("strCategory : " + strCategory);

			int[] limits1 = { 0 };
			for (int limit1 = 0; limit1 < limits1.length; limit1++) {
				String[] tokens = currentTimerName.split(
						scanMilestonedelimiter, limit1);
				String[] token = tokens;
				for (int i = 0; i < token.length; i++) {
					subStrMilestone = token[1];
				}
			}

			for (int i = 0; i < subStrMilestone.length(); i++) {
				char charE = subStrMilestone.charAt(i);
				strE = String.valueOf(charE);
				if (strE.equals(Constants.ESCALATION))
					break;
				else if (strE.equals(Constants.REMINDER)) {
					break;
				}
			}
			log.debug("E or R : " + strE);

			if (strE.equals(Constants.ESCALATION)) {
				strType = "Escalation";
				scanMilestonedelimiter = "[E]";
			} else if (strE.equals(Constants.REMINDER)) {
				strType = "Reminder";
				scanMilestonedelimiter = "[R]";
			}
			log.debug("strType : " + strType);
			log.debug("Delimiter E or R  : " + scanMilestonedelimiter);
			int[] limits = { 0 };
			for (int limit11 = 0; limit11 < limits.length; limit11++) {
				String[] tokens = subStrMilestone.split(scanMilestonedelimiter,
						limit11);

				String[] token = tokens;
				if (strCategory.equalsIgnoreCase("Milestone")) {
					strmilestoneTimerID = token[0];
					strmilestoneTimerLevel = token[1];
				} else if (strCategory.equalsIgnoreCase("Process")) {
					strmilestoneTimerLevel = token[1];
				}
				log.debug("strmilestoneTimerID  : " + strmilestoneTimerID);
				log
						.debug("strmilestoneTimerLevel  : "
								+ strmilestoneTimerLevel);

			}

			// If Present then set the related fields in PE

			Hashtable htWFFields = new Hashtable();

			if (strCategory.equalsIgnoreCase("Process")) {
				htWFFields
						.put("FnFA_TimerSceMilestoneID", Integer.valueOf("0"));
				htWFFields.put("FnFA_IsTimerValid", Boolean.TRUE);
				htWFFields.put("FnFA_NotificationLevel", Integer
						.valueOf(strmilestoneTimerLevel));
				htWFFields.put("FnFA_NotificationType", strType);
				htWFFields.put("FnFA_NotificationCatagory", strCategory);
			} else if (strCategory.equalsIgnoreCase("Milestone")) {

				// Check whether strmilestoneTimerID is present in
				// milestoneIDArray
				for (int k = currentMilestoneLevel - 1; k < milestoneIDArray.length; k++) {
					log.debug("milestoneIDArray[k] : " + milestoneIDArray[k]);
					log.debug("Integer.parseInt(strmilestoneTimerID) : "
							+ Integer.parseInt(strmilestoneTimerID));
					if (milestoneIDArray[k] == (Integer
							.parseInt(strmilestoneTimerID))) {

						currentMilestoneTimerPointer = k + 1;
						log.debug("Milestone ID is present and located at :: "
								+ currentMilestoneTimerPointer);
					}
				}

				htWFFields.put("FnFA_TimerSceMilestoneID", Integer
						.valueOf(strmilestoneTimerID));
				htWFFields.put("FnFA_NotificationLevel", Integer
						.valueOf(strmilestoneTimerLevel));
				htWFFields.put("FnFA_NotificationType", strType);
				htWFFields.put("FnFA_NotificationCatagory", strCategory);
				if (currentMilestoneTimerPointer != -1) {
					htWFFields.put("FnFA_IsTimerValid", Boolean.TRUE);
				} else {
					htWFFields.put("FnFA_IsTimerValid", Boolean.FALSE);
				}
			}

			log.debug("HashTable of values  : " + htWFFields.toString());

			// Create Connection to PE and set the fields
			FinanceFA_PEManager finPEManager = new FinanceFA_PEManager(
					Constants.APPLICATION_COMPONENT_MANAGER, null, null, null);
			finPEManager.setPEFields(Bp8CaseId, htWFFields);

		} catch (Exception ex) {
			log.error(
					"Exception occurred while checking the validity of current expired timer."
							+ ex.getMessage(), ex);
			throw ex;
		}

		log.debug("[Exit isValidTimer]");
		MDC.remove("CASEID");
		return currentMilestoneTimerPointer;
	}

	private int getMailMode(int notificationLevel, String notificationType,
			String notificationCategory) {
		log.debug("notificationCategory : " + notificationCategory
				+ " notificationType : " + notificationType
				+ " notificationLevel : " + notificationLevel);
		int mailMode = 0;
		if (notificationCategory.equalsIgnoreCase(Constants.STRPROCESS)) {
			if (notificationType.equalsIgnoreCase(Constants.STRING_ESCALATION)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 1;
					break;
				case 2:
					mailMode = 2;
					break;
				default:
					break;
				}
			} else if (notificationType
					.equalsIgnoreCase(Constants.STRING_REMINDER)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 3;
					break;
				// case 2:
				// mailMode = 4;
				// break;
				default:
					break;
				}
			}
		}

		else if (notificationCategory.equalsIgnoreCase(Constants.STRMILESTONE)) {
			if (notificationType.equalsIgnoreCase(Constants.STRING_ESCALATION)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 4;
					break;
				case 2:
					mailMode = 5;
					break;
				default:
					break;
				}
			} else if (notificationType
					.equalsIgnoreCase(Constants.STRING_REMINDER)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 6;
					break;
				// case 2:
				// mailMode = 8;
				// break;
				default:
					break;
				}
			}
		} else if (notificationCategory.equalsIgnoreCase(Constants.STRQUERY)) {
			if (notificationType.equalsIgnoreCase(Constants.STRING_ESCALATION)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 7;
					break;
				case 2:
					mailMode = 8;
					break;
				default:
					break;
				}
			} else if (notificationType
					.equalsIgnoreCase(Constants.STRING_REMINDER)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 9;
					break;
				// case 2:
				// mailMode = 12;
				// break;
				default:
					break;
				}
			}
		} else if (notificationCategory.equalsIgnoreCase(Constants.REQUEST)) {
			if (notificationType.equalsIgnoreCase(Constants.STRING_ESCALATION)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 10;
					break;
				case 2:
					mailMode = 11;
					break;
				default:
					break;
				}
			} else if (notificationType
					.equalsIgnoreCase(Constants.STRING_REMINDER)) {
				switch (notificationLevel) {
				case 1:
					mailMode = 12;
					break;
				// case 2:
				// mailMode = 12;
				// break;
				default:
					break;
				}
			}
		}
		log.debug("MAIL MODE ::  " + mailMode);
		return mailMode;
	}

	private void setMailMode(int notificationLevel, String notificationType,
			String notificationCategory, Hashtable htWFFields) {
		log.debug("************Entry  setMailMode(notificationLevel ["
				+ notificationLevel + "],notificationType [" + notificationType
				+ "],notificationCategory [" + notificationCategory
				+ "]htWFFields[" + htWFFields + "]");

		int mailMode = getMailMode(notificationLevel, notificationType,
				notificationCategory);

		log.debug("MAIL MODE ::  " + mailMode);
		htWFFields.put("FnFA_MailMode", new Integer(mailMode));
		log.debug("After setting the mail mode the hashtable is  ::"
				+ htWFFields);
		log.debug("************Entry  setMailMode(notificationLevel ["
				+ notificationLevel + "],notificationType [" + notificationType
				+ "],notificationCategory [" + notificationCategory
				+ "]htWFFields[" + htWFFields + "]");
	}

	/**
	 * This method fetches Maild ids of all the users/roles to whom the mail
	 * (reminder/escalation) should go. It also fetches user profile if the user
	 * is tagged; If the user is not tagged then it will fetch the mail Id
	 * according to the role tagged to it. <br>
	 * 
	 * If the type is reminder then mail goes to Current User(when user is
	 * tagged) and to the role's mailID (when no user tagged). If the type is
	 * escalation and level is 1, then the mail should go to User Supervisor
	 * (when user is tagged) and to the role's supervisor (when no user tagged).
	 * If the type is escalation and level is 2, then the mail should go to User
	 * Supervisor's Supervisor (when user is tagged) and to the role's
	 * Supervisor's supervisor (when no user tagged). Mails also go to the roles
	 * which are set in TO,CC, BCC fields.
	 * 
	 * @param userSSFID :
	 *            Current user SSFID
	 * @param userRole :
	 *            Current user Role
	 * @param notificationLevel :
	 *            level 1 or level 2
	 * @param notificationType :
	 *            Reminder/Escalation
	 * @param TO :
	 *            It is of the following format:
	 *            ([MailID1],[MailId2],...,Role1,Role2,...)
	 * @param CC
	 *            :It is of the following format:
	 *            ([MailID1],[MailId2],...,Role1,Role2,...)
	 * @param BCC:
	 *            It is of the following format:
	 *            ([MailID1],[MailId2],...,Role1,Role2,...)
	 * @param Bp8CaseId
	 * @throws Exception
	 */
	public void getNotificationDetails_LA(String userSSFID, String userRole,
			int notificationLevel, String notificationType,
			String notificationCategory, String to, String cc, String bcc,
			int Bp8CaseId) throws Exception {

		init();
		log.debug("************[Enter getNotificationDetails]************");

		MDC.put("CASEID", "" + Bp8CaseId);
		boolean success = false;
		Hashtable htWFFields = new Hashtable();

		log.debug("Bp8CaseId = " + Bp8CaseId);
		log.debug("UserSSFID = " + userSSFID);
		log.debug("userRole = " + userRole);
		log.debug("notificationLevel = " + notificationLevel);
		log.debug("notificationType = " + notificationType);
		log.debug("notificationCategory = " + notificationCategory);
		log.debug("to = " + to);
		log.debug("cc = " + cc);
		log.debug("bcc = " + bcc);
		FinanceFA_ExternalDBManager dbManager = new FinanceFA_ExternalDBManager(
				Constants.APPLICATION_STANDALONE);
		dbManager.getDbConnection();
		try {
			htWFFields = dbManager.getNotificationDetails(userSSFID, userRole,
					notificationLevel, notificationType, notificationCategory,
					to, cc, bcc);
			setMailMode(notificationLevel, notificationType,
					notificationCategory, htWFFields);
			log.debug("HashTable of PE Fields :" + htWFFields);

			FinanceFA_PEManager finPEManager = new FinanceFA_PEManager(
					Constants.APPLICATION_COMPONENT_MANAGER, null, null, null);
			finPEManager.setPEFields(Bp8CaseId, htWFFields);
			success = true;
		} catch (Exception ex) {
			log.error("Database Exception : " + ex.getMessage(), ex);
			success = false;
			throw ex;
		} finally {
			dbManager.closeDbConnection();
			log.debug("Execution Status of Query:" + success);
		}

		log.debug("[Exit getNotificationDetails]");
		MDC.remove("CASEID");
	}

	/**
	 * This method fetches Maild ids of all the users/roles to whom the mail
	 * (reminder/escalation) should go. It also fetches user profile if the user
	 * is tagged; If the user is not tagged then it will fetch the mail Id
	 * according to the role tagged to it. <br>
	 * 
	 * If the type is reminder then mail goes to Current User(when user is
	 * tagged) and to the role's mailID (when no user tagged). If the type is
	 * escalation and level is 1, then the mail should go to User Supervisor
	 * (when user is tagged) and to the role's supervisor (when no user tagged).
	 * If the type is escalation and level is 2, then the mail should go to User
	 * Supervisor's Supervisor (when user is tagged) and to the role's
	 * Supervisor's supervisor (when no user tagged). Mails also go to the roles
	 * which are set in TO,CC, BCC fields.
	 * 
	 * @param userSSFID :
	 *            Current user SSFID
	 * @param userRole :
	 *            Current user Role
	 * @param notificationLevel :
	 *            level 1 or level 2
	 * @param notificationType :
	 *            Reminder/Escalation
	 * @param TO :
	 *            It is of the following format:
	 *            ([MailID1],[MailId2],...,Role1,Role2,...)
	 * @param CC
	 *            :It is of the following format:
	 *            ([MailID1],[MailId2],...,Role1,Role2,...)
	 * @param BCC:
	 *            It is of the following format:
	 *            ([MailID1],[MailId2],...,Role1,Role2,...)
	 * @param Bp8CaseId
	 * @throws Exception
	 */
	public String[] getNotificationDetails_LR(String notificationXML,
			int cScenarioMilestoneID, int notificationPointer,
			String userSSFID, String userRole, int bp8caseID) throws Exception {
		log.debug("************[Enter getNotificationDetails_LR]: cScenarioMilestoneID ["
				+ cScenarioMilestoneID
				+ "] notificationPointer ["
				+ notificationPointer
				+ "] userSSFID ["
				+ userSSFID
				+ "] userRole ["
				+ userRole
				+ "] bp8caseID ["
				+ bp8caseID + "]************");

		MDC.put("CASEID", "" + bp8caseID);

		/*
		 * initialise the return array
		 */
		String[] notificationArray = new String[14];
		Utilities.initializeEmptyArray(notificationArray);

		/*
		 * instantiate an empty Notification bean and get it populated with
		 * required notification detaials.
		 */
		NotificationDTO emptyBean = new NotificationDTO();
		NotificationDTO notificationBean = (NotificationDTO) FinanceFA_XMLUtilities
				.getNodeDetailsFromXML(notificationXML, cScenarioMilestoneID,
						notificationPointer, emptyBean);

		log.debug("UserSSFID = " + userSSFID);
		log.debug("userRole = " + userRole);
		String notificationLevel = notificationBean.getLevel();
		log.debug("notificationLevel = "
				+ notificationLevel);
		String notificationType = notificationBean.getType();
		log.debug("notificationType = "
				+ notificationType);
		String notificationCategory = notificationBean.getCategory();
		log.debug("notificationCategory = "
				+ notificationCategory);
		String to = notificationBean.getTo();
		log.debug("to = " + to);
		String cc = notificationBean.getCc();
		log.debug("cc = " + cc);
		String bcc = notificationBean.getBcc();
		log.debug("bcc = " + bcc);
		String isTimerExpired = notificationBean.getIstimerexpired();
		log.debug("isTimerExpired = "
				+ notificationBean.getIstimerexpired());
		String timerNotificationIsEnabled = notificationBean
				.getTimernotificationisenabled();
		log.debug("timerNotificationIsEnabled = "
				+ timerNotificationIsEnabled);

		log.debug("modified xml  = "
				+ notificationBean.getModifiedXMLString());

		try {

			int level = Integer.parseInt(notificationLevel);
			FinanceFA_ExternalDBManager dbManager = new FinanceFA_ExternalDBManager(
					FinanceFA_Constants.APPLICATION_STANDALONE);
			notificationArray = dbManager.getNotificationDetails_LR(userSSFID,
					userRole, level, notificationType, notificationCategory,
					to, cc, bcc);
			log.info("notification array: "
					+ Utilities.displayArray(notificationArray));
			notificationArray[0] = notificationCategory;
			notificationArray[1] = notificationType;
			notificationArray[2] = notificationLevel;
			notificationArray[10] = isTimerExpired;
			notificationArray[11] = timerNotificationIsEnabled;
			notificationArray[12] = notificationBean.getModifiedXMLString();
			int mailMode = getMailMode(level, notificationType,
					notificationCategory);
			notificationArray[13] = mailMode + "";
			//	notificationArray[1] = notificationLevel;
			log.debug("Notification Details :"
					+ Utilities.displayArray(notificationArray));

		} catch (Exception ex) {
			log.error("Exception : " + ex.getMessage(), ex);
			throw new Exception(
					"Exception occurred while retreiving notification details "
							+ ex.getMessage(), ex);
		}

		/* Remove null from array */
		log.debug("Removing null value from return array");
		FinanceFA_Utilities.removeNullFromArray(notificationArray);
		FinanceFA_Utilities.displayArrayWithIndex(notificationArray);
		
		log.debug("[Exit getNotificationDetails]");
		MDC.remove("CASEID");
		return notificationArray;
	}

	/**
	 * This component will be called whenever Pull/Mileston
	 * Achieved/Achieve/Reject action is taken. purpose of this function is,
	 * return the details of milestone which is going to be executed on above
	 * said any of the action in case of reject action,last milestone details in
	 * case of other actions,next milestone details
	 * 
	 * @name getMilestoneDetails
	 * @param milestonePointer
	 *            -it contains pointer whose milestone details to be fetched in
	 *            the milestoneDetalsXML
	 * @param milestoneDetailsXML
	 *            -it contains all the milestone details
	 * 
	 * 
	 * 
	 * 
	 * @param notificationTimerXML
	 *            notification xml
	 * @param timerPointer
	 *            for process notification xml it contains the current
	 *            notification level of running timer for milestone notification
	 *            xml it will be -1
	 * @param currentScenarioMilestoneId
	 *            for milestone notification xml it contains the current
	 *            milestone's scenario milestone id for process notification xml
	 *            it will be -1
	 * @param relativeDate
	 *            either milestone sla date or process sla date
	 * @param slaTypeId
	 * @param slaCalculationId
	 * @param officeStartTime
	 * @param officeEndTime
	 * @param caseId
	 * 
	 * 
	 * @return returnArray- retrunArray will always return following value
	 *         String[] returnArray = new String[15] returnArray -it contains
	 *         below values MielestonePointer Param[1] =
	 *         CurrentScenarioMilestoneID Param[2] =
	 *         CurrentScenarioMilestoneName Param[3] =
	 *         CurrentScenarioMilestoneOrder Param[4] = CurrentMilestoneID
	 *         Param[5] = CurrentMilestoneType Param[6] =
	 *         CurrentMilestoneDescription Param[7] = CMilestoneSLA Param[8] =
	 *         PendingWithSSFID Param[9] =PendingWithRole Param[10] =
	 *         PendingWithEmailID Param[11] = PendingWithName Param[12] =
	 *         IsTimerExists Param[13] = NextTimerDate Param[14] =
	 *         NextTimerPointer
	 * 
	 * 
	 *  
	 */

	public String[] getMilestoneDetails_LR(int milestonePointer,
			String milestoneDetailsXML, String notificationDetailsXML,
			int timerPointer, int slaTypeId, int slaCalculationId,
			String officeStartTime, String officeEndTime, int bp8caseID)
			throws Exception {
		init();
		MDC.put("CASEID", new Integer(bp8caseID));
		log.debug("************[Entry getMilestoneDetails_LR]: milestonePointer ["
				+ milestonePointer
				+ "] timerPointer ["
				+ timerPointer
				+ "] slaTypeId ["
				+ slaTypeId
				+ "] slaCalculationId ["
				+ slaCalculationId
				+ "]  officeStartTime ["
				+ officeStartTime
				+ "]  officeEndTime ["
				+ officeEndTime
				+ "]  bp8caseID ["
				+ bp8caseID
				+ "]************");

		String currentUserSSFID = null;
		HashMap userdetails = new HashMap();

		/* Declare and initialise the output array */
		String[] returnArray = new String[15];
		Utilities.initializeEmptyArray(returnArray);
		
		/*
		 * i.traverse the FNFA_MilestoneDetailXML . find the matching
		 * FnFA_MilestonePointer i.if found , populate MilestoneDTO and return
		 * ii.fetch the pendingwith details with ownerssfid. iii.if
		 * f_response==Reject calculateSLA with restslaoffset and set
		 * FnFA_CMilestoneSLA
		 *  
		 */

		MilestoneDTO milestoneDTO = FinanceFA_XMLUtilities
				.getMilestoneDetailsFromXML(milestoneDetailsXML,
						milestonePointer);
		if (milestoneDTO == null) {
			log.debug("current milestone is the last one ,hence setting milestone pointer as zero, other fields with empty ");
			returnArray = getFinalMilestoneDetails();
			
			/* Remove null from array */
			log.debug("Removing null value from return array");
			FinanceFA_Utilities.removeNullFromArray(returnArray);
			log.debug("Final milestone details:"
					+ Utilities.displayArray(returnArray));
			return returnArray;
		}
		log.debug("milestone details :" + milestoneDTO.toString());
		String currentScenarioMilestoneIdStr = milestoneDTO
				.getScenariomilestoneid();
		int currentScenarioMilestoneId = new Integer(
				currentScenarioMilestoneIdStr).intValue();

		returnArray[0] = new Integer(milestonePointer).toString();
		returnArray[1] = currentScenarioMilestoneIdStr;
		returnArray[2] = milestoneDTO.getName();
		returnArray[3] = milestoneDTO.getOrder().toString();
		returnArray[4] = milestoneDTO.getId().toString();
		returnArray[5] = milestoneDTO.getType();
		returnArray[6] = milestoneDTO.getScenariomilestonedesc();
		//returnArray[7] = current milestone sla

		currentUserSSFID = milestoneDTO.getOwnerssfid();
		returnArray[8] = currentUserSSFID;
		returnArray[9] = milestoneDTO.getOwnerrole();

		log.debug("fetching user details for user[" + currentUserSSFID
				+ "]from cache...");
		UserDetailsBean userdetail = new UserDetailsBean();
		FinanceFA_ExternalDBManager dbManager = new FinanceFA_ExternalDBManager(
				Constants.APPLICATION_STANDALONE);
		userdetails = dbManager.getUserDetails();
		//boolean flag = false;

		boolean userFoundinCache = false;
		if (currentUserSSFID != null) {
			log.info("owner with SSFID [" + currentUserSSFID
					+ "] found in the milestone details XML ["
					+ milestoneDetailsXML + "]@ scenario milestone ["
					+ currentScenarioMilestoneId + "]");
			userFoundinCache = userdetails.containsKey(currentUserSSFID
					.toLowerCase().trim());
		} else {
			log.info("owner with SSFID [" + currentUserSSFID
					+ "]not found in the milestone details XML");
			log
					.warn("please check the milestone details @ scenario milestone ["
							+ currentScenarioMilestoneId
							+ "]in XML ["
							+ milestoneDetailsXML + "]");
		}

		if (userFoundinCache) {
			log
					.debug("User with SSFID ["
							+ currentUserSSFID
							+ "]found in the cache ,hence fetching his/her user name and email id from the cache..");
			userdetail = (UserDetailsBean) userdetails.get(currentUserSSFID
					.toLowerCase().trim());
			returnArray[10] = userdetail.getUserName();
			returnArray[11] = userdetail.getUserMailId();
			log.debug("user name is [" + returnArray[10] + "],user mailID is ["
					+ returnArray[11] + "  ]found from the cache.");
		} else {
			log.error("no user with SSFID [" + currentUserSSFID
					+ "] found in the cache");
		}

		String restSLA = milestoneDTO.getRestsla();
		if (restSLA == null || restSLA.trim().equals("")) {
			log
					.debug("restsla for the milestone is ["
							+ restSLA
							+ "] ,hence  pick offset from the xml  and calculate current milestone SLA");
			String offset = milestoneDTO.getOffset();
			if (offset == null || offset.trim().equals("")) {
				log
						.warn("offset value is ["
								+ offset
								+ "],please check the milestone details @ scenario milestone ["
								+ currentScenarioMilestoneId + "]in XML ["
								+ milestoneDetailsXML + "]");
			}
			restSLA = offset;

		}

		Date currentMilestoneSLADate = null;
		if (restSLA != null && !restSLA.trim().equals("")) {
			log.debug("calculating  current milestone SLA usign restSLA ["
					+ restSLA + "]...");
			Date[] relativeSLADate = calculateSLA(restSLA, new Date(),
					slaTypeId, slaCalculationId, officeStartTime,
					officeEndTime, bp8caseID);

			currentMilestoneSLADate = relativeSLADate[0];
		}
		if (currentMilestoneSLADate != null) {
			returnArray[7] = FinanceFA_Utilities
					.dateToString(currentMilestoneSLADate);

		} else {
			log.warn("current MilestoneSLADate is [" + currentMilestoneSLADate
					+ "],hence returning empty string..");
			returnArray[7] = "";
		}

		/* Get next qualifying timer details */
		String[] nextTimerArray = getNextQualifyingTimer_LR(
				notificationDetailsXML, timerPointer,
				currentScenarioMilestoneId, currentMilestoneSLADate, slaTypeId,
				slaCalculationId, officeStartTime, officeEndTime, bp8caseID);
		returnArray[12] = nextTimerArray[0];
		returnArray[13] = nextTimerArray[1];
		returnArray[14] = nextTimerArray[2];
				
		/* Remove null from array */
		log.debug("Removing null value from return array");
		FinanceFA_Utilities.removeNullFromArray(returnArray);
		log.debug("Resultant array is : ");
		FinanceFA_Utilities.displayArrayWithIndex(returnArray);
		log.debug("[Exit getMilestoneDetails_LR]");
		return returnArray;
	}

	/**
	 *  
	 */
	private String[] getFinalMilestoneDetails() {
		String[] returnArray = new String[18];
		Utilities.initializeEmptyArray(returnArray);
		
		//set the fields and return
		returnArray[0] = "0";
		return returnArray;
	}

	/**
	 * Creates a case
	 * 
	 * @param caseType
	 * @param caseClassName
	 * @param attachments
	 * @param actionName
	 * @param actionUserName
	 * @param caseFields
	 * @return
	 * @throws Exception
	 */
	public String[] createCaseWithCaseType(String caseType,
			String caseClassName, VWAttachment attachments[],
			String actionName, String actionUserName, String caseFields[],
			String wobNumber) throws Exception {
		init();
		MDC.put("CASEID", wobNumber);
		log
				.debug("******************** [Enter createCaseWithCaseType]: caseType ["
						+ caseType
						+ "] caseClassName ["
						+ caseClassName
						+ "] attachments ["
						+ attachments
						+ "]  actionName ["
						+ actionName
						+ "] actionUserName ["
						+ actionUserName
						+ "] caseFields ["
						+ Utilities.displayArray(caseFields)
						+ "]  wobNumber ["
						+ wobNumber
						+ "] ********************");
		String[] returnArray = null;
		try {
			if (bpfMgr == null) {
				bpfMgr = new BPFManager(caseType);
				log.debug("Initialized the BPF manager object");
			}
			returnArray = bpfMgr.createCaseWithCaseType(caseType,
					caseClassName, attachments, actionName, actionUserName,
					caseFields);
		} catch (Exception ex) {
			log.error("Exception while creating case: " + ex, ex);
			throw ex;
		}
		log.debug("Returned case fields are [ "
				+ Utilities.displayArray(returnArray) + " ]");
		log.debug("[Exit createCaseWithCaseType]");
		MDC.remove("CASEID");
		return returnArray;
	}

	/**
	 * This method is for relative workflow. This method will return String
	 * containing updated XML of tagged user and his supervisiors. This method
	 * takes currentuserSSFID and currentUserRole and will return array whcih
	 * contains Roles corresponding to mileStonesUsersSSFID given.
	 * 
	 * @param currentUser,
	 *            the current user tagged
	 * @param currentUserRole
	 *            the current role of the user tagged
	 * @param milestoneRoles
	 * @param mileStonesUsers
	 * @return
	 */

	public String updateUserSSFID_LR(String currentUserSSFID,
			String currentUserRole, int currentMilestoneArrayPointer,
			String MilestoneXML, int bp8CaseID) {
		String updatedXML = null;

		log.debug("********************[Entry updateUserSSFID_LR]********************");

		MDC.put("CASEID", new Integer(bp8CaseID));

		log.debug("currentUserSSFID ::: " + currentUserSSFID);
		log.debug("currentUserRole ::: " + currentUserRole);

		if (currentUserSSFID == null || currentUserSSFID.equals("")
				|| currentUserRole == null || currentUserRole.equals("")) {
			log
					.error("Input parameters (currentUserSSFID/currentUserRole) are blank or null.Kindly check the input parameters in the above log ");
			throw new IllegalArgumentException(
					"Input parameters (currentUserSSFID/currentUserRole) are blank or null.Kindly check the input parameters in the above log ");
		}
		FinanceFA_ExternalDBManager dbManager = new FinanceFA_ExternalDBManager(
				Constants.APPLICATION_STANDALONE);
		updatedXML = dbManager.updateUserSSFID_LR(currentUserSSFID,
				currentUserRole, currentMilestoneArrayPointer, MilestoneXML);
		if (updatedXML == null) {
			log
					.error("The updated xml string is null; hence returning empty string to workflow");
			updatedXML = "";
		}

		log.debug("[Exit updateUserSSFID_LR]");
		MDC.remove("CASEID");
		return updatedXML;
	}

	/**
	 * @purpose: This component will be called when user achieve or approve any
	 *           milestone. this component is called if milestone is not expired
	 *           then calculate milestones remaining SLA time and hold it in an
	 *           array. In case of rejection, this rest SLA will be available to
	 *           the user.
	 * 
	 * @param offset
	 * @param milestoneStartDate
	 * @param milestoneEndDate
	 * @param slaCalculationID
	 * @param shiftStartTime
	 * @param shiftEndTime
	 * @param arrayPointer
	 * @param restSLAArray
	 * @param caseid
	 * 
	 * @return restSLAArray
	 */

	public String updateRestSLAArray_LR(Date milestoneStartDate,
			Date milestoneEndDate, int slaCalculationID, String shiftStartTime,
			String shiftEndTime, int arrayPointer, String milestoneXML,
			int bp8caseID) throws Exception {

		init();
		MDC.put("CASEID", new Integer(bp8caseID));
		log.debug("********************[Entry updateRestSLAArray_LR]********************");
		log.debug("milestoneStartDate : " + milestoneStartDate);
		log.debug("milestoneEndDate : " + milestoneEndDate);
		log.debug("slaCalculationID : " + slaCalculationID);
		log.debug("shiftStartTime : " + shiftStartTime);
		log.debug("shiftEndTime : " + shiftEndTime);
		log.debug("Milestone arrayPointer : " + arrayPointer);
		log.debug("milestoneXML : " + milestoneXML);

		int remainingOffsetValueInMin = 0;
		int totalMins = 0;
		String xmlString = null;
		try {

			if (milestoneStartDate.after(milestoneEndDate)) {
				log.error("milestone End Date cannot be less than Milestone Start date. Kindly check again");
			} else {

				EscalationManager escMngr = new EscalationManager();
				totalMins = escMngr.totalUtilizedTime(milestoneStartDate,
						milestoneEndDate, slaCalculationID, shiftStartTime,
						shiftEndTime, filePath);

				try {

					DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
							.newInstance();
					DocumentBuilder docBuilder = docBuilderFactory
							.newDocumentBuilder();
					Document doc = docBuilder.parse(new InputSource(
							new StringReader(milestoneXML)));

					NodeList listOfMilestones = doc
							.getElementsByTagName(FinanceFA_Constants.MILESTONE_NODE);
					int totalMilestones = listOfMilestones.getLength();
					log.debug("Total no of milestones : " + totalMilestones);

					//Iterate the Milestone XML nodes with this for loop

					for (int s = 0; s < listOfMilestones.getLength(); s++) {

						Node milestoneNode = listOfMilestones.item(s);
						log.debug("milestoneNode :: "
								+ milestoneNode.getNodeName());

						if (s == arrayPointer - 1
								&& milestoneNode.getNodeType() == Node.ELEMENT_NODE) {

							Element milestoneElement = (Element) milestoneNode;

							//    	 	-------
							NodeList milestoneRestSLAList = milestoneElement
									.getElementsByTagName(FinanceFA_Constants.REST_SLA);
							Element milestoneRestSLAElement = (Element) milestoneRestSLAList
									.item(0);

							NodeList textRestSLAList = milestoneRestSLAElement
									.getChildNodes();

							//Check whether the RestSLA Node of given pointer
							// is
							// null or not. If not null then subtract the total
							// minsutes from that value else subtract from given
							// offset value
							if (((Node) textRestSLAList.item(0)) != null) {
								log
										.debug("RestSLA Node is not null and value is  : "
												+ ((Node) textRestSLAList
														.item(0))
														.getNodeValue().trim());
								String tempOffset = ((Node) textRestSLAList
										.item(0)).getNodeValue().trim();
								remainingOffsetValueInMin = Integer
										.parseInt(tempOffset)
										- totalMins;

								((Node) textRestSLAList.item(0))
										.setNodeValue(Integer
												.toString(remainingOffsetValueInMin));
							} else {
								log.debug(" RestSLA Node is null so checking offset node");
								NodeList milestoneOffsetList = milestoneElement
										.getElementsByTagName(FinanceFA_Constants.OFFSET);
								Element milestoneOffsetElement = (Element) milestoneOffsetList
										.item(0);

								NodeList textOffsetList = milestoneOffsetElement
										.getChildNodes();
								if (((Node) textOffsetList.item(0)) != null) {

									String tempOffset = ((Node) textOffsetList
											.item(0)).getNodeValue().trim();
									log
											.debug("Offset value is not null and value is : "
													+ tempOffset);
									remainingOffsetValueInMin = Integer
											.parseInt(tempOffset)
											- totalMins;
									Element ele = (Element) doc
											.createElement(FinanceFA_Constants.REST_SLA);
									ele
											.appendChild(doc
													.createTextNode(Integer
															.toString(remainingOffsetValueInMin)));
									milestoneElement.replaceChild(ele,
											milestoneRestSLAElement);
								} else {
									log
											.error("OFFSET node is null. Kindly Check.....");
								}
							}
							log.debug("Now remaining offset in minutes is: "
									+ remainingOffsetValueInMin);
							log
									.debug("Total time taken to complete the task is "
											+ totalMins
											/ 60
											+ " Hour &"
											+ totalMins
											% 60
											+ " Minutes"
											+ "\n Remaining SLA is "
											+ remainingOffsetValueInMin
											/ 60
											+ " Hour & "
											+ remainingOffsetValueInMin
											% 60
											+ " Minutes");

						}
					}
					
					// Now change the XML back to String
					Transformer transformer = TransformerFactory.newInstance()
							.newTransformer();

					StreamResult result = new StreamResult(new StringWriter());
					DOMSource source = new DOMSource(doc);
					transformer.transform(source, result);

					xmlString = result.getWriter().toString();
					log.debug("Updated XML string :: " + xmlString);

				} catch (Exception e) {
					log.error("Exception while XML parsing" + e, e);
					throw e;
				}
			}
		} catch (Exception ex) {
			log.error("Exception in updateRestSLAArray " + ex, ex);
			throw ex;
		}
		if(xmlString == null) {
			log.error("The updated xml string is null; hence returning empty string to workflow");
			xmlString = "";
		}
		
		MDC.remove("CASEID");
		return xmlString;
	}

	/**
	 * Gets the scenario details for the <code>scenarioId</code>. This method
	 * will be called for manual case creation process. Fields to return to
	 * workflow will be stored in an String array at specific index. The order
	 * of fields in returned array is:
	 * 
	 * <pre>
	 * 
	 *  		&lt;b&gt;Index&lt;/b&gt;	&lt;b&gt;workflow field&lt;/b&gt;
	 *  		0	FnFA_CScenarioMilestoneID
	 * 		1	FnFA_CMilestoneOwnerRole
	 * 		2	FnFA_CMilestoneName
	 * 		3	FnFA_CMilestoneID
	 * 		4	FnFA_CMilestoneType
	 * 		5	FnFA_CMilestoneOrder
	 * 		6	FnFA_CMilestoneDescription
	 * 		7	FnFA_CMilestoneSLA
	 * 		8	FnFA_CaseLaunchCldID
	 * 		9	FnFA_CMilestoneTimerDate
	 * 		10	FnFA_MilestoneTasksXML
	 * 		11	FnFA_MilestoneDetailsXML
	 * 		12	FnFA_MilestoneTimerDetailsXML
	 * 		13	FnFA_CProcessTimerDate
	 * 		14	FnFA_ProcessNotificationXML
	 * 		15	FnFA_ScenarioTypeID
	 * 		16	FnFA_SLATypeID
	 * 		17	FnFA_SLACalculationID
	 * 		18	FnFA_OfficeStartTime
	 * 		19	FnFA_OfficeEndTime
	 * 		20	FnFA_ProcessSLA
	 *  
	 * </pre>
	 * 
	 * If the <code>scenarioId</code> is not found in the database then it
	 * will return an string array of size 1.
	 * 
	 * @param scenarioId
	 *            scenario id whose configuration details need to be fetched
	 * @param caseId
	 *            BPF case id
	 * @return if successful returns an string array of size 21 otherwise string
	 *         array of size 1
	 * @throws Exception
	 */
	public String[] getScenarioConfiguration(int scenarioId, int caseId)
			throws Exception {

		/* Initialize the log4j system and read custom property file */
		init();

		/* Insert MDC */
		MDC.put("CASEID", new Integer(caseId));
		if (log.isDebugEnabled()) {
			log.debug("********************[Enter getScenarioConfiguration]: scenarioId: ["
					+ scenarioId
					+ "] caseId: ["
					+ caseId
					+ "] ********************");
		}
		String[] returnArray = null;
		try {

			/* Get the company holiday xml path */
			String holidayXMLPath = HOME_PATH + file_separator + "xml"
					+ file_separator + "CompanyHolidays.xml";

			/* Get the scenario configuration */
			FinanceFA_CIOperations ciOperations = new FinanceFA_CIOperations();
			returnArray = ciOperations.getScenarioConfiguration(scenarioId,
					FinanceFA_Constants.WF_RETURN_XML_DATA, holidayXMLPath);
			if (returnArray == null) {
				log.error("No records found for input scenario id ["
						+ scenarioId + "]. Hence returning empty array.");
				returnArray = new String[] { "" };
			} else {
				
				/* Remove the null value from the return array */
				log.debug("Removing null value from return array");
				FinanceFA_Utilities.removeNullFromArray(returnArray);
				
				/* Display the output array */
				log.info("Resultant array size is " + returnArray.length);
				FinanceFA_Utilities.displayArrayWithIndex(returnArray);
			}
		} catch (Exception ex) {
			log.error("Error occured while getting the scenario configuration details ", ex);
			throw ex;
		}
		log.debug("[Exit getScenarioConfiguration]");
		return returnArray;
	}

	public static void main(String args[]) {
		FinanceFAOperations fo = new FinanceFAOperations();
		try {
			
			new FinanceFA_PEManager(FinanceFA_Constants.APPLICATION_STANDALONE,"ceadmin","filenet",null);
		
			
//			try{
						fo.getNotificationDetails_LA("","FA Executive",2,"Escalation","Milestone",""," "," ",65899);
//						}
				//		catch(Exception e){
				//			e.printStackTrace();
				//		}
//			new FinanceFA_ExternalDBManager(0).getNotificationDetails_LR(
//					"", "FA Executive", 1, "Escalation", "Milestone",
//					"[manager1@peae.com]", "FA head",
//					"FA Executive");
			new FinanceFA_ExternalDBManager(0).getNotificationDetails_LR("B0002001",
					"FA Executive", 1, "Reminder", "Milestone", "FA Head", "",
					"FA Manager");
// fo.getScenarioConfiguration(6, 123);
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} 
		if(true)
			return;
		//		String[] a = new String[] {};
		//		System.out.println("AAAAAAAAAAAAAAAAAAAAA ::::::: "+a.length);
		fo = new FinanceFAOperations();
		//		fo.updateUserSSFID_LR("B0040776", "RR Executive - IUC", 2, "", 1234);
		try {
			//			fo.sendMail(1, "ceadmin@peae.com", null, null, new String[] {
			//					"CASE_COMMENTS",
			//					"first\nsecond\nthird\n\nfourth \" &<Harisha>" });
			//			DateFormat formatter = new SimpleDateFormat("dd-MM-yy HH:mm:ss");
			//			Date sdate = (Date) formatter.parse("03-11-09 11:30:00");
			//			Date edate = (Date) formatter.parse("03-11-09 13:30:00");
			//			log.debug("Start Date is: " + sdate);
			//			log.debug("End Date is: " + new Date());
			//			String arr[] = { "" };
			//			fo.updateRestSLAArray_LR("300", sdate, edate, 1, "07:00:00",
			//					"16:00:00", 2, "", 1122);
			//        op.calculateHoldTime(sdate, edate, "0", 2, 1, "09:00:00",
			// "18:00:00", 1111);
			System.out.println("Completed");
			fo
					.getMilestoneDetails_LR(
							2,
							"<MilestoneDetails><Milestone ScenarioMilestoneID='18'><Name>Sites Identified for verification</Name><Type>NORMAL</Type><Order>1</Order><ID>5</ID><OwnerSSFID>B0040608</OwnerSSFID><OwnerRole>FA Executive</OwnerRole><RestSLA>1078</RestSLA><Offset>1080</Offset><ScenarioMilestoneDesc><![CDATA[Identification of Sites / Assets for Verification]]></ScenarioMilestoneDesc></Milestone><Milestone ScenarioMilestoneID='19'><Name>Interim Status Submitted</Name><Type>NORMAL</Type><Order>2</Order><ID>6</ID><OwnerSSFID>B0040608</OwnerSSFID><OwnerRole>FA Executive</OwnerRole><RestSLA></RestSLA><Offset>8100</Offset><ScenarioMilestoneDesc>Submission of interim status </ScenarioMilestoneDesc></Milestone><Milestone ScenarioMilestoneID='20'><Name>Final Report Submitted</Name><Type>NORMAL</Type><Order>3</Order><ID>7</ID><OwnerSSFID>B0040608</OwnerSSFID><OwnerRole>FA Executive</OwnerRole><RestSLA/><Offset>8100</Offset><ScenarioMilestoneDesc><![CDATA[Submission of Physical Verification report]]></ScenarioMilestoneDesc></Milestone><Milestone ScenarioMilestoneID='21'><Name>Reconciliation Approved</Name><Type>APPROVAL</Type><Order>4</Order><ID>8</ID><OwnerSSFID/><OwnerRole>FA Manager</OwnerRole><RestSLA/><Offset>3780</Offset><ScenarioMilestoneDesc><![CDATA[Reconciliation & Approval as per DOA]]></ScenarioMilestoneDesc></Milestone><Milestone ScenarioMilestoneID='22'><Name>Adjustments / Rectification complete</Name><Type>NORMAL</Type><Order>5</Order><ID>9</ID><OwnerSSFID>B0040608</OwnerSSFID><OwnerRole>FA Executive</OwnerRole><RestSLA/><Offset>3780</Offset><ScenarioMilestoneDesc><![CDATA[Rectifications / adjustment in Oracle and FAR]]></ScenarioMilestoneDesc></Milestone><Milestone ScenarioMilestoneID='23'><Name>Verification Complete</Name><Type>APPROVAL</Type><Order>6</Order><ID>10</ID><OwnerSSFID/><OwnerRole>FA Manager</OwnerRole><RestSLA/><Offset>1080</Offset><ScenarioMilestoneDesc><![CDATA[Review of FAR post rectification]]></ScenarioMilestoneDesc></Milestone></MilestoneDetails>",
							"", 2, 2, 1, "09:00:00", "20:00:00", 123);
			//			fo.getScenarioConfiguration(6, 123);
		} catch (Exception e) {
			log.error("Exception :" + e);
		}

		if (false) {
			fo.checkValidityThenAdd(new String[] {}, null, false);
			fo.filterSubjectLine(null, 123);
		}
		//		fo.updateRestSLAArray_LR("300",)
		//		try{
		//		fo.getNotificationDetails("","RR Manager -
		// Prepaid",1,"Reminder","Milestone","RR Head"," "," ",65899);
		//		}
		//		catch(Exception e){
		//			e.printStackTrace();
		//		}
		//		if(false) {
		//			new FinanceOperations().checkValidityThenAdd(new String[]{}, null,
		// false);
		//			new FinanceOperations().filterSubjectLine(null, 0);
		//		}
		//		fo.sendMail(19, "po@peae.com, ggsadjgjga", null, null, new String[] {
		//				"MESSAGE","first\nsecond\nthird\n\nfourth \" &<Harisha>" });
		//fo.sendMail(1, "po@peae.com, ggsadjgjga", null, null, new String[] {
		//				"CASE_COMMENTS","first\nsecond\nthird\n\nfourth \" &<Harisha>" });
		//		if (false) {
		//			new FinanceOperations().checkValidityThenAdd(new String[] {}, null,
		//					false);
		//			new FinanceOperations().filterSubjectLine(new StringBuffer(""), 0);
		//		}

		//		milestoneXML = "<MilestoneDetails> <Milestone
		// ScenarioMilestoneID='11'> <Name>Input Files Recieved</Name>
		// <Type>Normal</Type> <Order>1</Order> <ID>1</ID>
		// <OwnerSSFID></OwnerSSFID> <OwnerRole>RR Executive - IUC</OwnerRole>
		// <RestSLA>200</RestSLA> <Offset>8100</Offset> </Milestone> "
		//		+ "<Milestone ScenarioMilestoneID='12'> <Name>Input Files
		// Recieved</Name> <Type>Normal</Type> <Order>1</Order> <ID>1</ID>
		// <OwnerSSFID></OwnerSSFID> <OwnerRole>ABC</OwnerRole>
		// <RestSLA></RestSLA><Offset>8100</Offset> </Milestone > "
		//		+ "<Milestone ScenarioMilestoneID='13'> <Name>Input Files
		// Recieved</Name> <Type>Approval</Type> <Order>1</Order> <ID>1</ID>
		// <OwnerSSFID></OwnerSSFID> <OwnerRole>PC FA Manager</OwnerRole>
		// <RestSLA>0</RestSLA> <Offset>8100</Offset></Milestone >"
		//		+ "</MilestoneDetails>";

	}
}