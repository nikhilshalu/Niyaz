/*
 * Created on Jun 29, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations.util.dto;

/**
 * @author Suneha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class UserProfileDTO {
	
	private String userID;
	private String userSSFID;
	/**
	 * @return Returns the supervisorSSFID.
	 */
	public String getSupervisorSSFID() {
		return supervisorSSFID;
	}
	private String userFullName;
	private String userEmailID;
	private String supervisorSSFID;

	/**
	 * @return Returns the userEmailID.
	 */
	public String getUserEmailID() {
		return userEmailID;
	}
	/**
	 * @param userEmailID The userEmailID to set.
	 */
	public void setUserEmailID(String userEmailID) {
		this.userEmailID = userEmailID;
	}
	/**
	 * @return Returns the userFullName.
	 */
	public String getUserFullName() {
		return userFullName;
	}
	/**
	 * @param userFullName The userFullName to set.
	 */
	public void setUserFullName(String userFullName) {
		this.userFullName = userFullName;
	}

	/**
	 * @param supervisorSSFID The supervisorSSFID to set.
	 */
	public void setSupervisorSSFID(String supervisorSSFID) {
		this.supervisorSSFID = supervisorSSFID;
	}
	/**
	 * @return Returns the userSSFID.
	 */
	public String getUserSSFID() {
		return userSSFID;
	}
	/**
	 * @param userSSFID The userSSFID to set.
	 */
	public void setUserSSFID(String userSSFID) {
		this.userSSFID = userSSFID;
	}
	/**
	 * @return Returns the userID.
	 */
	public String getUserID() {
		return userID;
	}
	/**
	 * @param userID The userID to set.
	 */
	public void setUserID(String userID) {
		this.userID = userID;
	}
}
