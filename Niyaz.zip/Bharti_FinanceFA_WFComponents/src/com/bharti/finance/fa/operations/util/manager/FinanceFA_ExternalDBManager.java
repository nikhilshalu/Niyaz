/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations.util.manager;

import java.io.StringReader;
import java.io.StringWriter;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;
import java.util.StringTokenizer;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.fa.common.operations.util.manager.ExternalDBManager;
import com.bharti.finance.fa.operations.FinanceFAOperations;
import com.bharti.finance.fa.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.operations.util.FinanceFA_Utilities;
import com.bharti.finance.fa.operations.util.beans.UserDetailsBean;

/**
 * @author Harisha
 *  
 */
public class FinanceFA_ExternalDBManager extends ExternalDBManager {

	public static Logger log = Logger
			.getLogger(FinanceFA_ExternalDBManager.class);

	Connection dbconn = null;

	FinanceFA_CacheDBManager cache;

	public FinanceFA_ExternalDBManager(int application) {
		super(application);

	}

	/*
	 * @see com.bharti.fr.common.operations.util.manager.ExternalDBManager#getDbConnection()
	 *      Connects to the database using the credentials mentioned in the
	 *      property file
	 */
	public Connection getDbConnection() {
		log.debug("[Entry getDbConnection]");

		String db2URL = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_URL"));
		String db2User = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_ID"));
		String db2pwd = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_PASSWORD"));

		dbconn = getDbConnection(db2URL, db2User, db2pwd);
		log.debug("[Exit getDbConnection]");
		return dbconn;
	}

	public void updateUserArray(String currentUserSSFID,
			String currentUserRole, String[] milestoneRoles,
			String[] mileStonesUsersSSFID, int currentMilestoneNo)
			throws Exception {
		log.debug("Entry Finance_ExternalDBManager : updateUserArray method ");
		String strUsersfromDB = null;
		CallableStatement proc_stmt = null;
		String firstRole = null;
		LinkedHashMap hmUsers = new LinkedHashMap();
		String strUserRole = null;
		String strUserSSFID = null;

		//Call SP Starts
		// Call a Stored Procedure which takes UserSSFID, UserRole as IN
		// parameters and will return a String
		// of the format
		// UserRole:UserSSFID|UserSupervisiorRole:UserSupervisiorSSFID|...

		proc_stmt = dbconn.prepareCall("{ call FA_GET_USERS_DETAILS(?,?,?) }");

		proc_stmt.setString(1, currentUserSSFID);
		proc_stmt.setString(2, currentUserRole);
		proc_stmt.registerOutParameter(3, Types.VARCHAR);
		proc_stmt.execute();

		strUsersfromDB = proc_stmt.getString(3);

		log.debug("User list from Database : " + strUsersfromDB);

		//Call SP Ends

		//Break the String fetched from SP and put it in HashTable

		String delimiters = "[|]";
		int[] limits = { 0 };
		for (int limit = 0; limit < limits.length; limit++) {
			String[] tokens = strUsersfromDB.split(delimiters, limit);
			String[] token = tokens;
			for (int i = 0; i < token.length; i++) {
				firstRole = token[i];
				log.debug("User Details : " + firstRole);

				String strsecdelimiters = "[:]";
				int[] limits1 = { 0 };
				for (int limit1 = 0; limit1 < limits1.length; limit1++) {
					String[] tokens1 = firstRole
							.split(strsecdelimiters, limit1);
					String[] token1 = tokens1;
					strUserRole = token1[0];
					log.debug("user Role : " + strUserRole);
					strUserSSFID = token1[1];
					log.debug("user SSFID : " + strUserSSFID);
				}
				hmUsers.put(strUserRole, strUserSSFID);
			}

		}

		// Break the String fetched from SP and put it in HashTable ENDS

		// Check the array of Roles starting from currentMilestoneNo. If
		// the roles are found in this array compare
		// to what we have got from SP then put the SSFID corresponding
		// to that role in mileStonesUsersSSFID.

		for (int k = currentMilestoneNo - 1; k < milestoneRoles.length; k++) {
			Set keySet = hmUsers.keySet();
			Iterator it = keySet.iterator();
			while (it.hasNext()) {
				String key = (String) it.next();
				String element = (String) hmUsers.get(key);
				//				String value = hmUsers.get(key).toString();

				if (milestoneRoles[k].trim().equalsIgnoreCase(key.trim())) {
					mileStonesUsersSSFID[k] = element;
					break;
				}

			}
		}
		log.debug("Exit Finance_ExternalDBManager : updateUserArray method ");

	}

	public HashMap getUserDetails() throws Exception {

		log.debug("Entry getUserDetails()");
		log.debug("Entry FinanceAP_ExternalDBManager : getUserDetails method ");
		if(cache == null)
		    cache = new FinanceFA_CacheDBManager(Constants.APPLICATION_STANDALONE);
		log.debug("Exit getUserDetails()");
	    return cache.getUserDetails();
	}


		
	
	public Hashtable getUserDetails(String userSSFID) throws Exception {

		log.debug("Entry getUserDetails ( userSSFID [ " + userSSFID + "] )");

		Hashtable htWFFields = new Hashtable();
		UserDetailsBean users;
		HashMap usersMap = new HashMap();

		if (cache == null) {
			cache = new FinanceFA_CacheDBManager(
					Constants.APPLICATION_STANDALONE);
		}

		usersMap = cache.getUserDetails();

		if (usersMap.containsKey(userSSFID.trim().toLowerCase())) {
			users = (UserDetailsBean) usersMap.get(userSSFID.toLowerCase()
					.trim());
			htWFFields.put("FnFA_CMilestoneOwnerSSFID",
					users.getUserSSFId() != null ? users.getUserSSFId()
							.toUpperCase() : "");
			htWFFields.put("FnFA_CMilestoneOwnerName",
					users.getUserName() != null ? users.getUserName() : "");
			htWFFields.put("FnFA_CMilestoneOwnerEmailID",
					users.getUserMailId() != null ? users.getUserMailId() : "");

			if (users.getSupervisorSSFId() == null
					|| users.getSupervisorSSFId().trim().equals("")) {
				log.warn("No supervisor is mapped to the user [" + userSSFID
						+ "]; as Supervisor SSFID is empty.");
			}
			htWFFields.put("FnFA_UserSupervisorSSFID", users
					.getSupervisorSSFId() != null ? users.getSupervisorSSFId()
					.toUpperCase() : "");
			htWFFields.put("FnFA_UserSupervisorName",
					users.getSupervisorName() != null ? users
							.getSupervisorName() : "");
			htWFFields.put("FnFA_UserSupervisorEmailID", users
					.getSupervisorMailId() != null ? users
					.getSupervisorMailId() : "");
		} else {
			log.error("User with SSFID : [" + userSSFID + "] doesn't exist");
		}

		log.debug("Total fields fetched : " + htWFFields.size());
		log.debug("Records Fetched are : " + htWFFields.toString());

		log.debug("Exit getUserDetails ( userSSFID [ " + userSSFID + "] )");
		return htWFFields;
	}

	/**
	 * This method is called from getEscalationDetails. It splits the string
	 * into roles and maild ids and save it in a HashMap
	 * 
	 * @param strField :
	 *            String to be split. It is of the following format:
	 *            ([MailID1],[MailId2],...,Role1,Role2,...)
	 * @return
	 */
	private HashMap splitString(String strField) {
		log.debug("[Enter splitString]");
		HashMap hm = new HashMap();

		//		String delimiter = ",";
		StringTokenizer st = new StringTokenizer(strField, ",");
		ArrayList mails = new ArrayList();
		ArrayList roles = new ArrayList();
		while (st.hasMoreTokens()) {
			String token = st.nextToken().trim();
			log.debug("Token " + token);
			if (token.indexOf('[') != -1) {
				int startIndex = token.indexOf('[') + 1;
				int endIndex = token.indexOf(']');
				String value = token.substring(startIndex, endIndex);
				mails.add(value.trim());

			} else {

				roles.add(token);
			}
		}
		String[] strMails = new String[mails.size()];
		mails.toArray(strMails);
		log.debug("Mails :: " + Utilities.displayArray(strMails));
		hm.put("Mails", strMails);
		String[] strRoles = new String[roles.size()];
		roles.toArray(strRoles);
		log.debug("Roles :: " + Utilities.displayArray(strRoles));
		hm.put("Roles", strRoles);
		log.debug("htOutput:" + hm.toString());

		log.debug("Exit Finance_ExternalDBManager : splitString method ");
		return hm;
	}

	public Hashtable getNotificationDetails(String userSSFID, String userRole,
			int notificationLevel, String notificationType,
			String notificationCategory, String to, String cc, String bcc)
			throws Exception {
		log.debug("[Enter getNotificationDetails]");
		String strQuery = null;
		Statement stmt = null;
		String userMail = "";
		String tempUserMail = "";
		String userID = "";
		String userName = "";
		String strUserRole = "";
		String strUserSSFID = "";
		String where = "";
		String mailsCC = "";
		String mailsBCC = "";
		String mailsTO = "";
		String[] rolesTO = new String[] {};
		String[] rolesCC = new String[] {};
		String[] rolesBCC = new String[] {};
		String[] tempMails = null;
		Integer userTypeId = new Integer(-1);

		if (!notificationCategory.equalsIgnoreCase(Constants.STRPROCESS)) {
			log.debug("The request is not for process timer expiration");

			if (notificationType.equalsIgnoreCase(Constants.STRING_ESCALATION)) {
				log.debug("Component called for Escalation");
				if (userSSFID != null && !("".equals(userSSFID))) {

					/*
					 * When user is not null and Notification is escalation then
					 * check the escalation level
					 */
					if (notificationLevel == 1) {

						// Query to fetch data of supervisor
						strQuery = "select supervisor.name as supervisor_ssfid, supervisor.user_attr_2 as supervisor_mailid ,supervisor.user_id as user_id, supervisor.full_name as supervisorname "
								+ " FROM FN_FA_TBL_CMT_USER user,FN_FA_TBL_CMT_USER supervisor"
								+ " where user.active = 1 and user.system <> 1 and  supervisor.USER_ID=user.REPORTSTO_USER_ID and  user.name= "
								+ "'" + userSSFID + "'";

						log
								.debug("Escalation 1 has happened and user is not null (so query will be called to get data of tagged user supervisor):: the related query is "
										+ strQuery);
						stmt = dbconn.createStatement();
						ResultSet rs = null;
						rs = stmt.executeQuery(strQuery);
						while (rs.next()) {
							log.debug("Inside rs.next");
							strUserSSFID = rs.getString("supervisor_ssfid");
							log.debug("supervisor_ssfid : " + strUserSSFID);
							userMail = rs.getString("supervisor_mailid") + ",";
							log.debug("supervisor_mailid : " + userMail);
							userID = rs.getString("user_id");
							log.debug("user_id : " + userID);
							userName = rs.getString("supervisorname");
							log.debug("supervisorname : " + userName);
							// ORG_HIERARCHY is a global Hashtable which gets
							// populated in the constructor of the class.

							Set keySet = FinanceFAOperations.ORG_HIERARCHY
									.keySet();
							Iterator it = keySet.iterator();

							// It stores (UserRole, Supervisor Role) as key
							// value pair.
							// Get the Supervisor role
							while (it.hasNext()) {
								String key = (String) it.next();
								log.debug("Key :: " + key);
								if (key.equalsIgnoreCase(userRole)) {
									strUserRole = (String) FinanceFAOperations.ORG_HIERARCHY
											.get(key);
									log.debug("supervisor role :: "+strUserRole);
									break;
								}
							}
						}
						//						log.info(scenariosMap.size() + " row(s) retrieved
						// from database");

					} else if (notificationLevel == 2) {

						// Query to fetch data of Supervisor's supervisor
						strQuery = "select super.name as super_ssfid, super.user_attr_2 as super_mailid , super.user_id as user_id, super.full_name as supername"
								+ " FROM FN_FA_TBL_CMT_USER user,FN_FA_TBL_CMT_USER supervisor , FN_FA_TBL_CMT_USER super where "
								+ " user.active = 1 and user.system <> 1 and  supervisor.USER_ID=user.REPORTSTO_USER_ID and super.user_id = supervisor.REPORTSTO_USER_ID and user.name= '"
								+ userSSFID + "'";
						log
								.debug("Escalation 2 has happened and user is not null (so query will be called to get data of tagged user supervisor's supervisor):: the related query is "
										+ strQuery);
						stmt = dbconn.createStatement();
						ResultSet rs = null;
						rs = stmt.executeQuery(strQuery);
						while (rs.next()) {
							log.debug("in Resultset");
							strUserSSFID = rs.getString("super_ssfid");
							log.debug("supervisor's supervisor ssfid :: " + strUserSSFID);
							userMail = rs.getString("super_mailid") + ",";
							log.debug("supervisor's supervisor mailid :: " + userMail);
							userID = rs.getString("user_id");
							log.debug("supervisor's supervisor user_id :: " + userID);
							userName = rs.getString("supername");
							log.debug("supervisor's supervisor name :: " + userName);
							for (int i = 0; i < notificationLevel; i++) {
								Set keySet = FinanceFAOperations.ORG_HIERARCHY
										.keySet();
								Iterator it = keySet.iterator();
								while (it.hasNext()) {
									String key = (String) it.next();
									log.debug("Key :: " + key);
									if (key.equalsIgnoreCase(userRole)) {
										userRole = (String) FinanceFAOperations.ORG_HIERARCHY
												.get(key);
										break;
									}
								}
								strUserRole = userRole;
							}
						}
					}
					log.debug("The escalation notification should go to User SSFID  = " + strUserSSFID
							+ ",  userMail = " + userMail + ", userID = "
							+ userID + ", userName = " + userName
							+ ", UserRole = " + strUserRole);
				} else if (userSSFID == null || "".equals(userSSFID)) {
					// If neither the user nor the role is present then log an
					// error
					if (userRole == null)
						log
								.error("Unable to get the notification details; as No User is Tagged also No Role is Tagged.");
					else {
						/*
						 * When user is null and Notification is escalation then
						 * check the escalation level When UserSSFID is null
						 */
						if (notificationLevel == 1) {
							log.debug("Escalation 1 has happened for this case");
							Set keySet = FinanceFAOperations.ORG_HIERARCHY
									.keySet();
							Iterator it = keySet.iterator();
							while (it.hasNext()) {
								String key = (String) it.next();
								log.debug("Key :: " + key);
								if (key.equalsIgnoreCase(userRole)) { // Get
									// Supervisor
									// from
									// hashtable
									userRole = (String) FinanceFAOperations.ORG_HIERARCHY
											.get(key);
									break;
								}
							}
							strUserRole = userRole.trim();
						} else if (notificationLevel == 2) {
							log.debug("Escalation 2 has happened for this case");
							for (int i = 0; i < notificationLevel; i++) {
								Set keySet = FinanceFAOperations.ORG_HIERARCHY
										.keySet(); // Get Supervisior's
								// Supervisor
								// from hashtable
								Iterator it = keySet.iterator();
								while (it.hasNext()) {
									String key = (String) it.next();
									log.debug("Key :: " + key);
									if (key.equalsIgnoreCase(userRole)) {
										userRole = (String) FinanceFAOperations.ORG_HIERARCHY
												.get(key);
										break;
									}
								}
								strUserRole = userRole.trim();
							}
						}
						log.debug("Role to which escalation should go is  :: "+strUserRole);
						log.debug("Now checking the emailids set on this role : "+strUserRole);
						strQuery = "select user.user_attr_2 emailid from FN_FA_TBL_CMT_USER user, (select securityprofile.profile,securityprofile.security_profile_id , userprofile.user_id "
								+ " from FN_FA_TBL_CMT_USERPROFILE userprofile , FN_FA_TBL_CMT_SECURITYPROFILE securityprofile where userprofile.security_profile_id = securityprofile.security_profile_id and securityprofile.profile='"
								+ userRole.trim()
								+ "') as ID where user.USER_ID = ID.USER_ID and user.active = 1 and user.system <> 1 ";
						log.debug("The user is not tagged to this case , so the query to find emails of the role ["+strUserRole+"] when user is not tagged is:: "
								+ strQuery);
						stmt = dbconn.createStatement();
						ResultSet rs = null;
						rs = stmt.executeQuery(strQuery);
						while (rs.next()) {
							userMail = userMail + rs.getString("emailid") + ",";
							log.debug("fetched emailids from the query:: " + userMail);
						}
						tempUserMail = userMail; // When user is null then in
						// TO
						// MailID field the Role
						// will come (here Supervisor's Supervisor Role as level
						// =2)
					}
				}

			} else if (notificationType
					.equalsIgnoreCase(Constants.STRING_REMINDER)) {
				// In Reminder when user is not null then user's Profile will
				// come

				log.debug("Case is of Reminder");
				if (userSSFID != null && !("".equals(userSSFID))) {
					strQuery = " select user.user_attr_2, user.user_Id , user.full_name from FN_FA_TBL_CMT_USER user"
							+ " where user.active = 1 and user.system <> 1 and user.name='"
							+ userSSFID + "'";
					log.debug("QUERY of Reminder when user is tagged with case:: "
							+ strQuery);
					stmt = dbconn.createStatement();
					ResultSet rs = null;
					rs = stmt.executeQuery(strQuery);
					//					Hashtable htWFFields = new Hashtable();
					while (rs.next()) {
						log.debug("in result set");
						strUserSSFID = userSSFID;
						strUserRole = userRole;
						userMail = userMail + rs.getString("user_attr_2") + ",";
						userName = rs.getString("full_name");
						userID = rs.getString("user_Id");
						log.debug("Email id :: " + userMail);
						log.debug("full_name :: " + userName);
						log.debug("user_Id :: " + userID);
					}
				} else if (userSSFID == null || "".equals(userSSFID)) {
					log.debug("User is not tagged and the type is Reminder, so the query  will fetch the emailids of the given roles");
					// In Reminder when user is null then in TO MailID Field
					// User Role will come and rest of the profile fields will
					// not
					// be populated.
					// Also the MailID of the user Role will be appended in the
					// TO
					// field
					if (userRole == null)
						log
								.error("Unable to get the notification details; as No User is Tagged also No Role is Tagged.");
					else {
						strQuery = "select user.user_attr_2 emailid from FN_FA_TBL_CMT_USER user, (select securityprofile.profile,securityprofile.security_profile_id , userprofile.user_id "
								+ " from FN_FA_TBL_CMT_USERPROFILE userprofile , FN_FA_TBL_CMT_SECURITYPROFILE securityprofile where userprofile.security_profile_id = securityprofile.security_profile_id and securityprofile.profile='"
								+ userRole
								+ "') as ID where user.USER_ID = ID.USER_ID and user.active = 1 and user.system <> 1 ";
						log.debug("QUERY of Reminder when no user is not tagged to the case: "
								+ strQuery);
						stmt = dbconn.createStatement();
						ResultSet rs = null;
						rs = stmt.executeQuery(strQuery);
						while (rs.next()) {
							userMail = userMail.trim() 
									+ rs.getString("emailid") + ",";							
							strUserRole = userRole.trim();
						}
						log.debug("fetched emailIds of the role :: ["+userRole+"] are ::: " + userMail);
						tempUserMail = userMail;
					}
				}
			}

			log.debug("Getting the User type id for the role [" + strUserRole
					+ "]");
			if (strUserRole != null && !strUserRole.equals("")) {
				userTypeId = getUserTypeIdForRole(strUserRole);
				log.debug("UserType_Id is [" + userTypeId + "]");
			} else {
				log.info("Unable to get the User type id; as user role is null or blank.");
			}
		}
		log.debug("strUserSSFID = " + strUserSSFID + ", strUserRole = "
				+ strUserRole + ", userID = " + userID + ", userMail = "
				+ userMail + " , userName" + userName + ", tempUserMail = "
				+ tempUserMail);

		// Now check the TO, CC and BCC fields and split the fields accordingly
		if ((to != null) && !(to.trim().equals(""))) {
			log.debug("to is not Null so going in Split Function");

			// splitString method is called in all the three TO, CC, BCC
			// fields which breaks the string and sends hashmap with
			// key,value as (mails array,Roles array)

			HashMap hmTO = splitString(to);
			////// String where = "";

			Object obj = hmTO.get("Mails");
			if ((obj instanceof String[])) {
				tempMails = (String[]) obj;
			}
			log
					.debug("tempMails of TO :: "
							+ Utilities.displayArray(tempMails));
			for (int i = 0; i < tempMails.length; i++) {
				mailsTO = mailsTO + tempMails[i] + ",";
			}

			Object objRoles = hmTO.get("Roles");
			if ((objRoles instanceof String[])) {
				rolesTO = (String[]) objRoles;
			}
			log.debug("Roles of To :: " + Utilities.displayArray(rolesTO));
			log.debug("After To Split");
		}

		if ((cc != null) && !(cc.trim().equals(""))) {
			log.debug("CC is not Null so going in Split Function");
			HashMap hmCC = splitString(cc);

			Object obj = hmCC.get("Mails");
			if ((obj instanceof String[])) {
				tempMails = (String[]) obj;
			}
			log.debug("tempMails :: " + Utilities.displayArray(tempMails));
			for (int l = 0; l < tempMails.length; l++)
				mailsCC = mailsCC + tempMails[l] + ",";

			Object objRoles = hmCC.get("Roles");
			if ((objRoles instanceof String[])) {
				rolesCC = (String[]) objRoles;
			}
			log.debug("Roles of CC :: " + Utilities.displayArray(rolesCC));
			log.debug("After CC Split");

		}

		if ((bcc != null) && !(bcc.trim().equals(""))) {
			log.debug("BCC is not Null so going in Split Function");
			HashMap hmBCC = splitString(bcc);

			Object obj = hmBCC.get("Mails");
			if ((obj instanceof String[])) {
				tempMails = (String[]) obj;
			}
			log.debug("tempMails BCC:: " + Utilities.displayArray(tempMails));
			for (int l = 0; l < tempMails.length; l++)
				mailsBCC = mailsBCC + tempMails[l] + ",";

			Object objRoles = hmBCC.get("Roles");
			if ((objRoles instanceof String[])) {
				rolesBCC = (String[]) objRoles;
			}
			log.debug("Roles BCC :: " + Utilities.displayArray(rolesBCC));

			log.debug("After BCC Split");
		}
		// Now split the roles of TO if any and create the where clause
		if ((to != null) && !(to.trim().equals(""))) {
			log.debug("Length of roles in  TO field :: " + rolesTO.length);
			if (rolesTO.length > 0) {
				for (int k = 0; k < rolesTO.length; k++) {

					log.debug("Roles in TO:: " + rolesTO[k]);
					if (!(rolesTO[k].equalsIgnoreCase(""))) {

						//This IF block is used to create the where clause if
						// CC present BCC present
						// or nothing is present

						if (k < rolesTO.length - 1) {
							log.debug("in iFF");
							where = where + " securityprofile.profile='"
									+ rolesTO[k] + "' or ";
						} else {
							if ((cc != null && rolesCC.length > 0)
									|| (bcc != null && rolesBCC.length > 0))
								where = where + " securityprofile.profile='"
										+ rolesTO[k] + "' or ";
							else
								where = where + "securityprofile.profile='"
										+ rolesTO[k] + "'";
						}
					}

				}
			}
		}
		log.debug("where clause TO :: " + where);

		// Now split the roles of CC if any and create the where clause
		if ((cc != null) && !(cc.trim().equals(""))) {
			log.debug("Length of roles in  CC field :: " + rolesCC.length);
			if (rolesCC.length > 0) {
				for (int i = 0; i < rolesCC.length; i++) {

					log.debug("Roles in CC :: " + rolesCC[i]);
					if (!(rolesCC[i].equalsIgnoreCase(""))) {

						//	This IF block is used to create the where clause if
						// BCC present
						// or nothing is present
						if (i < rolesCC.length - 1) {
							log.debug("in iFF");
							where = where + "  securityprofile.profile='"
									+ rolesCC[i] + "' or ";
						} else {
							if ((bcc != null && rolesBCC.length > 0))
								where = where + "  securityprofile.profile='"
										+ rolesCC[i] + "' or ";
							else
								where = where + "securityprofile.profile='"
										+ rolesCC[i] + "'";
						}
					}
				}
			}
		}
		log.debug("where clause CC :: " + where);

		// Now split the roles of CC if any and create the where clause

		if ((bcc != null) && !(bcc.trim().equals(""))) {
			log.debug("Length of roles in  BCC field :: " + rolesBCC.length);
			if (rolesBCC.length > 0) {
				for (int i = 0; i < rolesBCC.length; i++) {
					log.debug("Roles in BCC :: " + rolesBCC[i]);
					if (!(rolesBCC[i].equalsIgnoreCase(""))) {

						// This IF block is used to create the where clause
						if (i < rolesBCC.length - 1) {
							log.debug("in iFF");
							where = where + " securityprofile.profile='"
									+ rolesBCC[i] + "' or ";
						} else {
							where = where + "securityprofile.profile='"
									+ rolesBCC[i] + "'";
						}
					}
				}
			}
		}
		log.debug("where clause BCC :: " + where);

		if (!(where.equalsIgnoreCase(""))) {
			strQuery = "select user.user_attr_2 emailid,ID.role userrole from FN_FA_TBL_CMT_USER user, (select securityprofile.profile Role,securityprofile.security_profile_id ,"
					+ " userprofile.user_id from FN_FA_TBL_CMT_USERPROFILE userprofile , FN_FA_TBL_CMT_SECURITYPROFILE securityprofile"
					+ " where userprofile.security_profile_id = securityprofile.security_profile_id and ("
					+ where
					+ ") ) as ID"
					+ " where user.USER_ID = ID.USER_ID and user.active = 1 and user.system <> 1";
			log.debug("QUERY of TO,CCand BCC :: " + strQuery);
			ResultSet rs = null;
			stmt = dbconn.createStatement();
			rs = stmt.executeQuery(strQuery);
			while (rs.next()) {
				String userrole = rs.getString("userrole");
				String mailIDs = rs.getString("emailid");
				log.debug("userrole :: " + userrole + " and emailid :::  "
						+ mailIDs);

				// Here we are checking whether the roles which are fetched from
				// query is there in TO, CC or BCC fields
				// IF the role is there in TO, CC or BCC fields then add the
				// emailID in that field

				if (to != null) {
					for (int j = 0; j < rolesTO.length; j++) {
						if (rolesTO[j].equalsIgnoreCase(userrole)
								&& mailIDs != null) {
							mailsTO = mailsTO + mailIDs + ",";
							break;
						}

					}
				}
				if (cc != null) {
					for (int i = 0; i < rolesCC.length; i++) {
						if (rolesCC[i].equalsIgnoreCase(userrole)
								&& mailIDs != null) {
							mailsCC = mailsCC + mailIDs + ",";
							break;
						}

					}
				}
				if (bcc != null) {
					for (int j = 0; j < rolesBCC.length; j++) {
						if (rolesBCC[j].equalsIgnoreCase(userrole)
								&& mailIDs != null) {
							mailsBCC = mailsBCC + mailIDs + ",";
							break;
						}

					}
				}
			}
		}

		/* Remove the last trailing comma */
		if (userMail != null && !userMail.trim().equals("")) {
			userMail = userMail.substring(0, userMail.length() - 1);
			log.debug("After removing the last comma userMail:" + userMail);
		}
		if (mailsTO != null && !mailsTO.trim().equals("")) {
			mailsTO = mailsTO.substring(0, mailsTO.length() - 1);
			log.debug("After removing the last comma mailsTO:" + mailsTO);
		}
		if (mailsCC != null && !mailsCC.trim().equals("")) {
			mailsCC = mailsCC.substring(0, mailsCC.length() - 1);
			log.debug("After removing the last comma mailsCC:" + mailsCC);
		}
		if (mailsBCC != null && !mailsBCC.trim().equals("")) {
			mailsBCC = mailsBCC.substring(0, mailsBCC.length() - 1);
			log.debug("After removing the last comma mailsBCC:" + mailsBCC);
		}

		log.debug("Final mails USERSSFID :" + userMail);
		log.debug("Final mails  TO : " + userMail + mailsTO);
		log.debug("Final mails  CC : " + mailsCC);
		log.debug("Final mails  BCC : " + mailsBCC);
		log.debug("userRole " + userRole);

		//Code to find the mail mode type
		Hashtable htWFFields = new Hashtable();
		if (!notificationCategory.equalsIgnoreCase(Constants.STRPROCESS)) {
			// For Milestone, query or request
			if ((userSSFID != null) && (!userSSFID.trim().equals(""))) {
				htWFFields.put("FnFA_ToSSFID", strUserSSFID);
				htWFFields.put("FnFA_ToName", userName);
				htWFFields.put("FnFA_ToMailID", userMail);
				htWFFields.put("FnFA_ToUserType", userTypeId);
				htWFFields.put("FnFA_ToRole", strUserRole.trim());
			} else if ((userSSFID == null) || (userSSFID.trim().equals(""))) {
				htWFFields.put("FnFA_ToMailID", strUserRole); // Add user Role
				// in
				// MailID,
				// Name, and
				// Role field when user is not tagged
				htWFFields.put("FnFA_ToName", strUserRole.trim());
				htWFFields.put("FnFA_ToRole", strUserRole.trim());
				htWFFields.put("FnFA_ToUserType", userTypeId);
			}
		} else {

			// For Process
			htWFFields.put("FnFA_ToSSFID", "");
			htWFFields.put("FnFA_ToName", "");
			htWFFields.put("FnFA_ToMailID", mailsTO);

			// In the case of Process no need
			htWFFields.put("FnFA_ToUserType", new Integer(-1));
			htWFFields.put("FnFA_ToRole", "");
		}

		// Stores the both email id of userMail and mailsTO seperated by comma
		String strTo = "";
		if ((userMail == null || userMail.trim().equals(""))) {
			strTo = mailsTO;
		} else if ((mailsTO == null || mailsTO.trim().equals(""))) {
			strTo = userMail;
		} else {
			strTo = userMail + "," + mailsTO;
		}

		htWFFields.put("To", strTo);
		htWFFields.put("CC", mailsCC);
		htWFFields.put("BCC", mailsBCC);
		log.debug("Records set in PE are :: " + htWFFields.toString());
		log.debug("[Exit getNotificationDetails]");
		return htWFFields;
	}

	/**
	 * This method gets notification details (like to,cc,bcc...) for Relative
	 * Process
	 * 
	 * @param userRole
	 * @return notificationArray
	 */

	public String[] getNotificationDetails_LR(String userSSFID,
			String userRole, int notificationLevel, String notificationType,
			String notificationCategory, String to, String cc, String bcc)
			throws Exception {
		log.debug("[Enter getNotificationDetails_LR]: userSSFID [" + userSSFID
				+ "] userRole [" + userRole + "] notificationLevel ["
				+ notificationLevel + "] notificationType [" + notificationType
				+ "] notificationCategory [" + notificationCategory + "] to ["
				+ to + "] cc [" + cc + "] bcc [" + bcc + "]");
		String userMail = "";
		String toMailId = "";
		String tempUserMail = "";
		String userName = "";
		String strUserRole = "";
		String strUserSSFID = "";
		String mailsCC = "";
		String mailsBCC = "";
		String mailsTO = "";
		String[] rolesTO = new String[] {};
		String[] rolesCC = new String[] {};
		String[] rolesBCC = new String[] {};
		String[] tempMails = null;
		String[] returnArray = new String[14];
		Utilities.initializeEmptyArray(returnArray);
		HashMap roleUser = new HashMap();
		HashMap usersMap = new HashMap();
		UserDetailsBean user = new UserDetailsBean();

		ArrayList usersArr = new ArrayList();
		
		log.debug("Getting the user details from cache");
		if (cache == null) {
			cache = new FinanceFA_CacheDBManager(
					Constants.APPLICATION_STANDALONE);
		}
		usersMap = cache.getUserDetails();
		log.debug("User details map is :" + usersMap);
		roleUser = cache.getRoleUserMapping();
		if (userSSFID != null) {
			userSSFID = userSSFID.toLowerCase().trim();
			log.info("User ssfid in lower case [" + userSSFID + "]");
		}
		
		/*
		 * below block gets executed ,if input xml's category is of milestone
		 *  
		 */
		if (!notificationCategory.equalsIgnoreCase(Constants.STRPROCESS)) {
			log.debug("Milestone timer has expired");
			log.debug("Milestone [" + notificationType
					+ "] (notification type) has expired");
			if (notificationType.equalsIgnoreCase(Constants.STRING_ESCALATION)) {
				log.debug("Getting the notification details for Escalation");
				if (userSSFID != null && !("".equals(userSSFID))) {
					
					/*
					 * When user is not null and Notification is escalation then
					 * 
					 * check the escalation level
					 */
					log.debug("Case is tagged to Agent [" + userSSFID + "]");
					log.info(notificationLevel
							+ " level escalation has expired");
					if (notificationLevel == 1) {
						/*
						 * First Escalation ?? then Get user's supervisor
						 * details
						 */
						log.debug("For first level escalation");	
						
						log.debug("Is user present in map "
								+ usersMap.containsKey(userSSFID));
						if(usersMap.containsKey(userSSFID)) {
							user = (UserDetailsBean) usersMap.get(userSSFID);
							log.debug("The details of user with ssfid ["
									+ userSSFID + "] from map is " + user);
							strUserSSFID = user.getSupervisorSSFId();
							toMailId = user.getSupervisorMailId();
							userName = user.getSupervisorName();
							log.info("User with ssfid [" + userSSFID
									+ "]'s supervisor's details are: name ["
									+ userName + "]  mail id [ " + toMailId
									+ "] Supervisor SSFID [  " + strUserSSFID
									+ "]");
							/*
							 * user supervisor ssfid found.. fetch user role
							 * names using SSFID.
							 */
							log.debug("Finding the supervisor role corresponding to user's role ["
									+ userRole
									+ "] from organization mapping table");
							strUserRole = (String) FinanceFAOperations.ORG_HIERARCHY
									.get(userRole);
							log.debug("User's supervisor role is ["
									+ strUserRole + "]");
						} else {
							log.info("User with ssfid ["+userSSFID+"] not present in cache database");
						}

					} else if (notificationLevel == 2) {
						
						/*
						 * Second Escalation ?? then Get user's supervisor
						 * details
						 */
						log.debug("For second level escalation");
						log.debug("Finding the supervisor of user ["+userSSFID+"]");
						if (usersMap
								.containsKey(userSSFID)) {
							user = (UserDetailsBean) usersMap.get(userSSFID);
							strUserSSFID = user.getSupervisorSSFId();
							log.debug("Supervisor of user [" + userSSFID
									+ "] is [" + strUserSSFID + "]");
							
							log.debug("Finding the second level supervisor of user ["
									+ strUserSSFID + "]");
							if (strUserSSFID != null
									&& usersMap.containsKey(strUserSSFID.trim()
											.toLowerCase())) {
								
								strUserSSFID = strUserSSFID.toLowerCase()
										.trim();
								user = (UserDetailsBean) usersMap
										.get(strUserSSFID);
								strUserSSFID = user.getSupervisorSSFId();
								log.debug("Second level Supervisor ssfid is ["
										+ strUserSSFID + "]");
								
								// Get supervisor's supervisor details
								if (usersMap.containsKey(strUserSSFID.trim()
										.toLowerCase())) {
									user = (UserDetailsBean) usersMap
											.get(strUserSSFID.trim()
													.toLowerCase());
									log.debug("Second level supervisor details is "
											+ user);
									toMailId = user.getUserMailId();
									userName = user.getUserName();
									
									/*
									 * fetch role of user's second level
									 * escalation
									 */
									log.debug("Finding the second level supervisor role corresponding to user's role ["
											+ userRole
											+ "] from organization mapping table");
									strUserRole = (String) FinanceFAOperations.ORG_HIERARCHY
											.get(userRole);
									strUserRole = (String) FinanceFAOperations.ORG_HIERARCHY
											.get(strUserRole);
									log.info("Second level supervisor role is "
											+ strUserRole);
								} else {
									log.info("Supervisor's supervisor doesn't exist for user ["
											+ userSSFID + "]");
								}
							} else {
								log.info("Supervisor doesn't exist with ssfid ["
										+ strUserSSFID + "]");
							}
						} else {
							log.error("User doesn't exist with ssfid ["
									+ userSSFID + "]");
						}
					}
					log.info("The escalation notification should go to User SSFID ["
							+ strUserSSFID
							+ "], Mail Id ["
							+ toMailId
							+ "], Name ["
							+ userName
							+ "], User Role ["
							+ strUserRole + "]");
				} else if (userSSFID == null || "".equals(userSSFID)) {
					
					/* If neither the user nor the role is present then log an error */
					log.debug("Case is not tagged to any user; as user ssfid is blank");
					if (userRole == null || userRole == "") {
						log.error("Unable to get the notification details; as No User is Tagged also No Role is Tagged.");
						throw new IllegalArgumentException(
								"Unable to get the notification details; as No User is Tagged also No Role is Tagged.");
					} else {
						/*
						 * When user is null and Notification is escalation then
						 * check the escalation level When UserSSFID is null
						 */
						log.debug("");
						if (notificationLevel == 1) {
							log.debug("For first level escalation");	
							log.debug("Notification should be sent to all user of first level supervisor role");
							log.debug("Finding the supervisor role corresponding to user's role ["
									+ userRole
									+ "] from organization mapping table");
							strUserRole = (String) FinanceFAOperations.ORG_HIERARCHY
									.get(userRole);
							log.debug("User's supervisor role is [" + strUserRole
									+ "]");
							log.debug("Getting all user's mail id corresponding to role ["
											+ strUserRole + "]");
							usersArr = (ArrayList) roleUser.get(strUserRole);
							toMailId = getAllUsersMailIdFromRole(usersArr);
							log.info("All user's mail id  is [" + toMailId
									+ "]");
						} else if (notificationLevel == 2) {
							log.debug("For second level escalation");	
							log.debug("Notification should be sent to all user of second level supervisor role");
							log.debug("Finding the supervisor role corresponding to user's role ["
									+ userRole
									+ "] from organization mapping table");
							
							// First level
							strUserRole = (String) FinanceFAOperations.ORG_HIERARCHY
									.get(userRole);
							log.debug("First level supervisor role is [" + strUserRole
									+ "]");
							
							// Second level
							strUserRole = (String) FinanceFAOperations.ORG_HIERARCHY
									.get(strUserRole);
							log.debug("Second level supervisor role is [" + strUserRole
									+ "]");
							log.debug("Getting all user's mail id corresponding to role ["
											+ strUserRole + "]");
							usersArr = (ArrayList) roleUser.get(strUserRole);
							toMailId = getAllUsersMailIdFromRole(usersArr);
							log.info("All user's mail id  is [" + toMailId
									+ "]");
						}
					}
				}

			} else if (notificationType
					.equalsIgnoreCase(Constants.STRING_REMINDER)) {
				// In Reminder when user is not null then user's Profile will
				// come

				log.debug("It is a reminder notification");
				if (userSSFID != null && !("".equals(userSSFID))) {

					log.debug("User ["+ userSSFID + "] is tagged to case");
					log.debug("Reminder should go to tagged user ["
							+ userSSFID + "]");
					user = (UserDetailsBean) usersMap.get(userSSFID);
					strUserSSFID = userSSFID;
					strUserRole = userRole;
					toMailId = toMailId + user.getUserMailId() + ",";
					userName = user.getUserName();
					log.info("The reminder notification should go to User SSFID ["
							+ userSSFID
							+ "], Mail Id ["
							+ toMailId
							+ "], Name ["
							+ userName
							+ "], User Role ["
							+ strUserRole + "]");
					
				} else if (userSSFID == null || "".equals(userSSFID)) {
					// In Reminder when user is null then in TO MailID Field
					// User Role will come and rest of the profile fields will
					// not
					// be populated.
					// Also the MailID of the user Role will be appended in the
					// TO
					// field
					log.debug("No User is tagged to case");
					if (userRole == null || userRole == "") {
						log
								.error("Unable to get the notification details; as No User is Tagged also No Role is Tagged.");
						throw new IllegalArgumentException(
								"Unable to get the notification details; as No User is Tagged also No Role is Tagged.");
					} else {
						log.debug("Reminder should go to all user with role ["
								+ userRole + "]");
						log.debug("Getting all user's mail id corresponding to role ["
								+ strUserRole + "]");
						usersArr = (ArrayList) roleUser.get(userRole);
						userMail = getAllUsersMailIdFromRole(usersArr);
						strUserRole = userRole;
						toMailId = userMail;
						log.info("The reminder notification should go to [Mail Id ["
								+ tempUserMail
								+ "], User Role ["
								+ strUserRole + "]");
					}
				}
			} else if (notificationType
					.equalsIgnoreCase(FinanceFA_Constants.STRING_SLA)) {

				log.debug("the request is for notification type SLA");
				//set notification type and category.
				//	returnArray[0] = notificationCategory;
				//	returnArray[1] = notificationType;

			} else {
				log.error("Input parameter notification type ["
						+ notificationType
						+ "] is not matching any predefined value.");
			}
		}
		log.info("The notification should go to User SSFID ["
				+ userSSFID
				+ "], userMail ["
				+ userMail
				+ "], Name ["
				+ userName
				+ "], User Role ["
				+ strUserRole + "], tempUserMail ["+tempUserMail+"]");		

		// Now check the TO, CC and BCC fields and split the fields accordingly
		if ((to != null) && !(to.trim().equals(""))) {
			log.debug("to is not Null so going in Split Function");

			// splitString method is called in all the three TO, CC, BCC
			// fields which breaks the string and sends hashmap with
			// key,value as (mails array,Roles array)

			HashMap hmTO = splitString(to);
			////// String where = "";

			Object obj = hmTO.get("Mails");
			if ((obj instanceof String[])) {
				tempMails = (String[]) obj;
			}
			log
					.debug("tempMails of TO :: "
							+ Utilities.displayArray(tempMails));
			for (int i = 0; i < tempMails.length; i++) {
				mailsTO = mailsTO + tempMails[i] + ",";
			}

			Object objRoles = hmTO.get("Roles");
			if ((objRoles instanceof String[])) {
				rolesTO = (String[]) objRoles;
			}
			log.debug("Roles of To :: " + Utilities.displayArray(rolesTO));
			log.debug("After To Split");
		}

		if ((cc != null) && !(cc.trim().equals(""))) {
			log.debug("CC is not Null so going in Split Function");
			HashMap hmCC = splitString(cc);

			Object obj = hmCC.get("Mails");
			if ((obj instanceof String[])) {
				tempMails = (String[]) obj;
			}
			log.debug("tempMails :: " + Utilities.displayArray(tempMails));
			for (int l = 0; l < tempMails.length; l++)
				mailsCC = mailsCC + tempMails[l] + ",";

			Object objRoles = hmCC.get("Roles");
			if ((objRoles instanceof String[])) {
				rolesCC = (String[]) objRoles;
			}
			log.debug("Roles of CC :: " + Utilities.displayArray(rolesCC));
			log.debug("After CC Split");

		}

		if ((bcc != null) && !(bcc.trim().equals(""))) {
			log.debug("BCC is not Null so going in Split Function");
			HashMap hmBCC = splitString(bcc);

			Object obj = hmBCC.get("Mails");
			if ((obj instanceof String[])) {
				tempMails = (String[]) obj;
			}
			log.debug("tempMails BCC:: " + Utilities.displayArray(tempMails));
			for (int l = 0; l < tempMails.length; l++)
				mailsBCC = mailsBCC + tempMails[l] + ",";

			Object objRoles = hmBCC.get("Roles");
			if ((objRoles instanceof String[])) {
				rolesBCC = (String[]) objRoles;
			}
			log.debug("Roles BCC :: " + Utilities.displayArray(rolesBCC));

			log.debug("After BCC Split");
		}
		// Now split the roles of TO if any and create the where clause
		if ((to != null) && !(to.trim().equals(""))) {
			log.debug("Length of roles in  TO field :: " + rolesTO.length);
			if (rolesTO.length > 0) {
				for (int k = 0; k < rolesTO.length; k++) {

					log.debug("Roles in TO:: " + rolesTO[k]);
					if (!(rolesTO[k].equalsIgnoreCase(""))) {
						usersArr = (ArrayList) roleUser.get(rolesTO[k]);
						String allMailIds = getAllUsersMailIdFromRole(usersArr);
						mailsTO = mailsTO + allMailIds;
					}
				}
			}
		}

		// Now split the roles of CC if any and create the where clause
		if ((cc != null) && !(cc.trim().equals(""))) {
			log.debug("Length of roles in  CC field :: " + rolesCC.length);
			if (rolesCC.length > 0) {
				for (int i = 0; i < rolesCC.length; i++) {

					log.debug("Roles in CC :: " + rolesCC[i]);
					if (!(rolesCC[i].equalsIgnoreCase(""))) {

						log.debug("Roles in CC:: " + rolesCC[i]);
						if (!(rolesCC[i].equalsIgnoreCase(""))) {
							usersArr = (ArrayList) roleUser.get(rolesCC[i]);
							log.info("usersArr.size() :" + usersArr);
							log.info("userMail :" + userMail);
							String allMailIds = getAllUsersMailIdFromRole(usersArr);
							mailsCC = mailsCC + allMailIds;
						}
					}
				}
			}
		}

		// Now split the roles of CC if any and create the where clause

		if ((bcc != null) && !(bcc.trim().equals(""))) {
			log.debug("Length of roles in  BCC field :: " + rolesBCC.length);
			if (rolesBCC.length > 0) {
				for (int i = 0; i < rolesBCC.length; i++) {
					log.debug("Roles in BCC :: " + rolesBCC[i]);
					if (!(rolesBCC[i].equalsIgnoreCase(""))) {

						log.debug("Roles in CC:: " + rolesBCC[i]);
						if (!(rolesBCC[i].equalsIgnoreCase(""))) {
							usersArr = (ArrayList) roleUser.get(rolesBCC[i]);
							String allMailIds = getAllUsersMailIdFromRole(usersArr);
							mailsBCC = mailsBCC + allMailIds;
						}
					}
				}
			}
		}

		// Remove last comma(,) from all the email id variable
		if (toMailId != null && !toMailId.trim().equals("")
				&& (toMailId.endsWith(",")))
			toMailId = removeCharAt(toMailId, toMailId.length() - 1);
		if (mailsTO != null && !mailsTO.trim().equals(""))
			mailsTO = removeCharAt(mailsTO, mailsTO.length() - 1);
		if (mailsCC != null && !mailsCC.trim().equals(""))
			mailsCC = removeCharAt(mailsCC, mailsCC.length() - 1);
		if (mailsBCC != null && !mailsBCC.trim().equals(""))
			mailsBCC = removeCharAt(mailsBCC, mailsBCC.length() - 1);

		log.debug("Final mails  TO : " + mailsTO);
		log.debug("Final mails  CC : " + mailsCC);
		log.debug("Final mails  BCC : " + mailsBCC);
		log.debug("userRole " + userRole);

		/*
		 * below block gets executed for MILESTONE
		 */
		if (!notificationCategory.equalsIgnoreCase(Constants.STRPROCESS)) {
			// For Milestone, query or request
			if ((userSSFID != null) && (!userSSFID.trim().equals(""))) {
				//htWFFields.put("ToSSFID", strUserSSFID);
				returnArray[6] = strUserSSFID.toUpperCase(); //ToSSFID
				//htWFFields.put("ToName", userName);
				returnArray[7] = userName; // ToName
				//htWFFields.put("ToRole", strUserRole);
				returnArray[8] = strUserRole; //ToRole
				//htWFFields.put("ToMailID", toMailId);
				returnArray[9] = toMailId; //ToMailId

			} else if ((userSSFID == null) || (userSSFID.trim().equals(""))) {
				returnArray[9] = toMailId; // ToMailId
				//htWFFields.put("ToMailID", toMailId);
				// Add user Role in
				// MailID,
				// Name, and
				// Role field when user is not tagged
				returnArray[7] = strUserRole; // ToName
				returnArray[8] = strUserRole; // ToRole
				//htWFFields.put("ToName", strUserRole);
				//htWFFields.put("ToRole", strUserRole);
			}
		}
		/*
		 * below block gets executed for PROCESS
		 */
		else {

			//notification level
			//	returnArray[2] = notificationLevel+"";

			returnArray[6] = ""; //ToSSFID
			//htWFFields.put("ToSSFID", "");

			returnArray[7] = ""; //ToName
			//htWFFields.put("ToName", "");

			returnArray[8] = ""; //ToRole
			//htWFFields.put("ToRole", "");

			returnArray[9] = ""; //ToMailID
			//htWFFields.put("ToMailID", mailsTO);

		}
				
		// Stores the both email id of userMail and mailsTO seperated by comma
		String strTo = "";
		if ((toMailId == null || toMailId.trim().equals(""))) {
			strTo = mailsTO;
		} else if ((mailsTO == null || mailsTO.trim().equals(""))) {
			strTo = toMailId;
		} else {
			strTo = toMailId + "," + mailsTO;
		}
		
		//htWFFields.put("To", mailsTO);
		//htWFFields.put("CC", mailsCC);
		//htWFFields.put("BCC", mailsBCC);
		// To
		returnArray[3] = strTo;
		// CC
		returnArray[4] = mailsCC;
		// BCC
		returnArray[5] = mailsBCC;
		FinanceFA_Utilities.displayArrayWithIndex(returnArray);
		log.debug("[Exit getNotificationDetails_LR]");
		return returnArray;
	}

	/**
	 * 
	 * @param usersArr -
	 *            array of users
	 * @return
	 * @throws Exception
	 */

	private String getAllUsersMailIdFromRole(ArrayList usersArr)
			throws Exception {
		log.debug("getAllUsersMailIdFromRole()");
		UserDetailsBean user = new UserDetailsBean();
		String strUserSSFID = null;
		String userMail = "";
		String message = null;
		HashMap usersMap = new HashMap();
		if (cache == null) {
			cache = new FinanceFA_CacheDBManager(
					Constants.APPLICATION_STANDALONE);
		}
		usersMap = cache.getUserDetails();
		
		if (usersArr == null || usersArr.size() == 0) {
			message = "users Array is empty,hence no user maiIDs to fetch";
			log.warn(message);
			return "";
		}
		
		for (int i = 0; i < usersArr.size(); i++) {
			try {
				strUserSSFID = (String) usersArr.get(i);
				log.info("getAllUsersMailIdFromRole() - UserSSFID:: "
						+ strUserSSFID);
				user = (UserDetailsBean) usersMap.get(strUserSSFID
						.toLowerCase().trim());
				log.info("getAllUsersMailIdFromRole() - UserMailID:: "
						+ user.getUserMailId());
				userMail = userMail
						+ (user.getUserMailId() == null ? "" : user
								.getUserMailId()) + ",";
			} catch (Exception ex) {
				log.error("Error occured while getting all mail id for role. User is not found in Cached map ["
						+ strUserSSFID + "] : " + ex);
			}
		}
		log.debug("getAllUsersMailIdFromRole()");
		return userMail;
	}

	/**
	 * 
	 * @param str-
	 *            string from which character to be removed
	 * @param pos
	 *            -position of the character in the string
	 * @return
	 */
	public String removeCharAt(String str, int pos) {
		return str.substring(0, pos) + str.substring(pos + 1);
	}

	/**
	 * @param userRole
	 * @return
	 */
	private Integer getUserTypeIdForRole(String userRole) {
		log.debug("[Enter getUserTypeIdForRole]");
		Integer userTypeId = new Integer(-1);
		boolean success = false;
		try {
			String sql = "SELECT USERTYPE_ID FROM FN_FA_TBL_USERTYPE_MASTER where USERTYPE_NAME = '"
					+ userRole + "'";
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next()) {
				userTypeId = new Integer(rs.getInt("USERTYPE_ID"));
				log.debug("UserType_Id is [" + userTypeId + "]");
			} else {
				log.error("No results found for userRole [" + userRole + "]");
			}
			success = true;
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for user type id for role ["
							+ userRole + "]" + sqlEx.getMessage(), sqlEx);
			success = false;
		} catch (Exception ex) {
			log.error(
					"Exception occured while searching for user type id for role ["
							+ userRole + "]" + ex.getMessage(), ex);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getUserTypeIdForRole]");
		return userTypeId;
	}

	public String updateUserSSFID_LR(String currentUserSSFID,
			String currentUserRole, int currentMilestoneArrayPointer,
			String milestoneXML) {
		log.debug("********************Entry updateUserSSFID_LR ********************");

		log.debug("currentUserSSFID ::: " + currentUserSSFID);
		log.debug("currentUserRole ::: " + currentUserRole);
		log.debug("currentMilestoneArrayPointer ::: "
				+ currentMilestoneArrayPointer);
		log.debug("MilestoneXML ::: " + milestoneXML);

		HashMap roleMap = new HashMap();
		UserDetailsBean users;
		String xmlString = null;
		String supervisorSSFID = null;
		String supervisorName = null;

		if (cache == null)
			cache = new FinanceFA_CacheDBManager(
					Constants.APPLICATION_STANDALONE);
	
		try {
			roleMap = cache.getUserDetails();
			//			log.debug("HashMap got from cache :: "+roleMap.toString());

			DocumentBuilderFactory docBuilderFactory = DocumentBuilderFactory
					.newInstance();
			DocumentBuilder docBuilder = docBuilderFactory.newDocumentBuilder();
			Document doc = docBuilder.parse(new InputSource(new StringReader(
					milestoneXML)));

			NodeList listOfMilestones = doc
					.getElementsByTagName(FinanceFA_Constants.MILESTONE_NODE);
			int totalMilestones = listOfMilestones.getLength();
			log.debug("Total no of milestones nodes in XML : "
					+ totalMilestones);

			//Iterate the Milestone XML nodes with this for loop
			log.debug("Iterating the first loop ");
			for (int s = 0; s < listOfMilestones.getLength(); s++) {

				Node milestoneNode = listOfMilestones.item(s);
				log.debug("For Node no. : " +(s+1)+" Name of milestone node :: "
						+ milestoneNode.getNodeName());

				/*
				 * When the node is greater or equal the current pointer Node
				 * then check its role and SSFID. If the current iteration is
				 * less then the current pointer then dont do any thing, just
				 * traverse ahead
				 */
				
				if (s >= currentMilestoneArrayPointer - 1
						&& milestoneNode.getNodeType() == Node.ELEMENT_NODE) {

					//Expand the current Milestone Node and get its Name, Type,
					// OwnerSSFID, OwnerRole Attributes

//					log.debug("This is the required : Node no. " + currentMilestoneArrayPointer
//							);
					users = (UserDetailsBean) roleMap.get(currentUserSSFID
							.trim().toLowerCase());
					Element milestoneElement = (Element) milestoneNode;

					NodeList milestoneNameList = milestoneElement
							.getElementsByTagName(FinanceFA_Constants.NAME_ATTRIBUTE);
					Element milestoneNameElement = (Element) milestoneNameList
							.item(0);

					NodeList textNameList = milestoneNameElement
							.getChildNodes();
					log.debug(" Name tag of this node : "
							+ ((Node) textNameList.item(0)).getNodeValue()
									.trim());

					NodeList milestoneTypeList = milestoneElement
							.getElementsByTagName(FinanceFA_Constants.TYPE_ATTRIBUTE);

					Element milestoneTypeElement = (Element) milestoneTypeList
							.item(0);

					NodeList textTypeList = milestoneTypeElement
							.getChildNodes();
					log.debug("Type tag of this Node : "
							+ ((Node) textTypeList.item(0)).getNodeValue()
									.trim());

					NodeList milestoneRoleList = milestoneElement
							.getElementsByTagName(FinanceFA_Constants.OWNER_ATTRIBUTE);
					Element milestoneRoleElement = (Element) milestoneRoleList
							.item(0);

					NodeList textRoleList = milestoneRoleElement
							.getChildNodes();
					if (((Node) textRoleList.item(0)) != null) {
						String nodeRole = ((Node) textRoleList.item(0))
								.getNodeValue().trim();
						log.debug("OwnerRole tag of this node : "
								+ ((Node) textRoleList.item(0)).getNodeValue()
										.trim());

						if (nodeRole.equalsIgnoreCase(currentUserRole)) {
							//					    -------
							NodeList milestoneSSFIDList = milestoneElement
									.getElementsByTagName(FinanceFA_Constants.OWNERSSFID_ATTRIBUTE);
							Element milestoneSSFIDElement = (Element) milestoneSSFIDList
									.item(0);

							NodeList textSSFIDList = milestoneSSFIDElement
									.getChildNodes();
							if (((Node) textSSFIDList.item(0)) != null) {
								String str = ((Node) textSSFIDList.item(0))
										.getNodeValue();
								log.debug("OwnerSSFID tag of this node is not null and value is  :: "
										+ str
										+ " so we will update the OwnerSFID tag to the SSFID value which is given as parameter to this method");

								//set value to that OwnerSSFID node
								((Node) textSSFIDList.item(0))
										.setNodeValue(currentUserSSFID);
							} else {

								log.debug("OwnerSSFID tag of this node is null :: so we will create a new node of the tag OwnerSFFID and then replace the OwnerSSFID tag");
								Element ele = (Element) doc
										.createElement(FinanceFA_Constants.OWNERSSFID_ATTRIBUTE);
								ele.appendChild(doc
										.createTextNode(currentUserSSFID));

								milestoneElement.replaceChild(ele,
										milestoneSSFIDElement);
							}
						}
					} else {
						log.debug("The OwnerRole tag is empty. Kindly check the XML file");
					}

				} else {
					//not the desired node (this means that the current node is
					// less then the given current pointer). so move ahead to
					// check the next Node
					log.debug("not the " + currentMilestoneArrayPointer
							+ " node. Traverse ahead");
				}

			}
			log.debug("Now iterating in 2nd for loop ");
			for (int s = 0; s < listOfMilestones.getLength(); s++) {

				Node milestoneNode = listOfMilestones.item(s);
				log.debug("For Node no. : " +(s+1)+" Name of the node :: " + milestoneNode.getNodeName());
				//When the node is greater or equal the cuurent pointer Node
				// then check its role and SSFID. If the current iteration is
				// less then the current pointer then dont do any thing, just
				// traverse ahead
				if (s >= currentMilestoneArrayPointer
						&& milestoneNode.getNodeType() == Node.ELEMENT_NODE) {

					// Expand the current Milestone Node and get its Name, Type,
					// OwnerSSFID, OwnerRole Attributes
					if (roleMap.containsKey(currentUserSSFID.trim()
							.toLowerCase())) {
						users = (UserDetailsBean) roleMap.get(currentUserSSFID
								.toLowerCase().trim());
						supervisorSSFID = users.getSupervisorSSFId();
						supervisorName = users.getSupervisorName();

						if (supervisorSSFID == null
								|| supervisorSSFID.trim().equals("")) {
							supervisorSSFID = "";
						}
						log.debug("Supervisor SSFID of the given CurrentUserSSFID is : "
								+ supervisorSSFID
								+ " and Supervisor Name is : "
								+ supervisorName);

						Element milestoneElement = (Element) milestoneNode;

						NodeList milestoneNameList = milestoneElement
								.getElementsByTagName(FinanceFA_Constants.NAME_ATTRIBUTE);
						Element milestoneNameElement = (Element) milestoneNameList
								.item(0);

						NodeList textNameList = milestoneNameElement
								.getChildNodes();
						log.debug(" Name tag of the node : "
								+ ((Node) textNameList.item(0)).getNodeValue()
										.trim());

						NodeList milestoneTypeList = milestoneElement
								.getElementsByTagName(FinanceFA_Constants.TYPE_ATTRIBUTE);
						Element milestoneTypeElement = (Element) milestoneTypeList
								.item(0);

						NodeList textTypeList = milestoneTypeElement
								.getChildNodes();
						log.debug("Type tag of the node : "
								+ ((Node) textTypeList.item(0)).getNodeValue()
										.trim());
						String nodeType = ((Node) textTypeList.item(0))
								.getNodeValue().trim();

						NodeList milestoneRoleList = milestoneElement
								.getElementsByTagName(FinanceFA_Constants.OWNER_ATTRIBUTE);
						Element milestoneRoleElement = (Element) milestoneRoleList
								.item(0);

						NodeList textRoleList = milestoneRoleElement
								.getChildNodes();
						String nodeRole = ((Node) textRoleList.item(0))
								.getNodeValue().trim();
						log.debug("OwnerRole tag of the Node : "
								+ ((Node) textRoleList.item(0)).getNodeValue()
										.trim());

						NodeList milestoneSSFIDList = milestoneElement
								.getElementsByTagName(FinanceFA_Constants.OWNERSSFID_ATTRIBUTE);
						Element milestoneSSFIDElement = (Element) milestoneSSFIDList
								.item(0);

						NodeList textSSFIDList = milestoneSSFIDElement
								.getChildNodes();

						// adding
						if (nodeType
								.equalsIgnoreCase(FinanceFA_Constants.TYPE_APPROVAL)) {
							log.debug("This is 'Approval' milestone");
							
							/*
							 * check whether the chache supervisor role matches
							 * the xml supervisor role
							 */
							UserDetailsBean superUser = (UserDetailsBean) roleMap
									.get(supervisorSSFID.toLowerCase().trim());
							ArrayList superRoles = superUser.getUserRoleName();
							log.debug("Roles got from cache  for ssfid : "
									+ superUser.getUserSSFId() + " are "
									+ superRoles);
							// If type is Approval then check whether supervisor
							// has
							// that role which is given in the xml file. if the
							// role
							// matches to that of xml only then check the XML
							// ownerssfid is blank or not. If blank then set the
							// ownerSSFID tag to the value that we have got from
							// cahe manager else dont change

							if (superRoles.contains(nodeRole)) {

								if (((Node) textSSFIDList.item(0)) != null) {
									log
											.debug("NodeType is Approval and NodeOwnerSSFID is not null, so nothing to do ahead");
								} else {
									log
											.debug("NodeType is Approval and NodeOwnerSSFID is null, so add the SSFID to this node");
									Element ele = (Element) doc
											.createElement(FinanceFA_Constants.OWNERSSFID_ATTRIBUTE);
									ele.appendChild(doc
											.createTextNode(supervisorSSFID));
									milestoneElement.replaceChild(ele,
											milestoneSSFIDElement);
								}
							} else {
								// Cache Supervisor Role does not match to the
								// given
								// XML owner Role
								log
										.debug("No Matching Roles found for Approval Milestone");
							}
						}
						// adding ends
					} else {
						log.debug("Cache map does not contain the ssfid "
								+ currentUserSSFID
								+ " which is given as input parameter");
					}

				} else {
					//not the desired node (this means that the current node is
					// less then the given current pointer). so move ahead to
					// check the next Node
					log.debug("not the " + (currentMilestoneArrayPointer+1)
							+ " node. Traverse ahead");
				}

			}

			//Now change the XML back to String
			Transformer transformer = TransformerFactory.newInstance()
					.newTransformer();
			StreamResult result = new StreamResult(new StringWriter());
			DOMSource source = new DOMSource(doc);
			transformer.transform(source, result);

			xmlString = result.getWriter().toString();
			log.debug("Updated XML string :: " + xmlString);

		} catch (Exception e) {
			log.error("Error occurred while updating the user ssfid array", e);
		}
		return xmlString;
	}

}