/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations.util.dto;

import java.util.ArrayList;
import java.util.Date;

/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class ScenarioDTO {
	private Integer scenarioId = new Integer(-1);
	private Integer caseLaunchCldrId = new Integer(-1);
	private String status;
	private Date updateDate;
	private String updatedBy;
	private String workflowDefinition;
	private Integer processId = new Integer(-1);
	private String processName;
	private String subProcessName;
	private String launchType;
	private String frequencyType;
	private String slaLogicType;
	private String slaCalculationType;
	private String streamName;
	
	private ArrayList processNotificationList;
	private ArrayList milestoneList;
	
	/**
	 * @return Returns the caseLaunchCldrId.
	 */
	public Integer getCaseLaunchCldrId() {
		return caseLaunchCldrId;
	}
	/**
	 * @param caseLaunchCldrId The caseLaunchCldrId to set.
	 */
	public void setCaseLaunchCldrId(Integer caseLaunchCldrId) {
		this.caseLaunchCldrId = caseLaunchCldrId;
	}
	/**
	 * @return Returns the frequencyType.
	 */
	public String getFrequencyType() {
		return frequencyType;
	}
	/**
	 * @param frequencyType The frequencyType to set.
	 */
	public void setFrequencyType(String frequencyType) {
		this.frequencyType = frequencyType;
	}
	/**
	 * @return Returns the launchType.
	 */
	public String getLaunchType() {
		return launchType;
	}
	/**
	 * @param launchType The launchType to set.
	 */
	public void setLaunchType(String launchType) {
		this.launchType = launchType;
	}
	/**
	 * @return Returns the milestoneList.
	 */
	public ArrayList getMilestoneList() {
		return milestoneList;
	}
	/**
	 * @param milestoneList The milestoneList to set.
	 */
	public void setMilestoneList(ArrayList milestoneList) {
		this.milestoneList = milestoneList;
	}
	/**
	 * @return Returns the processId.
	 */
	public Integer getProcessId() {
		return processId;
	}
	/**
	 * @param processId The processId to set.
	 */
	public void setProcessId(Integer processId) {
		this.processId = processId;
	}
	/**
	 * @return Returns the processName.
	 */
	public String getProcessName() {
		return processName;
	}
	/**
	 * @param processName The processName to set.
	 */
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	/**
	 * @return Returns the processNotificationList.
	 */
	public ArrayList getProcessNotificationList() {
		return processNotificationList;
	}
	/**
	 * @param processNotificationList The processNotificationList to set.
	 */
	public void setProcessNotificationList(ArrayList processNotificationList) {
		this.processNotificationList = processNotificationList;
	}
	/**
	 * @return Returns the scenarioId.
	 */
	public Integer getScenarioId() {
		return scenarioId;
	}
	/**
	 * @param scenarioId The scenarioId to set.
	 */
	public void setScenarioId(Integer scenarioId) {
		this.scenarioId = scenarioId;
	}
	/**
	 * @return Returns the slaCalculationType.
	 */
	public String getSlaCalculationType() {
		return slaCalculationType;
	}
	/**
	 * @param slaCalculationType The slaCalculationType to set.
	 */
	public void setSlaCalculationType(String slaCalculationType) {
		this.slaCalculationType = slaCalculationType;
	}
	/**
	 * @return Returns the slaLogicType.
	 */
	public String getSlaLogicType() {
		return slaLogicType;
	}
	/**
	 * @param slaLogicType The slaLogicType to set.
	 */
	public void setSlaLogicType(String slaLogicType) {
		this.slaLogicType = slaLogicType;
	}
	/**
	 * @return Returns the status.
	 */
	public String getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * @return Returns the streamName.
	 */
	public String getStreamName() {
		return streamName;
	}
	/**
	 * @param streamName The streamName to set.
	 */
	public void setStreamName(String streamName) {
		this.streamName = streamName;
	}
	/**
	 * @return Returns the subProcessName.
	 */
	public String getSubProcessName() {
		return subProcessName;
	}
	/**
	 * @param subProcessName The subProcessName to set.
	 */
	public void setSubProcessName(String subProcessName) {
		this.subProcessName = subProcessName;
	}
	/**
	 * @return Returns the updateDate.
	 */
	public Date getUpdateDate() {
		return updateDate;
	}
	/**
	 * @param updateDate The updateDate to set.
	 */
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	/**
	 * @return Returns the updatedBy.
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}
	/**
	 * @param updatedBy The updatedBy to set.
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	/**
	 * @return Returns the workflowDefinition.
	 */
	public String getWorkflowDefinition() {
		return workflowDefinition;
	}
	/**
	 * @param workflowDefinition The workflowDefinition to set.
	 */
	public void setWorkflowDefinition(String workflowDefinition) {
		this.workflowDefinition = workflowDefinition;
	}
}
