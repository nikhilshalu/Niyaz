package com.bharti.finance.fa.operations.util;

import com.bharti.fa.common.operations.util.Constants;

public class FinanceFA_Constants extends Constants {

	public static final int CONDITIONAL_ABSOLUTE = 3;

	public static final int CONDITIONAL_RELATIVE = 4;

	public static final String STR_SCENARIO_MILESTONE_ID = "ScenarioMilestoneID";

	public static final String STR_NOTIFICATION = "Notification";

	public static final String STR_IS_TIMER_EXPIRED = "IsTimerExpired";

	public static final String MILESTONE_NODE = "Milestone";

	public static final String NAME_ATTRIBUTE = "Name";

	public static final String TYPE_ATTRIBUTE = "Type";

	public static final String OWNER_ATTRIBUTE = "OwnerRole";

	public static final String OWNERSSFID_ATTRIBUTE = "OwnerSSFID";

	public static final String TYPE_APPROVAL = "Approval";

	public static final String REST_SLA = "RestSLA";

	public static final String MILESTONE = "M";

	public static final String PROCESS = "P";

	public static final String ESCALATION = "E";

	public static final String REMINDER = "R";

	public static final String STRING_REMINDER = "Reminder";

	public static final String STRING_ESCALATION = "Escalation";

	public static final String STRING_SLA = "SLAExpired";

	public static final String STR_TIMER_NOTIFICATION_IS_ENABLED = "TimerNotificationIsEnabled";

	public static final String STR_CATEGORY = "Category";

	// public static final String = "Category";

	public static final String STR_MILESTONE = "Milestone";

	public static final String STR_PROCESS = "Process";

	public static final String STRQUERY = "Query";

	public static final String REQUEST = "Request";

	public static final String OFFSET = "Offset";

	public static final int WF_RETURN_ARRAY_DATA = 1;

	public static final int WF_RETURN_XML_DATA = 2;
}
