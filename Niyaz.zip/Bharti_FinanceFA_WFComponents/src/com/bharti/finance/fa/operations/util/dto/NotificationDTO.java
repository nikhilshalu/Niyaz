/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations.util.dto;

/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class NotificationDTO {
	private String category;
	private String type;
	private String level;
	private Integer offset = new Integer(-1);
	private String role;
	private String scenarioMileStoneID;
	private String to;
	private String cc;
	private String bcc;
	private String istimerexpired;
	private String timernotificationisenabled;
	private String modifiedXMLString;
	
	/**
	 * @return Returns the category.
	 */
	public String getCategory() {
		return category;
	}
	/**
	 * @param category The category to set.
	 */
	public void setCategory(String category) {
		this.category = category;
	}
	/**
	 * @return Returns the level.
	 */
	public String getLevel() {
		return level;
	}
	/**
	 * @param level The level to set.
	 */
	public void setLevel(String level) {
		this.level = level;
	}
	/**
	 * @return Returns the offset.
	 */
	public Integer getOffset() {
		return offset;
	}
	/**
	 * @param offset The offset to set.
	 */
	public void setOffset(Integer offset) {
		this.offset = offset;
	}
	/**
	 * @return Returns the role.
	 */
	public String getRole() {
		return role;
	}
	/**
	 * @param role The role to set.
	 */
	public void setRole(String role) {
		this.role = role;
	}
	/**
	 * @return Returns the type.
	 */
	public String getType() {
		return type;
	}
	/**
	 * @param type The type to set.
	 */
	public void setType(String type) {
		this.type = type;
	}
	
	/**
	 * @return Returns the scenarioMileStoneID.
	 */
	public String getScenarioMileStoneID() {
		return scenarioMileStoneID;
	}
	/**
	 * @param scenarioMileStoneID The scenarioMileStoneID to set.
	 */
	public void setScenarioMileStoneID(String scenarioMileStoneID) {
		this.scenarioMileStoneID = scenarioMileStoneID;
	}
	/**
	 * @return Returns the bcc.
	 */
	public String getBcc() {
		return bcc;
	}
	/**
	 * @param bcc The bcc to set.
	 */
	public void setBcc(String bcc) {
		this.bcc = bcc;
	}
	/**
	 * @return Returns the cc.
	 */
	public String getCc() {
		return cc;
	}
	/**
	 * @param cc The cc to set.
	 */
	public void setCc(String cc) {
		this.cc = cc;
	}
	/**
	 * @return Returns the to.
	 */
	public String getTo() {
		return to;
	}
	/**
	 * @param to The to to set.
	 */
	public void setTo(String to) {
		this.to = to;
	}
		/**
	 * @return Returns the modifiedXMLString.
	 */
	public String getModifiedXMLString() {
		return modifiedXMLString;
	}
	/**
	 * @param modifiedXMLString The modifiedXMLString to set.
	 */
	public void setModifiedXMLString(String modifiedXMLString) {
		this.modifiedXMLString = modifiedXMLString;
	}
	
	/**
	 * @return Returns the timernotificationisenabled.
	 */
	public String getTimernotificationisenabled() {
		return timernotificationisenabled;
	}
	/**
	 * @param timernotificationisenabled The timernotificationisenabled to set.
	 */
	public void setTimernotificationisenabled(String timernotificationisenabled) {
		this.timernotificationisenabled = timernotificationisenabled;
	}
	/**
	 * @return Returns the istimerexpired.
	 */
	public String getIstimerexpired() {
		return istimerexpired;
	}
	/**
	 * @param istimerexpired The istimerexpired to set.
	 */
	public void setIstimerexpired(String istimerexpired) {
		this.istimerexpired = istimerexpired;
	}
}
