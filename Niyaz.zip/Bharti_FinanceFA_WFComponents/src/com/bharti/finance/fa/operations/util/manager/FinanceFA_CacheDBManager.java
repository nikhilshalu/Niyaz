/*
 * Created on Sep 8, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.operations.util.manager;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.manager.ExternalDBManager;
import com.bharti.finance.fa.operations.util.beans.UserDetailsBean;

/**
 * @author Gaurav Jain IBM
 *
 * purpose of this class is to cache the db data into beans or arraylist
 * 
 * 
 */
public class FinanceFA_CacheDBManager extends ExternalDBManager {

    public static Logger log = Logger
									.getLogger(FinanceFA_CacheDBManager.class);

	Connection dbconn = null;
	/* Map holds Role & User mapping */
	public static HashMap roleUserMap = new HashMap();
	
	/* Map holds user details like Name, MailId, Role... etc. */
	public static HashMap userDetailMap = new HashMap();
	
	/* Map holds to whome notification will be send */
	public static HashMap CircleMappingMap = new HashMap();
	
	public static HashMap ORG_HIERARCHY = new HashMap();
	
	public static Calendar cachedRoleMapDate = null;
	public static Calendar cachedUserDetailDate = null;
	public static Calendar cachedCircleMappingDate = null;
	public static Calendar cachedOrgHierachyDate = null;

	public static HashMap emailSubjectDataMap;
	public static Calendar cachedEmailSubjectMasterDate = null;
	int nextReloadPeriod = 0;
	public FinanceFA_CacheDBManager(int application) {
	    super(application);
	    nextReloadPeriod = Integer.parseInt(PropertyLoader.props.getProperty("CACHED_DB_RELOAD_PERIOD"));

	}
	
	public Connection getDbConnection() {
		log.debug("[Entry getDbConnection]");

		String db2URL = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_URL"));
		String db2User = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_ID"));
		String db2pwd = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_PASSWORD"));

		dbconn = getDbConnection(db2URL, db2User, db2pwd); 
		log.info("nextReloadPeriod="+nextReloadPeriod);
		log.debug("[Exit getDbConnection]");
		return dbconn;
	}
	
	
	
	private boolean loadOrganizationHierarchy() throws Exception {
		log.debug("[Enter loadOrganizationHierarchy]");
		ORG_HIERARCHY = new HashMap();
		boolean success = false;

		dbconn = getDbConnection();
		String strQuery = "Select role_name , role_supervisor from FN_TBL_ORGANIZATION_MAPPING";
		log.debug("QUERY of Organisation :: " + strQuery);
		try {
			Statement stmt = dbconn.createStatement();
			ResultSet rs = null;
			rs = stmt.executeQuery(strQuery);
			while (rs.next()) {
				String roleName = ((rs.getString("role_name") != null) ? rs
						.getString("role_name") : "");
				String roleSupervisor = ((rs.getString("role_supervisor") != null) ? rs
						.getString("role_supervisor")
						: "");
				ORG_HIERARCHY.put(roleName, roleSupervisor);
			}
			log.debug("Organisation hashtable :: " + ORG_HIERARCHY.toString());
			success = true;
		} catch (Exception ex) {
			log.error("Database Exception : " + ex.getMessage(), ex);
			success = false;
			throw ex;
		} finally {
			if (dbconn != null)
				dbconn.close();
		}

		log.debug("Exit FinanceOperations : loadOrganizationHierarchy method ");
		return success;
	}
	
	private void loadUserDetails() throws Exception {

		log.debug("Entry loadUserDetails method ");

		String strQuery = null;
		userDetailMap = new HashMap();
		
		dbconn = getDbConnection();
		log.debug("Connected..");

		strQuery = "  SELECT user.USER_ID as user_id, user.FULL_NAME as full_name,user.NAME as user_ssfid,securityprofile.PROFILE as user_role, user.USER_ATTR_2 as user_mailid,  supervisor.USER_ID as supervisor_id,supervisor.FULL_NAME as supervisor_fullname, supervisor.NAME as supervisor_ssfid,supervisor.USER_ATTR_2 as supervisor_mailid "    
					 + " FROM FN_FA_TBL_CMT_USER user left outer join FN_FA_TBL_CMT_USER supervisor on supervisor.USER_ID = user.REPORTSTO_USER_ID "    
					 + " left outer join FN_FA_TBL_CMT_USERPROFILE userprofile on user.USER_ID = userprofile.USER_ID "    
					 + " left outer join FN_FA_TBL_CMT_SECURITYPROFILE securityprofile on userprofile.SECURITY_PROFILE_ID = securityprofile.SECURITY_PROFILE_ID "     
		              + " where user.ACTIVE = 1 and user.SYSTEM <> 1";
		
		log.debug("DB QUERY :: " + strQuery);
		try{
		Statement stmt = dbconn.createStatement();
			ResultSet rs = null;
			rs = stmt.executeQuery(strQuery);
			String userSSFId = null;
			ArrayList roles;
			UserDetailsBean userdetail;
			while (rs.next()) {
			    userdetail = new UserDetailsBean();
			    
			    userSSFId = rs.getString("user_ssfid").toLowerCase().trim();
			    if(!userDetailMap.containsKey(userSSFId))
			    {
				    userdetail.setUserSSFId((userSSFId) != null ? userSSFId : "");
				    userdetail.setUserName((rs.getString("full_name")) != null ? rs.getString("full_name") : "");
				    userdetail.setUserMailId((rs.getString("user_mailid") != null) ? rs.getString("user_mailid") : "");
				    
				    roles = new ArrayList();
				    roles.add(rs.getString("user_role"));
				    userdetail.setUserRoleName(roles);
				    
//				    userdetail.setShiftStartTime((rs.getString("user_shiftstart") != null) ? rs.getString("user_shiftstart") : "");
//				    userdetail.setShiftEndTime((rs.getString("user_shiftend") != null) ? rs.getString("user_shiftend") : "");
//				    
				    userdetail.setSupervisorName((rs.getString("supervisor_fullname") != null) ? rs.getString("supervisor_fullname") : "");
				    userdetail.setSupervisorSSFId((rs.getString("supervisor_ssfid") != null) ? rs.getString("supervisor_ssfid") : "");
				    userdetail.setSupervisorMailId((rs.getString("supervisor_mailid") != null) ? rs.getString("supervisor_mailid") : "");
				    userdetail.setSupervisorRoleName("");
				    
				    userDetailMap.put(userSSFId,userdetail);
			    }
			    else
			    {
			        log.debug("user already exist in bean map: "+userSSFId);
			        userdetail = (UserDetailsBean)userDetailMap.get(userSSFId.toLowerCase().trim());
			        roles = userdetail.getUserRoleName();
			        log.debug("roles.size() "+roles.size());
			        roles.add(rs.getString("user_role"));
			        userdetail.setUserRoleName(roles);
			        userDetailMap.put(userSSFId,userdetail);
			        log.debug("adding another role: "+rs.getString("user_role"));
			    }
			    log.debug(rs.getString("user_ssfid"));
			}

			log.debug("Total fields fetched :: " + userDetailMap.size());
			log.debug("Exit loadUserDetails method ");
		}catch (Exception ex) {
			log.debug("Exception occured while searching for user. "+ex);
			throw ex;
		} finally {
			try {
					dbconn.close();
				} catch (SQLException ex) {
				    log.debug("Exception while closing dbconn. "+ex);
				    throw ex;
				}
			}
	}
	
	
	private void loadRoleUserMapping() throws Exception
	{
	    String strQuery = null;
	    roleUserMap = new HashMap();
		ArrayList users;
		String roleName = "";
		String user = "";
		
		dbconn = getDbConnection();
		//security.profile like 'IB%' and 
		strQuery = "SELECT security.profile as role_name, user.NAME as user_ssfid from FN_FA_TBL_CMT_SECURITYPROFILE security, FN_FA_TBL_CMT_USERPROFILE users, FN_FA_TBL_CMT_USER user"
		    		+" where security.security_profile_id = users.security_profile_id "
		    		+" and users.USER_ID = user.USER_ID and user.active = 1 and user.system <> 1";
		log.debug("DB QUERY :: " + strQuery);
		try{
			Statement stmt = dbconn.createStatement();
			ResultSet rs = null;
			rs = stmt.executeQuery(strQuery);
			while (rs.next()) {
			    roleName 	= rs.getString("role_name");
			    user 		= rs.getString("user_ssfid");
			    log.debug("Role Names: "+roleName);
			    log.debug("UserSSFID: "+user);
			    
			    //log.debug(roleUserMap.size());
		
			    if(roleUserMap.containsKey(roleName)){
			        log.debug("Role already exist in map");
			         users = (ArrayList)roleUserMap.get(roleName);
			         users.add(user);
			         roleUserMap.put(roleName,users);
			         log.debug("Role ["+roleName+"] Exist hence updating arraylist for user: "+user);
				}
			    else{
				    users = new ArrayList();
				    users.add(user);
				    roleUserMap.put(roleName,users);
				    log.debug("Role Name added to the map: "+roleName);
				    log.debug("User added to the arraylist: "+user);
				}
			}
			log.debug("Total fields fetched :: " + roleUserMap.size());
		}catch (Exception ex) {
			log.debug("Exception occured while searching for user");
			throw ex;
		} finally {
			try {
					dbconn.close();
				} catch (SQLException ex) {
				    log.debug("Exception while closing dbconn ");
				    throw ex;
				}
			}
	}
	
	
	
	
	public HashMap getUserDetails() throws Exception {

		log.debug("Entry getUserDetails method ");
		Calendar currentDate = Calendar.getInstance();
	    
	    if((cachedUserDetailDate == null) || (currentDate.after(cachedUserDetailDate)))
	    {
	        //int nextReloadPeriod = Integer.parseInt(PropertyLoader.props.
	        cachedUserDetailDate = Calendar.getInstance();						//getProperty("CACHED_DB_RELOAD_PERIOD"));
	        cachedUserDetailDate.add(Calendar.HOUR, nextReloadPeriod);
	        log.info("nextReloadPeriod="+nextReloadPeriod);
	        log.debug("Next database cache date will be: "+cachedUserDetailDate.getTime());
	        userDetailMap.clear();
	        loadUserDetails();
	    }
	    else
	    {
	        log.debug("UserDetails not loading again");
	    }
	
		//log.debug("Total fields fetched :: " + userDetailMap.size());
		log.debug("Exit getUserDetails method ");
		return userDetailMap;
	}
	
	public HashMap getOrganizationHierarchy() throws Exception {

		log.debug("Entry getOrganizationHierarchy method ");
		Calendar currentDate = Calendar.getInstance();
	    
	    if((cachedOrgHierachyDate == null) || (currentDate.after(cachedOrgHierachyDate)))
	    {
	        //int nextReloadPeriod = Integer.parseInt(PropertyLoader.props.
	        cachedOrgHierachyDate = Calendar.getInstance();						//getProperty("CACHED_DB_RELOAD_PERIOD"));
	        cachedOrgHierachyDate.add(Calendar.HOUR, nextReloadPeriod);
	        log.debug("Next database cache date will be: "+cachedOrgHierachyDate.getTime());
	        ORG_HIERARCHY.clear();
	        loadOrganizationHierarchy();
	    }
	    else
	    {
	        log.debug("OrganizationHierarchy not loading again");
	    }
	
		//log.debug("Total fields fetched :: " + userDetailMap.size());
		log.debug("Exit getOrganizationHierarchy method ");
		return userDetailMap;
	}
	
	
	public HashMap getRoleUserMapping() throws Exception {

	    log.debug("Entry getRoleUserMapping method ");
	    Calendar currentDate = Calendar.getInstance();
	    
	    if((cachedRoleMapDate == null) || (currentDate.after(cachedRoleMapDate)))
	    {
	        //int nextReloadPeriod = Integer.parseInt(PropertyLoader.props.
	        cachedRoleMapDate = Calendar.getInstance();											//getProperty("CACHED_DB_RELOAD_PERIOD"));
	        cachedRoleMapDate.add(Calendar.HOUR, nextReloadPeriod);
	        log.debug("Next database cache date will be: "+cachedRoleMapDate.getTime());
	        roleUserMap.clear();
	        loadRoleUserMapping();
	    }
	    else
	    {
	        log.debug("RoleUserMapping not loading again");
	    }

	    log.debug("Exit getRoleUserMapping method ");
	    return roleUserMap;
	}
	
	public static void main(String[] args) {
	    
	    FinanceFA_CacheDBManager cache = new FinanceFA_CacheDBManager(1);
	    cache.testGetUserDetails();
	    // To test getUserDetails 
	  // cache.testGetUserDetails();
	    
	    // To test getRoleUserMapping() 
	    cache.testGetRoleUserMapping();
	    //log.debug("Calling agian "+cachedDBDate.getTime());
	    //cache.testGetRoleUserMapping();
	    
    }
	
	private void testGetUserDetails()
	{
	    try{
	        
	        getUserDetails();
	        log.debug("asddsad");
	        Set set = userDetailMap.keySet();
	        Iterator itr = set.iterator();
	        String ssfid = "";
	        UserDetailsBean bean;
	        int cnt =0;
	        while(itr.hasNext())
	        {
	            ssfid  = (String)itr.next();
	            bean = (UserDetailsBean)userDetailMap.get(ssfid);
	            
	            log.debug("User: "+ssfid +"  CompleteDetails:: "+bean.getUserName()+" / "+bean.getUserRoleName()+" / "+bean.getUserMailId()+" / "+bean.getUserSSFId()+" / "+bean.getSupervisorName()+" / "+bean.getSupervisorSSFId()+" / "+bean.getSupervisorMailId()+" / "+bean.getSupervisorRoleName());
	            cnt++;
	        }
	        log.debug(" total "+cnt);
	        
	    }
	    catch(Exception ex)
	    {
	        log.debug("Error: "+ ex);
	    }
	}
	
	private void testGetRoleUserMapping()
	{
	 try{
        getRoleUserMapping();
        log.debug("dfsf f fsff sd"+roleUserMap.size());
        Set set = roleUserMap.keySet();
        Iterator itr = set.iterator();
        ArrayList  usersList = new ArrayList();
        String role = "";
        int cnt =0;
        while(itr.hasNext())
        {
            role  = (String)itr.next();
            usersList = (ArrayList)roleUserMap.get(role);
            log.debug("Role: "+role +" Users: "+usersList.size());
            cnt++;
        }
        log.debug(" total "+cnt);
        
    }
    catch(Exception ex)
    {
        log.debug("Error: "+ ex);
    }
	}
}
