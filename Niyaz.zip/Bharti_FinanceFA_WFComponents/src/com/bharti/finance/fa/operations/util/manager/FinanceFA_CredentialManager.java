/*
 * Created on Feb 19, 2009
 * @author Harisha C S Achar(harisha.achar@in.ibm.com, mail2harisha@gmail.com)
 * 
 */
package com.bharti.finance.fa.operations.util.manager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.PropertyLoader;



/**
 * @author Harisha
 * 
 * This class is responsible for modification of Database user credentials in
 * property file. This class will be used when changing the user credentials in
 * property file. This program should be run in the following format:
 * <blockquote>
 * 
 * <pre>
 *     		java -jar jarFileName -(applicationTypeName) -credentials newUserName newPassword
 * </pre>
 * 
 * </blockquote> To change the credentials in property file use the
 * format:[-(applicationTypeName) -credentials userName password]
 * 
 * <pre>
 *     where jarFileName: the name of our program
 *     		 applicationTypeName: DB2 (case insensitive)
 *     		 credentials: keyword (case insensitive)
 *     		 userName: new user name to be modified(argument)
 *     		 password: new password to be modified(argument)
 *     
 * </pre>
 */
public class FinanceFA_CredentialManager {

	private static String HOME_PATH;
	private static String file_separator;
	public static Logger log = Logger.getLogger(FinanceFA_CredentialManager.class);
	public static String propFileName = "FinanceFA_Components.properties";
	public static String log4jFileName = "FinanceFA_log4j.properties";
	
	public static void main(String[] args) {
				
		/*
		 * Contains the name of the top hierarchical folder which has all
		 * configuration files
		 */
		String propsContainer = new String("fa_config");

		/* Search the classpath for "fa_config" folder */
		String class_path = System.getProperty("java.class.path");

		/* Get the path.separator system variable */
		String path_separator = System.getProperty("path.separator");
		file_separator = System.getProperty("file.separator");
		StringTokenizer tokenizer = new StringTokenizer(class_path,
				path_separator);

		while (tokenizer.hasMoreTokens()) {
			String pathString = tokenizer.nextToken();

			/* Get the path of "config" folder */
			if (pathString != null
					&& (pathString.length() >= propsContainer.length())) {
				String folder = pathString.substring((pathString.length())
						- propsContainer.length(), pathString.length());
				if (folder.equals(propsContainer)) {
					HOME_PATH = pathString;
					break;
				}
			}
		}
		if (HOME_PATH == null) {
			System.out
					.println("[Inside static block]: Unable to find the [fa_config] folder. Please check "
							+ "the Classpath(required libraries)");
		}

		/* Load Log4j property file */
		PropertyLoader.loadLog4jProperties(HOME_PATH + file_separator + "properties"
				+ file_separator + log4jFileName);

		/* Load custom property file */
		Properties prop = PropertyLoader.loadPropertiesFromFile(HOME_PATH
				+ file_separator + "properties" + file_separator
				+ propFileName);
		if (prop == null) {
			log.error("Unable to load Custom property file " + propFileName
					+ " from path " + HOME_PATH + file_separator
					+ propFileName);
			return;
		}

		boolean flag = false;
		try {
			flag = modify(args);

			if (flag == true) {
				log.info("Successfully modified the properties file.");
			} else {
				log.error("Error while performing the requested operation.");
			}
		} catch (Exception e) {
			log.error("Error while performing the requested operation."
					+ e.getMessage(), e);
		}
		log.debug("[Exit main]");
	}
	
	/**
	 * Modifies the property file content according to input parameter
	 * <code>args</code>
	 * 
	 * @param args
	 *            command line arguments
	 * @return true if successfully modifies the property file otherwise false
	 */
	public static boolean modify(String[] args) {
		log.debug("[Enter modify]");
		String connURL = null;
		String newUName = null;
		String newPwd = null;

		log.debug("Number of arguments passed is " + args.length);
		/*
		 * Contains all the new key-value pairs to be modified in the property
		 * file
		 */
		HashMap map = new HashMap();

		/* If insufficient arguments are provided, then log an error */
		if (args.length != 4) {
			printUsage();
			return false;
		}

		/*
		 * Change the credentials of user in property file when the program is
		 * invoked using -(applicationTypeName) -credentials userName password
		 * option. It verifies the new credentials by connecting to particular
		 * database then, after verifying; it modifies the property file.
		 */
		if (args.length == 4) {

			/*
			 * If the first option is not the application type name, then log an
			 * error
			 */
			if (!args[0].equalsIgnoreCase("-DB2")) {
				printUsage();
				return false;
			}

			/* If the second option is not the word "-credentials", then log an error */
			if (!args[1].equalsIgnoreCase("-credentials")) {
				printUsage();
				return false;
			} else {
				newUName = args[2];
				newPwd = args[3];
			}

			Connection db2Connection = null;
			
			if (args[0].equalsIgnoreCase("-DB2")) {

				// It modifies the application DB2 database's user credentials
				// in property file
				log.info("Trying to update application DB2 database's user credentials in property file.");
				connURL = Base64.decrypt(PropertyLoader.props
						.getProperty("DATABASE_URL"));

				try {
					log.info("Verifying the credentials. Trying to connect to application's DB2 database "
							+ "with new credentials.");
					Class.forName("com.ibm.db2.jcc.DB2Driver").newInstance();
					db2Connection = DriverManager.getConnection(connURL,
							newUName, newPwd);
					log.info("Connected to database.");

				} catch (Exception e) {
					log.error(
							"Unable to connect to database. Invalid user credentials."
									+ e.getMessage(), e);
					return false;
				} finally {

					/* Close the database connection */
					if (db2Connection != null) {
						try {
							db2Connection.close();
							log
									.debug("Database connection closed successfully.");
						} catch (SQLException e) {
							log.error(
									"Error occured while closing the database connection."
											+ e.getMessage(), e);
						}
					}
				}

				// As new credentials are valid, store it in map object
				map.put("DATABASE_USER_ID", Base64.encrypt(newUName));
				map.put("DATABASE_USER_PASSWORD", Base64.encrypt(newPwd));
			}		
		}

		/*
		 * Create a new temporary property file and copy each line from original
		 * property file and add it to new file except the lines which contains
		 * the encryted user name and password instead add the new encrypted
		 * user name and password.
		 * 
		 * After copying all lines, delete the original property file and rename
		 * the new file to the same name as our original file.
		 */
		File fin = null;
		FileReader fr = null;
		BufferedReader br = null;

		File fout = null;
		FileWriter fw = null;
		PrintWriter pw = null;

		String tempPropFileName = "Temp_" + propFileName;
		try {
			fin = new File(HOME_PATH + file_separator + "properties"
					+ file_separator + propFileName);
			fr = new FileReader(fin);
			br = new BufferedReader(fr);
		} catch (FileNotFoundException e) {
			log.error("[" + propFileName
					+ "] property file not found in directory " + HOME_PATH
					+ file_separator + "properties. " + e.getMessage(), e);
			return false;
		}

		try {
			fout = new File(HOME_PATH + file_separator + "properties"
					+ file_separator + tempPropFileName);
			fw = new FileWriter(fout);
			pw = new PrintWriter(fw);
		} catch (IOException e) {
			log.error("Cannot create [" + tempPropFileName
					+ "] property file. " + e.getMessage(), e);
			return false;
		}

		String str = null;
		Iterator iterator = null;

		try {

			// For modifying credentials in property file
			if (args.length == 4) { 
				log
						.debug("Copying the content of property file to temporary file.");
				while ((str = br.readLine()) != null) {
					if (!(str.trim().equals(""))) {

						// If it is not a blank line
						str = str.trim();
						iterator = map.entrySet().iterator();

						while (iterator.hasNext()) {
							Map.Entry entry = (Map.Entry) iterator.next();
							if (str.startsWith((String) entry.getKey())) {
								str = (String) entry.getKey() + "="
										+ (String) entry.getValue();
								break;
							}
						}
					}
					pw.println(str);
					pw.flush();
				}
			}
			br.close();
			fr.close();

			// delete the original file
			boolean flag = fin.delete();
			if (flag == false) {
				log.error("Unable to delete the original property file");
			} else {
				log.debug("Deleted the original property file");
			}

			// rename the new temporary file to the same name as our original
			// file
			File newFile = new File(HOME_PATH + file_separator + "properties"
					+ file_separator + propFileName);
			pw.close();
			fw.close();

			flag = fout.renameTo(newFile);
			if (flag == false) {
				log
						.error("Unable to rename the temporary file name to original file name");
			} else {
				log.debug("Temporary file renamed");
			}

		} catch (IOException e) {
			log.error("Exception occured while writing to property file: "
					+ e.getMessage(), e);
			return false;
		} catch (Exception e) {
			log.error("Exception: " + e.getMessage(), e);
			return false;
		}

		if (args.length == 4) {
			log.info("Successfully modified the user credentials in ["
					+ propFileName + "] property file.");
			log.debug("[Exit modify]");
			return true;
		}
		return false;
	}

	/**
	 * It prints the correct command line usage for changing property file
	 */
	private static void printUsage() {
		log.error("***********************************************");
		log.error("Invalid arguments provided. USAGE: " +
				"java -jar jarFileName -(applicationTypeName) -credentials newUserName newPassword");
		log.error("Valid application type name are:");
		log.error("DB2: to change database user credentails");
		log.error("***********************************************");

	}
}
