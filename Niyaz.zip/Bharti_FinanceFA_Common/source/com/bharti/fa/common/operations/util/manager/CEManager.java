package com.bharti.fa.common.operations.util.manager;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.filenet.api.collection.RepositoryRowSet;
import com.filenet.api.core.Connection;
import com.filenet.api.core.Domain;
import com.filenet.api.core.Factory;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.query.RepositoryRow;
import com.filenet.api.query.SearchSQL;
import com.filenet.api.query.SearchScope;
import com.filenet.api.util.Id;
import com.filenet.api.util.UserContext;
import com.filenet.wcm.toolkit.server.operations.util.opsUtil;
/**
 * This class is useful for CEOperations such as Making connection with CE and Search in Content Engine Respository

 * 1.Consructor of this class makes connection with Content Engine and gives Instance of Objectstore that can be used in various operations.

 * 2.Method searchCEObject is general mathod for search in CE Repository. 
 * @viz.diagram CEManager.tpx
 */

public class CEManager {
	private static Logger log = Logger.getLogger(CEManager.class);
	private ObjectStore objectStore = null;
	private String userId = null;
	private String password = null;

	public CEManager(int application, String userId, String password) throws Exception  {
		try {
			log.debug("ENTRY : CEManager");
					
			if (Constants.APPLICATION_COMPONENT_MANAGER == application)
			{
				com.filenet.wcm.api.Session session = (new opsUtil()).getSession();
				HashMap hm=session.fromToken(session.getToken());
				this.userId = (String)hm.get("userid");
				this.password = (String)hm.get("password");
			}
			
			String strAppURI = PropertyLoader.props.getProperty("FILENET_URI_SOAP");		
			String jassContext = Constants.APPLICATION_BPF_JASSCONTEXT;
			if(Constants.APPLICATION_WEB == application){
				strAppURI =PropertyLoader.props.getProperty("FILENET_URI_IIOP");
				jassContext = Constants.APPLICATION_CM_JASSCONTEXT;
			}

			log.debug("FILENET_URI :"+strAppURI);

			System.setProperty("java.security.auth.login.config", PropertyLoader.props.getProperty("java.security.auth.login.config"));
			System.setProperty("wasp.location",PropertyLoader.props.getProperty("wasp.location"));
			log.debug("java.security.auth.login.config : "+System.getProperty("java.security.auth.login.config"));
			log.debug("wasp.location : "+System.getProperty("wasp.location"));;

			
			this.userId = (userId != null)?userId:Base64.decrypt(PropertyLoader.props.getProperty("BPMUSERID"));
			this.password = (password != null)?password:Base64.decrypt(PropertyLoader.props.getProperty("BPMUSERPASSWORD"));
			Connection conn = (Connection) Factory.Connection.getConnection(strAppURI);
			UserContext uc = UserContext.get();        
			uc.pushSubject(UserContext.createSubject(conn, this.userId, this.password, jassContext));

			Domain domain = Factory.Domain.fetchInstance(conn,null, null);
			objectStore =Factory.ObjectStore.fetchInstance(domain, PropertyLoader.props.getProperty("objectStoreName"), null);
			log.debug("EXIT : CEManager");
		} catch (Exception e) {
			log.error("Failed to get CE session", e);
			throw e;
		}
	}

	public ObjectStore getObjectStore(){	
		return objectStore;
	}
     /*2.INPUT PARAMETERS FOR searchCEObject:-
	      a.Hashtable filterParams:A hashtable containing the  filter parameters on the basis of which we want to 
		     make a search in CE.
		  b.String[] resultParams:A String Array contaning parameters which we want as a result.For example if we want GUID of a document
		    then we pass {"id"};
		  c.String ObjectClassName:Class name on which we want to search.For example "Document" class to search a document. 
		  d.boolean includeSubClass:boolen value whether we want to includesubclass or not.
         INPUT PARAMETERS FOR searchCEObject:It returns ArrayList of Hashtables.
	 */
	public ArrayList searchCEObject(Hashtable filterParams,String[] resultParams, String ObjectClassName ,boolean includeSubClass) {
		log.debug("ENTRY : searchCEObject");
		String searchClassScope = (includeSubClass) ? Constants.BPM_CE_SEARCH_SCOPE_INCLUDESUBCLASS : Constants.BPM_CE_SEARCH_SCOPE_EXCLUDESUBCLASSES;
		String filter = "";
		String searchQuery="";
		Iterator iterParamKeys = filterParams.keySet().iterator();

		while (iterParamKeys.hasNext()) {
			String paramKey = iterParamKeys.next().toString();
			Object paramval = filterParams.get(paramKey);

			if (paramval instanceof Integer){
				int val = ((Integer)filterParams.get(paramKey)).intValue();
				filter = filter + " " + paramKey + "=" + val ;
			}
			else if (paramval instanceof String){
				String val = ((String)filterParams.get(paramKey)).toString();
				filter = filter + " " + paramKey + "='" + val + "'";
			}
			else if (paramval instanceof Boolean){
				boolean val = ((Boolean)filterParams.get(paramKey)).booleanValue();
				filter = filter + " " + paramKey + "=" + val + "";
			}
			else if (paramval instanceof Id){
				Id val = ((Id)filterParams.get(paramKey));
				filter = filter + " " + paramKey + "=" + val + "";
			}
			if(iterParamKeys.hasNext()){
				filter=filter+" AND ";
			}
		}
			searchQuery = null;
			for(int i = 0;i<resultParams.length;i++){
				if(i==0)
					searchQuery =resultParams[i];
				else
					searchQuery =searchQuery+","+resultParams[i];
			}


		String searchQ=null; 
		searchQ = "SELECT "+searchQuery+" FROM "+ ObjectClassName + " WITH "
		+ searchClassScope + " WHERE " + filter;
	    log.debug(searchQ);
		SearchSQL sqlObject = new SearchSQL(searchQ);
		SearchScope searchScope = new SearchScope(objectStore);
		RepositoryRowSet rowSet = searchScope.fetchRows(sqlObject, null, null, new Boolean(true));

		Iterator iter = rowSet.iterator();
		ArrayList alDocIds = new ArrayList();
		while (iter.hasNext())
		{
			Hashtable htResult = new Hashtable();
			RepositoryRow row = (RepositoryRow) iter.next();
			for(int i = 0;i<resultParams.length;i++){
				htResult.put(resultParams[i], row.getProperties().get(resultParams[i]).getObjectValue().toString());
			}
			alDocIds.add(htResult);
		}
log.debug("EXIT : searchCEObject");
		return alDocIds;
	}

	public String getPassword() {
		return password;
	}

	public String getUserId() {
		return userId;
	}
	public void closeSession(){
		if(objectStore != null){
			objectStore = null;
		}
	}
	
	protected void finalize() throws Throwable {
		//closeSession();
	}
	
}