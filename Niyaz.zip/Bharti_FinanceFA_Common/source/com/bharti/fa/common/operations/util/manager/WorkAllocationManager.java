/*
 * Created on May 9, 2009
 * 
 */
package com.bharti.fa.common.operations.util.manager;

import java.io.File;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.fa.common.workallocation.PushWorkAllocator;
import com.bharti.fa.common.workallocation.bean.UserDetailBean;
import com.bharti.fa.common.workallocation.bean.WorkAllocationXMLHandlerBean;

/**
 * The <code>WorkAllocationManager</code> class manages the allocation 
 * of work to users based on the Administrator's configuration.  
 * <p>
 * This class will be called when an new case is created or when user 
 * sends a case to another group. It reads the work allocation xml file 
 * and checks the work allocation type(Push or Pull) corresponding to the 
 * incoming case; if it is Pull then it will return string array {"PULL"} 
 * to workflow otherwise it will get the class name of the corresponding 
 * Push mechanism to be called from the xml file and call its <code>processRequest</code> 
 * method.
 * <br>
 * This class will also maintains group wise user details and group wise 
 * last user assigned in that group in the map objects. Any derived Push 
 * Work allocation class will use these maps to find the next available 
 * participant to allocate work in their own defined method.   
 * 
 * @author Harisha Achar
 * @viz.diagram WorkAllocationManager.tpx
 */
public class WorkAllocationManager {

	private static String HOME_PATH;
	private static String file_separator;
	private static String message = null;
	
	/** Contains last day on which user details has been reloaded */
	private static Date lastUserDetailsReloadedOnDay = null;
	
	/** Contains last xml file reloaded date */
	private static Calendar lastXMLFileReloadedOn = null;
	
	/**
	 * Contains group wise bpf user details. It contains GroupName(Role) as 
	 * its key and all the BPF users belonging to that role as its value.
	 * The structure of the Map looks like:
	 * <pre>
	 * 						HashMap
	 * 			-----Key-------|-----------------Value-----------
	 * 			   Group Name  |      		LinkedHashMap
	 * 							-------Key---------|-------------Value-----------
	 * 							    UserDetailBean |     	LinkedHashMap
	 * 									(object)	-------Key---|------Value-------			
	 * 												  Macro Name |     Macro Value
	 * 											    	
	 * </pre>  
	 * For Example:
	 * For the group "CSS Sourcing Group" which contains 2 users; the map 
	 * will look like:
	 * <pre>
	 * 						HashMap
	 * 		---------Key--------|-----------------Value-----------
	 * 		CSS Sourcing Group  |      		LinkedHashMap
	 * 							-------Key---------|---------------Value-----------
	 * 							    UserDetailBean1|     	LinkedHashMap
	 * 									(object)	-------Key-------|------Value-------			
	 * 												  USER_FULL_NAME |    Purushothama
	 * 												  USER_MAILID    |    Purushothama@in.ibm.com
	 * 								UserDetailBean2 |     	LinkedHashMap
	 * 									(object)	-------Key-------|------Value-------			
	 * 												  USER_FULL_NAME |      Vishu
	 * 												  USER_MAILID    |    Vishu@in.ibm.com
	 * </pre> 
	 */
	private static Map groupWiseUserDetailsMap = Collections.synchronizedMap(new HashMap());
	
	/**
	 * Contains group wise last user assigned's details. It contains GroupName(Role) 
	 * as its key and last user work assigned(as an UserDetailBean object) as its value.
	 * The structure of the Map looks like:
	 * <pre>
	 * 						HashMap
	 * 			-----Key-------|----------Value-----------
	 * 			   Group Name  |      UserDetailBean
	 * 									(object) 											    	
	 * </pre>  
	 */
	private static Map groupWiseLastUserAssignedMap = Collections.synchronizedMap(new HashMap());
	
	public static Logger log = Logger.getLogger(WorkAllocationManager.class);
	
	private static List xmlHandlerList = null;
	
	/* Contains the properties of incoming group from xml file */
	public static WorkAllocationXMLHandlerBean xmlHandler = null; 
	
	/* Get the Home directory path of all configuration files */
	static {
		log.debug("[Enter static block] ");
		
		/* Get the classpath and add "config" folder path to it. */
		String class_path = System.getProperty("java.class.path");
		
		/* Get the path.separator system variable */
		String path_separator = System.getProperty("path.separator");
		file_separator = System.getProperty("file.separator");
		StringTokenizer tokenizer = new StringTokenizer(class_path,path_separator);
		
		while(tokenizer.hasMoreTokens()) {			
			String pathString = tokenizer.nextToken();
			
			/* Get the path of "config" folder. */
			String folder = pathString.substring((pathString.length())-6,pathString.length());
			if(folder.equals("config")) {
				HOME_PATH = pathString;
				break;
			}
		}
		if(HOME_PATH == null) {
			log.error("[Inside static block]: Unable to find the [config] folder. " +
					"Please check the Classpath(required libraries.)");
		}
	}
	
	/**
	 * Gets the next available participant for allocating the work based on 
	 * the input parameter <code>inputParams</code> 
	 * <p>
	 * It reads the work allocation xml file whenever it is modified. It is 
	 * also responsible for dialy reloading the user details from bpf database.
	 * @param 	inputParams
	 * 			each input parameter will be sent in the form of {"FIELDNAME", FIELDVALUE, ...}
	 * 
	 * @return	the details of next available participant to allocate work in 
	 * 			the following order {USER_ID, USER_FULL_NAME, USER_NAME, USER_MAILID, 
	 * 			SUPERVISOR_NAME, SUPERVISOR_SSFID, SUPERVISOR_MAILID, MANAGER_NAME, 
	 * 			MANAGER_SSFID, MANAGER_MAILID, SRMANAGER_NAME, SRMANAGER_SSFID, 
	 * 			SRMANAGER_MAILID}
	 * 
	 * @throws 	IllegalArgumentException - throws for number of reasons:
	 * 				1. If the input parameter is null or empty
	 * 				2. If error occurred while parsing the xml file
	 * 			Exception - if unable to process the request due to any 
	 * 			exception occurred while processing
	 */
	public String[] getParticipant(String[] inputParams) throws Exception {
		log.debug("[Enter getParticipant]: inputParams: [" +
				Utilities.displayArray(inputParams) + "]");
		
		/* Check the input parameters */
		if(inputParams == null || inputParams.length == 0) {
			message = "Input parameter:[" + Utilities.displayArray(inputParams) + "]" +
					" is null or is empty. Hence unable to process the request.";
			log.error(message);
			throw new IllegalArgumentException(message);
		}
		
		/* Read XML file */
		log.info("--------------Reading the xml file for work allocation details of " +
				"all configured groups--------------");
		xmlHandlerList = readXMLFile();
		
		/* Check if xml file is null then we have to route to malfunction submap */
		if(xmlHandlerList == null || xmlHandlerList.size() == 0) {
			message = "Error occurred while parsing the xml file. XML Handler List is " +
					"null or empty; No Groups are configured in xml file.";
			log.error(message);
			throw new IllegalArgumentException(message);
		}
		
		/* Display the xml handler list */
		synchronized(xmlHandlerList) {
			
			// Must be in synchronized block
			Iterator itr = xmlHandlerList.iterator();		
			while(itr.hasNext()) {
				log.debug("Each XML handler is:" + (WorkAllocationXMLHandlerBean)itr.next());
			}
		}
		
		/* Load the user details dialy */
		Date today = new Date();
		if((lastUserDetailsReloadedOnDay == null) || 
				!(Utilities.converToDate(today).equals(
						Utilities.converToDate(lastUserDetailsReloadedOnDay)))) {
			log.info("--------------Loading the user details dialy once--------------");
			populateUserDetails();
			lastUserDetailsReloadedOnDay = today;
		}
		
		/* Display the current details of maps */
		displayAllMaps();

		log.debug("Processing the work");
		String[]  userDetails = processWorkAllocation(inputParams);
		log.info("Work allocation processing completed!!");
		log.debug("[Exit getParticipant]");
		return userDetails;
	}
	
	
	/**
	 * Displays the contains of group wise user details map and group wise last 
	 * user assigned map.
	 * 
	 * @throws Exception - if any exception occurred while displaying the map contents
	 */
	public static void displayAllMaps() throws Exception {
		log.debug("[Enter displayAllMaps]");
		try {
			/* Display the group wise user details list */
			if(groupWiseUserDetailsMap != null && groupWiseUserDetailsMap.size() != 0) {
				synchronized(groupWiseUserDetailsMap) {
					
					// Must be in synchronized block
					Iterator iterator = groupWiseUserDetailsMap.entrySet().iterator();	
					int groupCount = 1;
					
					log.info("\t\tGroup Wise User Details Map\t\t");
					log.info("---------------------------------------------------------");
					log.info("---------------------------------------------------------");
					log.info("Count |\t Group Name\t| Users Count");
					while (iterator.hasNext()) {
						int userCount = 1;
						Map.Entry entry = (Map.Entry) iterator.next();
						String groupName = (String)entry.getKey();
						LinkedHashMap userDetailsMap = (LinkedHashMap)entry.getValue();
						log.info("---------------------------------------------------------");
						log.info("[" + groupCount + "] |\t " + groupName + "\t  | "+
								(userDetailsMap == null ? "No" : String.valueOf(userDetailsMap.size()))+
								" users are there");
						
						if(userDetailsMap != null) {
							Iterator itr = userDetailsMap.entrySet().iterator();
							while (itr.hasNext()) {
								Map.Entry en = (Map.Entry) itr.next();
								UserDetailBean user = (UserDetailBean)en.getKey();
								HashMap hm = (HashMap)en.getValue();
								log.info("---------------------------------------------------------");
								log.info("\t| [" + userCount + "] |\t User [" + user.getOrderByUser() +
										"]\t| " + "Details [" + hm + "]");
								
								userCount++;
							}	
						}
						groupCount++;
					}
					log.info("---------------------------------------------------------");
				}
			} else {
				log.info("Group wise user details map is empty.");
			}
			
			/* Display the group wise last user assigned map  */
			if(groupWiseLastUserAssignedMap != null && groupWiseLastUserAssignedMap.size() != 0) {
				synchronized(groupWiseLastUserAssignedMap) {
					
					// Must be in synchronized block
					log.info("\t\tGroup Wise Last User Assigned Map\t\t");
					log.info("---------------------------------------------------------");
					log.info("---------------------------------------------------------");
					log.info("Count |\t Group Name\t| Last User Assigned |\t Details");
					Iterator iterator = groupWiseLastUserAssignedMap.entrySet().iterator();	
					int groupCount = 1;
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						String groupName = (String)entry.getKey();
						Object obj = entry.getValue();
						if(obj != null && obj instanceof UserDetailBean) {
							UserDetailBean userDetail = (UserDetailBean)obj;
							log.info("---------------------------------------------------------");
							log.info(" [" + groupCount + "] |\t [" + groupName + "]\t| " + 
									(userDetail.getOrderByUser() == "" ? "No User" : userDetail.getOrderByUser()) +
									"\t| [" + userDetail + "]");
						}
						groupCount++;
					}
					log.info("---------------------------------------------------------");
				}
			} else {
				log.info("Group wise last user assigned map is empty.");
			}
		} catch (Exception e) {
			log.error("Error occurred while diplaying the content of all maps." + e.getMessage(), e);
			throw e;
		}
		log.debug("[Exit displayAllMaps]");
	}


	/**
	 * Populates the bpf user details of all groups present in the group 
	 * wise user details map if and only if that group's current work 
	 * allocation type is other than PULL. 
	 * 
	 * @throws Exception - if any error occurred while populating user details
	 */
	private void populateUserDetails() throws Exception {
		log.debug("[Enter populateUserDetails]");
		try {
			log.debug("Reloading the user details of groups " + groupWiseUserDetailsMap +
					" present in the map");
			log.debug(groupWiseUserDetailsMap.size() + " groups are present in the map.");
						
			int count = 0;
			synchronized(groupWiseUserDetailsMap) {
				
				// Must be in synchronized block
				Iterator iterator = groupWiseUserDetailsMap.entrySet().iterator();	
				while (iterator.hasNext()) {
					count++;
					Map.Entry entry = (Map.Entry) iterator.next();
					String groupName = (String)entry.getKey();
					
					if(groupName != null || !(groupName.equals(""))) {
						log.debug("For Group [" + count + "] Name [" + groupName + "]: Reloading " +
								"the User details");
						
						/* Get this group's corresponding xml bean object */
						String tagNames = null;
						WorkAllocationXMLHandlerBean xmlBean = getXMLBeanForGroup(groupName);
						log.debug("For Group [" + count + "] Name [" + groupName + "]: Its xml " +
								"bean object is :" + xmlBean);
						if(xmlBean == null) {
							log.error("For Group [" + count + "] Name [" + groupName + "]: Could " +
									"not reload user details as XML Bean List " + xmlHandlerList + 
									" does not contain the specified group name. Continuing " +
									"with next group.");
							continue;
						}
						
						/* Check if the group's current work allocation type is other than PULL
						 * then only reload its user detail 
						 */ 
						if(xmlBean.getWorkAllocationType().equalsIgnoreCase("PULL")) {
							log.info("***********For Group [" + count + "] Name [" + groupName + "]: " +
									"XML Bean work allocation type is PULL; hence we " +
									"are not reloading its user details. Continuing with next group." +
									"***********");
							continue;
						}
						
						/* Get the tag name of the group in the xml list */
						tagNames = xmlBean.getTagNames();
						
						loadUserDetailsofGroup(groupName, tagNames, 
								new String[] {"GROUP_NAME", groupName});
					}
				}
			}
		} catch (Exception e) {
			log.error("Exception occurred while populating user details " + e.getMessage(), e);
			throw e;
		} 
	}

	/**
	 * Loads the active user details of the group <code>groupName</code> from the bpf database
	 * @param 	groupName
	 * 			name of the group(role) whose all active user details to be loaded
	 * @param 	tagNames
	 * 			tagname parameter value of the group from the work allocation xml file
	 * @param 	macroFields
	 * 			all the parameters in the form of {key, value, ...} to be replaced in 
	 * 			the sql query
	 * @throws 	Exception - if any error occurred while loading the user details
	 */
	private void loadUserDetailsofGroup(String groupName, String tagNames, 
			String[] macroFields) throws Exception {
		ExternalDBManager dbManager = null;
		try {
			/* Get database connection */
			dbManager = new ExternalDBManager(Constants.APPLICATION_STANDALONE);
			String db2URL = Base64.decrypt(
					PropertyLoader.props.getProperty("DATABASE_URL"));
			String db2User = Base64.decrypt(
					PropertyLoader.props.getProperty("DATABASE_USER_ID"));
			String db2pwd = Base64.decrypt(
					PropertyLoader.props.getProperty("DATABASE_USER_PASSWORD"));
			dbManager.getDbConnection(db2URL, db2User, db2pwd);
			
			/* Get the user details of the group */
			LinkedHashMap userDetailsMap = dbManager.getUserDetailsOfGroup(tagNames, macroFields);
			if(userDetailsMap == null || userDetailsMap.size() == 0) {
				log.info("For Group[" + groupName + "]: User Detail map is null");
			}
			
			/* Store the new user details for that group */ 
			groupWiseUserDetailsMap.put(groupName, userDetailsMap);
			
			/* Update the last user detail reloaded date to current date for this group */
			UserDetailBean userBean = null;
			if(groupWiseLastUserAssignedMap.containsKey(groupName)) {
				Object userObj = groupWiseLastUserAssignedMap.get(groupName);
				if(userObj != null && userObj instanceof UserDetailBean) {
					userBean = (UserDetailBean)userObj;
				} else {
					userBean = new UserDetailBean();
				}
			} else {
				userBean = new UserDetailBean();
			}
			
			// Get the current system time
			Calendar currentCal =  Calendar.getInstance();
			currentCal.setTime(new Date());
			userBean.setLastReloadedOn(currentCal);
			groupWiseLastUserAssignedMap.put(groupName, userBean);
			
			/* Close DB2 database connection */
			dbManager.closeDbConnection();
		} catch (Exception e) {
			log.error("Exception occurred while populating user details " + e.getMessage(), e);
			throw e;
		} finally {
			if(dbManager != null) {
				
				/* Close DB2 database connection */
				dbManager.closeDbConnection();
			}			
		}
	}


	/**
	 * Reads the <i>WorkAllocation.xml</i> file when ever it is modified and 
	 * stores it in an array of WorkAllocationXMLHandlerBean objects. 
	 * The structure of xml file looks like:
	 * <pre>
	 * <group-names>
	 *		<group-name id="unique id" name="group name">
     *			<property name="workAllocationType" 		value="property value1"/>
     *			<property name="workAllocationMechanism" 	value="property value2"/>
     *			<property name="usersUpdatedDate" 			value="property value3"/>
     *			<property name="tagNames" 					value="property value4"/>
     *		</group-name>
     * </group-names>
	 * </pre>
	 * 
	 * @return an ArrayList of WorkAllocationXMLHandlerBean objects 
	 * @throws IOException - if unable to parse the xml file
	 * @throws SAXException - if xml file is not well-formed
	 */
	private List readXMLFile() throws SAXException, IOException {
		log.debug("[Enter readXMLFile]");
		
		/* Get the xml file path */
		String xmlFilePath = HOME_PATH + file_separator + "xml" + file_separator +
				"WorkAllocation.xml";
		
		log.debug("Checking the last modified date of the Work allocation details " +
				"xml file [" + xmlFilePath + "]");
		File fin = new File(xmlFilePath);
		Calendar lastModCal =  Calendar.getInstance();
		lastModCal.setTimeInMillis(fin.lastModified());
		
		if(lastXMLFileReloadedOn != null) {
			log.debug("Work allocation details xml file last loaded on:["+
					lastXMLFileReloadedOn.getTime() + "] " + "It is last modified on:["
					+lastModCal.getTime() + "]");
		}
		
		if((lastXMLFileReloadedOn == null) || lastXMLFileReloadedOn.before(lastModCal)) {
			log.debug("Work allocation details xml file has been modified since its last " +
					"reload; hence reading the file");
			
			/* Load XML file */
			Document doc = parseFile(xmlFilePath);
			if(doc == null) {
				log.error("Error occurred while parsing the xml file.");
				return null;
			}
			
			/* Returns a list of all group-name elements */
			NodeList groupNameList = doc.getElementsByTagName("group-name");
			xmlHandlerList = Collections.synchronizedList(new ArrayList());
			
			/* Check each emailTypeList */
			int numGroupNameList = groupNameList.getLength();
			for (int i=0; i<numGroupNameList; i++) {
				
				/* Get each node element*/
				Node groupName = (Node) groupNameList.item(i);
				
				/* Contains all the properties of single consolidation email.
				 * Associates the name of property as its key and value of that property 
				 * as its value.  
				 */
				HashMap hm = new HashMap();
				WorkAllocationXMLHandlerBean xmlHandler = new WorkAllocationXMLHandlerBean();
				
				/* Retrieves values of the node attributes */
				String id = groupName.getAttributes().getNamedItem("id").getNodeValue().trim();
				hm.put("id", id);				
				String name = groupName.getAttributes().getNamedItem("name").getNodeValue().trim();
				
				/* Change the name to lower case and store in xml list */
				name = name.toLowerCase();
				hm.put("name", name);
				log.debug("[" + i + "] Group id [" + id + "] name(in lower case) [" + name + "]");
				
				log.debug("For group [" + i + "] name [" + name + "]: Reading its details.");
										
				Element element = (Element)groupName;
				
				/* Returns a list of all property elements */
				NodeList groupPropertyList = element.getElementsByTagName("property");
				
				int numPropertyList = groupPropertyList.getLength();
				for(int j=0; j<numPropertyList; j++) {
					Node property = groupPropertyList.item(j);
					String propName = property.getAttributes().getNamedItem("name").getNodeValue().trim();
					String propValue = property.getAttributes().getNamedItem("value").getNodeValue().trim();
					hm.put(propName, propValue);				
				}
				
				/* Get the class name */
				String workAllocationMechanism = (String)hm.get("workAllocationMechanism");
				log.debug("For group [" + i + "] name [" + name + "]: Work allocation mechanism is ["+
						workAllocationMechanism + "]");
				log.debug("For group [" + i + "] name [" + name + "]: Searching its class name.");
				
				/*
				 * In the property file, for the work allocation mechanism and that class name mapping, 
				 * we have replaced the space character in work allocation mechanism with underscore and
				 * represented in upper case
				 * Ex: Round Robin=com.bharti.fr.common.workallocation.impl.RoundRobinPushWorkAllocator, is changed to
				 *     ROUND_ROBIN=com.bharti.fr.common.workallocation.impl.RoundRobinPushWorkAllocator
				 *    
				 * So, Replace the space character with underscore and convert to upper case
				 */
				
				/* Get the group's supervisor role from the property file */
				workAllocationMechanism = 
					workAllocationMechanism.replace(' ','_').toUpperCase();
				log.debug("For group [" + i + "] name [" + name + "]: After changing work " +
						"allocation mechanism is [" + workAllocationMechanism + "]");
				
				if(!workAllocationMechanism.equals("")) {
					String workAllocationMechanismClassName = 
						PropertyLoader.props.getProperty(workAllocationMechanism);
					log.debug("The value of " + workAllocationMechanism + " from the properties " +
							"file is [" + workAllocationMechanismClassName + "]");
					hm.put("className", workAllocationMechanismClassName);	
				}
				
				/* Print the data read from xml file */
				Iterator iterator = hm.entrySet().iterator();
				log.debug("For group [" + i + "] name [" + name + "]: Displaying all properties " +
						"from xml file");
				while (iterator.hasNext()) {
					Map.Entry entry = (Map.Entry) iterator.next();
					log.debug("Property name [" + entry.getKey() + "] value [" + entry.getValue() + "]");
				}
				
				/* 
				 * Examines all of the Map parameters to see if any match a bean 
				 * property (i.e., a setXxx method) in the object. If so, the map 
				 * parameter value is passed to that method. If the method expects
				 * an int, Integer, double, Double, or any of the other primitive or 
				 * wrapper types, parsing and conversion is done automatically. 
				 * If the request parameter value is malformed (cannot be converted 
				 * into the expected type), numeric properties are assigned zero and 
				 * boolean properties are assigned false: no exception is thrown.
				 */
				Utilities.populateBean(xmlHandler, hm);
				xmlHandlerList.add(xmlHandler);
			}
						
			/* update the variable to last modified date */
			lastXMLFileReloadedOn = lastModCal;
			log.debug("Successfully reloaded the work allocation details xml file");
		} else {
			log.debug("Work allocation details xml file is not modified since its last " +
					"reload; hence not reading the file");
		}
		log.debug("[Exit readXMLFile]");
		return xmlHandlerList;
	}
	
	/** 
	 * Parses XML file and returns XML document.
	 * @param   filePath 
	 * 			XML file to parse(in absolute or relative path)
	 * @return  XML document or <B>null</B> if error occurred
	 * @throws 	SAXException - if xml file is not well-formed
	 * @throws 	IOException - if unable to parse the xml file
	 */
	public Document parseFile(String filePath) throws SAXException, IOException {
		log.debug("[Enter parseFile]");
		log.debug("Parsing XML file... " + filePath);
		DOMParser parser = new DOMParser();
		Document doc = null;
		try {
			parser.parse(filePath); 
			log.debug(filePath + " is well-formed.");
			
			/* Stores the tree object in a variable of Document type */
			doc = parser.getDocument();
			
		} catch (SAXException sax) {
			log.error(filePath + " is not well-formed.", sax);
			throw sax;
		} catch (IOException ex) { 
			log.error("Due to an IOException, the parser could not check "	+ filePath, ex); 
			throw ex;
		}
		log.debug("[Exit parseFile]");
		return doc;
	}
	
	
	/**
	 * Processes the work allocation request for the input parameter 
	 * <code>inputParams</code>.
	 * <p>
	 * If the group is configured for PULL mechanism then it return 
	 * string array {"PULL"} otherwise 
	 * 1. If the group name is not present in the user details map then 
	 * load its user details 
	 * 2. Else If the group's UserStatusChange value is updated then 
	 * reload its user details
	 * 3. Call the group's work allocation type's class
	 * @param 	inputParams
	 * 			each input parameter will be sent in the form of {"FIELDNAME", FIELDVALUE, ...}
	 * 
	 * @return	the details of next available participant to allocate work in 
	 * 			the following order {USER_ID, USER_FULL_NAME, USER_NAME, USER_MAILID, 
	 * 			SUPERVISOR_NAME, SUPERVISOR_SSFID, SUPERVISOR_MAILID, MANAGER_NAME, 
	 * 			MANAGER_SSFID, MANAGER_MAILID, SRMANAGER_NAME, SRMANAGER_SSFID, 
	 * 			SRMANAGER_MAILID}
	 * 
	 * @throws 	Exception - throws for number of reasons:
	 * 				1. If unable to find the group name from the input parameter
	 * 				2. If the requested group is not configured in the xml file
	 * 			    3. If unable to process the request due to any other exception 
	 * 					occurred while processing
	 */
	private String[] processWorkAllocation(String[] inputParams) throws Exception {
		log.debug("[Enter processWorkAllocation]: inputParams: ["+
				Utilities.displayArray(inputParams) + "]");
		
		/* Check the group's work allocation type:
		 * 1. If it is PULL, then return string array {"PULL"}
		 * 2. Else If the group name is not found in xml list then throws exception
		 * 3. Else If it is PUSH then 
		 * 		For that group check, 
		 * 			1. If the group name is not present in the user details map then load its user details
		 * 			2. Else If the group's UserStatusChange value is updated then reload its user details
		 * 		    3. Call its class 
		 */
		String[] userDetails = null;
		try {
			/* Get the name of the group from the input parameter */
			String groupName = null;
			try {
				for(int i=0; i<inputParams.length; i++) {
					String key = inputParams[i];
					String value = inputParams[++i];
					if(key.equalsIgnoreCase("GROUP_NAME")) {
						groupName = value;
					}
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				log.error("Input parameter inputParams array ["+
						Utilities.displayArray(inputParams) + "] does not contain sufficient " +
						"parameters. It should be of the format {MACRO_NAME, MACRO_VALUE, ...}"+
						e.getMessage(), e);
				throw e;
			} catch (Exception e) {
				log.error("Exception occurred parsing the input parameters. Unable to " +
						"get the group name" + e.getMessage(), e);
				throw e;
			}
			
			groupName = groupName.toLowerCase();
			log.info("The Group name(in lower case) is [" + groupName + "]");
			if(groupName == null) {
				message = "Input parameter:[" + Utilities.displayArray(inputParams) + "] " +
						"doesnot contain the Macro GROUP_NAME. Hence unable to process the " +
						"request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			/* Get this group's corresponding xml bean object */
			WorkAllocationXMLHandlerBean xmlBean = getXMLBeanForGroup(groupName);
			if(xmlBean == null) {
				message = "For Group[" + groupName + "]: Could not get the xml bean object " +
						"from  XML Bean List " + xmlHandlerList + " does not contain the specified " +
						"group name. Hence unable to process the request";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			log.info("For Group[" + groupName + "]: Work allocation type is ["+
					xmlBean.getWorkAllocationType() + "]");
			
			/* If it is PULL, then return 1 */
			if(xmlBean.getWorkAllocationType().equalsIgnoreCase("PULL")) {
				log.info("For Group[" + groupName + "]: *********** Work allocation type is PULL. " +
						"Hence returning [" + Constants.WA_RETURN_PULL_VALUE + "] as return value." +
						"***********");
				return new String[] {Constants.WA_RETURN_PULL_VALUE};
			}
			
			/* Get the tag name of the group in the xml list */
			String tagNames = xmlBean.getTagNames();
			
			/* If the group name is not present in the user details map then load its user details */
			if(!(groupWiseUserDetailsMap.containsKey(groupName))) {
				loadUserDetailsofGroup(groupName, tagNames, inputParams);
			} else {
				
				/* Else If the group's UserStatusChange value is updated then reload its user details */
				reloadUserDetailsOnStatusChange(groupName, tagNames, inputParams, xmlBean);
			}
			
			/* Call its class */
			log.info("For Group[" + groupName + "]: *********** Calling its class ***********");
			try {
				if(xmlBean.getClassName() == null) {
					message = "For Group[" + groupName + "]: Unable to call its class. " +
							"As, its class name attribute is null. Hence unable to process" +
							" the request.";
					log.fatal(message);
					throw new IllegalArgumentException(message);
				}
				
				/* Create an instance of class */ 
				Class workAllocClass = Class.forName(xmlBean.getClassName());
				PushWorkAllocator workAllocObject = (PushWorkAllocator) workAllocClass.newInstance();
				
				/* Set the current xml handler object to the class xml handler object */ 
				WorkAllocationManager.setXmlHandler(xmlBean);
				userDetails = workAllocObject.getParticipant(inputParams);
				
			} catch (ClassNotFoundException ex) {
				log.error("Error occurred while calling its class: " + ex.getMessage(),ex);
				throw ex;
			} catch (InstantiationException ex) {
				log.error("Error occurred while calling its class: " + ex.getMessage(),ex);
				throw ex;
			} catch (IllegalAccessException ex) {
				log.error("Error occurred while calling its class: " + ex.getMessage(),ex);
				throw ex;
			}	
		} catch (Exception ex) {
			log.error("Exception occurred while processing the work " + ex.getMessage(), ex);
			throw ex;
		}
		log.debug("[Exit processWorkAllocation]");
		return userDetails;
	}
	
	/**
	 * Reloads the bpf user details for the group <code>groupName</code> 
	 * if any of the group's user status(active) has been changed since 
	 * its last reload for that group.
	 * <p>
	 * It compares the group's last reloaded date(which is stored in the 
	 * corresponding UserDetailBean object) with the group's last user 
	 * status changed date(which is stored in the corresponding 
	 * WorkAllocationXMLHandlerBean object) and reload the user details 
	 * if necessary. 
	 * @param 	groupName
	 * 			name of the group(role) whose all active user details to be loaded
	 * @param 	tagNames
	 * 			tagname parameter value of the group from the work allocation xml file
	 * @param 	inputParams
	 * 			each input parameter will be sent in the form of {"FIELDNAME", FIELDVALUE, ...}
	 * @param 	xmlBean
	 * 			WorkAllocationXMLHandlerBean object for the corresponding group
	 * @throws 	Exception - if any error occurred while reloading the user details
	 */
	private void reloadUserDetailsOnStatusChange(String groupName, String tagNames, 
			String[] inputParams, WorkAllocationXMLHandlerBean xmlBean) throws Exception {
		log.debug("[Enter reloadUserDetailsOnStatusChange]");
		
		/* If the group's UserStatusChange value is updated since its last 
		 * reload time then reload its user details */
		
		// Get the group's last reloaded date
		log.debug("For Group[" + groupName + "]: Checking its last reloaded date.");
		Object userObj = groupWiseLastUserAssignedMap.get(groupName);
		if(userObj != null && userObj instanceof UserDetailBean) {
			
			// Get the group's last modified date from xml bean object
			UserDetailBean userBean = (UserDetailBean)userObj;
			Calendar lastReloadedOn = userBean.getLastReloadedOn();
			
			/* In xml file, Users Dated Date for a group will be stored in 
			 * yyyy-MM-dd HH:mm:ss format.
			 * For Example: 2009-05-13 15:09:43
			 * Hence parse the string to Date object 
			 */
			log.debug("Parsing the Users Updated Date string to Date");
			SimpleDateFormat simDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");        
			try {
				Date updatedDate = simDate.parse(xmlBean.getUsersUpdatedDate());
				Calendar updatedCal =  Calendar.getInstance();
				updatedCal.setTime(updatedDate); 						
				log.debug("For Group[" + groupName + "]: User Details last loaded on:["+
						lastReloadedOn.getTime() + "] " + "Its user details last modified" +
						" on(in xml file):[" + updatedCal.getTime() + "]");
				
				if((lastReloadedOn == null) || lastReloadedOn.before(updatedCal)) {
					
					/* Group user details has been updated hence reload it */ 
					log.info("For Group[" + groupName + "]: Group's user detail is modified " +
							"since its last reload; hence reloading its user details.");
					loadUserDetailsofGroup(groupName, tagNames, inputParams);
				} else {		
					
					/* Group user details is not modified since its last reload */
					log.info("For Group[" + groupName + "]: Group's user detail is not modified " +
							"since its last reload.");
				}
			} catch (ParseException e) {
				log.error("Unable to parse the users updated date:["+
						xmlBean.getUsersUpdatedDate() + "]. " + "It should be of the format " +
						"yyyy-MM-dd HH:mm:ss " + e.getMessage(), e);
				log.info("Hence reloading the user details");
				loadUserDetailsofGroup(groupName, tagNames, inputParams);
			}
		} else {
			log.info("For Group[" + groupName + "]: User Object in groupwise last assigned " +
					"user map is null or is not an instance of UserDetailBean class. Hence " +
					"reloading its user details.");
			loadUserDetailsofGroup(groupName, tagNames, inputParams);
		}
		log.debug("[Exit reloadUserDetailsOnStatusChange]");
	}


	/**
	 * Returns the WorkAllocationXMLHandlerBean object the group <code>groupName</code> 
	 * @param 	groupName
	 * 			name of the group(role) whose xml bean object to be retrieved
	 * @return	the WorkAllocationXMLHandlerBean object the group <code>groupName</code> 
	 * 			if found; otherwise null
	 */
	private WorkAllocationXMLHandlerBean getXMLBeanForGroup(String groupName) {
		log.debug("[Enter getXMLBeanForGroup]");
		boolean isBeanFound = false;
		WorkAllocationXMLHandlerBean xmlBean = null;
		
		synchronized(xmlHandlerList) {
			Iterator itr = xmlHandlerList.iterator();		// Must be in synchronized block
			while(itr.hasNext()) {
				xmlBean = (WorkAllocationXMLHandlerBean)itr.next();
				//log.debug("each bean: "+xmlBean);	
				
				/* Check the bean name */
				if(xmlBean.getName().equalsIgnoreCase(groupName)) {
					isBeanFound = true;
					break;
				}
			}
		}
		if(!isBeanFound) {
			log.debug("Xml Bean not found");
			log.debug("[Exit getXMLBeanForGroup]");
			return null;
		} else {
			log.debug("Xml Bean " + xmlBean + " found");
			log.debug("[Exit getXMLBeanForGroup]");
			return xmlBean;
		}
	}

	/**
	 * @return Returns the groupWiseUserDetailsMap.
	 */
	public static Map getGroupWiseUserDetailsMap() {
		return groupWiseUserDetailsMap;
	}
	
	/**
	 * @param groupWiseUserDetailsMap The groupWiseUserDetailsMap to set.
	 */
	public static void setGroupWiseUserDetailsMap(Map groupWiseUserDetailsMap) {
		WorkAllocationManager.groupWiseUserDetailsMap = groupWiseUserDetailsMap;
	}
	
	/**
	 * @return Returns the groupWiseLastUserAssignedMap.
	 */
	public static Map getGroupWiseLastUserAssignedMap() {
		return groupWiseLastUserAssignedMap;
	}
	/**
	 * @param groupWiseLastUserAssignedMap The groupWiseLastUserAssignedMap to set.
	 */
	public static void setGroupWiseLastUserAssignedMap(Map groupWiseLastUserAssignedMap) {
		WorkAllocationManager.groupWiseLastUserAssignedMap = groupWiseLastUserAssignedMap;
	}
	
	/**
	 * @return Returns the xmlHandler.
	 */
	public static WorkAllocationXMLHandlerBean getXmlHandler() {
		return WorkAllocationManager.xmlHandler;
	}
	/**
	 * @param xmlHandler The xmlHandler to set.
	 */
	public static void setXmlHandler(WorkAllocationXMLHandlerBean xmlHandler) {
		WorkAllocationManager.xmlHandler = xmlHandler;
	}
	
	/**
	 * Returns the user details map of the corresponding user
	 * @param 	userDetailsMap
	 * 			map in which user details have to be searched
	 * @param 	nextUserToBeAssigned
	 * 			the user to be searched
	 * @return	the user details map
	 */
	public static LinkedHashMap getDetailsOfUser(LinkedHashMap userDetailsMap, 
			UserDetailBean nextUserToBeAssigned) {
		
		log.debug("[Enter getDetailsOfUser]");
		LinkedHashMap detailsMap = null;
		Iterator itr = userDetailsMap.entrySet().iterator();
		while(itr.hasNext()) {
			Map.Entry entry = (Map.Entry) itr.next();
			UserDetailBean eachBean = (UserDetailBean)entry.getKey();
			if(eachBean.getBpfUserId() == nextUserToBeAssigned.getBpfUserId()) {
				detailsMap = (LinkedHashMap)entry.getValue();
			}
		}
		log.debug("[Exit getDetailsOfUser]");
		return detailsMap;
	}
	
	public static void main(String[] args) {
	}
}
