package com.bharti.fa.common.operations.util.manager;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.fa.common.workallocation.bean.UserDetailBean;

/**
 * @viz.diagram ExternalDBManager.tpx
 */
public class ExternalDBManager {
	
	private static Logger logger = Logger.getLogger(ExternalDBManager.class);
	
	private Connection dbConnection = null;
	private int application;
	
	public ExternalDBManager(int application) {
		this.application=application;
	}
	
	/**
	 * Creates a DB connection (JDBC/JNDI)
	 * @param	  db2URL: URL for JDBC connection
	 *                    Data Source Name for JNDI connection
	 * @param	  db2User:User Name for JDBC connection
	 *                    null for JNDI connection
	 * @param	  db2pwd:Password for JDBC connection
	 *                   null for JNDI connection 
	 * */
	
	public Connection getDbConnection(String db2URL, String db2User, String db2pwd) {
		logger.debug("[Entry getDbConnection]");
		try {
			if (application == Constants.APPLICATION_WEB) {
			    String dataSourceName=db2URL;
			    logger.info("Data Source Name:"+dataSourceName);
				
				InitialContext ctx = new InitialContext();
				java.lang.Object objRef = ctx.lookup(dataSourceName);
				DataSource dataSource = (DataSource) objRef;
				dbConnection = dataSource.getConnection();
				
			} else if (application == Constants.APPLICATION_STANDALONE) {
				try	{
					logger.debug("Trying to connect to Database.");
					Class.forName( PropertyLoader.props.getProperty("DATABASE_CLASSFORNAME"));				
					dbConnection = DriverManager.getConnection(db2URL, db2User, db2pwd);
					
					logger.debug("Connected to Database.");
				}
				catch (Exception ex) {
					logger.error("Error while connecting to database. " + ex.getMessage(), ex);
				}
			}
		} catch (Exception e) {
			logger.fatal("Error while creating DB connection  : ", e);
		}
		logger.debug("[Exit ExternalDBManager]");
		return dbConnection;
	}
	
	public Connection getDbConnection() {
		return dbConnection;
	}
	
	public void closeDbConnection() {
		try {
			if(dbConnection!=null){
				dbConnection.close();
			}
		} catch(SQLException e) {
			logger.error("Error while closing DB connection  : ", e);
		}
		dbConnection = null;
	}
	
	protected void finalize() throws Throwable {
		try {
			if(dbConnection!=null){
				dbConnection.close();
			}
		} catch(SQLException e) {
			logger.error("In finalize block: Error while closing DB connection  : ", e);
		}
		dbConnection = null;
	}
	
	public static void main(String[] args) {
		//ExternalDBManager dbmanager = new ExternalDBManager(1);
	}

	/**
	 * Gets the user details based on the input parameters <code>macroFields</code> 
	 * from the database.
	 * @param  	tagNames
	 * 			tagname parameter value of the group from the work allocation xml file
	 * @param 	macroFields
	 * 			all the parameters in the form of {key, value, ...} to be replaced in 
	 * 			the sql query
	 * @return	all user details based on the input parameters <code>macroFields</code>.
	 * 			The returned map will be of the form
	 * <pre>
	 * 					LinkedHashMap
	 * 		-------Key---------|-------------Value-----------
	 * 		  UserDetailBean   |     	LinkedHashMap
	 * 		   (object)			-------Key---|------Value-------			
	 * 							  Macro Name |     Macro Value
	 * 											    	
	 * </pre>  
	 * @throws Exception - if any exception occurred while getting the user details
	 */
	public LinkedHashMap getUserDetailsOfGroup(String tagNames, String[] macroFields) throws Exception {
		logger.debug("[Entry getUserDetailsOfGroup]");
		LinkedHashMap userDetailsMap = new LinkedHashMap();
				
		// Sql query will be defined in the properties as follows:
		// Key will be: tag name of that group + "_GET_EMAIL_QUERY"
		// Value is the sql query
		String queryString = tagNames + "_GET_EMAIL_QUERY";
		boolean success=false;
		try	{	
			String sql = PropertyLoader.props.getProperty(queryString);
			logger.debug("SQL Query before replacing macros(if present) is :"+sql);
			
			StringBuffer sqlBuf = new StringBuffer(sql);
			
			/* Replace any macros present in query */
			if(macroFields == null) {
				logger.info("Macro fields array is null." );
			} else {
				try {
					for(int i=0; i<macroFields.length; i++) {
						Utilities.replaceAll(sqlBuf, "$"+macroFields[i], macroFields[++i]);
					}
				} catch (ArrayIndexOutOfBoundsException e) {
					logger.error("Input parameter macroFields array does not contain sufficient " +
							"parameters. It should be of the format {MACRO_NAME, MACRO_VALUE, ...}"+
							e.getMessage(), e);
					throw e;
				} catch (Exception e) {
					logger.error("Exception occurred while filtering the sql query for macros."+
							e.getMessage(), e);
					throw e;
				}
			}
					
			logger.debug("SQL Query after replacing macros(if present) is :"+sqlBuf);
			
			PreparedStatement pstmt=dbConnection.prepareStatement(sqlBuf.toString());
			ResultSet rs=pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
		    int numberOfColumns = rsmd.getColumnCount();
		    logger.debug("Number of columns in each selected record is:"+numberOfColumns);
			
			String orderByUserFieldName = PropertyLoader.props.getProperty(
					tagNames + "_ORDER_BY_USER_FIELD");
			logger.debug("The value of "+tagNames + "_ORDER_BY_USER_FIELD from the properties file is ["+
					orderByUserFieldName+"]");
			
			while(rs.next()) {
				UserDetailBean user = new UserDetailBean();
				String orderByUser = rs.getString(orderByUserFieldName);
				user.setOrderByUser(orderByUser);
				
				int bpfUserId = Integer.parseInt(rs.getString("USER_ID"));
				user.setBpfUserId(bpfUserId);
				
				LinkedHashMap hm = new LinkedHashMap();
				for(int j=1; j<=numberOfColumns; j++) {
					hm.put(rsmd.getColumnName(j), rs.getObject(j));
				}
				
				/* Add each user detail */
				userDetailsMap.put(user, hm);
				logger.info("User ["+user+"] with details ["+hm+"] found.");
			}
			
			if(userDetailsMap.size() == 0) {
				logger.info("No active users found for parameter ["+Utilities.displayArray(macroFields)+
						"]. ResultSet is empty.");
			} else {
				logger.info(userDetailsMap.size()+" users found for parameter ["+
						Utilities.displayArray(macroFields)+"].");
			}
			success = true;
		}
		catch (SQLException sqlEx) {
			logger.error("SQL exception occurred while searching users for parameter ["+
					Utilities.displayArray(macroFields)+"]. "+sqlEx.getMessage(), sqlEx);
			success = false;
			throw sqlEx;
		}
		finally	{
			try	{
				if (dbConnection != null) {
					if (success) {
						dbConnection.commit();
					} else {
						dbConnection.rollback();
					}
					//dbConnection.close();
				}
				logger.info("Execution Status of Query:" + success);
			}
			catch (SQLException ex) {
				success = false;
				throw ex;
			}
		}
		logger.debug("[Exit getUserDetailsOfGroup]");		
		return userDetailsMap;
	}

	/**
	 * Gets the workload of all users (all groups) from the database
	 * @param 	inputParams
	 * 			each input parameter will be sent in the form of 
	 * 			{"FIELDNAME", FIELDVALUE ...}
	 * @return  each users workload count with key has the user ssfid and value 
	 * 			has workload count 
	 * @throws 	Exception - if any error occurred while getting user workload 
	 * 			from database
	 */
	public HashMap getWorkload(String[] inputParams) throws Exception {
		logger.debug("[Entry getWorkload]");
		HashMap eachUserWorkloadMap = new HashMap();
				
		String queryString = "WORKLOAD_GET_EMAIL_QUERY";
		boolean success=false;
		try	{	
			String sql = PropertyLoader.props.getProperty(queryString);
			logger.debug("SQL Query before replacing macros(if present) is :"+sql);
			
			StringBuffer sqlBuf = new StringBuffer(sql);
			
			/* Replace any macros present in query */
			if(inputParams == null) {
				logger.info("Macro fields array is null." );
			} else {
				try {
					for(int i=0; i<inputParams.length; i++) {
						Utilities.replaceAll(sqlBuf, "$"+inputParams[i], inputParams[++i]);
					}
				} catch (ArrayIndexOutOfBoundsException e) {
					logger.error("Input parameter inputParams array does not contain sufficient " +
							"parameters. It should be of the format {MACRO_NAME, MACRO_VALUE, ...}"+
							e.getMessage(), e);
					throw e;
				} catch (Exception e) {
					logger.error("Exception occurred while filtering the sql query for macros."+
							e.getMessage(), e);
					throw e;
				}
			}
					
			logger.debug("SQL Query after replacing macros(if present) is :"+sqlBuf);
			
			PreparedStatement pstmt=dbConnection.prepareStatement(sqlBuf.toString());
			ResultSet rs=pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
		    int numberOfColumns = rsmd.getColumnCount();
		    logger.debug("Number of columns in each selected record is:"+numberOfColumns);
			
		    logger.info("---------------------------------------------------------");
			logger.info("Count |\t User\t| Workload Count");
			logger.info("---------------------------------------------------------");
			int userCount = 1;
			while(rs.next()) {
				String user = rs.getString(1);
				int count = rs.getInt(2);
				eachUserWorkloadMap.put(user, new Integer(count));
				logger.info("["+userCount+"] |\t "+user+" |\t "+count+" pending cases.");
				logger.info("---------------------------------------------------------");
				userCount++;
			}
			
			if(eachUserWorkloadMap.size() == 0) {
				logger.info("-----------No users has pending cases for input parameter["+
						Utilities.displayArray(inputParams)+"]. ResultSet is empty.-----------");
			} else {
				logger.info("-----------"+eachUserWorkloadMap.size()+" users found for parameter ["+
						Utilities.displayArray(inputParams)+"].-----------");
			}
			success = true;
		}
		catch (SQLException sqlEx) {
			logger.error("SQL exception occurred while searching workload of users for parameter ["+
					Utilities.displayArray(inputParams)+"]. "+sqlEx.getMessage(), sqlEx);
			success = false;
			throw sqlEx;
		}
		finally	{
			try	{
				if (dbConnection != null) {
					if (success) {
						dbConnection.commit();
					} else {
						dbConnection.rollback();
					}
					//dbConnection.close();
				}
				logger.info("Execution Status of Query:" + success);
			}
			catch (SQLException ex) {
				success = false;
				throw ex;
			}
		}
		logger.debug("[Exit getWorkload]");		
		return eachUserWorkloadMap;
	}
	
		
	public void setAutoCommit(boolean enable) throws Exception{
		try {
			dbConnection.setAutoCommit(enable);
		} catch (SQLException e) {
			logger.fatal(e);
			throw e;
		}
	}
	
	public void persistData(boolean flag) throws SQLException {
		if(flag == true) {
			try {
				dbConnection.commit();
			} catch (SQLException e) {
				logger.fatal(e);
				throw e;
			}
		} else if(flag == false) {
			try {
				dbConnection.rollback();
			} catch (SQLException e) {
				logger.fatal(e);
				throw e;
			}
		}
	}
}