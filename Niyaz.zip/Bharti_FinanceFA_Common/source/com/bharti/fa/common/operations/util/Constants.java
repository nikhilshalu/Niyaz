package com.bharti.fa.common.operations.util;

/**
 * @viz.diagram Constants.tpx
 */
public class Constants {

	public static final int APPLICATION_WEB=0;
	public static final int APPLICATION_STANDALONE=1;
	public static final int APPLICATION_COMPONENT_MANAGER=2;
	public static final int APPLICATION_SUBSCRIPTION=3;
	
	public static final String WA_RETURN_PULL_VALUE = "PULL";
	public static final int WA_RETURN_ERROR=-1;
	
	public static final String APPLICATION_BPF_JASSCONTEXT="FileNetP8WSI";
	public static final String APPLICATION_CM_JASSCONTEXT="FileNetP8";
	
	public static final String BPM_CE_SEARCH_SCOPE="searchscope";
	public static final String BPM_CE_SEARCH_MAXRECORDS="500";
	public static final String BPM_CE_SEARCH_SCOPE_INCLUDESUBCLASS="INCLUDESUBCLASSES";
	public static final String BPM_CE_SEARCH_SCOPE_EXCLUDESUBCLASSES="EXCLUDESUBCLASSES";


	public static final int PE_SEARCH_WFTYPE_MAIN = 0;
	public static final int PE_SEARCH_WFTYPE_REMINDER = 1;
	public static final String PE_SEARCH_WFTYPE_HRSS_SUBJECT = "HRSS";


	
	public static final String PE_SEARCH_SCOPE_QUEUE = "SEARCH_QUEUE";
	public static final String PE_SEARCH_SCOPE_ROSTER = "SEARCH_ROSTER";
	public static final String PE_FETCH_WORK_OBJECT = "WORKOBJECT";
	public static final String PE_FETCH_INSTRUCTION_ELEMENT = "INSTRUCTION_ELEMENT";
	public static final String PE_FETCH_QUEUE_ELEMENT = "QUEUE_ELEMENT";
	public static final String PE_FETCH_STEP_ELEMENT = "STEP_ELEMENT";
	public static final String PE_FETCH_ROSTER_ELEMENT = "ROSTER_ELEMENT";
	
	public static final String SEARCH_SCOPE_QUEUE = "SEARCH_QUEUE";
	public static final String SEARCH_SCOPE_ROSTER = "SEARCH_ROSTER";
	public static final String FETCH_WORK_OBJECT = "WORKOBJECT";
	public static final String FETCH_INSTRUCTION_ELEMENT = "INSTRUCTION_ELEMENT";
	public static final String FETCH_QUEUE_ELEMENT = "QUEUE_ELEMENT";
	public static final String FETCH_STEP_ELEMENT = "STEP_ELEMENT";
	public static final String FETCH_ROSTER_ELEMENT = "ROSTER_ELEMENT";
	
	public static final String MILESTONE = "M";
	public static final String PROCESS = "P";
	public static final String ESCALATION = "E";
	public static final String REMINDER = "R";
	
	public static final String STRING_REMINDER = "Reminder";
	public static final String STRING_ESCALATION = "Escalation";
	
	public static final String STRMILESTONE = "Milestone";
	public static final String STRPROCESS = "Process";
	public static final String STRQUERY = "Query";
	public static final String REQUEST = "Request";
	
	public static final String DATE_STRING_FORMAT = "yyyy-MM-dd HH:mm:ss";

}
