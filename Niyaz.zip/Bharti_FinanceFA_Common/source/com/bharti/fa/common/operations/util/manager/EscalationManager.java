/*
 * Created on Dec 21, 2008
 *
 */
package com.bharti.fa.common.operations.util.manager;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Set;

import org.apache.log4j.Logger;
import org.apache.xerces.parsers.DOMParser;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author Harisha C S Achar(Email ID: harisha.achar@in.ibm.com,
 *         mail2harisha@gmail.com)
 * @viz.diagram EscalationManager.tpx
 * 
 */
public class EscalationManager {
	public static Logger log = Logger.getLogger(EscalationManager.class);

	private long WORKING_MINS;

	private int S_HOUR;

	private int S_MINUTE;

	private int S_SECOND;

	private int E_HOUR;

	private int E_MINUTE;

	private int E_SECOND;

	/*
	 * 3,600,000 the number of milliseconds in an hour
	 */
	private static final int MILLISECONDS_PER_HOUR = 60 * 60 * 1000;

	private static final int MILLISECONDS_PER_MINUTE = 60 * 1000;

	/* This map object will contain all the company holidays */
	private static LinkedHashMap yearMap = null;

	private static LinkedHashMap yearHolidayMap = null;

	private boolean isSaturdayAWorkingDay;

	private boolean isSundayAWorkingDay;

	private boolean isHolidayAWorkingDay;

	private boolean isNegativeOffset = false;

	private boolean isNightShiftTiming = false;

	/* Contains last xml file reloaded date */
	private static Calendar lastHolidayXMLFileReloadedOn = null;

	private void processOfficeWorkingTime(String officeStartTime,
			String officeEndTime) {
		/*
		 * Validate the .properties file for any errors
		 */
		log.debug("Initializing the Office timings.");
		int sHour = 0;
		int sMinute = 0;
		int sSecond = 0;
		int eHour = 0;
		int eMinute = 0;
		int eSecond = 0;
		long sMinutes = 0;
		long eMinutes = 0;
		try {
			/*
			 * Check for errors in reading the StartOfficeWorkingTime element
			 * from properties file
			 */

			String tokens[] = officeStartTime.split(":");
			sHour = Integer.parseInt(tokens[0]);
			sMinute = Integer.parseInt(tokens[1]);
			sSecond = Integer.parseInt(tokens[2]);

			sMinutes = sHour * 60 + sMinute;
			/* Check if Office starting time's hour is between 0-23 */
			if (sHour < 0 || sHour > 23) {
				throw new IllegalArgumentException(
						"Invalid argument Start Office Time's Hour(hh)" + "["
								+ officeStartTime
								+ "] should be in the range of 0 and 23.");
			}

			/* Check if Office starting time's minute is between 0-59 */
			if (sMinute < 0 || sMinute > 59) {
				throw new IllegalArgumentException(
						"Invalid argument Start Office Time's Minute(mm)" + "["
								+ officeStartTime + "]"
								+ " should be in the range of 0 and 59.");
			}

			/* Check if Office starting time's second is between 0-59 */
			if (sSecond < 0 || sSecond > 59) {
				throw new IllegalArgumentException(
						"Invalid argument Start Office Time's Second(ss)" + "["
								+ officeStartTime + "]"
								+ " should be in the range of 0 and 59.");
			}

		} catch (NumberFormatException e) {
			log.error("Unable to read the Start Office Time ["
					+ officeStartTime + "]"
					+ "Time should be of the format hh:mm:ss. "
					+ e.getMessage(), e);
		} catch (IllegalArgumentException e) {
			log.error(e.getMessage(), e);
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error("Unable to read the Start Office Time ["
					+ officeStartTime + "]"
					+ "Time should be of the format hh:mm:ss. "
					+ e.getMessage(), e);
		}

		/*
		 * Check for errors in reading the EndOfficeWorkingTime element from
		 * properties file
		 */

		try {
			String tokens[] = officeEndTime.split(":");
			eHour = Integer.parseInt(tokens[0]);
			eMinute = Integer.parseInt(tokens[1]);
			eSecond = Integer.parseInt(tokens[2]);

			eMinutes = eHour * 60 + eMinute;
			/* Check if Office ending time's hour is between 0-23 */
			if (eHour < 0 || eHour > 23) {
				throw new IllegalArgumentException(
						"Invalid argument End Office Time's Hour(hh)" + "["
								+ officeEndTime + "]"
								+ " should be in the range of 0 and 23. ");
			}

			/* Check if Office ending time's minute is between 0-59 */
			if (eMinute < 0 || eMinute > 59) {
				throw new IllegalArgumentException(
						"Invalid argument End Office Time's Minute(mm)" + "["
								+ officeEndTime + "]"
								+ " should be in the range of 0 and 59. ");
			}

			/* Check if Office ending time's second is between 0-59 */
			if (eSecond < 0 || eSecond > 59) {
				throw new IllegalArgumentException(
						"Invalid argument End Office Time's Second(ss)" + "["
								+ officeEndTime + "]"
								+ " should be in the range of 0 and 59. ");
			}
		} catch (NumberFormatException e) {
			log.error("Unable to read the End Office Time " + "["
					+ officeEndTime + "]" + "Time should "
					+ "be of the format hh:mm:ss. " + e.getMessage(), e);
		} catch (IllegalArgumentException e) {
			log.error(e.getMessage(), e);
		} catch (ArrayIndexOutOfBoundsException e) {
			log.error("Unable to read the End Office Time " + "["
					+ officeEndTime + "]" + "Time should be "
					+ "of the format hh:mm:ss. " + e.getMessage(), e);
		}

		/*
		 * Calculate the Number of Working Hours in a day
		 */
		WORKING_MINS = (eMinutes < sMinutes) ? ((eMinutes + (24 * 60)) - sMinutes)
				: (eMinutes - sMinutes);
		S_HOUR = sHour;
		S_MINUTE = sMinute;
		S_SECOND = sSecond;

		E_HOUR = eHour;
		E_MINUTE = eMinute;
		E_SECOND = eSecond;
		log.info("Office Starting Time is [" + officeStartTime
				+ "]. Office Ending Time is [" + officeEndTime + "].");
		log.info("Number of Office Working hours per day is " + (WORKING_MINS)
				/ 60 + " hour(s) and " + (WORKING_MINS) % 60 + " minute(s).");

		/*
		 * Check the office timing for night shift timings
		 */
		Calendar todayCal = Calendar.getInstance();

		Calendar dayStartCal = Calendar.getInstance();
		dayStartCal.set(todayCal.get(Calendar.YEAR), todayCal
				.get(Calendar.MONTH), todayCal.get(Calendar.DATE), S_HOUR,
				S_MINUTE, S_SECOND);

		Calendar dayEndCal = Calendar.getInstance();
		dayEndCal.set(todayCal.get(Calendar.YEAR),
				todayCal.get(Calendar.MONTH), todayCal.get(Calendar.DATE),
				E_HOUR, E_MINUTE, E_SECOND);

		if (dayEndCal.before(dayStartCal)) {
			isNightShiftTiming = true;
			log.debug("The office timing is overlapped between two days; "
					+ "hence isNightShiftTiming flag is true");
		} else {
			log.debug("isNightShiftTiming flag is false");
		}
	}
	
	

	public int totalUtilizedTime(Date startDate, Date endDate, int slaCalculationID, String shiftStartTime, String shiftEndTime, String filePath)
	{
	    
	    int mins = 0;
	    
	    processOfficeWorkingTime(shiftStartTime, shiftEndTime);
		processSlaCalculationId(slaCalculationID);
		
		Calendar mStartCal = Calendar.getInstance();
		mStartCal.setTime(startDate);
/*		System.out.println("Start Date: "+mStartCal.getTime());
		mStartCal = getStartingOfficeWorkingTime(mStartCal);*/
		System.out.println("Updated Start Date: "+mStartCal.getTime());
		
		
		
		Calendar mEndCal = Calendar.getInstance();
		mEndCal.setTime(endDate);
/*		System.out.println("End Date: "+mEndCal.getTime());
		mEndCal = getEndingOfficeWorkingTime(mEndCal);*/
		System.out.println("UpdATED End Date: "+mEndCal.getTime());
		
		
		Calendar officeStartCal = Calendar.getInstance();
		Calendar officeEndCal	= Calendar.getInstance();
		
		
		
		
		// Get the ending office working time of caseReceivedDate
		officeStartCal.set(mStartCal.get(Calendar.YEAR), mStartCal.get(Calendar.MONTH),
				mStartCal.get(Calendar.DATE), S_HOUR, S_MINUTE, S_SECOND);
		//officeStartCal = getStartingOfficeWorkingTime(officeStartCal);
		
		
		officeEndCal.set(mStartCal.get(Calendar.YEAR), mStartCal.get(Calendar.MONTH),
				mStartCal.get(Calendar.DATE), E_HOUR, E_MINUTE, E_SECOND);
		
		//officeEndCal = getEndingOfficeWorkingTime(officeEndCal);
		//log.info(Office)
		// Parse the Company Holidays xml file and store all Holidays in an
		// LinkedHashMap object
		if (!isHolidayAWorkingDay) {
				parseCompanyHolidayXML(filePath);
		}

		if(compareDate(mStartCal, mEndCal)) 		// Check whether milestone is achieved the same day
		{
		    
		    if(((mStartCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SUNDAY && !isSundayAWorkingDay)
				|| ((mStartCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SATURDAY && !isSaturdayAWorkingDay))
		    {
		        log.debug("Action is taken on non working day returning [0] mins");
		        mins = 0;
		    }
		    
		    else if((mStartCal.after(officeStartCal) || mStartCal.equals(officeStartCal)) 
		            		&& (mEndCal.before(officeEndCal) || mEndCal.equals(officeEndCal)))
		    {
				mins = calculateNumberOfMinutesBetween(mStartCal, mEndCal);
				log.debug("Total time taken to complete the task is Hour: "+mins/60+" Minutes "+mins%60);
		    }

		    else if(mStartCal.before(officeStartCal) && mEndCal.after(officeEndCal))
		    {
		        mins = calculateNumberOfMinutesBetween(officeStartCal, officeEndCal);
				log.debug("Total time spend is "+mins/60+" Hour & "+mins%60+" Minutes");
		    }
		    else if(mStartCal.before(officeStartCal) && (mEndCal.before(officeEndCal) || mEndCal.equals(officeEndCal)))
		    {
		        mins = calculateNumberOfMinutesBetween(officeStartCal, mEndCal);
		        log.debug("Total time taken is Hour: "+mins/60+" Minutes "+mins%60);
		    }
		    
		    else if(mStartCal.after(officeEndCal) && mEndCal.after(officeEndCal))
		    {
				mins = 0;
				log.debug("Total time to complete the task is Hour: "+mins/60+" Minutes "+mins%60);
		    }
		    
		    else if(mStartCal.after(officeStartCal) && mEndCal.after(officeEndCal))
		    {
		        mins = calculateNumberOfMinutesBetween(mStartCal, officeEndCal);
		        //mins = 0;
		        log.debug("Total time taken is Hour: "+mins/60+" Minutes "+mins%60);
		    }
/*		    else if((mStartCal.before(officeStartCal) || mStartCal.after(officeEndCal)) 
            		&& (mEndCal.before(officeStartCal) || mEndCal.after(officeEndCal)))
		    {
				mins = 0;
				log.debug("Action achived on same day outside office hours "+
										"Total time taken to complete the task is Hour: "+mins/60+" Minutes "+mins%60);
		    }*/
		    
		    else
		    {
		        mins = calculateNumberOfMinutesBetween(officeStartCal, officeEndCal);
				log.debug("This Milestone is achived on same day of case arrival but outside office hour"+
										"\n Total time spend is "+mins/60+" Hour & "+mins%60+" Minutes");
		    }
		}
		else{
		    
		    
		    if(mStartCal.before(officeStartCal))
		    {
			    mins = calculateNumberOfMinutesBetween(officeStartCal, officeEndCal);
				log.debug("Action is not achived on same day of case arrival"+
									"\n Total time spend is "+mins/60+" Hour & "+mins%60+" Minutes");
		    }
		    else if(mStartCal.before(officeEndCal))
		    {
			    mins = calculateNumberOfMinutesBetween(mStartCal, officeEndCal);
				log.debug("Not achived on same day of case arrival"+
									"\n Total time spend is "+mins/60+" Hour & "+mins%60+" Minutes");
		    }
		    /*else if(mStartCal.before(officeStartCal))
		    {
		        
		    }*/
		    
			Calendar nextWorkingDayCal;
			do{
				nextWorkingDayCal = getNextWorkingDay(officeStartCal);
				if(nextWorkingDayCal.after(mEndCal))
				{
				    nextWorkingDayCal = getPrevWorkingDay(officeStartCal);
				    log.debug("Prev working day is "+nextWorkingDayCal.getTime());
				    officeEndCal = getEndingOfficeWorkingTime(nextWorkingDayCal);
				    mins += calculateNumberOfMinutesBetween(officeStartCal, nextWorkingDayCal);
				    break;
				    
				}
				log.debug("Next working day is "+nextWorkingDayCal.getTime());
				officeEndCal = getEndingOfficeWorkingTime(nextWorkingDayCal);
				log.debug("2- Office Start Time "+officeStartCal.getTime());
				log.debug("2- Office End Time "+officeEndCal.getTime());
			
				if(compareDate(mEndCal, nextWorkingDayCal))
				{
				    if(mEndCal.after(officeStartCal) && mEndCal.before(officeEndCal))
				    {
				        log.debug("xOffice Start Time "+officeStartCal.getTime());
				        log.debug("xOffice End Time "+officeEndCal.getTime());
						log.debug("xActual End Date "+mEndCal.getTime());
						mins += calculateNumberOfMinutesBetween(mEndCal, nextWorkingDayCal);
				    }
				    else if(mEndCal.after(officeEndCal))
				    {
				        log.debug("Inside Else");
						log.debug("Office End Time "+officeEndCal.getTime());
						log.debug("Actual End Date "+mEndCal.getTime());
				        mins += calculateNumberOfMinutesBetween(officeStartCal, officeEndCal);
				    }
				}
				else{
					mins += (int)WORKING_MINS;
				}
			}while(!compareDate(mEndCal, nextWorkingDayCal));

		}
		return mins;
	}
	
	public boolean compareDate(Calendar calender1, Calendar calender2)
	{
		
		if ( calender1.get(Calendar.YEAR) == calender2.get(Calendar.YEAR) &&
				calender1.get(Calendar.MONTH) == calender2.get(Calendar.MONTH) &&
				calender1.get(Calendar.DAY_OF_MONTH) == calender2.get(Calendar.DAY_OF_MONTH) ) 
			return true;
		else
			return false;
	}
	
	
	private Calendar getPrevWorkingDay(Calendar arrivalCal) {

		// Decrement to previous day
		arrivalCal.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? 1 : -1));

		if ((arrivalCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SUNDAY
				&& !isSundayAWorkingDay) {
			arrivalCal.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? 1 : -1));
		}
		
		if ((arrivalCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SATURDAY
				&& !isSaturdayAWorkingDay) {
			arrivalCal.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? 1 : -1));
		}
		
		if (isDayIsHoliday(arrivalCal)) {
			arrivalCal = getPrevWorkingDay(arrivalCal);
		}
		log.info("The Previous Working office day is " + arrivalCal.getTime());
		return arrivalCal;
	}
	

	public static void main(String args[]) {
		String slaMins = "";

		InputStreamReader isr = new InputStreamReader(System.in);
		BufferedReader inData = new BufferedReader(isr);
		System.out.print("Please enter the Number of SLA Hours :");
		try {
			slaMins = inData.readLine();
			System.out.println(slaMins);
		} catch (IOException e) {
			e.printStackTrace();
		}
		if (false) {
			new EscalationManager().calculateNumberOfHoursBetween(null, null);
		}
		// String[] str = new SCMOperations().calculateSLA(slaHour, "Oct 09
		// 15:28:03 2008");
		/*
		 * String[] str = new EscalationManager().calculateSLA(slaHour, "");
		 * for(int i=0; i<str.length; i++) System.out.println("The Exact SLA As
		 * String is :" + str[i]);
		 */
		// parseCompanyHolidayXML();
		// Date[] slaExactDate = new EscalationManager().calculateSLA(
		// slaMins, "Oct 09 15:28:03 2008", 2, 8, "09:00:00", "18:00:00", "");
	}

	/**
	 * Returns the SLA expiration time for the given <code>slaHour</code> with
	 * respect to <code>caseReceivedOnDate</code>, where SLA means Service
	 * Level Agreement in terms of hours.
	 * 
	 * <p>
	 * It returns the exact time of the day from <code>caseReceivedOnDate</code>
	 * date after <code>slaHour</code> number of hours; by considering <b>only
	 * working hours</b> of a day(defined in the property file) and excluding
	 * <b>weekends</b> and <b>company holidays</b>(defined in the xml file).
	 * 
	 * <p>
	 * The <code>slaHour</code> contains the multilple SLA hours separated by
	 * delimiter "-".
	 * 
	 * @see com.bharti.fr.common.operations.util.manager.EscalationManager#calculateSLA()
	 * 
	 * @param eachSLAMin
	 *            number of SLA hours separated by delimiter "-" if there are
	 *            multiple SLA hours.
	 * 
	 * @param caseReceivedOnDate
	 *            contains either
	 * 
	 * <pre>
	 *  
	 *          1. Exact case received on date : then consider this to add the slaHour
	 *  		   2. null : then consider current system time to add the slaHour
	 * </pre>
	 * 
	 * @return SLA expiration time in "day month dd hh:tt:ss yyyy" format.
	 */
	/**
	 * @param slaMins
	 * @param relativeDate
	 * @param slaTypeId
	 * @param slaCalculationId
	 * @param officeStartTime
	 * @param officeEndTime
	 * @param filePath
	 * @return
	 */
	public Date[] calculateSLA(String offset, Date relativeDate, int slaTypeId,
			int slaCalculationId, String officeStartTime, String officeEndTime,
			final String filePath) {

		// Use the comments present in the BussinessdayUtil.java in path
		// C:\Harisha\My contents\Projects\Finance Revenue

		log.debug("************[Enter calculateSLA]: offset [" + offset
				+ "] relativeDate [" + relativeDate + "] slaTypeId ["
				+ slaTypeId + "] slaCalculationId [" + slaCalculationId
				+ "] officeStartTime [" + officeStartTime + "] officeEndTime ["
				+ officeEndTime + "] filePath [" + filePath + "]************");

		// Process the sla calculation id
		processSlaCalculationId(slaCalculationId);

		processOfficeWorkingTime(officeStartTime, officeEndTime);

		// Parse the Company Holidays xml file and store all Holidays in an
		// LinkedHashMap object
		if (!isHolidayAWorkingDay) {
			parseCompanyHolidayXML(filePath);
		}

		Date[] slaExactDate = null;

		if (slaTypeId == 1) { // Absolute

			slaExactDate = adjustToWorkingTime(offset);

		} else if (slaTypeId == 2) { // Relative

			/* Get each sla hour from input parameter */
			String tokens[] = offset.split("\\|");
			String eachSLA;
			slaExactDate = new Date[tokens.length];
			for (int i = 0; i < tokens.length; i++) {
				eachSLA = tokens[i];
				try {
					if (eachSLA.equals("")) {
						log.info("For SLA [" + eachSLA
								+ "]: SLA is \"\"(blank); hence the "
								+ "Exact SLA Date is \"\"(blank)");
						slaExactDate[i] = null;

					} else {
						long eachSLAMin = Long.parseLong(eachSLA);

						// Initialize isNegativeOffset
						isNegativeOffset = false;

						if (eachSLAMin < 0) {
							isNegativeOffset = true;
						}
						Calendar exact = calculateEachSLA(eachSLAMin,
								relativeDate);
						log
								.debug("---------------------------------------------------------");
						log.info("For SLA [" + eachSLA
								+ "]: The Exact SLA Date for hour " + eachSLA
								+ " is :" + exact.getTime());
						log
								.debug("---------------------------------------------------------");
						slaExactDate[i] = exact.getTime();
					}
				} catch (NumberFormatException e) {
					/*
					 * If it is not an Integer then log error, assign blank("")
					 * to slaExactDate and continue with next sla hour
					 */ 
					log.error("For SLA hour:[" + eachSLA
							+ "]: Unable to parse the input. "
							+ "SLA Value should be an Integer."
							+ e.getMessage(), e);
					slaExactDate[i] = null;
					continue;
				}

			}
		} else {
			log.error("Invalid slaTypeId [" + slaTypeId
					+ "]. It should be in the range 1-2");
		}
		log.debug("[Exit calculateSLA]");
		return slaExactDate;
	}

	/**
	 * @param offset
	 * @return
	 */
	private Date[] adjustToWorkingTime(String offset) {
		log.debug("[Enter adjustToWorkingTime]: offset:" + offset);

		/*
		 * check the input date whether it is within office working time; if not
		 * get the next office working day
		 */
		log.debug("For SLA string [" + offset + "]:Parsing the sla date string...");
		SimpleDateFormat simDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date offsetDate = null;
		try {
			offsetDate = simDate.parse(offset);
			log.debug("For SLA string [" + offset + "]: SLA date is [" + offsetDate + "]");
		} catch (ParseException e) {
			log.error("For SLA string [" + offset
					+ "]:Unable to parse the "
					+ "input offset. It should be of format "
					+ "\"yyyy-MM-dd HH:mm:ss\"." + e.getMessage(), e);
			return null;
		}

		log.debug("For SLA date [" + offsetDate + "]: Getting the office start and end timings");
		Calendar exactSLA = Calendar.getInstance();
		Calendar arrivalCal = Calendar.getInstance();
		arrivalCal.setTime(offsetDate);

		// Get the starting office working time of caseReceivedDate
		Calendar startCal = Calendar.getInstance();
		startCal.setTime(offsetDate);
		startCal = getStartingOfficeWorkingTime(startCal);

		// Get the ending office working time of caseReceivedDate
		Calendar endCal = Calendar.getInstance();
		endCal.setTime(offsetDate);
		endCal = getEndingOfficeWorkingTime(endCal);

		log.debug("For SLA date [" + offsetDate + "]: Office start time :"
				+ startCal.getTime() + " Office end time :" + endCal.getTime());
		if (isWithInWorkingHours(arrivalCal, startCal, endCal)) {
			log.info("For SLA date ["
							+ offsetDate
							+ "]: "
							+ "------------------SLA date is within office working hours------------------");
			exactSLA = arrivalCal;
		} else {
			log.info("For SLA date ["
							+ offsetDate
							+ "]: "
							+ "------------------SLA date is in Off working hours------------------");
			if (arrivalCal.before(startCal)) {
				// case arrived before the office starting time
				// then check the day of arrrival and adjust it accordingly
				log.debug("For SLA date [" + offsetDate
						+ "]: SLA date is before the office start time");
				exactSLA = getStartingOfficeWorkingTime(arrivalCal);

				if (exactSLA.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
						&& !isSaturdayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, 1);
				}

				if (exactSLA.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
						&& !isSundayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, 1);
				}
				log.debug("For SLA date [" + offsetDate
						+ "]: After adjusting to next working "
						+ "day time, SLA date is:" + exactSLA.getTime() + ".");
			} else if (arrivalCal.after(endCal)) {
				// case arrived after the office ending time
				// then check the day of arrrival and adjust it accordingly

				// Set exactSLA to arrivalCal's date and
				// Goto next day and then set to next day's starting office time
				log.debug("For SLA date [" + offsetDate
						+ "]: SLA date is after the office end time");
				
				exactSLA.set(arrivalCal.get(Calendar.YEAR), arrivalCal
						.get(Calendar.MONTH), arrivalCal.get(Calendar.DATE), 0,
						0, 0);
				exactSLA.add(Calendar.DAY_OF_MONTH, 1);
				exactSLA = getStartingOfficeWorkingTime(exactSLA);

				if (exactSLA.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
						&& !isSaturdayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, 1);
				}

				if (exactSLA.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
						&& !isSundayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, 1);
				}
				log.debug("For SLA date [" + offsetDate
						+ "]: After adjusting to next working "
						+ "day time, SLA date is:" + exactSLA.getTime() + ".");
			} else {
				/*
				 * If we reach here it means case has arrived on SATURDAY or
				 * SUNDAY and between the office working time, then check the
				 * day of arrrival and adjust it accordingly
				 */
				exactSLA.set(arrivalCal.get(Calendar.YEAR), arrivalCal
						.get(Calendar.MONTH),
						arrivalCal.get(Calendar.DATE), 0, 0, 0);
				
				if (Calendar.SATURDAY == exactSLA.get(Calendar.DAY_OF_WEEK)
						&& !isSaturdayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, 1);
					exactSLA = getStartingOfficeWorkingTime(exactSLA);
					
				}
				if (Calendar.SUNDAY == exactSLA.get(Calendar.DAY_OF_WEEK)
						&& !isSundayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, 1);
					exactSLA = getStartingOfficeWorkingTime(exactSLA);
				}
			}
		}
		
		/* Check the day for holiday */
		if (isDayIsHoliday(exactSLA)) {
			
			log.debug("For SLA date [" + offsetDate
					+ "]: Searching for Next Office working day.");
			exactSLA = getNextWorkingDay(exactSLA);
			exactSLA = getStartingOfficeWorkingTime(exactSLA);
			log.debug("For SLA date [" + offsetDate
					+ "]: After adjusting to next working "
					+ "day time, SLA date is:" + exactSLA.getTime() + ".");
		}
		
		log.info("For SLA offset date [" + offsetDate
				+ "]: The Exact SLA Date is :" + exactSLA.getTime());
		log.debug("[Exit adjustToWorkingTime]");
		return new Date[] { exactSLA.getTime() };
	}

	/**
	 * @param slaCalculationId
	 * 
	 */
	private void processSlaCalculationId(int slaCalculationId) {

		// Process the sla calculation id
		log.debug("Initializing the SLA calculation paramaters.");
		switch (slaCalculationId) {
		case 1:
			isSaturdayAWorkingDay = false;
			isSundayAWorkingDay = false;
			isHolidayAWorkingDay = false;
			break;
		case 2:
			isSaturdayAWorkingDay = true;
			isSundayAWorkingDay = false;
			isHolidayAWorkingDay = false;
			break;
		case 3:
			isSaturdayAWorkingDay = false;
			isSundayAWorkingDay = true;
			isHolidayAWorkingDay = false;
			break;
		case 4:
			isSaturdayAWorkingDay = false;
			isSundayAWorkingDay = false;
			isHolidayAWorkingDay = true;
			break;
		case 5:
			isSaturdayAWorkingDay = true;
			isSundayAWorkingDay = true;
			isHolidayAWorkingDay = false;
			break;
		case 6:
			isSaturdayAWorkingDay = true;
			isSundayAWorkingDay = false;
			isHolidayAWorkingDay = true;
			break;
		case 7:
			isSaturdayAWorkingDay = false;
			isSundayAWorkingDay = true;
			isHolidayAWorkingDay = true;
			break;
		case 8:
			isSaturdayAWorkingDay = true;
			isSundayAWorkingDay = true;
			isHolidayAWorkingDay = true;
			break;
		default:
			log.error("Invalid argument sla claculation id ["
					+ slaCalculationId + "]. "
					+ "It should be in the range of 1 to 8.");
			break;
		}
		log.info("Saturday is "
				+ (isSaturdayAWorkingDay ? "Working day" : "Non working day"));
		log.info("Sunday is "
				+ (isSundayAWorkingDay ? "Working day" : "Non working day"));
		log.info("Company holidays are "
				+ (isHolidayAWorkingDay ? "Working day" : "Non working day"));
	}

	private Calendar calculateEachSLA(long eachSLAMin, Date relativeDate) {

		Calendar arrivalCal = null;
		Calendar startCal = null;
		Calendar endCal = null;

		if (relativeDate == null || relativeDate.equals("")) {
			/*
			 * If relativeDate is equal to null or blank, then we have to
			 * consider Current System date to add to the number of slaHour.
			 * This code will execute in two cases: a. For the first time
			 * recalculateSLA method is called or b. When SME reminder time is
			 * being calculated.
			 */
			/* Get the Case arrival date and Time */
			log.debug("For SLA hour:[" + eachSLAMin
					+ "]: parameter relativeDate [" + relativeDate
					+ "] is null or blank; hence considering current "
					+ "system date as the relative date.");
			Date presentDate = new Date();
			arrivalCal = Calendar.getInstance();
			arrivalCal.setTime(presentDate);
			log
					.debug("---------------------------------------------------------");
			log.info("For SLA hour:[" + eachSLAMin
					+ "]: Current System Date is :" + arrivalCal.getTime());
			log
					.debug("---------------------------------------------------------");

			// Get the starting office working time of currentDate
			Date currentDate = new Date();
			startCal = Calendar.getInstance();
			startCal.setTime(currentDate);
			startCal = getStartingOfficeWorkingTime(startCal);

			// Get the ending office working time of currentDate
			endCal = Calendar.getInstance();
			endCal.setTime(currentDate);
			endCal = getEndingOfficeWorkingTime(endCal);

		} else {
			/*
			 * If relativeDate is not equal to "", then we have to consider the
			 * Case Received on date to add to the number of slaHour. <p> This
			 * code will execute whenever: Agent selects the "Update Category"
			 * response and if some escalation is already occured. <p> Parameter
			 * caseReceivedDate is of the format: "MMM dd HH:mm:ss yyyy" please
			 * refer calculateSLA method to the time format.
			 */

			log.info("For SLA hour:[" + eachSLAMin + "]: As input parameter "
					+ "relativeDate is valid date, so we are considering "
					+ "it as the date to add to slaHour");
			log
					.debug("---------------------------------------------------------");
			log.info("For SLA hour:[" + eachSLAMin
					+ "]: Relative Date is: " + relativeDate);
			log
					.debug("---------------------------------------------------------");

			/* Get the Case arrival date and Time */
			arrivalCal = Calendar.getInstance();
			arrivalCal.setTime(relativeDate);

			// Get the starting office working time of caseReceivedDate
			startCal = Calendar.getInstance();
			startCal.setTime(relativeDate);
			startCal = getStartingOfficeWorkingTime(startCal);

			// Get the ending office working time of caseReceivedDate
			endCal = Calendar.getInstance();
			endCal.setTime(relativeDate);
			endCal = getEndingOfficeWorkingTime(endCal);
		}
		log.info("For SLA [" + eachSLAMin + "]: " + (eachSLAMin / 60)
				+ " hour(s) and " + (eachSLAMin % 60) + " minute(s).");
		Calendar exactSLA = Calendar.getInstance();

		/*
		 * Check whether case arrrived within office working time and not in
		 * SUNDAY or SATURDAY
		 */
		if (isWithInWorkingHours(arrivalCal, startCal, endCal)) {
			log.info("For SLA hour:["
							+ eachSLAMin
							+ "]: "
							+ "------------------Request Arrived within office working hours------------------");
			log.info("For SLA hour:[" + eachSLAMin
					+ "]: Checking whether case arrived "
					+ "on company holiday.");

			if (isDayIsHoliday(arrivalCal)) {
				log.info("For SLA hour:[" + eachSLAMin
						+ "]: Searching for Next Office working day.");
				arrivalCal = getNextWorkingDay(arrivalCal);
				arrivalCal = (isNegativeOffset ? getEndingOfficeWorkingTime(arrivalCal)
						: getStartingOfficeWorkingTime(arrivalCal));

				log.info("For SLA hour:[" + eachSLAMin
						+ "]: After adjusting to next working "
						+ "day time, Case arrived time is:"
						+ arrivalCal.getTime() + ".");
			}
			exactSLA = withInWorkingTime(arrivalCal, eachSLAMin);
		} else {
			log.info("For SLA hour:["
					+ eachSLAMin
					+ "]: ------------------Request arrived in Off Working Hours------------------");
			if (arrivalCal.before(startCal)) {

				// Case arrived before the office starting time
				// then check the day of arrrival and adjust it accordingly
				log
						.debug("For SLA hour:["
								+ eachSLAMin
								+ "]: Case arrived before the "
								+ "office starting time. Adjusting to next working day starting "
								+ "office working time.");
				if (isNegativeOffset) {
					exactSLA.setTime(arrivalCal.getTime());
					exactSLA.add(Calendar.DAY_OF_MONTH, -1);

				} else {
					exactSLA = getStartingOfficeWorkingTime(arrivalCal);
				}

				if (((exactSLA.get(Calendar.DAY_OF_WEEK)) == Calendar.SUNDAY && !isSundayAWorkingDay)
						|| ((exactSLA.get(Calendar.DAY_OF_WEEK)) == Calendar.SATURDAY && !isSaturdayAWorkingDay)) {
					exactSLA.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1
							: 1));
					exactSLA = getWorkingDay(exactSLA);
				}

				if (isNegativeOffset)
					exactSLA = getEndingOfficeWorkingTime(exactSLA);
			} else if (arrivalCal.after(endCal)) {

				// case arrived after the office ending time
				// then check the day of arrrival and adjust it accordingly

				log
						.debug("For SLA hour:["
								+ eachSLAMin
								+ "]: Case arrived after the "
								+ "office end time. Adjusting to next working day starting "
								+ "office working time.");

				// Set exactSLA to arrivalCal's date and
				// Goto next day and then set to next day's starting office time
				if (isNegativeOffset) {
					exactSLA = getEndingOfficeWorkingTime(exactSLA);
				} else {
					exactSLA.set(arrivalCal.get(Calendar.YEAR), arrivalCal
							.get(Calendar.MONTH),
							arrivalCal.get(Calendar.DATE), 0, 0, 0);
					exactSLA.add(Calendar.DAY_OF_MONTH, 1);
					exactSLA = getStartingOfficeWorkingTime(exactSLA);
				}

				if (exactSLA.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY
						&& !isSaturdayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1
							: 1));
				}

				if (exactSLA.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
						&& !isSundayAWorkingDay) {
					exactSLA.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1
							: 1));
				}
			} else {
				/*
				 * If we reach here it means case has arrived on SATURDAY or
				 * SUNDAY and between the office working time, then check the
				 * day of arrrival and adjust it accordingly
				 */
				log
						.debug("For SLA hour:["
								+ eachSLAMin
								+ "]: Case arrived on Saturday or Sunday. "
								+ "Adjusting to next working day starting office working time.");

				exactSLA = getWorkingDay(arrivalCal);
				exactSLA = (isNegativeOffset ? getEndingOfficeWorkingTime(exactSLA)
						: getStartingOfficeWorkingTime(exactSLA));

				// for negative value, now saturday check is not needed as it is
				// consider later in
				// checkDayThenAdd method
			}

			// check SLA date is holiday or not. If it's holiday then get next working day
			if (isDayIsHoliday(exactSLA)) {
			    log.debug("["+exactSLA +"] is holiday");
			    log.info("For SLA hour:[" + eachSLAMin
						+ "]: Searching for Next Office working day.");
				exactSLA = getNextWorkingDay(exactSLA);
			}
			log.info("For SLA hour:[" + eachSLAMin
					+ "]: After adjusting to next working "
					+ "day time, Case arrived time is:" + exactSLA.getTime());
			exactSLA = withInWorkingTime(exactSLA, eachSLAMin);
		}
		return exactSLA;
	}

	/**
	 * @param arrivalCal
	 * @return
	 */
	private Calendar getNextWorkingDay(Calendar arrivalCal) {

		// Increment to next day
		arrivalCal.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1 : 1));

		if ((arrivalCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SATURDAY
				&& !isSaturdayAWorkingDay) {
			arrivalCal.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1 : 1));
		}
		if ((arrivalCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SUNDAY
				&& !isSundayAWorkingDay) {
			arrivalCal.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1 : 1));
		}

		if (isDayIsHoliday(arrivalCal)) {
			arrivalCal = getNextWorkingDay(arrivalCal);
		}
		log.info("The Next Working office day is " + arrivalCal.getTime());
		return arrivalCal;
	}

	private Calendar getWorkingDay(Calendar arrivalCal) {

		arrivalCal.set(Calendar.MILLISECOND, 0);

		Calendar startCal = getStartingOfficeWorkingTime(arrivalCal);
		startCal.set(Calendar.MILLISECOND, 0);
		int minutes = calculateNumberOfMinutesBetween(arrivalCal, startCal);

		while (((startCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SUNDAY && !isSundayAWorkingDay)
				|| ((startCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SATURDAY && !isSaturdayAWorkingDay)) {

			startCal.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1 : 1));
			// getWorkingDay(startCal);
		}

		if (isDayIsHoliday(startCal)) {
			startCal = getNextWorkingDay(startCal);
		}

		// arrivalCal.set(startCal.get(Calendar.YEAR), startCal
		// .get(Calendar.MONTH), startCal.get(Calendar.DATE), arrivalCal
		// .get(Calendar.HOUR), arrivalCal.get(Calendar.MINUTE), arrivalCal
		// .get(Calendar.SECOND));
		startCal.add(Calendar.MINUTE, minutes);
		log.info("The Next Working office day is " + startCal.getTime());
		return startCal;

	}

	/**
	 * @param arrivalCal
	 * @return
	 */
	private boolean isDayIsHoliday(Calendar arrivalCal) {
		
		log.debug("Searching whether the day is an company holiday or not...");
		if (!isHolidayAWorkingDay) {

			/* Get the office start date of the parameter arrivalCal */
			Calendar startCal = getStartingOfficeWorkingTime(arrivalCal);
			log.debug("Office starting date of date [" + arrivalCal.getTime()
					+ "] is [" + startCal.getTime() + "]");
			log.debug("Checking Office start date [" + startCal.getTime()
					+ "] for company holidays...");

			// boolean flag = false;

			// get the year of case arrived date
			SimpleDateFormat simDate = new SimpleDateFormat("yyyy");

			String formatted = simDate.format(startCal.getTime());
			String startCalYear = formatted;

			simDate = new SimpleDateFormat("dd-MM-yyyy");
			formatted = simDate.format(startCal.getTime());
			String startCalDate = formatted;

			Set setList = yearMap.keySet();
			Iterator itr = setList.iterator();
			while (itr.hasNext()) {
				String holidayYear = (String) itr.next();

				// Search only for that year's holidays
				if (holidayYear.equalsIgnoreCase(startCalYear)) {

					log.info("Checking the day [" + startCal.getTime()
							+ "] with [" + holidayYear + "] year's Holidays.");
					yearHolidayMap = (LinkedHashMap) yearMap.get(holidayYear);

					if (yearHolidayMap.containsKey(startCalDate)) {
						log.info("The Day [" + startCal.getTime()
								+ "] is an company "
								+ "holiday on occasion of ["
								+ yearHolidayMap.get(startCalDate) + "].");
						return true;
					}
				}
			}
			log.info("The Day [" + startCal.getTime()
					+ "] is not an company holiday.");
		} else {
			log.debug("Company holidays should not be considered");
		}
		return false;
	}

	/**
	 * @param arrivalCal:
	 *            case arrival Time
	 * @param startCal:
	 *            Office starting time of case arrived day
	 * @param endCal:
	 *            Office ending time of case arrived day
	 * @return the exact sla day and time
	 */
	private Calendar withInWorkingTime(Calendar arrivalCal, long eachSLAMin) {

		/* If sla minutes is zero, then return the arrival time */
		if (eachSLAMin == 0) {
			log.info("For SLA ["
					+ eachSLAMin
					+ "]: SLA parameter is zero; hence returning relative date ["
					+ arrivalCal.getTime() + "] as exact sla date");
			return arrivalCal;
		}

		/* Number of days to Increment */
		int numberOfDayToIncrement;

		/* Number of hours to Increment */
		long numberOfMinsToIncrement;
		Calendar exact;

		// WORKING_HOURS indicates the Number of Office working hours
		numberOfMinsToIncrement = eachSLAMin % WORKING_MINS;
		numberOfDayToIncrement = (new Long(eachSLAMin / WORKING_MINS))
				.intValue();

		log.debug("Need to add [" + numberOfDayToIncrement + "] day(s) and ["
				+ numberOfMinsToIncrement + "] minute(s)");
		/*
		 * If Number of hours to Increment is zero then we have to increment
		 * exactly interms of days
		 */
		if (numberOfMinsToIncrement == 0) {
			exact = checkDayThenAdd(arrivalCal, numberOfDayToIncrement);
		} else {
			exact = checkDayThenAdd(arrivalCal, numberOfDayToIncrement);
			exact = checkMinsThenAdd(exact, numberOfMinsToIncrement);
		}
		return exact;
	}

	/**
	 * @param slaMin
	 * @param exactSLA
	 * @param numberOfHourToIncrement
	 * @return calendar day after incrementing in terms of hours
	 */
	private Calendar checkMinsThenAdd(Calendar tempCal, long numberOfMins) {

		log.debug("Adding [" + numberOfMins + "] minute(s)....");

		// Get the ending working hour time of tempCal date
		Calendar fromTime = (isNegativeOffset ? getStartingOfficeWorkingTime(tempCal)
				: getEndingOfficeWorkingTime(tempCal));

		// Calculate the number of hour left to close for the day(represented by
		// tempCal)
		int leftMins = calculateNumberOfMinutesBetween(fromTime, tempCal);

		if (leftMins >= Math.abs(numberOfMins)) {

			// Means number of hours left to close the day is more then the
			// numbers of hours to add
			// so we can directly add the number of hours to this day without
			// having to increment the day
			tempCal.add(Calendar.MINUTE, (new Long(numberOfMins)).intValue());
		} else {

			// Means number of hours left to close the day is less then the
			// numbers of hours to add
			// so we have to increment the day
			int newMins = (new Long(Math.abs(numberOfMins) - leftMins))
					.intValue();
			tempCal.add(Calendar.MINUTE, (isNegativeOffset ? -(leftMins)
					: leftMins));

			int tempMins = (new Long((24 * 60 - WORKING_MINS))).intValue();
			tempCal.add(Calendar.MINUTE, (isNegativeOffset ? -(tempMins)
					: tempMins));
			tempCal = checkDay(tempCal);
			tempCal.add(Calendar.MINUTE, (isNegativeOffset ? -(newMins)
					: newMins));
		}
		log.debug("Resulting Working office day is " + tempCal.getTime());
		return tempCal;
	}

	/**
	 * @param tempCal
	 * @return calendar day after updating
	 */
	private Calendar checkDay(Calendar tempCal) {

		tempCal = getWorkingDay(tempCal);

		// // If the day is SATURDAY then add 2 days to it as we have reached
		// the Weekend
		// if((tempCal.get(Calendar.DAY_OF_WEEK)) == Calendar.SATURDAY) {
		// tempCal.add(Calendar.DAY_OF_MONTH, 2);
		// }
		//		
		// boolean flag = isDayIsHoliday(tempCal);
		// if(flag == true) {
		// tempCal = getNextWorkingDay(tempCal);
		// }
		return tempCal;
	}

	/**
	 * @param arrivalCal
	 * @return calendar day after incrementing in terms of number of days
	 */

	private Calendar checkDayThenAdd(Calendar arrival, int numberOfDay) {
		log.debug("Adding [" + numberOfDay + "] day(s)....");
		for (int i = 1; i <= Math.abs(numberOfDay); i++) {
			arrival = getWorkingDay(arrival);
			arrival.add(Calendar.DAY_OF_MONTH, (isNegativeOffset ? -1 : 1));
			arrival = getWorkingDay(arrival);

		}

		log.debug("Resulting Working office day is " + arrival.getTime());
		return arrival;
	}

	/**
	 * @return true if case arrived within working hours and case not arrived in
	 *         SATURDAY or SUNDAY otherwise it returns false
	 */
	private boolean isWithInWorkingHours(Calendar arrival, Calendar start,
			Calendar end) {
		if ((arrival.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY)
				&& !isSaturdayAWorkingDay) {
			log.debug("Request arrived on Saturday.");
			return false;
		}

		if ((arrival.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY)
				&& !isSundayAWorkingDay) {
			log.debug("Request arrived on Sunday.");
			return false;
		}

		if ((arrival.after(start) || arrival.equals(start))
				&& (arrival.before(end) || arrival.equals(end))) {
			log.debug("Request arrived within office start and end time.");
			return true;
		}
		log.debug("Request not arrived within office start and end time.");
		return false;
	}

	/**
	 * @param the
	 *            day of which starting office time to be calculated
	 * @return the starting office working time for the argument passed
	 *         day(represented by tempCal)
	 * 
	 */
	private Calendar getStartingOfficeWorkingTime(Calendar tempCal) {
		log.debug("[Enter getStartingOfficeWorkingTime]");

		Calendar startCal = Calendar.getInstance();

		Calendar dayStartCal = Calendar.getInstance();
		dayStartCal.set(tempCal.get(Calendar.YEAR),
				tempCal.get(Calendar.MONTH), tempCal.get(Calendar.DATE),
				S_HOUR, S_MINUTE, S_SECOND);

		Calendar dayEndCal = Calendar.getInstance();
		dayEndCal.set(tempCal.get(Calendar.YEAR), tempCal.get(Calendar.MONTH),
				tempCal.get(Calendar.DATE), E_HOUR, E_MINUTE, E_SECOND);

		if (!isNightShiftTiming) {
			startCal = dayStartCal;

		} else if (tempCal.after(dayStartCal)) {
			startCal = dayStartCal;

		} else if (tempCal.before(dayEndCal)) {
			startCal.set(tempCal.get(Calendar.YEAR), tempCal
					.get(Calendar.MONTH), tempCal.get(Calendar.DATE), 0, 0, 0);
			startCal.add(Calendar.DAY_OF_MONTH, -1);
			startCal.set(startCal.get(Calendar.YEAR), startCal
					.get(Calendar.MONTH), startCal.get(Calendar.DATE), S_HOUR,
					S_MINUTE, S_SECOND);
		} else {
			startCal = dayStartCal;
		}

		/*
		 * For scenarios where start office time is greater than end office time
		 * For example: start office time = 22:00:00 and end office time =
		 * 06:00:00
		 * 
		 * In the above scenario: After setting to start office time, the day
		 * should be decremented to previous day
		 */
		
		log.debug("For calendar [" + tempCal.getTime()
				+ "]: Start office time is:" + startCal.getTime());
		log.debug("[Exit getStartingOfficeWorkingTime]");
		return startCal;
	}

	/**
	 * @param the
	 *            day of which ending office time to be calculated
	 * @return the ending office working time for the argument passed
	 *         day(represented by tempCal)
	 */
	private Calendar getEndingOfficeWorkingTime(Calendar tempCal) {
		log.debug("[Enter getEndingOfficeWorkingTime]");

		Calendar endCal = Calendar.getInstance();

		Calendar dayStartCal = Calendar.getInstance();
		dayStartCal.set(tempCal.get(Calendar.YEAR),
				tempCal.get(Calendar.MONTH), tempCal.get(Calendar.DATE),
				S_HOUR, S_MINUTE, S_SECOND);

		Calendar dayEndCal = Calendar.getInstance();
		dayEndCal.set(tempCal.get(Calendar.YEAR), tempCal.get(Calendar.MONTH),
				tempCal.get(Calendar.DATE), E_HOUR, E_MINUTE, E_SECOND);

		if (!isNightShiftTiming) {
			endCal = dayEndCal;

		} else if (tempCal.after(dayStartCal)) {
			endCal.set(tempCal.get(Calendar.YEAR), tempCal.get(Calendar.MONTH),
					tempCal.get(Calendar.DATE), 0, 0, 0);
			endCal.add(Calendar.DAY_OF_MONTH, 1);
			endCal.set(endCal.get(Calendar.YEAR), endCal.get(Calendar.MONTH),
					endCal.get(Calendar.DATE), E_HOUR, E_MINUTE, E_SECOND);

		} else if (tempCal.before(dayEndCal)) {
			endCal = dayEndCal;
		} else {
			endCal.set(tempCal.get(Calendar.YEAR), tempCal.get(Calendar.MONTH),
					tempCal.get(Calendar.DATE), 0, 0, 0);
			endCal.add(Calendar.DAY_OF_MONTH, 1);
			endCal.set(endCal.get(Calendar.YEAR), endCal.get(Calendar.MONTH),
					endCal.get(Calendar.DATE), E_HOUR, E_MINUTE, E_SECOND);

		}

		/*
		 * For scenarios where start office time is greater than end office time
		 * For example: start office time = 22:00:00 and end office time =
		 * 06:00:00
		 * 
		 * In the above scenario: After setting to end office time, the day
		 * should be incremented to next day
		 */
		log.debug("For calendar [" + tempCal.getTime()
				+ "]: End office time is:" + endCal.getTime());
		log.debug("[Exit getEndingOfficeWorkingTime]");
		return endCal;
	}

	/**
	 * calculates the number of hours between two Calendar instance
	 * 
	 * @param from :
	 *            starting Calendar instance
	 * @param to :
	 *            ending Calendar instance
	 * @return the number of hours between two Calendar instance
	 */
	private int calculateNumberOfHoursBetween(Calendar from, Calendar to) {

		// milliseconds since 1970 Jan 1
		long fromTime = from.getTime().getTime();
		long toTime = to.getTime().getTime();

		int hour = (int) (fromTime - toTime) / MILLISECONDS_PER_HOUR;
		return hour;
	}

	/**
	 * @param endTime
	 * @param tempCal
	 * @return
	 */
	private int calculateNumberOfMinutesBetween(Calendar from, Calendar to) {

		// milliseconds since 1970 Jan 1
		from.set(Calendar.MILLISECOND, 0);
		to.set(Calendar.MILLISECOND, 0);
		long fromTime = from.getTime().getTime();
		long toTime = to.getTime().getTime();
		int min = 0;
		if (fromTime >= toTime) {
			min = (int) (fromTime - toTime) / MILLISECONDS_PER_MINUTE;
		} else {
			min = (int) (toTime - fromTime) / MILLISECONDS_PER_MINUTE;
		}
		return min;
	}

	private void parseCompanyHolidayXML(String filePath) {

		log.debug("Checking the last modified date of the Company holidays xml file ["
						+ filePath + "]");
		File fin = new File(filePath);
		Calendar lastModCal = Calendar.getInstance();
		lastModCal.setTimeInMillis(fin.lastModified());

		if (lastHolidayXMLFileReloadedOn != null) {
			log
					.debug("Company holidays xml file last loaded on:["
							+ lastHolidayXMLFileReloadedOn.getTime()
							+ "] It is last modified on:["
							+ lastModCal.getTime() + "]");
		}

		if ((lastHolidayXMLFileReloadedOn == null)
				|| lastHolidayXMLFileReloadedOn.before(lastModCal)) {
			log.debug("Company holidays xml file has been modified since its last reload; hence reading the file");

			try {
				// Creates a DOM parser object and parse the xml
				log.debug("Parsing the CompanyHolidays.xml file for company holidays.");
				DOMParser parser = new DOMParser();
				parser.parse(filePath);

				// Stores the tree object in a variable of Document type
				Document docMailsMode = parser.getDocument();

				// Returns a list of all mailMode elements in docmailsMode
				// Document
				NodeList yearList = docMailsMode.getElementsByTagName("Year");
				yearMap = new LinkedHashMap();

				// Now check each mailModeList
				for (int i = 0; i < yearList.getLength(); i++) {
					Node eachYear = yearList.item(i);

					// Retrieving values of the attributes
					String yearValue = eachYear.getAttributes().getNamedItem(
							"value").getNodeValue();
					log.debug("Holidays for the Year [" + yearValue + "].");

					Element yearElement = (Element) eachYear;

					NodeList holidayList = yearElement
							.getElementsByTagName("Holiday");
					yearHolidayMap = new LinkedHashMap();
					for (int j = 0; j < holidayList.getLength(); j++) {

						Node eachHoliday = holidayList.item(j);
						String date = eachHoliday.getAttributes().getNamedItem(
								"date").getNodeValue();
						String occasion = eachHoliday.getAttributes()
								.getNamedItem("occasion").getNodeValue();
						log.debug("Holiday " + (j + 1) + " Date: " + date
								+ " on Occasion: " + occasion);

						// instantiating and storing mailMode's attribute data
						// into innerMap
						yearHolidayMap.put(date, occasion);
					}
					// mapping
					yearMap.put(yearValue, (Object) yearHolidayMap);
				}

			} catch (Exception e) {
				log.error(
						"Error occured while parsing the CompanyHolidays xml file. "
								+ e.getMessage(), e);
			}

			/* update the variable to last modified date */
			lastHolidayXMLFileReloadedOn = lastModCal;
			log.debug("Successfully reloaded the Company holidays xml file");
		} else {
			log.debug("Company holidays xml file is not modified since its last "
						+ "reload; hence not reading the file");
		}
	}
}
