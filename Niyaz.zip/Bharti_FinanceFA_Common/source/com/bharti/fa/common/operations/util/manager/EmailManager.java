package com.bharti.fa.common.operations.util.manager;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.SendFailedException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;

import org.apache.log4j.Logger;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.context.Context;

import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;
import com.filenet.api.collection.ContentElementList;
import com.filenet.api.core.ContentTransfer;
import com.filenet.apiimpl.core.DocumentImpl;

/**
 * @viz.diagram EmailManager.tpx
 */
public class EmailManager {
	
	public static Logger log = Logger.getLogger(EmailManager.class);
	
	public javax.mail.Session session = null;
	public EmailManager() {
		/*	    PropertyLoader.getInstance();
		 log.debug("ENTRY :  EmailManager");
		 Properties smtpProps = new Properties();
		 log.debug(" mail.smtp.host, Read from properties file == " +PropertyLoader.props.getProperty("mail.smtp.host"));
		 smtpProps.put("mail.smtp.host",PropertyLoader.props.getProperty("mail.smtp.host"));
		 log.debug("mail.smtp.host, AFTER SETTING IN PROPS == " + smtpProps.get("mail.smtp.host"));
		 session = javax.mail.Session.getDefaultInstance(smtpProps, null);
		 log.debug("javax.mail.Session :: " + session.toString());
		 */	}
	public Session getSession() {
		return session;
	}
	
	public  StringBuffer createTemplate(Hashtable templateProps,InputStream mailBody)throws Exception
	{	
		log.debug("ENTRY - createTemplate ");
		StringBuffer message = new StringBuffer();
		Velocity.init();
		log.debug("Velocity Init : Start");
		Context context = new VelocityContext();
		log.debug("Velocity Init : End");
		log.debug("Template properties"+templateProps);
		InputStreamReader reader=new InputStreamReader(mailBody);
		Iterator paramSIter = templateProps.keySet().iterator();
		while(paramSIter.hasNext()){
			
			log.debug("Inside while paramSIter");
			String key = (String)paramSIter.next();
			System.out.println(templateProps);
			context.put(key, templateProps.get(key).toString());
			log.debug(context.put(key,templateProps.get(key).toString()));
		}		
		StringWriter w = new StringWriter();
		log.debug("Retrieving Document content.");
		log.debug("Template merged.");
		Velocity.evaluate(context,w,"",reader);
		message = w.getBuffer();
		//	log.debug(" email message :: " + message);
		//System.out.println("message::"+message);
		//System.out.println("Generated email message : "+message);
		log.debug("EXIT - createTemplate ");
		return message;
	}
	
	
	/**
	 * Sends an email to the specified receipients.
	 * 
	 * @param 	props 
	 * 			Properties object. Used only if a new Session object is created.
	 *			It is expected that the user supplies values for the properties listed in 
	 *			Appendix A of the JavaMail spec (particularly mail.store.protocol, 
	 *			mail.transport.protocol, mail.host, mail.user, and mail.from) as the defaults 
	 *			are unlikely to work in all cases.
	 *
	 * @param 	strFrom 
	 * 			address of the sender
	 * @param 	strTo 
	 * 			To address of receipients
	 * @param 	strCC 
	 * 			CC address of receipients
	 * @param 	strBCC 
	 * 			BCC address of receipients
	 * @param 	strSubject 
	 * 			subject of mail
	 * @param 	multipart 
	 * 			it contains body of the mail and attachments if any in the form of Multipart object
	 * @throws 	AddressException - if the parse failed
	 * @throws 	MessagingException
	 *         	IllegalWriteException - if the underlying implementation does not support modification 
	 * 			of existing values 
     *         	IllegalStateException - if this message is obtained from a READ_ONLY folder.
	 */
	public void sendEmail(Properties props, String strFrom, String[] strTo, String[] strCC,
			String[] strBCC, String strSubject, Multipart multipart) throws AddressException, MessagingException {
		
		log.debug("[Enter sendMail]: strFrom: ["+strFrom+"] strTo: [" + Utilities.displayArray(strTo)+"] strCC: [" + Utilities.displayArray(strCC)+"] strBCC: ["+Utilities.displayArray(strBCC)+"] strSubject: ["+strSubject+"] multipart: ["+multipart+"].") ;
		
		javax.mail.Session mailSession = javax.mail.Session.getDefaultInstance(props, null);
		log.debug("javax.mail.Session :" + mailSession.toString());
		Message message = new MimeMessage(mailSession);
		message.setFrom(new InternetAddress(strFrom));
		for(int i = 0; strTo!=null && i<strTo.length; i++){
			log.debug("Email Address :"+strTo[i]);	
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(strTo[i]));
		}
		
		if(strCC!=null && strCC.length>0){
			for(int i = 0; i<strCC.length; i++)
				message.addRecipient(Message.RecipientType.CC, new InternetAddress(strCC[i]));
		} 
		if(strBCC!=null && strBCC.length>0){
			for(int i = 0; i<strBCC.length; i++)
				message.addRecipient(Message.RecipientType.BCC, new InternetAddress(strBCC[i]));
		}
		message.setSubject(strSubject); 		
		log.debug("message.subject :" + message.getSubject());
		
		message.setContent(multipart); 
		try {
			Transport.send(message); 
			log.info("Mail successfully sent to To:[" + Utilities.displayArray(strTo)+"] Cc:["
					+Utilities.displayArray(strCC)+"] Bcc:[" + Utilities.displayArray(strBCC)+"].");
		} catch(SendFailedException sfe) {
			log.error("[sendMail]: Error occured while sending mail." + sfe.getMessage(), sfe);
			processValidUnsentAddresses(message, sfe, strTo, strCC, strBCC);
		}
		log.debug("[Exit sendEmail]");
	}
	
	public boolean sendEmail(String strFrom, String[] strTo, String[] strCC,
			String[] strBCC, String strSubject, String strBody,Object[] objAttachments) throws AddressException, MessagingException, IOException  {
		
		log.debug("ENTRY - EMailManager -> sendEmail ");
		Properties props = System.getProperties(); 
		
		props.put("mail.smtp.host", PropertyLoader.props.getProperty("mail.smtp.host")); 
		log.debug("mail.smtp.host == " + PropertyLoader.props.getProperty("mail.smtp.host"));
		javax.mail.Session mailSession = javax.mail.Session.getDefaultInstance(props, null);
		log.debug("javax.mail.Session == " + mailSession.toString());
		Message message = new MimeMessage(mailSession);
		message.setFrom(new InternetAddress(strFrom));
		log.debug("message.from == " + message.getFrom());
		for(int i = 0; strTo!=null && i<strTo.length; i++){
			log.debug("Email Address:"+strTo[i]);	
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(strTo[i]));
		}
		
		if(strCC!=null && strCC.length>0){
			for(int i = 0; i<strCC.length; i++)
				message.addRecipient(Message.RecipientType.CC, new InternetAddress(strCC[i]));
		} 
		if(strBCC!=null && strBCC.length>0){
			for(int i = 0; i<strBCC.length; i++)
				message.addRecipient(Message.RecipientType.BCC, new InternetAddress(strBCC[i]));
		}
		message.setSubject(strSubject); 
		
		log.debug("message.subject == " + message.getSubject());
		
		BodyPart messageBodyPart = new MimeBodyPart(); 
		messageBodyPart.setContent(strBody,"text/html");
		log.debug("###3");
		log.debug("strBody :"+strBody);
		Multipart multipart = new MimeMultipart();
		multipart.addBodyPart(messageBodyPart); 
		if(objAttachments!=null)
		{
			addAtachments(objAttachments, multipart);
		}
		message.setContent(multipart); 
		//	log.debug(multipart.getContentType()); 
		
		try {
			Transport.send(message); 
			log.info("Mail successfully sent to To:[" + Utilities.displayArray(strTo) + "] Cc:["
					+ Utilities.displayArray(strCC) + "] Bcc:[" + Utilities.displayArray(strBCC) + "].");
		} catch(SendFailedException sfe) {
			log.error("[sendMail]: Error occured while sending mail." + sfe.getMessage(), sfe);
			processValidUnsentAddresses(message, sfe, strTo, strCC, strBCC);
		}
		log.debug("[Exit sendEmail]");
		return false;
	}
	
	protected void addAtachments(Object[] attachments, Multipart multipart) 
	{ 
		log.debug("ENTRY - EMailManager -> addAtachments ");
		
		for(int i = 0; i < attachments.length; i++) 
		{ 
			try
			{
				DocumentImpl filename = (DocumentImpl)attachments[i]; 
				MimeBodyPart attachmentBodyPart = new MimeBodyPart(); 
				String mime=filename.get_MimeType();
				ContentElementList	oConentEleList	=	filename.get_ContentElements();
				log.debug("oConentEleList size="+oConentEleList.size());
				Iterator itr1	=	oConentEleList.iterator();
				
				while(itr1.hasNext())
				{
					log.debug("Inside addAtachments -> while : ");
					ContentTransfer oConRef	=	(ContentTransfer)itr1.next();
					log.debug(" ContentTransfer == " + oConRef.get_RetrievalName());
					InputStream is	=	oConRef.accessContentStream();
					log.debug("InputStream == " + is.toString());
					
					DataSource source	=	new ByteArrayDataSource(is,mime);
					log.debug(" DataSource== " + source.getContentType());
					attachmentBodyPart.setDataHandler(new DataHandler(source));
					log.debug(" attachmentBodyPart==  " + attachmentBodyPart.getContentID()+ "  " + attachmentBodyPart.getFileName());
					log.debug("End of While");
					
				}
				if(mime.equalsIgnoreCase("application/pdf"))
					attachmentBodyPart.setFileName(filename.get_Name()+".pdf");
				else if(mime.equalsIgnoreCase("application/msword")){
					attachmentBodyPart.setFileName(filename.get_Name()+".doc");	
				}
				else if(mime.equalsIgnoreCase("application/vnd.ms-excel")){
					attachmentBodyPart.setFileName(filename.get_Name()+".xls");
				}
				else if(mime.equalsIgnoreCase("application/vnd.ms-powerpoint")){
					attachmentBodyPart.setFileName(filename.get_Name()+".ppt");
				}else if(mime.equalsIgnoreCase("multipart/x-zip")){
					attachmentBodyPart.setFileName(filename.get_Name()+".zip");
				}
				else if(mime.equalsIgnoreCase("text/plain")){
					attachmentBodyPart.setFileName(filename.get_Name()+".txt");	
				}
				log.debug(" Attachment File Name == " + attachmentBodyPart.getFileName());
				multipart.addBodyPart(attachmentBodyPart); 
				log.debug("END of TRY BLOCK");
				
			}
			
			catch(Exception e)
			{
				log.debug("Exception caught= " + e, e);
			}
		}
	} 
	
	/**
	 * Processes the valid unsent addresses and tries to resend the email to those users
	 * 
	 * @param 	msg
	 * 			Message object
	 * @param 	sfe
	 * 			exception object
	 * @param 	strTo 
	 * 			To address of receipients
	 * @param 	strCC 
	 * 			CC address of receipients
	 * @param 	strBCC 
	 * 			BCC address of receipients
	 * @throws MessagingException
	 */
	public static void processValidUnsentAddresses(Message msg, SendFailedException sfe, 
			String[] strTo, String[] strCC, String[] strBCC) throws MessagingException {
		
		log.debug("[Enter processValidUnsentAddresses]: msg: [" + msg + "] sfe ValidUnsentAddresses: ["  +  
				Utilities.displayAddressArray(sfe.getValidUnsentAddresses())  + "] strTo: [" 
				+ Utilities.displayArray(strTo) + "] strCC: [" + Utilities.displayArray(strCC)  + "] strBCC: ["
				+ Utilities.displayArray(strBCC)) ;
		
		if(!(sfe.getValidSentAddresses() ==null)) {
			log.info("[sendMail]: Mail succesfully  sent only to Email Id(s) ["
					+ Utilities.displayAddressArray( sfe.getValidSentAddresses()) + "].");
		}
		log.info("[sendMail]: Email not sent to Id(s) ["
				+ Utilities.displayAddressArray( sfe.getInvalidAddresses()) + "], as those are " +
				"invalid address(s).");
		
		if(!(sfe.getValidUnsentAddresses() == null)) {
			log.info("[sendMail]: Retrying to send mail to valid Unsent Email Id(s) ["
					+ Utilities.displayAddressArray(sfe.getValidUnsentAddresses()) + "].");
			ArrayList toList = null;
			ArrayList ccList = null;
			ArrayList bccList = null;
			
			InternetAddress[] newToAddrs = null;
			InternetAddress[] newCcAddrs = null;
			InternetAddress[] newBccAddrs = null;
			
			// Copy the string array to list objects
			if(strTo != null && (strTo.length > 0)) {
				toList = new ArrayList();
				for(int i=0; i < strTo.length; i++) {
					toList.add(strTo[i]);
				}
			}
			if(strCC != null && (strCC.length > 0)) {
				ccList = new ArrayList();
				for(int i=0; i < strCC.length; i++) {
					ccList.add(strCC[i]);
				}
			}
			if(strBCC != null && (strBCC.length > 0)) {
				bccList = new ArrayList();
				for(int i=0; i < strBCC.length; i++) {
					bccList.add(strBCC[i]);
				}
			}
				
			/*
			 * First remove all Valid Sent Addresses and remove all invalid Addresses 
			 * from the list then try to resend email to remaining users(valid unsent users)
			 */
			log.debug("Removing all valid sent Addresses ["+ Utilities.displayAddressArray(
						sfe.getValidSentAddresses())+"] from toList:" + toList
					+ " ccList:" + ccList + " bccList:" + bccList);
			
			// Remove all Valid Sent Addresses from the list
			if(!(sfe.getValidSentAddresses() == null)) {
				log.debug("Removing all Valid Sent Addresses [" + Utilities.displayAddressArray(
						sfe.getValidSentAddresses())+"] from the list" );
				Address[] validSentAddresses = sfe.getValidSentAddresses();
				int numValidSentAddr = validSentAddresses.length;
				for(int countAddr=0; countAddr < numValidSentAddr; countAddr++) {
					InternetAddress validSentAddr = (InternetAddress) validSentAddresses[countAddr];
					log.debug("Each valid sent address:" + validSentAddr.getAddress());
					if(toList != null){
						while(toList.remove(validSentAddr.getAddress()) == true) {
						}
					}
					if(ccList != null) {
						while(ccList.remove(validSentAddr.getAddress()) == true) {
						}
					}
					if(bccList != null) {
						while(bccList.remove(validSentAddr.getAddress()) == true) {
						}
					}
				}
			}
			
			log.debug("After Removing all valid sent Addresses toList:" + toList
					+ " ccList:" + ccList + " bccList:" + bccList);
			
			// Remove all invalid Addresses from the list
			if(!(sfe.getInvalidAddresses() == null)) {
				log.debug("Removing all invalid Addresses [" + Utilities.displayAddressArray(
						sfe.getInvalidAddresses()) + "] from the list" );
				Address[] invalidAddresses = sfe.getInvalidAddresses();
				int numInvalidAddr = invalidAddresses.length;
				for(int countAddr=0; countAddr < numInvalidAddr; countAddr++) {
					InternetAddress invalidAddr = (InternetAddress) invalidAddresses[countAddr];
					log.debug("Each invalid  address:" + invalidAddr.getAddress());
					
					if(toList != null){
						while(toList.remove(invalidAddr.getAddress()) == true) {
						}
					}					
					if(ccList != null) {
						while(ccList.remove(invalidAddr.getAddress()) == true) {
						}
					}
					if(bccList != null) {
						while(bccList.remove(invalidAddr.getAddress()) == true) {
						}
					}
				}
			}
			
			log.debug("After Removing all invalid Addresses toList:" + toList
					+ " ccList:" + ccList + " bccList:" + bccList);
			try {
				if(toList != null) {
					newToAddrs = new InternetAddress[toList.size()];
					for(int countAddr = 0; countAddr < newToAddrs.length; countAddr++) {
						newToAddrs[countAddr] = new InternetAddress((String) toList.get(countAddr));
					}
					
					msg.setRecipients(Message.RecipientType.TO, newToAddrs);
					log.debug("[sendMail]: Current To Email Id(s) ["
							+ Utilities.displayAddressArray( msg.getRecipients(Message.RecipientType.TO)) + "].");
				}
				if(ccList != null) {
					newCcAddrs = new InternetAddress[ccList.size()];
					for(int countAddr = 0; countAddr < newCcAddrs.length; countAddr++) {
						newCcAddrs[countAddr] = new InternetAddress((String) ccList.get(countAddr));
					}
					
					msg.setRecipients(Message.RecipientType.CC, newCcAddrs);
					log.debug("[sendMail]: Current CC Email Id(s) ["
							+ Utilities.displayAddressArray( msg.getRecipients(Message.RecipientType.CC)) + "].");
				}				
				if(bccList != null) {
					newBccAddrs = new InternetAddress[bccList.size()];
					for(int countAddr = 0; countAddr < newBccAddrs.length; countAddr++) {
						newBccAddrs[countAddr] = new InternetAddress((String) bccList.get(countAddr));
					}
					
					msg.setRecipients(Message.RecipientType.BCC, newBccAddrs);
					log.debug("[sendMail]: Current BCC Email Id(s) ["
							+ Utilities.displayAddressArray( msg.getRecipients(Message.RecipientType.BCC)) + "].");
				}
				log.debug("Resending the email....");
				Transport.send(msg);
				log.info("Mail successfully sent to " +
						"To:[" + Utilities.displayAddressArray(msg.getRecipients(Message.RecipientType.TO))+"] " +
						"Cc:[" + Utilities.displayAddressArray(msg.getRecipients(Message.RecipientType.CC)) +"] " +
						"Bcc:["	+ Utilities.displayAddressArray(msg.getRecipients(Message.RecipientType.BCC))+"].");
			} catch(SendFailedException se) {
				log.error("[sendMail]: Unable to send mail to Email Id(s) ["
						+ Utilities.displayAddressArray( se.getValidUnsentAddresses()) + "].");
			}
		}
		log.debug("[Exit processValidUnsentAddresses]");
	}
	
	public void closeSession(){
		if(session != null)session=null;
	}
	
	protected void finalize() throws Throwable {
		closeSession();
	}
}
