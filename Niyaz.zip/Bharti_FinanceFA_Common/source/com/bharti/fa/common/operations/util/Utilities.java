/*
 * Created on Dec 23, 2008
 * 
 */
package com.bharti.fa.common.operations.util;

import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Map;

import javax.mail.Address;
import javax.mail.internet.InternetAddress;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.log4j.Logger;

/**
 * @author Harisha C S Achar(Email ID: harisha.achar@in.ibm.com,
 *         mail2harisha@gmail.com)
 * 
 * This class contains some utilities methods
 */
public class Utilities {

	public static Logger log = Logger.getLogger(Utilities.class);

	/**
	 * Returns a string representation of all String array elements seperated by
	 * comma
	 * 
	 * @param mailFields
	 *            :String array to be displayed as string
	 * @return string representation of all String array elements seperated by
	 *         comma
	 */
	public static String displayArray(String[] array) {
		if (array == null) {
			return null;
		}
		StringBuffer totalArray = new StringBuffer();
		for (int i = 0; i < array.length; i++) {
			totalArray.append(array[i] + ",");
		}

		/* remove the last comma */
		if (!(totalArray.length() == 0)) {
			totalArray.deleteCharAt((totalArray.length() - 1));
		}
		return totalArray.toString();
	}

	public static String displayObjectArray(Object[] array) {
		if (array == null) {
			return null;
		}
		StringBuffer totalArray = new StringBuffer();
		for (int i = 0; i < array.length; i++) {
			totalArray.append(array[i] + ",");
		}

		/* remove the last comma */
		if (!(totalArray.length() == 0)) {
			totalArray.deleteCharAt((totalArray.length() - 1));
		}
		return totalArray.toString();
	}

	/**
	 * Returns a string representation of all InternetAddress array elements
	 * seperated by comma
	 * 
	 * @param addrArray:
	 *            InternetAddress array to be displayed as string
	 * @return string representation of all InternetAddress array elements
	 *         seperated by comma
	 */
	public static String displayAddressArray(InternetAddress[] addrArray) {
		if (addrArray == null) {
			return null;
		}
		StringBuffer totalArray = new StringBuffer();
		for (int i = 0; i < addrArray.length; i++) {

			totalArray.append(addrArray[i].getAddress() + ",");
		}
		/* remove the last comma */
		if (!(totalArray.length() == 0)) {
			totalArray.deleteCharAt((totalArray.length() - 1));
		}

		return totalArray.toString();
	}

	public static String displayAddressArray(Address[] addrArray) {
		if (addrArray == null) {
			return null;
		}
		StringBuffer totalArray = new StringBuffer();
		for (int i = 0; i < addrArray.length; i++) {
			InternetAddress eachAdd = (InternetAddress) addrArray[i];
			totalArray.append(eachAdd.getAddress() + ",");
		}

		/* remove the last comma */
		if (!(totalArray.length() == 0)) {
			totalArray.deleteCharAt((totalArray.length() - 1));
		}

		return totalArray.toString();
	}

	/**
	 * Returns a date in string format
	 * 
	 * @param day
	 *            date to be converted
	 * @return a date in string format
	 */
	public static String dateToString(Calendar day) {
		String strFormat = "MM/dd/yyyy";
		SimpleDateFormat simDate = new SimpleDateFormat(strFormat);
		String formatted = simDate.format(day.getTime());
		return formatted;
	}

	/**
	 * 
	 * @param date- date which has to be converted to string format
	 * @return formatted string form of date
	 */
	public static String dateToString(Date date)
	{
	    String stringDate = null;
	    try {    
	 		SimpleDateFormat formatter = new SimpleDateFormat(Constants.DATE_STRING_FORMAT);
	 		stringDate = (String)formatter.format(date); 
	 		log.debug("DateToString(): Converted date is " +stringDate);
	    	}
	    catch (Exception e)
	    {
	        log.error("Exception while converting date, Exception is: "+e);    
	    } 
   		return stringDate;
	}

	/**
	 * Converts date to string in the specified format
	 * @param date
	 * @param format
	 * @return
	 * @throws Exception 
	 */
	public static String dateToString(Date date, String format) throws Exception {
		String stringDate = null;
		try {

			SimpleDateFormat formatter = new SimpleDateFormat(format);
			stringDate = (String) formatter.format(date);
			log.debug("Converted date is " + stringDate);
		} catch (Exception e) {
			log.error("Exception while converting date, Exception is: " + e);
			throw e;
		}
		return stringDate;
	}
	
	/**
	 * This method replaces the input parameter <code>MACRO</code> with the
	 * <code>value</code> where ever it appears in the buffer.
	 * 
	 * It also filters the HTML special characters present in the
	 * <code>value</code>.
	 * 
	 * @param buffer
	 *            StringBuffer from which to replace the MACRO
	 * @param MACRO
	 *            the name of the macro to be replace
	 * @param value
	 *            new value to be replace
	 * @return filtered string
	 */
	public static StringBuffer replaceMacro(StringBuffer buffer, String MACRO,
			String value) {
		int temp;

		/* Filter all html special characters */
		String strValue = null;
		if (value == null) {
			strValue = "";
		} else {
			strValue = filterHTMLSpecialCharacters(value.toString());
		}

		while ((temp = buffer.indexOf(MACRO)) != -1) {
			buffer.replace(temp, (temp + MACRO.length()), strValue);
		}
		return buffer;
	}

	/**
	 * Replaces characters that have special HTML meanings with their
	 * corresponding HTML character entities.
	 * <p>
	 * Given a string, this method replaces all occurrences of '<' with '&lt;',
	 * all occurrences of '>' with '&gt;', and (to handle cases that occur
	 * inside attribute values), all occurrences of double quotes with '&quot;'
	 * all occurrences of '&' with '&amp;', and all occurrences of '\n' with
	 * html BR tag.
	 * <p>
	 * Without such filtering, an arbitrary string could not safely be inserted
	 * in a Web page.
	 * 
	 * @param input
	 *            input string to be filtered
	 * @return filtered string
	 */
	public static String filterHTMLSpecialCharacters(String input) {

		log.debug("[Enter filterHTMLSpecialCharacters]: " + "input: [" + input
				+ "]");
		if (input == null) {
			return (input);
		}

		int startPos = indexOfSpecialChars(input);
		if (startPos == -1) {
			log.debug("Input string doesn't contains HTML special characters");
			return (input);
		}

		// Then the input string has special characters
		StringBuffer filtered = new StringBuffer(input.length());

		// Copy the characters upto 'startPos' position to filtered string
		filtered.append(input.substring(0, startPos));
		char c;
		for (int i = startPos; i < input.length(); i++) {
			c = input.charAt(i);
			switch (c) {
			case '<':
				filtered.append("&lt;");
				break;
			case '>':
				filtered.append("&gt;");
				break;
			case '"':
				filtered.append("&quot;");
				break;
			case '&':
				filtered.append("&amp;");
				break;
			case '\n':
				filtered.append("<BR>");
				break;
			default:
				filtered.append(c);
			}
		}
		log
				.debug("Input string has HTML special characters and thus modified accordingly ["
						+ filtered + "]");
		log.debug("[Exit filterHTMLSpecialCharacters]");
		return filtered.toString();
	}

	/**
	 * Replaces all the occurrences of '\n' with html BR tag
	 * 
	 * @param input
	 *            input string to be filtered
	 * @return filtered string
	 */
	public static String filterNewLineChar(String input) {
		log.debug("[Enter filterNewLineChar]");

		log.debug("[Exit filterNewLineChar]");
		return input.replaceAll("\n", "<BR>");
	}

	
	/**
	 * 
	 * @param array- array to be intilised with empty string
	 * @return -empty array
	 */
	public static String[] initializeEmptyArray(String[] array) {
	    int k =0;
		  while(k<array.length)
		  {
		      array[k] = "";  
		      k++;
		  }
		return array;
	}
	
	
	/**
	 * Returns the index within the input string of the first occurrence of the
	 * special characters.
	 * 
	 * @param input
	 *            string to check
	 * @return if the special characters occurs as a substring within this input
	 *         string, then the index of the first character of the first such
	 *         special character is returned; if it does not occur as a
	 *         substring, -1 is returned.
	 */
	private static int indexOfSpecialChars(String input) {
		int pos = -1;
		boolean flag = false;
		if ((input != null) && (input.length() > 0)) {
			char c;
			for (int i = 0; i < input.length(); i++) {
				c = input.charAt(i);
				switch (c) {
				case '<':
					flag = true;
					break;
				case '>':
					flag = true;
					break;
				case '"':
					flag = true;
					break;
				case '&':
					flag = true;
					break;
				case '\n':
					flag = true;
					break;
				}
				if (flag == true) {
					pos = i;
					break;
				}
			}
		}
		return (pos);
	}

	/**
	 * this function is used to eleminate the time from the date so that date
	 * check is only for the date,not date and time.
	 * 
	 * @param today-
	 *            this is a Date type ,from where time should be eleminited.
	 * @return - the date with time 00:00:00 to set.
	 */

	public static Date converToDate(Date today) {
		String strDate = null;
		Date date = null;
		String strFormat = "MM/dd/yyyy";
		try {
			// log.debug("The parameter value (today) ]" + today);

			DateFormat myDateFormat = new SimpleDateFormat(strFormat);
			strDate = myDateFormat.format(today);

			date = myDateFormat.parse(strDate);
			// log.debug("The returned value (date) ]"+date);
		} catch (ParseException e) {
			log.error(
					"Error occurred while parsing the date " + e.getMessage(),
					e);
		} catch (Exception ex) {
			log.error("Error occurred while parsing the date "
					+ ex.getMessage(), ex);
		}
		return date;
	}

	/**
	 * Populates a bean based on a Map: Map keys are the bean property names;
	 * Map values are the bean property values. Type conversion is performed
	 * automatically as described above.
	 */
	public static void populateBean(Object bean, Map propertyMap) {
		try {
			BeanUtils.populate(bean, propertyMap);
		} catch (Exception e) {
			// Empty catch. The two possible exceptions are
			// java.lang.IllegalAccessException and
			// java.lang.reflect.InvocationTargetException.
			// In both cases, just skip the bean operation.
			log.error("[ERROR: Exception:]" + e.getMessage(), e);
		}
	}

	/**
	 * This method replaces the input parameter MACRO with the new value where
	 * ever it appears in the buffer.
	 * 
	 * @param buffer
	 *            StringBuffer from which to replace the MACRO
	 * @param MACRO
	 *            the name of the macro to be replace
	 * @param value
	 *            new value to be replace
	 * @return
	 */
	public static StringBuffer replaceAll(StringBuffer buffer, String MACRO,
			String value) {
		int temp;

		/* Filter all macros */
		if (value == null) {
			value = "";
		}
		while ((temp = buffer.indexOf(MACRO)) != -1) {
			buffer.replace(temp, (temp + MACRO.length()), value);
		}
		return buffer;
	}

	public static Double roundTwoDecimals(double d) {
		DecimalFormat twoDForm = new DecimalFormat("#.##");
		return Double.valueOf(twoDForm.format(d));
	}
	
	public static void main(String[] args) {
	}

	/**
	 * This method replaces the input parameter <code>MACRO</code> with the
	 * <code>value</code> where ever it appears in the buffer.
	 * 
	 * It also filters the HTML special characters present in the
	 * <code>value</code> if <code>filterHTMLSpecialCharFlag</code> is set.
	 * 
	 * @param buffer
	 *            StringBuffer from which to replace the MACRO
	 * @param MACRO
	 *            the name of the macro to be replace
	 * @param value
	 *            new value to be replace
	 * @param filterHTMLSpecialCharFlag
	 *            indicates whether HTML special characters should be filtered
	 *            or not
	 * @return filtered string
	 */
	public static StringBuffer replaceMacro(StringBuffer buffer, String MACRO,
			String value, boolean filterHTMLSpecialCharFlag) {
		int temp;

		/* Filter all html special characters */
		String strValue = null;
		if (value == null) {
			strValue = "";
		} else {
			strValue = (filterHTMLSpecialCharFlag ? filterHTMLSpecialCharacters(value
					.toString())
					: value.toString());
		}

		while ((temp = buffer.indexOf(MACRO)) != -1) {
			buffer.replace(temp, (temp + MACRO.length()), strValue);
		}
		return buffer;
	}
}
