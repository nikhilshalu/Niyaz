package com.bharti.fa.common.operations.util.manager;

import java.net.MalformedURLException;
import java.security.AccessController;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

import javax.security.auth.Subject;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.filenet.api.admin.IsolatedRegion;
import com.filenet.api.admin.PEConnectionPoint;
import com.filenet.api.collection.PEConnectionPointSet;
import com.filenet.api.core.Domain;
import com.filenet.api.core.ObjectStore;
import com.filenet.api.events.ClassWorkflowSubscription;
import com.filenet.api.events.InstanceWorkflowSubscription;
import com.filenet.api.events.Subscription;
import com.filenet.api.property.PropertyFilter;

import filenet.vw.api.VWCreateLiveWOResult;
import filenet.vw.api.VWException;
import filenet.vw.api.VWFetchType;
import filenet.vw.api.VWQueue;
import filenet.vw.api.VWQueueQuery;
import filenet.vw.api.VWRoster;
import filenet.vw.api.VWRosterQuery;
import filenet.vw.api.VWSession;
import filenet.vw.api.VWWorkObject;
import filenet.vw.base.VWVersion;
import filenet.vw.server.VWBootstrapURL;

/**
 * @viz.diagram PEManager.tpx
 */
public class PEManager {

	private static Logger log = Logger.getLogger(PEManager.class);

	private VWSession peSession = null;

	private VWWorkObject vwObject = null;

	private VWVersion m_vwVersion;

	/**
	 * Establishes a Process engine session.
	 * 
	 * @param application
	 *            Constants defining whether PE session is needed through:
	 *            <ol>
	 *            1 : Standalone application(credentials needed)
	 *            </ol>
	 *            <ol>
	 *            2 : Web application(credentials needed)
	 *            </ol>
	 *            <ol>
	 *            3 : Component Manager
	 *            </ol>
	 *            <ol>
	 *            4 : Subscription
	 *            </ol>
	 * @param userId
	 *            A String containing the name of a user with permissions to log
	 *            on to the Process Engine.
	 * @param password
	 *            A String containing the password for the specified user.
	 * @param sub
	 *            Subscription event
	 * @throws VWException
	 *             Thrown for various causes, including when the specified user
	 *             is already logged on to the Process Engine.
	 * @throws MalformedURLException
	 * @throws ClassNotFoundException
	 */
	public PEManager(int application, String userId, String password,
			Subscription sub) throws VWException, MalformedURLException,
			ClassNotFoundException {

		log.debug("[Enter PEManager]");
		log.debug("Trying to establish PE session");

		if (Constants.APPLICATION_COMPONENT_MANAGER == application) {
			Subject subject = Subject.getSubject(AccessController.getContext());
			try {
				Set creds = subject.getPrivateCredentials(Class
						.forName("filenet.vw.api.VWSession"));
				Iterator iter = null;
				if (creds != null)
					iter = creds.iterator();
				if (iter != null)
					peSession = (VWSession) iter.next();
			} catch (ClassNotFoundException e) {
				log.fatal(
						"Error while creating PE Session : " + e.getMessage(),
						e);
				throw e;
			}
		} else if (Constants.APPLICATION_SUBSCRIPTION == application) {

			// If subscription is applied on a class
			if (sub instanceof ClassWorkflowSubscription) {
				ClassWorkflowSubscription cws = (ClassWorkflowSubscription) sub;
				//m_propertyMap = cws.get_PropertyMap();
				String strversion = cws.get_VWVersion();
				log
						.debug("WorkflowEventHandler Subscription = ClassWorkflowSubscription vwversion = "
								+ strversion);

				m_vwVersion = new VWVersion(strversion);
			}

			// If subscription is applied on a Object or instance
			else if (sub instanceof InstanceWorkflowSubscription) {
				InstanceWorkflowSubscription iws = (InstanceWorkflowSubscription) sub;
				//m_propertyMap = iws.get_PropertyMap();
				String strversion = iws.get_VWVersion();
				log
						.debug("WorkflowEventHandler Subscription = InstanceWorkflowSubscription vwversion = "
								+ strversion);

				m_vwVersion = new VWVersion(strversion);
			} else {
				log.debug("The subscription is not a workflow subscription");

			}

			// Get the isolated region
			int region = m_vwVersion.getIsolatedRegion();
			String service = m_vwVersion.getServiceName();
			String versionOfVWVersion = m_vwVersion.getVersion();
			PEConnectionPoint connPoint = null;
			if (versionOfVWVersion.compareToIgnoreCase("1") == 0) {
				connPoint = findPEConnectionPoint(sub, region, service, null);

			} else if (versionOfVWVersion.compareToIgnoreCase("3") == 0) {
				String connPointName = m_vwVersion.getConnectionPoint();
				connPoint = findPEConnectionPoint(sub, region, service,
						connPointName);
			}

			String ceURI = connPoint.getConnection().getURI();
			String vwBootstrapURL = (new VWBootstrapURL(ceURI, connPoint
					.get_Name())).toString();

			// Get the vwsession
			peSession = new VWSession(vwBootstrapURL);

		} else { // For Standalone and web application

			String strAppURI = PropertyLoader.props
					.getProperty("FILENET_URI_SOAP");

			if (Constants.APPLICATION_WEB == application) {
				strAppURI = PropertyLoader.props
						.getProperty("FILENET_URI_IIOP");
			}
			log.debug("FILENET_URI :" + strAppURI);

			System.setProperty("java.security.auth.login.config",
					PropertyLoader.props
							.getProperty("java.security.auth.login.config"));
			System.setProperty("wasp.location", PropertyLoader.props
					.getProperty("wasp.location"));

			try {
				peSession = new VWSession();
				peSession.setBootstrapCEURI(strAppURI);
				peSession.logon(userId, password, PropertyLoader.props
						.getProperty("BPM_CONNECTIONPOINT"));
			} catch (VWException e) {
				log.error("Exception occured while establishing PE session."
						+ e.getMessage(), e);
				throw e;
			}
		}
		log.debug("PE session established");
		log.debug("[Exit PEManager]");
	}

	public void launchWorkflow(String[] launchFields, Object[] launchValues,
			String workflowName) throws Exception {

		log.debug("--------------Launching Workflow-----------------");
		try {
			String myWorkObjectNumbers[] = null;
			String myRosterNames[] = null;

			// if(peSession.checkWorkflowIdentifier(workflowName)) {

			VWCreateLiveWOResult[] createWORes = peSession
					.createLiveWorkObject(launchFields, launchValues,
							workflowName, 1);

			if (createWORes[0].success()) {

				myWorkObjectNumbers = new String[createWORes.length];
				myRosterNames = new String[createWORes.length];
				for (int i = 0; i < createWORes.length; ++i) {
					myWorkObjectNumbers[i] = createWORes[i]
							.getWorkObjectNumber();
					log.info("New workflow with Wob Number ["
							+ myWorkObjectNumbers[i]
							+ "] launched successfully");
					myRosterNames[i] = createWORes[i].getRosterName();
					log.debug("Workflow Roster Name is [" + myRosterNames[i]
							+ "]");
				}
			}
			/*
			 * } else { log.error("Unable to launch the workflow. Workflow with
			 * name ["+workflowName+ "] does not exist in the Process Engine."); }
			 */
		} catch (Exception ex) {
			log.error("Exception occured while launching workflow:"
					+ ex.getMessage(), ex);
			throw ex;
		}
	}

	/**
	 * <p>
	 * This method will Return the Processs engine Connection Points as well as
	 * the Isolated Region and Number of the Workflow and its DNSName
	 * <p>
	 * 
	 * @param sub
	 *            Indicates the Subscription which is used
	 * @param region
	 *            Indicates the isolated region to process engine uses
	 * @param service
	 *            Indicates the service name
	 * @param connPointName
	 *            Indicates the connection point Name
	 * @return This method will return PEConnectionPoint Object
	 * @throws VWException
	 */
	public PEConnectionPoint findPEConnectionPoint(Subscription sub,
			int region, String service, String connPointName)
			throws VWException {
		log.debug("[Enter findPEConnectionPoint]");

		log.debug("region = " + region + ", service=" + service);

		// Get The Server name using service
		String servername = service.substring(service.indexOf(":") + 1, service
				.lastIndexOf(":"));
		log.debug("Name from service = " + servername);

		// Get the Object Store
		ObjectStore objStore = sub.getObjectStore();
		PropertyFilter pf = new PropertyFilter();
		pf.addIncludeProperty(0, null, null, "Domain");
		objStore.fetchProperties(pf);

		// get the Domain of the ObjectStore
		Domain domain = objStore.get_Domain();

		// using the domain Get the Process Engine Connection Points
		PEConnectionPointSet connPointSet = domain.get_PEConnectionPoints();
		Iterator it = connPointSet.iterator();
		ArrayList arList = new ArrayList();
		do {
			if (!it.hasNext())
				break;

			// Iterate through the Connection points and get the isolated region
			// of the Workflow
			PEConnectionPoint connPoint = (PEConnectionPoint) it.next();
			String name = connPoint.get_Name();

			// Get tge Isolated region of the Workflow
			IsolatedRegion ir = connPoint.get_IsolatedRegion();

			// Get the DNSName and isolated region Number
			String connPointDNSname = ir.get_DNSName();
			Integer connPointRegion = ir.get_IsolatedRegionNumber();
			if (connPointName != null && name.compareTo(connPointName) == 0) {
				log.debug("connectionPoint = " + connPoint.get_Name());
				return connPoint;
			}
			if (connPointName == null && connPointRegion.intValue() == region) {
				if (connPointDNSname.compareToIgnoreCase(servername) == 0) {
					log.debug("connectionPoint = " + connPoint.get_Name());
					return connPoint;
				}
				arList.add(connPoint);
			}
		} while (true);

		// Checking For Exception Conditions
		if (arList.size() > 0) {
			PEConnectionPoint connPoint = (PEConnectionPoint) arList.get(0);
			log.debug("connectionPoint = " + connPoint.get_Name());
			return connPoint;
		}
		if (connPointName != null) {
			log.debug("No connection point found for name = " + connPointName);
			VWException vwe = new VWException("filenet.pe.ce.NoCPForName",
					"No connection point found with name {0}", connPointName);
			throw vwe;
		} else {
			log.debug("No connection point found for region = " + region
					+ ", service=" + service);
			VWException vwe = new VWException("filenet.pe.ce.NoCPForRegion",
					"No connection point found for region {0}", (new Integer(
							region)).toString());
			throw vwe;
		}
	}

	private String getFilterParams(Hashtable filterParams) {
		log.debug("ENTRY : getFilterParams");
		String strFilterParam = "";
		Set oKeySet = filterParams.keySet();
		log.debug("Keyn set size :" + oKeySet.size());
		Iterator oIterator = oKeySet.iterator();
		while (oIterator.hasNext()) {

			String tmpString = (String) oIterator.next();
			Object objVal = filterParams.get(tmpString);
			if (objVal instanceof Integer) {
				strFilterParam = strFilterParam + tmpString + "="
						+ ((Integer) objVal).intValue();
			} else if (objVal instanceof String) {
				strFilterParam = strFilterParam + tmpString + "='"
						+ ((String) objVal).toString() + "'";
			} else if (objVal instanceof Boolean) {
				strFilterParam = strFilterParam + tmpString + "="
						+ ((Boolean) objVal).booleanValue();
			}

			if (oIterator.hasNext()) {
				strFilterParam = strFilterParam + " AND ";
			}
		}

		log.debug("Filter Params : " + strFilterParam);
		log.debug("EXIT : getFilterParams");
		return strFilterParam;

	}

	private int getFetchType(String searchResultType) {
		log.debug("ENTRY : getFetchType");
		int intReturn = 0;
		if (searchResultType.equalsIgnoreCase("WORKOBJECT"))
			intReturn = VWFetchType.FETCH_TYPE_WORKOBJECT;
		if (searchResultType.equalsIgnoreCase("INSTRUCTION_ELEMENT"))
			intReturn = VWFetchType.FETCH_TYPE_INSTRUCTION_ELEMENT;
		if (searchResultType.equalsIgnoreCase("QUEUE_ELEMENT"))
			intReturn = VWFetchType.FETCH_TYPE_QUEUE_ELEMENT;
		if (searchResultType.equalsIgnoreCase("STEP_ELEMENT"))
			intReturn = VWFetchType.FETCH_TYPE_STEP_ELEMENT;
		if (searchResultType.equalsIgnoreCase("ROSTER_ELEMENT"))
			intReturn = VWFetchType.FETCH_TYPE_ROSTER_ELEMENT;
		log.debug("EXIT : getFetchType");
		return intReturn;
	}

	public VWSession getSession() {

		return peSession;
	}

	public ArrayList searchPEObject(Hashtable filterParams, String searchScope,
			String searchResultType, String ClassName) throws VWException {
		log.debug("ENTRY : searchPEObject");
		ArrayList oSearchResultAL = new ArrayList();

		String wobNum = (filterParams.get("WobNum") != null) ? (String) filterParams
				.get("WobNum")
				: null;
		log.debug("Wob num is:" + wobNum);
		filterParams.remove("WobNum");
		String strIndexField_WobNum = "F_WobNum";
		String strIndexField = strIndexField_WobNum;
		String[] indexMinValue = { wobNum };
		String[] indexMaxValue = { wobNum };

		if (searchScope.equalsIgnoreCase(Constants.PE_SEARCH_SCOPE_QUEUE)) {
			try {
				VWQueue oVWQueue = peSession.getQueue(ClassName);
				VWQueueQuery oQuery = (wobNum == null || "".equals(wobNum)) ? oVWQueue
						.createQuery(null, null, null,
								VWQueue.QUERY_NO_OPTIONS,
								getFilterParams(filterParams), null,
								getFetchType(searchResultType))
						: oVWQueue.createQuery(strIndexField, indexMinValue,
								indexMaxValue,
								VWQueue.QUERY_MIN_VALUES_INCLUSIVE
										+ VWQueue.QUERY_MAX_VALUES_INCLUSIVE,
								getFilterParams(filterParams), null,
								getFetchType(searchResultType));
				while (oQuery.hasNext()) {
					oSearchResultAL.add(oQuery.next());
				}
			} catch (VWException e) {
				log.error("Exception caught while fetching from Queue", e);
				throw e;
				
			}
		} else if (searchScope
				.equalsIgnoreCase(Constants.PE_SEARCH_SCOPE_ROSTER)) {
			try {
				VWRoster oVWRoster = peSession.getRoster(ClassName);
				VWRosterQuery oQuery = (wobNum == null || "".equals(wobNum)) ? oVWRoster
						.createQuery(null, null, null,
								VWQueue.QUERY_NO_OPTIONS,
								getFilterParams(filterParams), null,
								getFetchType(searchResultType))
						: oVWRoster.createQuery(strIndexField, indexMinValue,
								indexMaxValue,
								VWQueue.QUERY_MIN_VALUES_INCLUSIVE
										+ VWQueue.QUERY_MAX_VALUES_INCLUSIVE,
								getFilterParams(filterParams), null,
								getFetchType(searchResultType));
				while (oQuery.hasNext()) {
					oSearchResultAL.add(oQuery.next());
				}
			} catch (VWException e) {
				log.error("Exception caught while fetching from Roster", e);
				throw e;
			}

		}
		log.debug("EXIT : searchPEObject");
		return oSearchResultAL;
	}

	public VWWorkObject fetchCaseVWObject(int Bp8CaseId, boolean lockWFObject,
			boolean overrideLock) throws VWException {
		log.debug("ENTRY : fetchCaseVWObject");
		// if(vwObject == null){
		vwObject = fetchWFObject(Bp8CaseId);
		log.debug("WF Subject :" + vwObject.getSubject());
		if (lockWFObject) {
			if (overrideLock)
				vwObject.doLock(true);
			else
				vwObject.doLock(false);
		}

		// }

		log.debug("EXIT : fetchCaseVWObject");
		return vwObject;
	}

	public VWWorkObject fetchCaseVWObject(int Bp8CaseId, String wobNum,
			boolean lockWFObject, boolean overrideLock) throws Exception {
		log.debug("ENTRY : fetchCaseVWObject");
		// if(vwObject == null){
		vwObject = fetchWFObject(Bp8CaseId, wobNum);
		log.debug("WF Subject :" + vwObject.getSubject());
		if (lockWFObject) {
			if (overrideLock)
				vwObject.doLock(true);
			else
				vwObject.doLock(false);
		}

		// }

		log.debug("EXIT : fetchCaseVWObject");
		return vwObject;
	}

	private VWWorkObject fetchWFObject(int Bp8CaseId) throws VWException {
		log.debug("ENTRY : fetchWFObject");
		// if(vwObject == null){
		// log.debug("vwObject is NULL");
		Hashtable filterParams = new Hashtable();
		filterParams.put("Bp8CaseID", new Integer(Bp8CaseId));
		ArrayList searchResult = searchPEObject(filterParams,
				Constants.PE_SEARCH_SCOPE_ROSTER,
				Constants.PE_FETCH_WORK_OBJECT, "DefaultRoster");

		log.debug("Search result size " + searchResult.size());
		for (int i = 0; i < searchResult.size(); i++) {
			vwObject = (VWWorkObject) searchResult.get(i);
		}
		// if(searchResult.size() > 1)
		// vwObject=(VWWorkObject) searchResult.get(searchResult.size()-1);
		// else if(searchResult.size() == 1)
		// vwObject=(VWWorkObject) searchResult.get(0);

		log.debug("WF Subject *********:" + vwObject.getSubject());
		// }

		log.debug("EXIT : fetchWFObject");
		return vwObject;
	}

	private VWWorkObject fetchWFObject(int Bp8CaseId, String wobNum)
			throws Exception {
		log.debug("ENTRY : fetchWFObject");
		// if(vwObject == null){
		log.debug("vwObject is NULL");
		Hashtable filterParams = new Hashtable();
		filterParams.put("Bp8CaseID", new Integer(Bp8CaseId));
		filterParams.put("WobNum", wobNum);

		ArrayList searchResult = searchPEObject(filterParams,
				Constants.PE_SEARCH_SCOPE_ROSTER,
				Constants.PE_FETCH_WORK_OBJECT, "DefaultRoster");
		vwObject = (VWWorkObject) searchResult.get(0);
		log.debug("WF Subject :" + vwObject.getSubject());
		// }

		log.debug("EXIT : fetchWFObject");
		return vwObject;
	}

	public void setVWFieldValue (int Bp8CaseId, String fieldName,
			String fieldValue) throws VWException{
		try {
			VWWorkObject vwObject = fetchCaseVWObject(Bp8CaseId, true, true);
			vwObject.setFieldValue(fieldName, fieldValue, true);
			vwObject.doSave(true);
			vwObject.doDispatch();
		} catch (VWException e) {
			log.error("Exception : PEManager : setVWFieldValue :fieldName", e);
			throw e;
		}
	}

	public VWWorkObject setVWFieldValue(int Bp8CaseId, Hashtable htFields) throws Exception {
		log.debug("ENTRY : setVWFieldValue");
		
		try {
			vwObject = fetchCaseVWObject(Bp8CaseId, true, true);
			Iterator iterFields = htFields.keySet().iterator();

			log.debug("Keyset size :" + htFields.keySet().size());
			int count = 1;
			while (iterFields.hasNext()) {
				String fieldName = (String) iterFields.next();
				Object fieldVal = htFields.get(fieldName);
				log.debug("Setting Field [" + count + "] Name (" + fieldName
						+ ") " + "Value (" + fieldVal + ")");

				try {
					vwObject.setFieldValue(fieldName, fieldVal, false);
				} catch (VWException ve) {
					log
							.error(
									"Exception occurred while setting Field Name ["
											+ fieldName + "] with value ["
											+ fieldVal + "]", ve);
					throw ve;
				}
				count++;
			}

			vwObject.doSave(false);
			log.debug("Successfully updated the Process Engine fields");
		} catch (Exception e) {
			
			log.error("Exception occurred while setting PE fields.", e);
			throw e;
		}
		log.debug("EXIT : setVWFieldValue");
		return vwObject;
	}

	// public Object getVWFieldValue(int Bp8CaseId,String fieldName) throws
	// Exception
	// {
	// vwObject=(vwObject != null)? vwObject :
	// fetchCaseVWObject(Bp8CaseId,true,true);
	// return (vwObject.getFieldValue(fieldName));
	// }

	public int getWorkItemLockedStatus(int Bp8CaseId) throws Exception {
		log.debug("ENTRY : getWorkItemLockedStatus");
		int lockStatus = 1;
		if (fetchWFObject(Bp8CaseId) != null) {
			lockStatus = vwObject.fetchLockedStatus();
		}
		log.debug("EXIT : getWorkItemLockedStatus");
		return lockStatus;
	}

	public void dispatchCaseVWObject(String response) throws VWException {
		log.debug("ENTRY : dispatchCaseVWObject");

		if (response != null) {
			vwObject.setSelectedResponse(response);
		}
		vwObject.doSave(true);
		vwObject.doDispatch();
		log.debug("EXIT : dispatchCaseVWObject");
	}

	public VWSession getPESession() {
		log.debug("ENTRY : getPeSession");
		log.debug("EXIT : getPeSession");
		return peSession;
	}

	/**
	 * Ends the session with the Process Engine
	 * 
	 * @throws VWException
	 */
	public void closePESession() {
		log.debug("[Enter closePESession]");
		try {
			if (peSession != null) {
				peSession.logoff();
				log.debug("PE session logged off successfully.");
			}
		} catch (VWException e) {
			log.error("Error occurred while closing the PE session."
					+ e.getMessage(), e);
		}

		log.debug("[Exit : closePESession]");
	}

	protected void finalize() throws Throwable {
		// closeSession();
	}

	// Hifzur Added this function on 4th April.Its a replica of VWWorkObject
	// fetchWFObject(int Bp8CaseId).But to make it independent from any other
	// function
	public VWWorkObject fetchWFObjectSearch(int Bp8CaseId) throws Exception {
		log.debug("ENTRY : fetchWFObjectSearch");
		log.debug("fetchWFObjectSearch is called for case ID " + Bp8CaseId);

		Hashtable filterParams = new Hashtable();

		VWWorkObject vwObjectNew = null;
		if (vwObjectNew == null) {

			log.debug("vwObject is NULL");

			filterParams.put("Bp8CaseID", new Integer(Bp8CaseId));
			ArrayList searchResult = searchPEObject(filterParams,
					Constants.PE_SEARCH_SCOPE_ROSTER,
					Constants.PE_FETCH_WORK_OBJECT, "DefaultRoster");
			log.debug("Search result size " + searchResult.size());

			for (int i = 0; i < searchResult.size(); i++) {
				vwObjectNew = (VWWorkObject) searchResult.get(i);
			}

		}

		filterParams = null;

		// log.debug("BP8 CASE ID in fetchWFObjectSearch is
		// "+vwObjectNew.getFieldValue("Bp8CaseID").toString());
		// log.debug("doc Status in fetchWFObjectSearch is
		// "+vwObjectNew.getFieldValue("documentationStatus").toString());
		log.debug("EXIT : fetchWFObject");
		return vwObjectNew;
	}

}
