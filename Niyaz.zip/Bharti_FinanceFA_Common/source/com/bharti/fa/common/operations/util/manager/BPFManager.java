/*
 * Created on Oct 4, 2006
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.fa.common.operations.util.manager;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.filenet.operations.Bp8Operations;

/**
 * @author Administrator
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
public class BPFManager extends Bp8Operations {

	private static Logger logger = Logger.getLogger(BPFManager.class);

	String schemaName;
	
	Connection dbconn = null;

	public BPFManager(String caseType) throws Exception {
		logger.debug("[Enter BPFManager constructor]");
		try {
			
			/* Get the datbase connection */
			logger.debug("Trying to get the database connection");
			getDbConnection();
			
			schemaName = PropertyLoader.props
					.getProperty("DATABASE_SCHEMA_NAME");
			logger.debug("The value of [DATABASE_SCHEMA_NAME] from the properties file is ["
					+ schemaName + "]");
			
			getBootstrapObjectStoreName();
			logger.info("[ getBootstrapObjectStoreName() completed ]");
			getCaseObjectStoreName(caseType);
			logger.info("[ getCaseObjectStoreName completed ]");
			getAuditObjectStoreName(caseType);
			logger.info("[ getAuditObjectStoreName completed ]");
			
			
		} catch (Exception ex) {
			logger.error("Error in BPFManager constructor " + ex, ex);
			throw ex;
		} finally {
			if (dbconn != null) {
				dbconn.close();
				logger.debug("Datbase connection closed successfully.");
			}
		}
		logger.debug("[Exit BPFManager constructor]");
	}

	protected String getBootstrapObjectStoreName() throws SQLException {
		logger.debug("[Enter getBootstrapObjectStoreName]");
		if (bootstrapObjectStoreNameCache != null
				&& bootstrapObjectStoreNameCache.length() > 0) {
			logger.debug("Returning bootstrapObjectStoreName ["
					+ bootstrapObjectStoreNameCache + "]");
			return bootstrapObjectStoreNameCache;
		}
		logger.debug("Entering method getBootstrapOS()");
		String bootstrapOSName = null;
		String sql = "SELECT ass.VALUE AS BootstrapObjectStore FROM "
				+ schemaName
				+ "APPLICATION_SETTINGS ass WHERE ass.NAME = 'OBJECT_STORE'";

		Statement stmt = null;
		ResultSet rs = null;
		try {

			stmt = dbconn.createStatement();
			logger.debug(sql);
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				bootstrapOSName = rs.getString("BootstrapObjectStore");
				logger.debug("The bootstrap object store name is : "
						+ bootstrapOSName);
			}
		} catch (SQLException ex) {
			logger.error("Error access database");
			logger.debug(null, ex);
			throw ex;
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		bootstrapObjectStoreNameCache = bootstrapOSName;
		logger.debug("[Exit getBootstrapObjectStoreName]");
		return bootstrapOSName;
	}

	protected String getCaseObjectStoreName(String caseType)
			throws SQLException {
		logger.debug("[Enter getCaseObjectStoreName]");
		HashMap osNameMapping = getObjectStoreNameMapping(caseType);
		String caseOSName = null;
		if (osNameMapping != null
				&& (String) osNameMapping.get("CaseObjectStore") != null
				&& ((String) osNameMapping.get("CaseObjectStore")).length() > 0)
			caseOSName = (String) osNameMapping.get("CaseObjectStore");
		if (caseOSName == null || caseOSName.length() == 0)
			caseOSName = getDefaultObjectStoreName();
		logger.debug("[Exit getCaseObjectStoreName]");
		return caseOSName;
	}

	protected String getAuditObjectStoreName(String caseType)
			throws SQLException {
		logger.debug("[Enter getAuditObjectStoreName]");
		HashMap osNameMapping = getObjectStoreNameMapping(caseType);
		String auditOSName = null;
		if (osNameMapping != null
				&& (String) osNameMapping.get("AuditObjectStore") != null
				&& ((String) osNameMapping.get("AuditObjectStore")).length() > 0)
			auditOSName = (String) osNameMapping.get("AuditObjectStore");
		if (auditOSName == null || auditOSName.length() == 0)
			auditOSName = getDefaultObjectStoreName();
		logger.debug("[Exit getAuditObjectStoreName]");

		return auditOSName;
	}

	protected HashMap getObjectStoreNameMapping(String caseType)
			throws SQLException {
		HashMap osNameMapping = (HashMap) objectStoreNameMappingCache
				.get(caseType);
		if (osNameMapping != null && osNameMapping.size() > 0)
			return osNameMapping;
		osNameMapping = new HashMap();
		String sql = MessageFormat
				.format(
						"SELECT cts.CASE_OBJECT_STORE_NAME AS CaseObjectStore, cts.DOC_OBJECT_STORE_NAME AS DocObjectStore, cts.AUDIT_OBJECT_STORE_NAME AS AuditObjectStore FROM "
								+ schemaName
								+ "CASE_TYPES cts WHERE cts.NAME = {0}",
						new String[] { "'" + caseType + "'" });
		logger.debug("Get object store mapping from Metastore for Case Type = "
				+ caseType);
		
		Statement stmt = null;
		ResultSet rs = null;
		try {
			
			stmt = dbconn.createStatement();
			logger.debug(sql);
			rs = stmt.executeQuery(sql);
			if (rs.next()) {
				String caseOSName = rs.getString("CaseObjectStore");
				String docOSName = rs.getString("DocObjectStore");
				String auditOSName = rs.getString("AuditObjectStore");
				osNameMapping.put("CaseObjectStore", caseOSName);
				osNameMapping.put("DocObjectStore", docOSName);
				osNameMapping.put("AuditObjectStore", auditOSName);
				logger.debug("CaseObjectStore = " + caseOSName
						+ " DocObjectStore = " + docOSName
						+ " AuditObjectStore = " + auditOSName);
			}
		} catch (SQLException ex) {
			logger.error("Error access database");
			logger.debug(null, ex);
			throw ex;
		} finally {
			if (rs != null)
				rs.close();
			if (stmt != null)
				stmt.close();
		}
		objectStoreNameMappingCache.put(caseType, osNameMapping);
		logger.debug("Exiting method getOSMapping(), returing fieldsMapping"
				+ osNameMapping);
		return osNameMapping;
	}

	public Connection getDbConnection() throws Exception {
		logger.debug("[Entry getDbConnection]");

		String db2URL = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_BPF_METASTORE_URL"));
		String db2User = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_ID"));
		String db2pwd = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_PASSWORD"));
				
		ExternalDBManager dbMgr = new ExternalDBManager(Constants.APPLICATION_STANDALONE);
		dbconn = dbMgr.getDbConnection(db2URL, db2User, db2pwd);
		
		logger.debug("Calling the createDataSource method");
		
		String databaseName = PropertyLoader.props
				.getProperty("DATABASE_BPF_METASTORE_DATABASE_NAME");
		logger.debug("The value of [DATABASE_BPF_METASTORE_DATABASE_NAME] from the properties file is ["
						+ databaseName + "]");

		String server = PropertyLoader.props
				.getProperty("DATABASE_BPF_METASTORE_DATABASE_SERVER");
		logger.debug("The value of [DATABASE_BPF_METASTORE_DATABASE_SERVER] from the properties file is ["
						+ server + "]");

		String portStr = PropertyLoader.props
				.getProperty("DATABASE_BPF_METASTORE_DATABASE_PORT");
		logger.debug("The value of [DATABASE_BPF_METASTORE_DATABASE_PORT] from the properties file is ["
						+ portStr + "]");
		int port = Integer.parseInt(portStr);

		String dbType = PropertyLoader.props
				.getProperty("DATABASE_BPF_METASTORE_DATABASE_DBTYPE");
		logger.debug("The value of [DATABASE_BPF_METASTORE_DATABASE_DBTYPE] from the properties file is ["
						+ dbType + "]");

		metastore_ds = createDataSource(db2User, db2pwd, databaseName, server, port, dbType);
		logger.debug("Data Source initialized");
		
		logger.debug("[Exit getDbConnection]");
		return dbconn;
	}
	
	public static void main(String[] args) {
	}
}
