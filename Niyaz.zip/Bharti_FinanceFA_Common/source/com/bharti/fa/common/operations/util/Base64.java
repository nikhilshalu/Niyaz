/*
 * Created on Dec 1, 2008
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.fa.common.operations.util;

/**
 * @viz.diagram Base64.tpx
 */
public class Base64
{

    private static final char intToBase64[] = {
        'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 
        'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 
        'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 
        'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
        'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', 
        '8', '9', '+', '/'
    };
    private static final char intToAltBase64[] = {
        '!', '"', '#', '$', '%', '&', '\'', '(', ')', ',', 
        '-', '.', ':', ';', '<', '>', '@', '[', ']', '^', 
        '`', '_', '{', '|', '}', '~', 'a', 'b', 'c', 'd', 
        'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 
        'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 
        'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', 
        '8', '9', '+', '?'
    };
    private static final byte base64ToInt[] = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, 62, -1, -1, -1, 63, 52, 53, 
        54, 55, 56, 57, 58, 59, 60, 61, -1, -1, 
        -1, -1, -1, -1, -1, 0, 1, 2, 3, 4, 
        5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 
        15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 
        25, -1, -1, -1, -1, -1, -1, 26, 27, 28, 
        29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 
        39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 
        49, 50, 51
    };
    private static final byte altBase64ToInt[] = {
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, 0, 1, 2, 3, 4, 5, 6, 
        7, 8, -1, 62, 9, 10, 11, -1, 52, 53, 
        54, 55, 56, 57, 58, 59, 60, 61, 12, 13, 
        14, -1, 15, 63, 16, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 
        -1, 17, -1, 18, 19, 21, 20, 26, 27, 28, 
        29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 
        39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 
        49, 50, 51, 22, 23, 24, 25
    };

    Base64()
    {
    }

    public static String byteArrayToBase64(byte abyte0[])
    {
        return byteArrayToBase64(abyte0, false);
    }

    static String byteArrayToAltBase64(byte abyte0[])
    {
        return byteArrayToBase64(abyte0, true);
    }

    private static String byteArrayToBase64(byte abyte0[], boolean flag)
    {
        int i = abyte0.length;
        int j = i / 3;
        int k = i - 3 * j;
        int l = 4 * ((i + 2) / 3);
        StringBuffer stringbuffer = new StringBuffer(l);
        char ac[] = flag ? intToAltBase64 : intToBase64;
        int i1 = 0;
        for(int j1 = 0; j1 < j; j1++)
        {
            int l1 = abyte0[i1++] & 0xff;
            int j2 = abyte0[i1++] & 0xff;
            int k2 = abyte0[i1++] & 0xff;
            stringbuffer.append(ac[l1 >> 2]);
            stringbuffer.append(ac[l1 << 4 & 0x3f | j2 >> 4]);
            stringbuffer.append(ac[j2 << 2 & 0x3f | k2 >> 6]);
            stringbuffer.append(ac[k2 & 0x3f]);
        }

        if(k != 0)
        {
            int k1 = abyte0[i1++] & 0xff;
            stringbuffer.append(ac[k1 >> 2]);
            if(k == 1)
            {
                stringbuffer.append(ac[k1 << 4 & 0x3f]);
                stringbuffer.append("==");
            } else
            {
                int i2 = abyte0[i1++] & 0xff;
                stringbuffer.append(ac[k1 << 4 & 0x3f | i2 >> 4]);
                stringbuffer.append(ac[i2 << 2 & 0x3f]);
                stringbuffer.append('=');
            }
        }
        return stringbuffer.toString();
    }

    static byte[] base64ToByteArray(String s)
    {
        return base64ToByteArray(s, false);
    }

    static byte[] altBase64ToByteArray(String s)
    {
        return base64ToByteArray(s, true);
    }

    private static byte[] base64ToByteArray(String s, boolean flag)
    {
        byte abyte0[] = flag ? altBase64ToInt : base64ToInt;
        int i = s.length();
        int j = i / 4;
        if(4 * j != i)
        {
            throw new IllegalArgumentException(" String length must be a multiple of four. ");
        }
        int k = 0;
        int l = j;
        if(i != 0)
        {
            if(s.charAt(i - 1) == '=')
            {
                k++;
                l--;
            }
            if(s.charAt(i - 2) == '=')
            {
                k++;
            }
        }
        byte abyte1[] = new byte[3 * j - k];
        int i1 = 0;
        int j1 = 0;
        for(int k1 = 0; k1 < l; k1++)
        {
            int i2 = base64toInt(s.charAt(i1++), abyte0);
            int k2 = base64toInt(s.charAt(i1++), abyte0);
            int i3 = base64toInt(s.charAt(i1++), abyte0);
            int j3 = base64toInt(s.charAt(i1++), abyte0);
            abyte1[j1++] = (byte)(i2 << 2 | k2 >> 4);
            abyte1[j1++] = (byte)(k2 << 4 | i3 >> 2);
            abyte1[j1++] = (byte)(i3 << 6 | j3);
        }

        if(k != 0)
        {
            int l1 = base64toInt(s.charAt(i1++), abyte0);
            int j2 = base64toInt(s.charAt(i1++), abyte0);
            abyte1[j1++] = (byte)(l1 << 2 | j2 >> 4);
            if(k == 1)
            {
                int l2 = base64toInt(s.charAt(i1++), abyte0);
                abyte1[j1++] = (byte)(j2 << 4 | l2 >> 2);
            }
        }
        return abyte1;
    }

    private static int base64toInt(char c, byte abyte0[])
    {
        byte byte0 = abyte0[c];
        if(byte0 < 0)
        {
            throw new IllegalArgumentException(" Illegal character: " + c);
        } else
        {
            return byte0;
        }
    }

    public static void main(String args[])
    {
        String data1="anil@peae.com";
        
        byte text1[] = new byte[data1.length()];
        for(int i1 = 0; i1 < data1.length(); i1++)
        {
            text1[i1] = ( byte)data1.charAt(i1);
        }
        String s = byteArrayToBase64(text1);
        
        byte abyte1[] = base64ToByteArray(s);
        int i1;
        char ch;
        String conv=null;
        for(i1=0; i1 < abyte1.length; i1++)
        {
            if(i1==0)
            {
            	//System.out.println("["+i1+"]"+abyte1[i1]);
                ch=(char)abyte1[i1];
                conv="a"+ch;
                conv=conv.substring(1);
            }
        	else{
        	//System.out.println("["+i1+"]"+abyte1[i1]);
            ch=(char)abyte1[i1];
            conv=conv+ch;
        	}
        }
        //System.out.println("cs1.length="+cs1.length+" no="+(cs1.length/3));
        //String encrypted=encrypt("B0000002HRSSPORTAL");
/*        String SSFID="amRiYzpkYjI6Ly8xMC41Ljc2LjE2OjYwMDAwL0VNUERC";
        String decrypt1=decrypt(SSFID);
        System.out.println("decrypted url= "+decrypt1);
        String encryptedEmailId="ZW1hZGJ1c3I=";
        String decrypt2=decrypt(encryptedEmailId);
        
        System.out.println("decrypted user= "+decrypt2);
      
        System.out.println("[http://10.13.7.103:9080/smsTest/services/MOService]  encrypted: "+encrypt("http://10.13.7.103:9080/smsTest/services/MOService")
        		+"decrypted: "+decrypt(encrypt("http://10.13.7.103:9080/smsTest/services/MOService")));
        
*/
        System.out.println(decrypt("amRiYzpkYjI6Ly9DTkRBQ1NTRkRCRFAwMTo2MDAwMC9TQ01CUEZEQg=="));
        System.out.println("sdfhuihk"+decrypt("REIyVVNFUg=="));
    	System.out.println(decrypt("YmhhcnRpMTIz"));
    	
    	System.out.println("------------");
        System.out.println(encrypt("jdbc:db2://10.5.76.16:60000/FINBPFDB"));
    	System.out.println(encrypt("db2user"));
    	System.out.println(encrypt("bharti123"));
    	
        System.out.println("------------");
        System.out.println(encrypt("jdbc:db2://10.13.6.94:50000/CSS_DB"));
    	System.out.println(encrypt("ceadmin"));
    	System.out.println(encrypt("filenet"));
        
/*    	System.out.println("------------");
    	System.out.println(decrypt(encrypt("jdbc:db2://CNDACSSFDBDP01:60000/SCMBPFDB")));
    	System.out.println(decrypt(encrypt("empdbusr")));
    	System.out.println(decrypt(encrypt("content123")));
*/        /*
        for(int k = 0; k < i; k++)
        {
            for(int l = 0; l < j; l++)
            {
                byte abyte0[] = new byte[l];
                for(int i1 = 0; i1 < l; i1++)
                {
                    abyte0[i1] = (byte)random.nextInt();
                }

                String s = byteArrayToBase64(abyte0);
                System.out.println("String s="+s);
                byte abyte1[] = base64ToByteArray(s);
                if(!Arrays.equals(abyte0, abyte1))
                {
                    System.out.println(" Dismal failure! ");
                }
                s = byteArrayToAltBase64(abyte0);
                abyte1 = altBase64ToByteArray(s);
                System.out.println("abyte1="+abyte1);
                if(!Arrays.equals(abyte0, abyte1))
                {
                    System.out.println(" Alternate dismal failure! ");
                }
            }

        }
*/
    }
    public static String encrypt(String str)
    {
    	byte text1[] = new byte[str.length()];
        for(int i1 = 0; i1 < str.length(); i1++)
        {
            text1[i1] = ( byte)str.charAt(i1);
        }
        String s = byteArrayToBase64(text1);
        //System.out.println("The encrypted value for String="+str+" is ="+s);
        return s;
    }
    public static String decrypt(String str)
    {
    	byte abyte1[] = base64ToByteArray(str);
    	int i1;
        char ch;
        String conv="a";
        for(i1=0; i1 < abyte1.length; i1++)
        {
            //System.out.println("["+i1+"]"+abyte1[i1]);
            ch=(char)abyte1[i1];
            conv=conv+ch;
        }
        
        //System.out.println("The converted string="+conv);
        String result=conv.substring(1);
        //System.out.println("The decrypted value for String="+str+" is ="+result);
        return result;
        
    }

}
