/*
 * Created on May 9, 2009
 */
package com.bharti.fa.common.workallocation.impl;

import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.fa.common.operations.util.manager.WorkAllocationManager;
import com.bharti.fa.common.workallocation.PushWorkAllocator;
import com.bharti.fa.common.workallocation.bean.UserDetailBean;
import com.bharti.fa.common.workallocation.bean.WorkAllocationXMLHandlerBean;

/**
 * This class is responsible for allocating the work in round robin basis. 
 * @author Harisha
 * @viz.diagram RoundRobinPushWorkAllocator.tpx
 */
public class RoundRobinPushWorkAllocator implements PushWorkAllocator {

	public static Logger log = Logger.getLogger(RoundRobinPushWorkAllocator.class);
	
	private static String message = null;
	
	/**
	 * Gets the next available participant for allocating the work based on 
	 * the input parameter <code>inputParams</code> in round robin basis. 
	 * <p>
	 * For any request, it checks the last assigned user details for that group 
	 * from the group wise last user assigned map,
	 *  
	 * 1. If there is no active user for that group then it will return a string 
	 * array {"PULL"} and hence will be routed to unassigned cases queue.
	 * 
	 * 2. If no user is yet assigned for this group, then it returns the first 
	 * user details from the group wise user details map of that group  and update 
	 * the selected user as last user assigned.
	 * 
	 * 3. Otherwise, It returns the next user details from the group wise user 
	 * details map of that group and update the selected user as last user assigned.
	 * 
	 * @param 	inputParams
	 * 			each input parameter will be sent in the form of 
	 * 			{"FIELDNAME", FIELDVALUE ...}
	 * 
	 * @return	the details of next available participant to allocate work in 
	 * 			the following order {USER_ID, USER_FULL_NAME, USER_NAME, USER_MAILID, 
	 * 			SUPERVISOR_NAME, SUPERVISOR_SSFID, SUPERVISOR_MAILID, MANAGER_NAME, 
	 * 			MANAGER_SSFID, MANAGER_MAILID, SRMANAGER_NAME, SRMANAGER_SSFID, 
	 * 			SRMANAGER_MAILID}
	 * 
	 * @throws 	IllegalArgumentException - throws for number of reasons:
	 * 				1. If the input parameter is null or empty
	 * 				2. If error occurred while parsing the xml file
	 * 			Exception - if unable to process the request due to any 
	 * 			exception occurred while processing 
	 * @see com.bharti.fa.common.workallocation.PushWorkAllocator#getParticipant(java.lang.String[])
	 */

	public String[] getParticipant(String[] inputParams) throws Exception {
		log.debug("[Enter getParticipant]: inputParams: ["+
				Utilities.displayArray(inputParams) + "]");
		log.info("*********** Round Robin Work allocation mechanism ***********");
		WorkAllocationXMLHandlerBean handler = WorkAllocationManager.getXmlHandler();
		log.debug("Its XML Handler is:" + handler.toString());
		
		log.debug("Displaying the current content of all user details maps");
		WorkAllocationManager.displayAllMaps();
		
		String[] userDetails = null;
		try {
			/* Get the name of the group from the input parameter */
			String groupName = null;
			try {
				for(int i=0; i<inputParams.length; i++) {
					String key = inputParams[i];
					String value = inputParams[++i];
					if(key.equalsIgnoreCase("GROUP_NAME")) {
						groupName = value;
					}
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				log.error("Input parameter inputParams array [" + Utilities.displayArray(inputParams)+
						"] does not contain sufficient parameters. It should be of the format " +
						"{MACRO_NAME, MACRO_VALUE, ...}" + e.getMessage(), e);
				throw e;
			} catch (Exception e) {
				log.error("Exception occurred parsing the input parameters. Unable to " +
						"get the group name" + e.getMessage(), e);
				throw e;
			}
			
			groupName = groupName.toLowerCase();
			log.debug("The Group name(in lower case) is [" + groupName + "]");
			if(groupName == null) {
				message = "Input parameter:[" + Utilities.displayArray(inputParams) + "] "  + 
						"doesnot contain the Macro GROUP_NAME. Hence unable to process the " +
						"request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			// If Groupwise user details map does not contain group name return error
			Map groupWiseUserDetailsMap = WorkAllocationManager.getGroupWiseUserDetailsMap();
			if(!(groupWiseUserDetailsMap.containsKey(groupName))) {
				message = "GroupWise user details map does not contain the groupName. " +
						"Hence unable to process the request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			// If no active users found for group then return to unassigned cases queue
			LinkedHashMap userDetailsMap = (LinkedHashMap)groupWiseUserDetailsMap.get(groupName);
			if(userDetailsMap == null || userDetailsMap.size() == 0) {
				message = "No active users found for the group " + groupName + ". Hence " +
						"returning " + Constants.WA_RETURN_PULL_VALUE + " as return value";
				log.info(message);
				return new String[] {Constants.WA_RETURN_PULL_VALUE};
			}
			
			Map groupWiseLastUserAssignedMap = WorkAllocationManager.getGroupWiseLastUserAssignedMap();
			if(!(groupWiseLastUserAssignedMap.containsKey(groupName))) {
				message = "GroupWise last user assigned map does not contain the groupName." +
						"Hence unable to process the request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			Object lastUserAssignedObj = groupWiseLastUserAssignedMap.get(groupName);
			if(lastUserAssignedObj == null || !(lastUserAssignedObj instanceof UserDetailBean)) {
				message = "For Group[" + groupName + "]: User Object in groupwise last assigned " +
						"user map is null or is not an instance of UserDetailBean class. " +
						"Hence unable to process the request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			UserDetailBean lastUserAssignedBean = (UserDetailBean)lastUserAssignedObj;
			log.info("For Group[" + groupName + "]: *********** Last Assigned User is:"+
					lastUserAssignedBean + "***********");
			
			// Contains details of next user to be assigned in round robin basis
			UserDetailBean nextUserToBeAssigned = null;
			LinkedHashMap nextUserToBeAssignedDetails = null;
			Iterator itr = null;
			
			// Get the order by user name
			String lastAssignedOrderByUser = lastUserAssignedBean.getOrderByUser();
			if(lastAssignedOrderByUser.equals("") || userDetailsMap.size() == 1) {
				/*
				 * First time we are selecting an user for this group; hence get 
				 * the first user OR
				 * It means only one user is active in this group then select that user
				 */
				message = (lastAssignedOrderByUser.equals("") 
						? 
						"First time we are selecting an user for this group" 
						: 
						"Only one user is active in this group");
				
				log.info("For Group[" + groupName + "]: " + message);
				log.debug("For Group[" + groupName + "]: Getting the first user details");
				
				itr = userDetailsMap.entrySet().iterator();
				if(itr.hasNext()) {
					Map.Entry entry = (Map.Entry) itr.next();
					UserDetailBean firstUser = (UserDetailBean)entry.getKey();
					nextUserToBeAssigned = firstUser;
					nextUserToBeAssignedDetails = (LinkedHashMap)entry.getValue();
				}
			} else {
				boolean isUserFound = false;
				
				// Search for the last assigned user in all users details map
				log.info("For Group[" + groupName + "]: Searching the last assigned user in " +
						"the user details map");
				itr = userDetailsMap.entrySet().iterator();
				while(itr.hasNext()) {
					Map.Entry entry = (Map.Entry) itr.next();
					UserDetailBean eachUser = (UserDetailBean)entry.getKey();
					
					// If this is the last assigned user
					if(eachUser.getOrderByUser().equalsIgnoreCase(lastAssignedOrderByUser)) {
						log.debug("For Group[" + groupName + "]: Last assigned user found in " +
								"the map. Selecting the next user");
						
						// Get next user
						if(itr.hasNext()) {
							Map.Entry en = (Map.Entry) itr.next();
							UserDetailBean nextUser = (UserDetailBean)en.getKey();
							nextUserToBeAssigned = nextUser;
							nextUserToBeAssignedDetails = (LinkedHashMap)en.getValue();
							log.info("For Group[" + groupName + "]: Got the next user.");
							isUserFound = true;
							break;
						} else {
							log.info("For Group[" + groupName + "]: Last assigned user is the last " +
									"member of this group; hence we have to get the first user as " +
									"next participant");
							break;
						}
					} else if(eachUser.getOrderByUser().compareTo(lastAssignedOrderByUser) > 0) {
						
						// It means last assigned user has become inactive now and we got the next 
						// user(greater than the last assigned) to be assigned
						nextUserToBeAssigned = eachUser;
						nextUserToBeAssignedDetails = (LinkedHashMap)entry.getValue();
						log.info("For Group[" + groupName + "]: Last assigned user has become inactive " +
								"now and we got the next user(greater than the last assigned) to be " +
								"assigned the work.");
						isUserFound = true;
						break;
					}
				}
				log.info("Searching Status of User:" + isUserFound);
				if(!isUserFound) {
					 
					/* It means last assigned user has become inactive now and no user with
					 * greater order by id is there. Then we have to get the first user
					 * OR
					 * Last assigned user is the last member of this group then we have to 
					 * get the first user as next participant 
					 */
					itr = userDetailsMap.entrySet().iterator();
					if(itr.hasNext()) {
						Map.Entry entry = (Map.Entry) itr.next();
						UserDetailBean firstUser = (UserDetailBean)entry.getKey();
						nextUserToBeAssigned = firstUser;
						nextUserToBeAssignedDetails = (LinkedHashMap)entry.getValue();
						log.info("For Group[" + groupName + "]: Last assigned user has become " +
								"inactive now and no user with greater order by user id exists; " +
								"or Last assigned user is the last member of this group." +
								"Hence we have to select the first user");
					}
				} else {
					log.info("For Group[" + groupName + "]: Next User to assign the work found");
				}
			}
			
			if(nextUserToBeAssigned != null) {
				log.info("For Group[" + groupName + "]: Work has to be assigned to User ["+
						nextUserToBeAssigned.getOrderByUser() + "] Details: ["+
						nextUserToBeAssigned + "] according to Round Robin basis");
								
				log.info("For Group[" + groupName + "]: Updating the last assigned user details " +
						"for the group with next user to be assigned's details");
				
				// Update the last assigned user details to this user details
				lastUserAssignedBean.setBpfUserId(nextUserToBeAssigned.getBpfUserId());
				lastUserAssignedBean.setOrderByUser(nextUserToBeAssigned.getOrderByUser());
				
				// Update the group wise last user assigned map with this bean
				log.info("For Group[" + groupName + "]: Updated the map with details :" + lastUserAssignedBean);
				groupWiseLastUserAssignedMap.put(groupName, lastUserAssignedBean);
			} else {
				message = "For Group[" + groupName + "]: Unable to find the next user.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			log.debug("For Group[" + groupName + "]: Copying the user details to String array.");
			userDetails = new String[nextUserToBeAssignedDetails.size() - 1];
			int index = 0;
			itr = nextUserToBeAssignedDetails.values().iterator();
			if(itr.hasNext()) {
				
				// Do not copy the first USER_ID's value element to String array
				itr.next();
			}
			
			// Copy all the remaining details
			while(itr.hasNext()) {
				Object value = itr.next();
				userDetails[index++] = (value == null ? "" : value.toString());
			}
			log.debug("KEYS:" + nextUserToBeAssignedDetails.keySet());
			log.debug("VALUES:" + nextUserToBeAssignedDetails.values());
			log.info("For Group[" + groupName + "]: **************Next User Details is [" +
					Utilities.displayArray(userDetails) + "]**************");
		} catch (Exception ex) {
			log.error("Exception occurred while searching for user in Round Robin " +
					"mechanism." + ex.getMessage(), ex);
			throw ex;
		}
		log.debug("[Exit getParticipant]");
		return userDetails;
	}
}
