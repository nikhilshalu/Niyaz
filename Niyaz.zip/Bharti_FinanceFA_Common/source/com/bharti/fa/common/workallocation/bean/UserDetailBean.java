/*
 * Created on May 13, 2009
 *
 */
package com.bharti.fa.common.workallocation.bean;

import java.util.Calendar;

/**
 * This class represents details of a group's last assigned user's bpf user id,
 * his/her id and last user details reloaded date 
 * @author Harisha
 * @viz.diagram UserDetailBean.tpx
 */
public class UserDetailBean {

	private int bpfUserId = -1;
	private String orderByUser = "";
	private Calendar lastReloadedOn = null;
	
	
	/**
	 * 
	 */
	public UserDetailBean() {
		super();
	}
	
	/**
	 * @param bpfUserId
	 * @param orderByUser
	 * @param lastReloadedOn
	 */
	public UserDetailBean(int bpfUserId, String orderByUser,
			Calendar lastReloadedOn) {
		super();
		this.bpfUserId = bpfUserId;
		this.orderByUser = orderByUser;
		this.lastReloadedOn = lastReloadedOn;
	}
	/**
	 * @return Returns the bpfUserId.
	 */
	public int getBpfUserId() {
		return bpfUserId;
	}
	/**
	 * @param bpfUserId The bpfUserId to set.
	 */
	public void setBpfUserId(int bpfUserId) {
		this.bpfUserId = bpfUserId;
	}
	/**
	 * @return Returns the lastReloadedOn.
	 */
	public Calendar getLastReloadedOn() {
		return lastReloadedOn;
	}
	/**
	 * @param lastReloadedOn The lastReloadedOn to set.
	 */
	public void setLastReloadedOn(Calendar lastReloadedOn) {
		this.lastReloadedOn = lastReloadedOn;
	}
	/**
	 * @return Returns the orderByUser.
	 */
	public String getOrderByUser() {
		return orderByUser;
	}
	/**
	 * @param orderByUser The orderByUser to set.
	 */
	public void setOrderByUser(String orderByUser) {
		this.orderByUser = orderByUser;
	}
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("bpfUserId:[" + getBpfUserId() + "] ")
				.append("orderByUser:[" + getOrderByUser() + "] ")
				.append("lastReloadedOn:[" + 
						(getLastReloadedOn() == null ? null : getLastReloadedOn().getTime()) + "]");
		return buf.toString();
	}
}
