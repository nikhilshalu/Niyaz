/*
 * Created on May 8, 2009
 *Java Class File used for
 *Retriving and Updating the work allocation methods(Round Robin/workload), work allocation type(PUSH/PULL) for 
 *each Group in the application
 */
package com.bharti.fa.common.workallocation.bpf.xml;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Result;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

/**
 * @author Ranjith Kumar
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @viz.diagram WorkAllocationXmlManipulator.tpx
 */
public class WorkAllocationXmlManipulator {
	
	public static final Logger log = Logger.getLogger(WorkAllocationXmlManipulator.class);
	/**getPushMechXMLFile(): method for getting the details of work allocation methods(Round Robin/workload), work allocation type(PUSH/PULL) for 
	 *each Group in the application
	 * @param pushMechPath: path of the XML file
	 * @return:an XML containing information about the users
	 */
	public String getPushMechXMLFile(String pushMechPath){
		Document pushMechDocument=null;
		String responseString=null;
		try{
			log.info("ENTRY:[getPushMechXMLFile() of WorkAllocationXmlManipulator Class]");
			DocumentBuilder parser=null;
			
			try{
				DocumentBuilderFactory factory 
				= DocumentBuilderFactory.newInstance();
				parser = factory.newDocumentBuilder();
			}
			catch (ParserConfigurationException e) {
				log.error("Wrong parser configuration: " + e,e);
				//result=false;
			}
			try{
				File pushMechxml=new File(pushMechPath);
				pushMechDocument= parser.parse(pushMechxml);
				
				try
				{
					DOMSource domSource = new DOMSource(pushMechDocument);
					StringWriter writer = new StringWriter();
					StreamResult result = new StreamResult(writer);
					TransformerFactory tf = TransformerFactory.newInstance();
					Transformer transformer = tf.newTransformer();
					transformer.transform(domSource, result);
					responseString=writer.toString();
					// System.out.println("check this!:"+responseString);
					//return responseString;
				}
				catch(TransformerException ex)
				{
					log.error("Error While parsing XML FIle, TransformerException:"+ex,ex);
					return null;
				}
				
				//log.debug("push Mech Document from [Path:"+pushMechPath+"] ="+pushMechDocument.toString());
			}catch(Exception ex){
				log.error("Error in While parsing XML FIle"+ex,ex);
			}
		}catch(Exception ex){
			log.error("Error While forming the Document Object From XML File: "+ex,ex);
			
		}
		log.info("EXIT:[getPushMechXMLFile() of WorkAllocationXmlManipulator Class]");
		return responseString;
	}
	/**updatePushMechXMLFile():method used to update the pushmechanism.xml file
	 * @param pushMechPath: path of the XML file
	 * @param ChangedFile: new XML file to be copied
	 * @return: true-if XML updatedd successfully else false
	 * 
	 */
	public synchronized boolean updatePushMechXMLFile(String pushMechPath, String ChangedFile, boolean isUserChanged){
		boolean result=true;
		log.info("ENTRY:[updatePushMechXMLFile() of WorkAllocationXmlManipulator Class]Inputs: [pushMechPath:"+pushMechPath+"] [ChangedFile:"+ChangedFile+"] [isUserChanged:"+isUserChanged+"] ");
		try{
			Document pushMechDocument=null;
			Document ChangedpushMechDocument=null;
			DocumentBuilder parser=null;
			
			try{
				DocumentBuilderFactory factory 
				= DocumentBuilderFactory.newInstance();
				parser = factory.newDocumentBuilder();
			}
			catch (ParserConfigurationException e) {
				log.error("Wrong parser configuration: " + e,e);
				result=false;
			}
			try{
				File pushMechxml=new File(pushMechPath);
				pushMechDocument= parser.parse(pushMechxml);
				
				NodeList orgGroupNodeLst = pushMechDocument.getElementsByTagName("group-name");
				if(!isUserChanged)
				{
					log.debug("update the Group-names Nodes in XML File isUserChanged="+isUserChanged);
					//log.debug("strBuffer="+strBuffer1.toString());
					ChangedpushMechDocument= parser.parse(new InputSource(new StringReader(ChangedFile)));
					HashMap hp=new HashMap();
					NodeList ChangedgroupNodeLst = ChangedpushMechDocument.getElementsByTagName("group-name");
					for(int j=0;j<ChangedgroupNodeLst.getLength();j++){
						Node changedGroupNode=ChangedgroupNodeLst.item(j);
						Element changedGroupNodeEle=(Element)changedGroupNode;
						HashMap propertyMap=new HashMap();
						//Element newGroupNodeEle=(Element)changedGroupNodeEle;
						NodeList changedPropertyNodeLst = changedGroupNodeEle.getElementsByTagName("property");
						for(int k=0;k<changedPropertyNodeLst.getLength();k++){
							
							Node changedPropertyNode=changedPropertyNodeLst.item(k);
							Element changedPropertyNodeEle=(Element)changedPropertyNode;
							
							propertyMap.put(changedPropertyNodeEle.getAttribute("name"),changedPropertyNodeEle.getAttribute("value"));
						}
						hp.put(changedGroupNodeEle.getAttribute("name"),propertyMap);
					}
					
					log.debug("Number of Groups to be Updated in the XML File="+hp.size());
					for(int j=0;j<orgGroupNodeLst.getLength();j++){
						Node orgGroupNode=orgGroupNodeLst.item(j);
						Element orgGroupNodeEle=(Element)orgGroupNode;
						
						NodeList orgPropertyNodeLst=orgGroupNodeEle.getElementsByTagName("property");
						String GroupName=orgGroupNodeEle.getAttribute("name");
						if(hp.containsKey(GroupName))
						{
							log.debug("Changed group name="+GroupName);
							HashMap propertyMap=(HashMap)hp.get(GroupName);
							for(int k=0;k<orgPropertyNodeLst.getLength();k++){
								
								Node orgPropertyNode=orgPropertyNodeLst.item(k);
								Element orgPropertyNodeEle=(Element)orgPropertyNode;
								
								String propertyName=orgPropertyNodeEle.getAttribute("name");
								
								if(propertyMap.containsKey(propertyName))
								{
									Element newpropertyEle = pushMechDocument.createElement("property");
									
									newpropertyEle.setAttribute("name",propertyName);
									newpropertyEle.setAttribute("value",(String)propertyMap.get(propertyName));
									orgGroupNodeEle.replaceChild(newpropertyEle,orgPropertyNodeEle);	
								}
							}
						}
					}
				}
				else
				{
					log.info("update the usersUpdatedDate property of "+ChangedFile+" node in XML File,FLAG isUserChanged="+isUserChanged);
					for(int j=0;j<orgGroupNodeLst.getLength();j++){
						Node orgGroupNode=orgGroupNodeLst.item(j);
						Element orgGroupNodeEle=(Element)orgGroupNode;
						String GroupName=orgGroupNodeEle.getAttribute("name");
						
						if(GroupName.equals(ChangedFile))
						{
							NodeList orgPropertyNodeLst=orgGroupNodeEle.getElementsByTagName("property");
							for(int i=0;i<orgPropertyNodeLst.getLength();i++)
							{
								Node orgPropertyNode=orgPropertyNodeLst.item(i);
								Element orgPropertyEle=(Element)orgPropertyNode;
								String propertyName=orgPropertyEle.getAttribute("name");
								log.debug("Property name="+propertyName);
								if(propertyName.equals("usersUpdatedDate"))
								{
									String DATE_FORMAT_NOW = "yyyy-MM-dd HH:mm:ss";
									Calendar cal = Calendar.getInstance();
									SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT_NOW);
									//log.debug(sdf.format(cal.getTime()));
									Element propertyNode = pushMechDocument.createElement("property");
									propertyNode.setAttribute("name","usersUpdatedDate");
									propertyNode.setAttribute("value",sdf.format(cal.getTime()));//Saves Date in the format:2009-05-12 12:13:53
									
									orgGroupNodeEle.replaceChild(propertyNode,orgPropertyEle);
									//groupNode.appendChild(propertyNode);
								}
							}
							
						}
						
					}
				}
			}
			catch (SAXException e) {
				log.error("Wrong XML file structure  : " + e,e);
				result=false;
			}
			catch(IOException e){
				log.error("IOException message= "+e,e);
				result=false;
			}
			try{
				//		        Create transformer
				Transformer tFormer = TransformerFactory.newInstance().newTransformer();
				//		        Output Types (text/xml/html)
				tFormer.setOutputProperty(OutputKeys.METHOD, "xml");
				//		        Write the document to a file
				Source source = new DOMSource(pushMechDocument);
				//		       Create File  to view your xml data as       vk.txt/vk.doc/vk.xls/vk.shtml/vk.html)
				Result resultXML = new StreamResult(new File(pushMechPath));
				tFormer.transform(source, resultXML);
				log.info("File creation successfully!");
			}catch(Exception ex){
				log.error("Error in [getPushMechXMLFile() of WorkAllocationXmlManipulator Class], while writing XML File to the [location:"+pushMechPath+"] error message:"+ex,ex);
				result=false;
			}
		}catch (Exception e){
			//System.err.println(e);
			// System.exit(0);
			log.error("Error in [getPushMechXMLFile() method] error message:"+e,e);
			result=false;
		}  
		log.debug("EXIT:[getPushMechXMLFile() of WorkAllocationXmlManipulator Class] result="+result);
		return result;
	}
	
	
	
}
