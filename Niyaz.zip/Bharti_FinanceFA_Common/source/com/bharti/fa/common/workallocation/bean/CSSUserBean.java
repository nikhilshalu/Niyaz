/*
 * Created on May 12, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.fa.common.workallocation.bean;

/**
 * @author Ranjith Kumar
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @viz.diagram CSSUserBean.tpx
 */
public class CSSUserBean {
	/* @author Ranjith Kumar
	 * TODO To change the template for this generated type comment go to
	 * Window - Preferences - Java - Code Style - Code Templates
	 * */
	    String EMPLOYEENAME;
	 	String SSFID;
		String EMPLOYEEUSERID;
		String MAILID;
		String DEFAULT_PROFILE_ID;
		String IsActive;
		String SECURITY_PROFILEID;
		String PROFILENAME;
	 

		/**
		 * @return Returns the dEFAULT_PROFILE_ID.
		 */
		public String getDEFAULT_PROFILE_ID() {
			return DEFAULT_PROFILE_ID;
		}
		/**
		 * @param default_profile_id The dEFAULT_PROFILE_ID to set.
		 */
		public void setDEFAULT_PROFILE_ID(String default_profile_id) {
			DEFAULT_PROFILE_ID = default_profile_id;
		}
	/**
	 * @return Returns the eMPLOYEENAME.
	 */
	public String getEMPLOYEENAME() {
		return EMPLOYEENAME;
	}
	/**
	 * @param employeename The eMPLOYEENAME to set.
	 */
	public void setEMPLOYEENAME(String employeename) {
		EMPLOYEENAME = employeename;
	}
		/**
		 * @return Returns the eMPLOYEEUSERID.
		 */
		public String getEMPLOYEEUSERID() {
			return EMPLOYEEUSERID;
		}
		/**
		 * @param employeeuserid The eMPLOYEEUSERID to set.
		 */
		public void setEMPLOYEEUSERID(String employeeuserid) {
			EMPLOYEEUSERID = employeeuserid;
		}
		/**
		 * @return Returns the isActive.
		 */
		public String getIsActive() {
			return IsActive;
		}
		/**
		 * @param isActive The isActive to set.
		 */
		public void setIsActive(String isActive) {
			IsActive = isActive;
		}
		/**
		 * @return Returns the mAILID.
		 */
		public String getMAILID() {
			return MAILID;
		}
		/**
		 * @param mailid The mAILID to set.
		 */
		public void setMAILID(String mailid) {
			MAILID = mailid;
		}
		/**
		 * @return Returns the pROFILENAME.
		 */
		public String getPROFILENAME() {
			return PROFILENAME;
		}
		/**
		 * @param profilename The pROFILENAME to set.
		 */
		public void setPROFILENAME(String profilename) {
			PROFILENAME = profilename;
		}
		/**
		 * @return Returns the sECURITY_PROFILEID.
		 */
		public String getSECURITY_PROFILEID() {
			return SECURITY_PROFILEID;
		}
		/**
		 * @param security_profileid The sECURITY_PROFILEID to set.
		 */
		public void setSECURITY_PROFILEID(String security_profileid) {
			SECURITY_PROFILEID = security_profileid;
		}
		/**
		 * @return Returns the sSFID.
		 */
		public String getSSFID() {
			return SSFID;
		}
		/**
		 * @param ssfid The sSFID to set.
		 */
		public void setSSFID(String ssfid) {
			SSFID = ssfid;
		}
}
