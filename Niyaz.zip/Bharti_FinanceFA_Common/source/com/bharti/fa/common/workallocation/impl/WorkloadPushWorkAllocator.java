/*
 * Created on May 9, 2009
 */
package com.bharti.fa.common.workallocation.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.Constants;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.fa.common.operations.util.manager.ExternalDBManager;
import com.bharti.fa.common.operations.util.manager.WorkAllocationManager;
import com.bharti.fa.common.workallocation.PushWorkAllocator;
import com.bharti.fa.common.workallocation.bean.UserDetailBean;
import com.bharti.fa.common.workallocation.bean.WorkAllocationXMLHandlerBean;

/**
 * This class is responsible for allocating the work in workload basis i.e.,
 * user with minimum number of pending cases will get the work.
 * @author Harisha
 * @viz.diagram WorkloadPushWorkAllocator.tpx
 */
public class WorkloadPushWorkAllocator implements PushWorkAllocator {

	public static Logger log = Logger.getLogger(WorkloadPushWorkAllocator.class);
	private static String message = null;
	
	/**
	 * Gets the next available participant for allocating the work based on 
	 * the input parameter <code>inputParams</code> in workload basis. 
	 * <p>
	 * For any request, it gets the work load of all users (all groups); then it
	 * will select only users of incoming group.
	 *  
	 * 1. If there is no active user for that group then it will return a string 
	 * array {"PULL"} and hence will be routed to unassigned cases queue.
	 * 
	 * 2. Otherwise, it will get the users with minimum workload. If only a single 
	 * has minimum workload then we will select that user; Otherwise If there are 
	 * more than one user with minimum workload, then it will select the user 
	 * with bpf user id immediately greater than the last user assigned's bpf 
	 * user id for that group. If there are no users with greater bpf user id
	 * then user with the minimum bpf user id will be selected. This is done to 
	 * randomly allocate the work to user when more the one users has minimum 
	 * workload.
	 * 
	 * 3. It returns the selected user details from the group wise user 
	 * details map of that group and update the selected user as last user assigned.
	 * 
	 * @param 	inputParams
	 * 			each input parameter will be sent in the form of 
	 * 			{"FIELDNAME", FIELDVALUE ...}
	 * 
	 * @return	the details of next available participant to allocate work in 
	 * 			the following order {USER_ID, USER_FULL_NAME, USER_NAME, USER_MAILID, 
	 * 			SUPERVISOR_NAME, SUPERVISOR_SSFID, SUPERVISOR_MAILID, MANAGER_NAME, 
	 * 			MANAGER_SSFID, MANAGER_MAILID, SRMANAGER_NAME, SRMANAGER_SSFID, 
	 * 			SRMANAGER_MAILID}
	 * 
	 * @throws 	IllegalArgumentException - throws for number of reasons:
	 * 				1. If the input parameter is null or empty
	 * 				2. If error occurred while parsing the xml file
	 * 			Exception - if unable to process the request due to any 
	 * 			exception occurred while processing 
	 * @see com.bharti.fa.common.workallocation.PushWorkAllocator#getParticipant(java.lang.String[])
	 */

	public String[] getParticipant(String[] inputParams) throws Exception {
		log.debug("[Enter getParticipant]: inputParams: [" + Utilities.displayArray(inputParams) + "]");
		log.info("*********** Workload Work allocation mechanism ***********");
		
		WorkAllocationXMLHandlerBean handler = WorkAllocationManager.getXmlHandler();
		log.debug("Its XML Handler is:" + handler.toString());
		
		WorkAllocationManager.displayAllMaps();
		String[] userDetails = null;
		try {
			/* Get the name of the group from the input parameter */
			String groupName = null;
			try {
				for(int i=0; i<inputParams.length; i++) {
					String key = inputParams[i];
					String value = inputParams[++i];
					if(key.equalsIgnoreCase("GROUP_NAME")) {
						groupName = value;
					}
				}
			} catch (ArrayIndexOutOfBoundsException e) {
				log.error("Input parameter inputParams array [" + Utilities.displayArray(inputParams)+
						"] does not contain sufficient parameters. It should be of the format " +
						"{MACRO_NAME, MACRO_VALUE, ...}" + e.getMessage(), e);
				throw e;
			} catch (Exception e) {
				log.error("Exception occurred parsing the input parameters. Unable to get " +
						"the group name" + e.getMessage(), e);
				throw e;
			}
			
			groupName = groupName.toLowerCase();
			log.debug("The Group name(in lower case) is [" + groupName + "]");
			if(groupName == null) {
				message = "Input parameter:[" + Utilities.displayArray(inputParams) + "] " +
						"doesnot contain the Macro GROUP_NAME. Hence unable to process the " +
						"request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			// If Groupwise user details map does not contain group name return error
			Map groupWiseUserDetailsMap = WorkAllocationManager.getGroupWiseUserDetailsMap();
			if(!(groupWiseUserDetailsMap.containsKey(groupName))) {
				message = "GroupWise user details map does not contain the groupName. " +
						"Hence unable to process the request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			// If no active users found for group then return to unassigned cases queue
			LinkedHashMap userDetailsMap = (LinkedHashMap)groupWiseUserDetailsMap.get(groupName);
			if(userDetailsMap == null || userDetailsMap.size() == 0) {
				message = "No active users found for the group " + groupName + ". Hence " +
						"returning " + Constants.WA_RETURN_PULL_VALUE + " as return value";
				log.info(message);
				return new String[] {Constants.WA_RETURN_PULL_VALUE};
			}
			
			log.info("For Group[" + groupName + "]: Total [" + userDetailsMap.size() + "] " +
					"users are active.");
			log.debug("For Group[" + groupName + "]: Getting the workload of users");
			HashMap usersWorkloadMap = getWorkload(inputParams);
			
			LinkedHashMap eachUsersWorkloadMap = new LinkedHashMap();
			Iterator itr = userDetailsMap.entrySet().iterator();
			while(itr.hasNext()) {
				Map.Entry entry = (Map.Entry) itr.next();
				HashMap hm = (HashMap)entry.getValue();
				String userName = hm.get("USER_NAME").toString();
				//log.debug("each user name:" + userName);
				if(usersWorkloadMap.containsKey(userName)) {
					eachUsersWorkloadMap.put(entry.getKey(), usersWorkloadMap.get(userName));
					//log.debug("found");
				} else {
					eachUsersWorkloadMap.put(entry.getKey(), new Integer(0));
				}
				log.info("For Group[" + groupName + "]: User [" + entry.getKey() + "]  ---------- " +
						"Pending Cases Count [" + eachUsersWorkloadMap.get(entry.getKey()) + 
						"] Details:[" + hm + "]");
			}
			
			log.info("--------------Displaying all users pending cases count----------------");
			itr = eachUsersWorkloadMap.entrySet().iterator();

			Integer minCount = (Integer)Collections.min(eachUsersWorkloadMap.values());
			int count = 0;			
			// get the Users with minimum workload			
			ArrayList eachUsersWithMinWorkloadList = new ArrayList();
			while(itr.hasNext()) {
				count++;
				Map.Entry entry = (Map.Entry) itr.next();
				log.debug("[" + count + "] User: " + ((UserDetailBean)entry.getKey()).getOrderByUser()+
						"---- Pending cases: " + entry.getValue() +  " Details: " + entry.getKey());
				
				//log.debug(minCount + "---" + (Integer)entry.getValue());
				if(minCount.equals((Integer)entry.getValue())) {
					//log.debug("found");
					eachUsersWithMinWorkloadList.add(entry.getKey());
				}
			}
			log.info("For Group[" + groupName + "]: Minimum workload count is:" + minCount);
			
			log.info("--------------Displaying users with minimum workload----------------");
			count = 0;
			itr = eachUsersWithMinWorkloadList.iterator();
			while(itr.hasNext()) {
				count++;
				UserDetailBean user = (UserDetailBean)itr.next();
				log.info("[" + count + "] User: " + user.getOrderByUser()+ 
						" Details: " + user);
			}
			//log.info(eachUsersWithMinWorkloadList);
			
			// Get the last assigned user for this group
			Map groupWiseLastUserAssignedMap = WorkAllocationManager.getGroupWiseLastUserAssignedMap();
			if(!(groupWiseLastUserAssignedMap.containsKey(groupName))) {
				message = "GroupWise last user assigned map does not contain the groupName. " +
						"Hence unable to process the request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			Object lastUserAssignedObj = groupWiseLastUserAssignedMap.get(groupName);
			if(lastUserAssignedObj == null || !(lastUserAssignedObj instanceof UserDetailBean)) {
				message= "For Group[" + groupName + "]: User Object in groupwise last assigned " +
						"user map is null or is not an instance of UserDetailBean class. " +
						"Hence unable to process the request.";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			UserDetailBean lastUserAssignedBean = (UserDetailBean)lastUserAssignedObj;
			log.info("For Group[" + groupName + "]: *********** Last assigned user for this group " +
					"is:" + lastUserAssignedBean + "***********");
			
			// Contains details of next user to be assigned in workload basis
			UserDetailBean nextUserToBeAssigned = null;
			LinkedHashMap nextUserToBeAssignedDetails = null;
			
			if(lastUserAssignedBean.getBpfUserId() == -1 || eachUsersWithMinWorkloadList.size() == 1) {
				// First time we are selecting an user for this group
				// Then get the first user
				// OR
				// It means only one user is active in this group then select that user
				message = (lastUserAssignedBean.getBpfUserId() == -1 
						? 
						"First time we are selecting an user for this group" 
						: 
						"Only one user is active in this group");
				
				log.info("For Group[" + groupName + "]: " + message);
				log.debug("For Group[" + groupName + "]: Getting the first user details");
				nextUserToBeAssigned = (UserDetailBean)eachUsersWithMinWorkloadList.get(0);
			} else {
				// Get the user from minimum workload list who is greater than last work 
				// assigned bpf user id
				log.debug("For Group[" + groupName + "]: Getting the user from minimum workload " +
						"list whose bpf id is greater than last work assigned bpf user id");
				
				UserDetailBean userGreaterThanLastAssignedUser = null;
				
				// Contains the user bean with minimum bpf user id
				UserDetailBean userWithMinimumBpfUserId = null;
				
				itr = eachUsersWithMinWorkloadList.iterator();
				while(itr.hasNext()) {
					UserDetailBean eachUser = (UserDetailBean)itr.next();
					//log.debug("each user:" + eachUser);
					//log.debug("min user:" + userWithMinimumBpfUserId);
					if(userWithMinimumBpfUserId == null) {
						userWithMinimumBpfUserId = eachUser;						
					} else if(eachUser.getBpfUserId() < userWithMinimumBpfUserId.getBpfUserId()) {
						//log.debug("user with minimum bpf user id:" + eachUser);
						userWithMinimumBpfUserId = eachUser; 
					}
					
					if(eachUser.getBpfUserId() > lastUserAssignedBean.getBpfUserId()) {
						
						if(userGreaterThanLastAssignedUser == null) {
							userGreaterThanLastAssignedUser = eachUser;
							nextUserToBeAssigned = userGreaterThanLastAssignedUser;
							
						} else if(eachUser.getBpfUserId() < userGreaterThanLastAssignedUser.getBpfUserId()) {
							log.debug("Minimum than last selected user found:" + eachUser);
							userGreaterThanLastAssignedUser = eachUser;
							nextUserToBeAssigned = userGreaterThanLastAssignedUser; 
						}
					}
				}
				if(nextUserToBeAssigned == null) {
					
					// This means that no user with minimum workload has bpf user id field 
					// greater than the last assigned user' bpf user id
					// then get the details of user with minimum bpf id
					log.debug("For Group[" + groupName + "]: No user with minimum workload has " +
							"bpf user id field greater than the last assigned user' bpf user id;" +
							"hence getting the details of user with minimum bpf id");
					
					log.info("User with minimum bpf user id is [" + userWithMinimumBpfUserId + "]");
					if(userWithMinimumBpfUserId != null) {
						nextUserToBeAssigned = userWithMinimumBpfUserId;
					}
				} else {
					log.info("For Group[" + groupName + "]: Next User to assign the work found");
				}
			}
			
			if(nextUserToBeAssigned != null) {
				log.info("For Group[" + groupName + "]: Work has to be assigned to User "+
						nextUserToBeAssigned + " according to workload basis");
				//log.info("**************Next User Details is [" + nextUserToBeAssignedDetails + "]");
				
				log.info("For Group[" + groupName + "]: Updating the last assigned user details " +
						"for the group with next user to be assigned's details");
				
				// Update the last assigned user details to this user details
				lastUserAssignedBean.setBpfUserId(nextUserToBeAssigned.getBpfUserId());
				lastUserAssignedBean.setOrderByUser(nextUserToBeAssigned.getOrderByUser());
				
				// Update the group wise last user assigned map with this bean
				log.info("For Group[" + groupName + "]: Updated the map with details :" + lastUserAssignedBean);
				groupWiseLastUserAssignedMap.put(groupName, lastUserAssignedBean);
			} else {
				message = "For Group[" + groupName + "]: Unable to find the next user";
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			// Get the user details of next user to be assigned
			nextUserToBeAssignedDetails = 
				WorkAllocationManager.getDetailsOfUser(userDetailsMap, nextUserToBeAssigned);
			if(nextUserToBeAssignedDetails == null) {
				message = "Unable to get the details of user:" + nextUserToBeAssigned;
				log.error(message);
				throw new IllegalArgumentException(message);
			}
			
			log.debug("For Group[" + groupName + "]: Copying the user details to String array.");
			userDetails = new String[nextUserToBeAssignedDetails.size() - 1];
			int index = 0;
			itr = nextUserToBeAssignedDetails.values().iterator();
			if(itr.hasNext()) {
				// Do not copy the first USER_ID's value element to String array
				itr.next();
			}
			
			// Copy all the remaining details
			while(itr.hasNext()) {
				Object value = itr.next();
				userDetails[index++] = (value == null ? "" : value.toString());
			}
			log.info("KEYS:" + nextUserToBeAssignedDetails.keySet());
			log.info("VALUES:" + nextUserToBeAssignedDetails.values());
			log.info("For Group[" + groupName + "]: **************Next User Details is ["+
					Utilities.displayArray(userDetails) + "]**************");
		} catch (Exception ex) {
			log.error("Exception occurred while searching for user in Workload " +
					"mechanism." + ex.getMessage(), ex);
			throw ex;
		}
		
		log.debug("[Exit getParticipant]");
		return userDetails;
	}
	
	/**
	 * Gets the workload of all users (all groups)
	 * @param 	inputParams
	 * 			each input parameter will be sent in the form of 
	 * 			{"FIELDNAME", FIELDVALUE ...}
	 * @return  each users workload count with key has the user ssfid and value 
	 * 			has workload count 
	 * @throws 	Exception - if any error occurred while getting user workload 
	 * 			from database
	 */
	private HashMap getWorkload(String[] inputParams) throws Exception {
		log.debug("[Enter getWorkload]");
		ExternalDBManager dbManager = null;
		HashMap eachUserWorkloadMap = null;
		try {
			/* Get database connection */
			dbManager = new ExternalDBManager(Constants.APPLICATION_STANDALONE);
			String db2URL = Base64.decrypt(
					PropertyLoader.props.getProperty("WORKLOAD_DATABASE_URL"));
			String db2User = Base64.decrypt(
					PropertyLoader.props.getProperty("DATABASE_USER_ID"));
			String db2pwd = Base64.decrypt(
					PropertyLoader.props.getProperty("DATABASE_USER_PASSWORD"));
			dbManager.getDbConnection(db2URL, db2User, db2pwd);
			
			eachUserWorkloadMap = dbManager.getWorkload(inputParams);
			
			/* Close DB2 database connection */
			dbManager.closeDbConnection();
		} catch (Exception e) {
			log.error("Exception occurred while getting the workload " + e.getMessage(), e);
			throw e;
		} finally {
			if(dbManager != null) {
				
				/* Close DB2 database connection */
				dbManager.closeDbConnection();
			}			
		}	
		log.debug("[Exit getWorkload]");
		return eachUserWorkloadMap;
	}

}
