/*
 * Created on May 14, 2009
 *
 */
package com.bharti.fa.common.workallocation.bean;

import org.apache.log4j.Logger;

/**
 * This class represents the configuration details of each group.
 * All the details from work allocation xml file will be stored in 
 * the objects of this class.
 * @author Harisha
 * @viz.diagram WorkAllocationXMLHandlerBean.tpx
 *
 */
public class WorkAllocationXMLHandlerBean {
	
	public static Logger log = Logger.getLogger(WorkAllocationXMLHandlerBean.class);
	
	int id = 0;
	String name = "";
	String className = "";	
	String workAllocationType = "";
	String workAllocationMechanism = "";
	String usersUpdatedDate = null;
	String tagNames = "";

	public static void main(String[] args) {
		WorkAllocationXMLHandlerBean wrk = new WorkAllocationXMLHandlerBean();
		wrk.setName("CSS PO Group");
		System.out.println(wrk.equals("CSS PO Group"));
	}
	
	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	public boolean equals(Object groupName) {
		if (groupName instanceof String || groupName instanceof WorkAllocationXMLHandlerBean) {					
			return this.getName().equalsIgnoreCase(groupName.toString());			
		} else {
			return false;
		}
	}
		
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("id:[" + getId() + "] ")
				.append("name:[" + getName() + "] ")
				.append("className:[" + getClassName() + "] ")
				.append("workAllocationType:[" + getWorkAllocationType() + "] ")
				.append("workAllocationMechanism:[" + getWorkAllocationMechanism() + "] ")
				.append("usersUpdatedDate:[" + getUsersUpdatedDate() + "] ")
				.append("tagNames:[" + getTagNames() + "] ");
		return buf.toString();
	}
	/**
	 * @return Returns the className.
	 */
	public String getClassName() {
		return className;
	}
	/**
	 * @param className The className to set.
	 */
	public void setClassName(String className) {
		this.className = className;
	}
	/**
	 * @return Returns the id.
	 */
	public int getId() {
		return id;
	}
	/**
	 * @param id The id to set.
	 */
	public void setId(int id) {
		this.id = id;
	}
	/**
	 * @return Returns the name.
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name The name to set.
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return Returns the tagNames.
	 */
	public String getTagNames() {
		return tagNames;
	}
	/**
	 * @param tagNames The tagNames to set.
	 */
	public void setTagNames(String tagNames) {
		this.tagNames = tagNames;
	}
	/**
	 * @return Returns the usersUpdatedDate.
	 */
	public String getUsersUpdatedDate() {
		return usersUpdatedDate;
	}
	/**
	 * @param usersUpdatedDate The usersUpdatedDate to set.
	 */
	public void setUsersUpdatedDate(String usersUpdatedDate) {
		this.usersUpdatedDate = usersUpdatedDate;
	}
	/**
	 * @return Returns the workAllocationMechanism.
	 */
	public String getWorkAllocationMechanism() {
		return workAllocationMechanism;
	}
	/**
	 * @param workAllocationMechanism The workAllocationMechanism to set.
	 */
	public void setWorkAllocationMechanism(String workAllocationMechanism) {
		this.workAllocationMechanism = workAllocationMechanism;
	}
	/**
	 * @return Returns the workAllocationType.
	 */
	public String getWorkAllocationType() {
		return workAllocationType;
	}
	/**
	 * @param workAllocationType The workAllocationType to set.
	 */
	public void setWorkAllocationType(String workAllocationType) {
		this.workAllocationType = workAllocationType;
	}
}
