/*
 * Created on May 5, 2009
 *JAVA file used for
 *Updating and retreving the users information from USERS table of BPF database
 */
package com.bharti.fa.common.workallocation.bpf;

import java.io.IOException;
import java.io.StringReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;


import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import com.bharti.fa.common.workallocation.bean.CSSUserBean;

/**
 * @author Ranjith Kumar
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @viz.diagram UserDetails.tpx
 */

public class UserDetails {
	public static final Logger log = Logger.getLogger(UserDetails.class);
	private Context ctx = null;
	private DataSource ds = null;
	private Connection conn = null;
	
	public UserDetails(String DataSourceName){
		
		try {
			
			log.info("[ENTRY :UserDetails Constructor: ]DataSource Name: "+DataSourceName);
			
			ctx = new InitialContext();
			ds = (DataSource) ctx.lookup(DataSourceName);
			conn = ds.getConnection();
			conn.setAutoCommit(false);
			log.debug("[EXIT :PopulateUserDetails Constructor: ]");
			
		} 
		catch (NamingException ex) {
			
			log.error("[ERROR: UserDetails Constructor:] Problem to create connection with DataSource +"+DataSourceName+": NamingException : "+ex,ex);
			
		}
		catch (SQLException ex) {
			
			log.error("[ERROR: UserDetails Constructor:] Problem to create connection with DataSource +"+DataSourceName+": SQLException : "+ex,ex);
		}
		catch (Exception ex) {
			
			log.error("[ERROR: UserDetails Constructor:] Problem to create connection with DataSource +"+DataSourceName+" due to "+ex,ex);
		}
		
	}
	
	/**getUserInformation():method for getting the users information from the users table of BPF database
	 * @param groupName: group names like 'CSS PO Group'
	 * @param SupervisorID: ID of a particular user
	 * @param type: specifies to retrieve all the users under the group or only users under the supervisor
	 * @return: XML File containing info of users
	 */
	public String getUserInformation(String groupName,String SupervisorID, String type)
	{
		log.info("[ENTRY :getUserInformation method of UserDetails CLASS: ]groupName: "+groupName+" SupervisorID="+SupervisorID);
		String responseXML="<response><users>";
		String getUserInfoSQL=null;
		HashMap hp=new HashMap();
		ArrayList UserIDsArray=new ArrayList();
		
		getUserInfoSQL="select u.FULL_NAME as EMPLOYEENAME,u.NAME as SSFID, u.USER_ID as EMPLOYEEUSERID, u.USER_ATTR_2 as MAILID,u.DEFAULT_SECURITY_PROFILE_ID as DEFAULT_PROFILE_ID,";
		getUserInfoSQL=getUserInfoSQL+"u.USER_ATTR_3 as IsActive,up1.security_profile_id as SECURITY_PROFILEID,(select up2.profile from security_profile up2 where up2.security_profile_id=up1.security_profile_id) as PROFILENAME ";
		getUserInfoSQL=getUserInfoSQL+"from users u inner join User_profile up on (u.user_id=up.user_id and u.active!=0) right outer join user_profile up1 on u.user_id=up1.user_id  where ";
		getUserInfoSQL=getUserInfoSQL+"up.security_profile_id=(select up2.security_profile_id from security_profile up2 where up2.profile='"+groupName+"')";
		
		if(type.equals("users")) //code to form a query to get users under a supervisor and u.REPORTSTO_USER_ID=243
		{
			getUserInfoSQL=getUserInfoSQL+" and u.REPORTSTO_USER_ID="+SupervisorID;
		}
		
		
		if(conn!=null){
			
			try{
				log.debug("Query to get user information:"+getUserInfoSQL);
				PreparedStatement agentPR = conn.prepareStatement(getUserInfoSQL);
				ResultSet rsAgentDetails = agentPR.executeQuery();
				while(rsAgentDetails.next()){//after querying the database form an XML file from the result set
					String isActive="0";
					//log.debug("User Name:"+rsAgentDetails.getString("EMPLOYEENAME")+" Active:"+rsAgentDetails.getString("IsActive"));
					if(rsAgentDetails.getString("IsActive")==null)
					{
						isActive="1";				
					}
					else
					{
						//log.debug(" Active Length="+rsAgentDetails.getString("IsActive").length());
						if(rsAgentDetails.getString("IsActive").length()==0)
							isActive="1";
						else
							isActive=rsAgentDetails.getString("IsActive");
					}
					String EmployeeUserID=rsAgentDetails.getString("EMPLOYEEUSERID");
					if(hp.containsKey(EmployeeUserID))
					{
						CSSUserBean cssuser=(CSSUserBean)hp.get(EmployeeUserID);
						String profileNames=cssuser.getPROFILENAME();
						profileNames=profileNames+","+rsAgentDetails.getString("PROFILENAME");
						cssuser.setPROFILENAME(profileNames);
						hp.put(EmployeeUserID,cssuser);
						
					}
					else
					{
						UserIDsArray.add(EmployeeUserID);
						CSSUserBean cssuser=new CSSUserBean();
						cssuser.setEMPLOYEENAME(rsAgentDetails.getString("EMPLOYEENAME"));
						cssuser.setSSFID(rsAgentDetails.getString("SSFID"));
						cssuser.setEMPLOYEEUSERID(rsAgentDetails.getString("EMPLOYEEUSERID"));
						cssuser.setMAILID(rsAgentDetails.getString("MAILID"));
						cssuser.setDEFAULT_PROFILE_ID(rsAgentDetails.getString("DEFAULT_PROFILE_ID"));
						cssuser.setIsActive(isActive);
						cssuser.setSECURITY_PROFILEID(rsAgentDetails.getString("SECURITY_PROFILEID"));
						cssuser.setPROFILENAME(rsAgentDetails.getString("PROFILENAME"));
						hp.put(EmployeeUserID,cssuser);	
						
					}
					
				}
				//--------------------
				//String userInfo;
				for(int l=0;l<UserIDsArray.size();l++)
				{
					CSSUserBean cssuser=(CSSUserBean)hp.get(UserIDsArray.get(l));
					String userInfo="<user count='"+l+"'><fullName>"+cssuser.getEMPLOYEENAME()+"</fullName>";
					userInfo=userInfo+"<SSFID>"+cssuser.getSSFID()+"</SSFID>";
					userInfo=userInfo+"<UserID>"+cssuser.getEMPLOYEEUSERID()+"</UserID>";
					userInfo=userInfo+"<MailID>"+cssuser.getMAILID()+"</MailID>";
					userInfo=userInfo+"<ProfileNames>"+cssuser.getPROFILENAME()+"</ProfileNames>";
					//userInfo=userInfo+"<DefaultProfileID>"+cssuser.getDEFAULT_PROFILE_ID()+"</DefaultProfileID>";
					userInfo=userInfo+"<IsActive>"+cssuser.getIsActive()+"</IsActive>";
					userInfo=userInfo+"</user>";
					responseXML=responseXML+userInfo;
					
				}
				responseXML=responseXML+"</users></response>";
			}
			catch (SQLException ex) {
				log.error("[ERROR: getUserInformation() of UserDetails :SQLException : ]"+ex,ex);
				
			}
			catch (Exception ex) {
				log.error("[ERROR: getUserInformation()of UserDetails ]:Exception "+ex,ex);
				
			}
			
			
		}
		return responseXML;
	}
	
	/**SaveUsersInformation(): method for updating users information in the USERS table of BPF database
	 * @param updatedUsersXML: an XML file containing information of users to be updated
	 * <users>
	 <user><name>Mr. Ravindra Bhatnagar</name><active>false</active><UserID>252</UserID></user>
	 <user><name>Manager</name><active>false</active><UserID>253</UserID></user
	 </users>
	 * @return: returns true if users information updated sucessfully, else false
	 */
	public boolean SaveUsersInformation(String updatedUsersXML, String pushMechPath)
	{
		
		boolean result=true;
		boolean hasActiveUsers=false;
		boolean hasInActiveUsers=false;
		String updateQuery=null;
		log.info("ENTRY:[updatePushMechXMLFile() of WorkAllocationXmlManipulator Class]Inputs:[updatedUsersXML:"+updatedUsersXML+"]");
		
		Document updatedUsersDoc=null;
		DocumentBuilder parser=null;
		
		try{
			DocumentBuilderFactory factory 
			= DocumentBuilderFactory.newInstance();
			parser = factory.newDocumentBuilder();
		}
		catch (ParserConfigurationException e) {
			log.error("Wrong parser configuration: " +e,e);
			result=false;
		}
		try{
			updatedUsersDoc= parser.parse(new InputSource(new StringReader(updatedUsersXML)));// form a document element from the input string
			String ActiveuserIDs="(";
			String InActiveuserIDs="(";
			/*
			 <users>
			 <user><name>Mr. Ravindra Bhatnagar</name><active>false</active><UserID>252</UserID></user>
			 <user><name>Manager</name><active>false</active><UserID>253</UserID></user
			 </users>
			 
			 */
			NodeList userNodeLst = updatedUsersDoc.getElementsByTagName("user");
			for(int j=0;j<userNodeLst.getLength();j++){
				Node userNode=userNodeLst.item(j);
				Element userNodeEle=(Element)userNode;
				NodeList userIDNodeLst=userNodeEle.getElementsByTagName("UserID");
				Element userID=(Element)userIDNodeLst.item(0);
				String UserID=null;
				
				if(userID.hasChildNodes())
				{
					Node firstChild=userID.getFirstChild();
					UserID=firstChild.getNodeValue();
				}
				
				NodeList activeNodeLst=userNodeEle.getElementsByTagName("active");
				Element active=(Element)activeNodeLst.item(0);
				String activeValue=null;
				
				if(active.hasChildNodes()){
					Node firstActiveChild=active.getFirstChild();
					activeValue=firstActiveChild.getNodeValue();
				}
				
				if(activeValue.equals("false"))
				{
					hasInActiveUsers=true;
					if(j==(userNodeLst.getLength()-1))
						InActiveuserIDs=InActiveuserIDs+UserID+")";
					else
						InActiveuserIDs=InActiveuserIDs+UserID+",";
				}
				else{
					hasActiveUsers=true;
					if(j==(userNodeLst.getLength()-1))
						ActiveuserIDs=ActiveuserIDs+UserID+")";
					else
						ActiveuserIDs=ActiveuserIDs+UserID+",";
					
				}
				
			}
			
			if(hasActiveUsers)// check if the input xml has any user to be made active
			{
				try{
					updateQuery="UPDATE USERS SET USER_ATTR_3='1' WHERE USER_ID IN "+ActiveuserIDs;
					log.debug("[SaveUsersInformation()] ActiveUserIDS="+ActiveuserIDs);
					PreparedStatement usersPR = conn.prepareStatement(updateQuery);
					int usersRowsUpdated = usersPR.executeUpdate();
					if(usersRowsUpdated==0)
						result=false;
					else
						result=true;
					
					conn.commit();
					conn.setAutoCommit(true);
					
				}
				catch(SQLException sqlex){
					conn.rollback();
					log.error("sql exception while Active/InActive users exception="+sqlex,sqlex);
				}
				catch(Exception sqlex){
					conn.rollback();
					log.error("Exception while Active/InActive users exception="+sqlex,sqlex);
				}
			}
			if(hasInActiveUsers)// check if the input xml has any user to be made Inactive
			{
				try{
					log.debug("[SaveUsersInformation()] InActiveuserIDs="+InActiveuserIDs);
					updateQuery="UPDATE USERS SET USER_ATTR_3='0' WHERE USER_ID IN "+InActiveuserIDs;
					PreparedStatement usersPR = conn.prepareStatement(updateQuery);
					int usersRowsUpdated = usersPR.executeUpdate();
					if(usersRowsUpdated==0)
						result=false;
					
					conn.commit();
					conn.setAutoCommit(true);
				}
				catch(SQLException sqlex){
					conn.rollback();
					log.error("sql exception while Active/InActive users exception="+sqlex,sqlex);
				}
				catch(Exception sqlex){
					conn.rollback();
					log.error("Exception while Active/InActive users exception="+sqlex,sqlex);
				}
			}
		}
		catch (SAXException e) {
			log.error("Wrong XML file structure  : " + e,e);
			result=false;
		}
		catch(IOException e){
			log.error("IOException message= "+e,e);
			result=false;
		}
		catch(Exception ex){
			
			log.error("Error in [getPushMechXMLFile() of WorkAllocationXmlManipulator Class], while writing XML File to the [location:] error message:"+ex,ex);
			result=false;
		}
		
		log.debug("EXIT:[getPushMechXMLFile() of WorkAllocationXmlManipulator Class] result="+result);
		return result;
		
	}
	
	
}
