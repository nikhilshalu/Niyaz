/*
 * Created on May 9, 2009
 *
 */
package com.bharti.fa.common.workallocation;

/**
 * A push work allocation implementor who wishes to provide explicit 
 * information about their push work allocation may provide a PushWorkAllocator 
 * class that implements this PushWorkAllocator interface and provides explicit 
 * information about the methods, properties, etc, of their push work allocation.
 * @author Harisha Achar
 * @viz.diagram PushWorkAllocator.tpx
 *
 */
public interface PushWorkAllocator {
	/**
	 * Process the work allocation request. This method of implemented class will 
	 * be called by the Work allocation manager when any group is configured for 
	 * this mechanism.
	 * 
	 * @throws Exception - if any error occurred while getting the participant
	 */
	public java.lang.String[] getParticipant(java.lang.String[] inputParams) throws Exception;
}
