/*
 * Created on Jul 7, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util.mapper;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.finance.fa.ci.operations.FinanceFA_CIOperations;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Utilities;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_XMLUtilities;
import com.bharti.finance.fa.ci.operations.util.dto.MilestoneDTO;
import com.bharti.finance.fa.ci.operations.util.dto.NotificationDTO;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioDTO;

/**
 * @author Harisha
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 * @viz.diagram MilestoneMapper.tpx
 */
public class MilestoneMapper {
	public static Logger log = Logger.getLogger(MilestoneMapper.class);

	public static final String MILESTONENAMEARRAY_NAME = "FnFA_MilestoneNameArray";

	public static final String MILESTONEIDARRAY_NAME = "FnFA_MilestoneIDArray";

	public static final String SCENARIOMILESTONEIDARRAY_NAME = "FnFA_ScenarioMilestoneIDArray";

	public static final String MILESTONEORDERARRAY_NAME = "FnFA_MilestoneOrderArray";

	public static final String MILESTONEOWNERSROLEARRAY_NAME = "FnFA_MilestoneOwnersRoleArray";
	
	public static final String MILESTONEOWNERSSFIDARRAY_NAME = "FnFA_MilestoneOwnerSSFIDArray";

	public static final String MILESTONETYPEARRAY_NAME = "FnFA_MilestoneTypeArray";

	public static final String MILESTONESLADATEARRAY_NAME = "FnFA_MilestoneSLADateArray";

	public static final String SCENARIOMILESTONEDESCARRAY_NAME = "FnFA_ScenarioMilestoneDescArray";

	private Integer slaTypeId;

	private Integer slaCalculationId;

	private String startTime;

	private String endTime;

	/**
	 * @param slaTypeId
	 * @param slaCalculationId
	 * @param startTime
	 * @param endTime
	 */
	public MilestoneMapper(Integer slaTypeId, Integer slaCalculationId,
			String startTime, String endTime) {
		super();
		this.slaTypeId = slaTypeId;
		this.slaCalculationId = slaCalculationId;
		this.startTime = startTime;
		this.endTime = endTime;
		
		FinanceFA_XMLUtilities.milestoneNotificationDetailsDoc = null;
		FinanceFA_XMLUtilities.milestoneNotificationDetailsRootElement = null;
	}

	/**
	 * @param scenarioDTO
	 * @param htEmailIsEnabled
	 */
	public void setWorkflowFields(ScenarioDTO scenarioDTO,
			HashMap htTimers, HashMap htTO,
			HashMap htCC, HashMap htBCC,
			HashMap htEmailIsEnabled) {
		log.debug("[Enter setWorkflowFields]");

		// Get the milestone array list
		ArrayList milestoneList = scenarioDTO.getMilestoneList();

		int numberOfMilestones = milestoneList.size();
		log.debug(numberOfMilestones + " milestone(s) are present.");

		// Create the temporary arrays
		String[] milestoneNameArray = new String[numberOfMilestones];
		Integer[] milestoneIDArray = new Integer[numberOfMilestones];
		Integer[] scenarioMilestoneIDArray = new Integer[numberOfMilestones];
		Integer[] milestoneOrderArray = new Integer[numberOfMilestones];
		String[] milestoneOwnersRoleArray = new String[numberOfMilestones];
		String[] milestoneOwnerSSFIDArray = new String[numberOfMilestones];
		
		String[] milestoneTypeArray = new String[numberOfMilestones];
		String[] milestoneSLADateArray = new String[numberOfMilestones];
		Boolean[] milestoneConditionalArray = new Boolean[numberOfMilestones];
		String[] milestoneConditionalValues = new String[numberOfMilestones];
		String[] scenarioMilestoneDescArray = new String[numberOfMilestones];
		Boolean[] milestoneAlertIsEnabledArray = new Boolean[numberOfMilestones];

		MilestoneDTO nextMilestoneDTO = null;
		NotificationMapper notificationMapper = new NotificationMapper(
				slaCalculationId, startTime, endTime);
		
		log.debug("Finding the default route milestone details");
		int defaultRouteId = 0;
		for (int i = 0; i < numberOfMilestones; i++) {

			/* Get first milestone */
			MilestoneDTO milestoneDTO = (MilestoneDTO) milestoneList.get(i);
			if (i != 0
					&& (milestoneDTO.getScenario_milestone_id().intValue() != defaultRouteId || Character
							.toLowerCase(milestoneDTO.getMilestone_isactive()
									.charValue()) == 'n')) {
				continue;
			}

			nextMilestoneDTO = milestoneDTO;

			/*
			 * Set the milestone details to temporary arrays; if the value is
			 * null then store default value
			 */
			milestoneNameArray[i] = nextMilestoneDTO.getMilestone_name();
			milestoneIDArray[i] = nextMilestoneDTO.getMilestone_id();
			scenarioMilestoneIDArray[i] = nextMilestoneDTO
					.getScenario_milestone_id();
			milestoneOrderArray[i] = (nextMilestoneDTO.getMilestone_order() == null ? new Integer(
					-1)
					: nextMilestoneDTO.getMilestone_order());
			milestoneOwnersRoleArray[i] = (nextMilestoneDTO.getMilestone_role() == null ? ""
					: nextMilestoneDTO.getMilestone_role());
			milestoneTypeArray[i] = (nextMilestoneDTO.getMilestone_type() == null ? ""
					: nextMilestoneDTO.getMilestone_type());
			milestoneOwnerSSFIDArray[i] = "";

			// if(scenarioDTO.getScenario_type_id()) {
			
			/*
			 * Calculate the sla date and if it is modified then retain the 
			 * time 
			 */
			FinanceFA_CIOperations financeOp = new FinanceFA_CIOperations();
			log.debug("Checking the Milestone sla date "
					+ nextMilestoneDTO.getMilestone_sla());
			Date[] tempDate = financeOp.calculateSLA(nextMilestoneDTO
					.getMilestone_sla(), null, this.slaTypeId.intValue(),
					this.slaCalculationId.intValue(), this.startTime, this.endTime);
			if (tempDate != null) {
				
				SimpleDateFormat simDate = new SimpleDateFormat(FinanceFA_Constants.DATE_PATTERN);
				try {
					Date milestoneSlaDate_DB = simDate.parse(nextMilestoneDTO
							.getMilestone_sla());
					
					if(milestoneSlaDate_DB.equals(tempDate[0])) {
						log.debug("Milestone sla not changed");
						
					} else {
						log.debug("Milestone sla has been changed. Milestone sla in database is:"
								+ milestoneSlaDate_DB
								+ " and after altering:" + tempDate[0]);
						log.debug("Reverting the time field of new milestone sla to that of milestone sla in database.");
						Calendar newCal = Calendar.getInstance();
						newCal.setTime(tempDate[0]);

						Calendar dbCal = Calendar.getInstance();
						dbCal.setTime(milestoneSlaDate_DB);

						newCal.set(newCal.get(Calendar.YEAR), newCal
								.get(Calendar.MONTH),
								newCal.get(Calendar.DATE), dbCal
										.get(Calendar.HOUR_OF_DAY), dbCal
										.get(Calendar.MINUTE), dbCal
										.get(Calendar.SECOND));

						tempDate[0] = newCal.getTime();
						log.debug("After changing the time field, new milestone sla is:"
								+ tempDate[0]);
					}
				} catch (ParseException e) {
					log.error(
							"Error occured while parsing the milestone sla. It should be in "
									+ FinanceFA_Constants.DATE_PATTERN
									+ "format.", e);
				}
				
				// Used to update the current scenario sla
				nextMilestoneDTO.setMilestone_sla_date(new Timestamp(tempDate[0]
						.getTime()));
				milestoneSLADateArray[i] = simDate.format(tempDate[0]);
				
				ArrayList notifications = nextMilestoneDTO
						.getNotificationList();
				notificationMapper.setWorkflowFields(notifications,
						tempDate[0], htTimers, htTO, htCC, htBCC,
						htEmailIsEnabled);
			}
			// }
			milestoneConditionalArray[i] = (("Y")
					.equalsIgnoreCase(nextMilestoneDTO
							.getIsmilestonerole_conditional()) ? new Boolean(
					true) : new Boolean(false));

			milestoneConditionalValues[i] = (nextMilestoneDTO
					.getConditional_value() == null ? "" : nextMilestoneDTO
					.getConditional_value());
			
			scenarioMilestoneDescArray[i] = (nextMilestoneDTO
					.getScenario_milestone_description() == null ? ""
					: nextMilestoneDTO.getScenario_milestone_description());
				
			milestoneAlertIsEnabledArray[i] = (("Y")
					.equalsIgnoreCase(nextMilestoneDTO.getIs_alert_enabled()) ? new Boolean(
					true)
					: new Boolean(false));

			if (nextMilestoneDTO.getDefault_route_id() != null
					&& nextMilestoneDTO.getIsmilestonerole_conditional()
							.equalsIgnoreCase("Y")) {
				
				/* If the milestone is conditional then get the default route milestone */
				defaultRouteId = nextMilestoneDTO.getDefault_route_id()
						.intValue();
			} else if (nextMilestoneDTO.getSuccessor_id() != null
					&& !("".equals(nextMilestoneDTO.getSuccessor_id()))) {
				
				/* If the milestone is not conditional then get the successor milestone */
				defaultRouteId = (new Integer(nextMilestoneDTO
						.getSuccessor_id())).intValue();
			} else {
				break;
			}
		}
		
		log.debug("Setting milestoneNameArray:"
				+ Utilities.displayObjectArray(milestoneNameArray));
		scenarioDTO.setWorkflowFieldValue(MILESTONENAMEARRAY_NAME,
				milestoneNameArray);

		log.debug("Setting milestoneIDArray:"
				+ Utilities.displayObjectArray(milestoneIDArray));
		scenarioDTO.setWorkflowFieldValue(MILESTONEIDARRAY_NAME,
				milestoneIDArray);

		log.debug("Setting scenarioMilestoneIDArray:"
				+ Utilities.displayObjectArray(scenarioMilestoneIDArray));
		scenarioDTO.setWorkflowFieldValue(SCENARIOMILESTONEIDARRAY_NAME,
				scenarioMilestoneIDArray);

		log.debug("Setting milestoneOrderArray:"
				+ Utilities.displayObjectArray(milestoneOrderArray));
		scenarioDTO.setWorkflowFieldValue(MILESTONEORDERARRAY_NAME,
				milestoneOrderArray);

		log.debug("Setting milestoneOwnersRoleArray:"
				+ Utilities.displayObjectArray(milestoneOwnersRoleArray));
		scenarioDTO.setWorkflowFieldValue(MILESTONEOWNERSROLEARRAY_NAME,
				milestoneOwnersRoleArray);
		
		log.debug("Setting milestoneOwnerSSFIDArray:"
				+ Utilities.displayObjectArray(milestoneOwnerSSFIDArray));
		scenarioDTO.setWorkflowFieldValue(MILESTONEOWNERSSFIDARRAY_NAME,
				milestoneOwnerSSFIDArray);

		log.debug("Setting milestoneTypeArray:"
				+ Utilities.displayObjectArray(milestoneTypeArray));
		scenarioDTO.setWorkflowFieldValue(MILESTONETYPEARRAY_NAME,
				milestoneTypeArray);

		 log.debug("Setting milestoneSLADateArray:"
				+ Utilities.displayObjectArray(milestoneSLADateArray));
		scenarioDTO.setWorkflowFieldValue(MILESTONESLADATEARRAY_NAME,
				milestoneSLADateArray);

		log.debug("Setting scenarioMilestoneDescriptionArray:"
				+ Utilities
						.displayObjectArray(scenarioMilestoneDescArray));
		scenarioDTO.setWorkflowFieldValue(
				SCENARIOMILESTONEDESCARRAY_NAME,
				scenarioMilestoneDescArray);

		log.debug("[Exit setWorkflowFields]");
	}

	public void setWorkflowFields(ScenarioDTO scenarioDTO, String[] returnArray)
			throws Exception {
		log.debug("[Enter setWorkflowFields]");
		try {
			String milestoneDetailsXML = FinanceFA_XMLUtilities
					.prepareMilestoneDetailsXML(scenarioDTO, returnArray);
			log.info("Milestone details XML is [" + milestoneDetailsXML + "]");

			/* Set the first milestone details */
			// Get the milestone array list
			ArrayList milestoneList = scenarioDTO.getMilestoneList();
			if (milestoneList != null) {

				int numberOfMilestones = milestoneList.size();
				log.debug(numberOfMilestones + " milestone(s) are present.");
				if (numberOfMilestones == 0) {
					log.warn("No milestone configured for the scenario.");
				} else {
					MilestoneDTO milestoneDTO = (MilestoneDTO) milestoneList
							.get(0);

					// Got the first milestone
					log.debug("Adding first scenario milestone id to output array");
					FinanceFA_Utilities.setField(returnArray, 0, milestoneDTO
							.getScenario_milestone_id()
							+ "");
					
					log.debug("Adding first milestone role to output array");
					FinanceFA_Utilities.setField(returnArray, 1, milestoneDTO
							.getMilestone_role());
					
					log.debug("Adding first milestone name to output array");
					FinanceFA_Utilities.setField(returnArray, 2, milestoneDTO
							.getMilestone_name());
					
					log.debug("Adding first milestone id to output array");
					FinanceFA_Utilities.setField(returnArray, 3, milestoneDTO
							.getMilestone_id()
							+ "");
					
					log.debug("Adding first milestone type to output array");
					FinanceFA_Utilities.setField(returnArray, 4, milestoneDTO
							.getMilestone_type());
					
					log.debug("Adding first milestone order to output array");
					FinanceFA_Utilities.setField(returnArray, 5, milestoneDTO
							.getMilestone_order()
							+ "");
					
					log.debug("Adding first milestone description role to output array");
					FinanceFA_Utilities.setField(returnArray, 6, milestoneDTO
							.getScenario_milestone_description());

					/* Calculate the first milestone sla */

					FinanceFA_CIOperations financeOp = new FinanceFA_CIOperations();
					log.debug("Calculating the first milestone sla for offset "
							+ milestoneDTO.getMilestone_sla());
					Date[] tempDate = financeOp.calculateSLA(milestoneDTO
							.getMilestone_sla(), null, slaTypeId.intValue(),
							slaCalculationId.intValue(), startTime, endTime);

					if (tempDate != null) {

						String milestoneSLADateStr = FinanceFA_Utilities
								.dateToString(tempDate[0]);
						log.debug("Adding first milestone sla date to output array");
						FinanceFA_Utilities.setField(returnArray, 7,
								milestoneSLADateStr);
						
						/* Get the first milestone first timer date */
						getFirstMilestoneTimerDate(milestoneDTO, tempDate[0], returnArray, financeOp);
					}
				}
			} else {
				log.warn("No milestone configured for the scenario. Milestone list is null");
			}
		} catch (Exception ex) {
			log.error("Error occured while mapping the milestone workflow fields",
						ex);
			throw ex;
		}
		log.debug("[Exit setWorkflowFields]");
	}

	private void getFirstMilestoneTimerDate(MilestoneDTO milestoneDTO,
			Date milestoneSLADate, String[] returnArray, FinanceFA_CIOperations financeOp) throws Exception {
		
		log.debug("[Enter getFirstMilestoneTimerDate]");
		
		String milestoneSLADateStr = FinanceFA_Utilities.dateToString(
				milestoneSLADate);
		
		ArrayList notificationsList = milestoneDTO.getNotificationList();
		if (notificationsList != null) {
			if (notificationsList.size() == 0) {
				log.info("No milestone notifications configured.");

				/* First milestone first timer date is same as milestone sla date */
				log.debug("Adding first milestone first timer date to output array");
				FinanceFA_Utilities
						.setField(returnArray, 9, milestoneSLADateStr);
			} else {

				/* Get the first notification dto */
				NotificationDTO notificationDTO = (NotificationDTO) notificationsList
						.get(0);
				
				/*
				 * If first notification is a reminder then we have to calculate its exact 
				 * expiration date otherwise(means escalation) then first timer to start will be 
				 * sla timer 
				 */
				if ("Reminder".equalsIgnoreCase(notificationDTO
						.getNotification_type())) {
					Date[] timerDate = financeOp.calculateSLA(notificationDTO
							.getOffset(), milestoneSLADate, slaTypeId.intValue(), 
							slaCalculationId.intValue(), startTime, endTime);
					log.debug("Adding first milestone first timer date to output array");
					FinanceFA_Utilities.setField(returnArray, 9,
							FinanceFA_Utilities.dateToString(timerDate[0]));
				} else {
					log.debug("Adding first milestone first timer date to output array");
					FinanceFA_Utilities.setField(returnArray, 9, milestoneSLADateStr);
				}
			}
		} else {

			/* First milestone first timer date is same as milestone sla date */
			log.debug("Adding first milestone first timer date to output array");
			FinanceFA_Utilities.setField(returnArray, 9, milestoneSLADateStr);
		}
		log.debug("[Exit getFirstMilestoneTimerDate]");
	}

	
	/**
	 * @param defaultRouteId
	 * @param milestoneList
	 * @return
	 */
//	private MilestoneDTO getMilestoneDTOWithScenarioMilestoneId(
//			Integer defaultRouteId, ArrayList milestoneList) {
//		log
//				.debug("[Enter getMilestoneDTOWithScenarioMilestoneId]: defaultRouteId:"
//						+ defaultRouteId);
//		final int numberOfMilestones = milestoneList.size();
//		for (int i = 0; i < numberOfMilestones; i++) {
//			final MilestoneDTO milestoneDTO = (MilestoneDTO) milestoneList
//					.get(i);
//			if (milestoneDTO.getScenario_milestone_id().equals(defaultRouteId)) {
//				return milestoneDTO;
//			}
//		}
//		log.error("Unable to get the milestone with ScenarioMilestoneId:"
//				+ defaultRouteId);
//		log.debug("[Exit getMilestoneDTOWithScenarioMilestoneId]");
//		return null;
//	}

}
