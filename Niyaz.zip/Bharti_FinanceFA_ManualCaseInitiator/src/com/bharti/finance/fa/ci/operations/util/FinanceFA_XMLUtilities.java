/*
 * Created on 26/09/2006 Author HCL
 */
package com.bharti.finance.fa.ci.operations.util;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.apache.log4j.Logger;
import org.apache.xpath.XPathAPI;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.bharti.finance.fa.ci.operations.util.dto.MilestoneDTO;
import com.bharti.finance.fa.ci.operations.util.dto.NotificationDTO;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioDTO;
import com.bharti.finance.fa.ci.operations.util.dto.TaskDTO;

/**
 * @viz.diagram XMLUtil.tpx
 */
public class FinanceFA_XMLUtilities {
	private static Logger log = Logger.getLogger(FinanceFA_XMLUtilities.class);

	/* Create the milestone notification details xml */
	public static Document milestoneNotificationDetailsDoc = null;

	public static Element milestoneNotificationDetailsRootElement = null;
	
	public FinanceFA_XMLUtilities() {

	}

	/**
	 * This method created instance of DOM Object from String.
	 * 
	 * @param docStr
	 *            String
	 * @return Document
	 * @throws Exception
	 */
	public static Document getDocumentInstance(String docStr) throws Exception {
		StringReader sr = new StringReader(docStr);
		InputSource ip = new InputSource(sr);
		DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
		DocumentBuilder db = dbf.newDocumentBuilder();
		Document doc = db.parse(ip);
		return doc;
	}

	public static Document getDocumentInstance() throws Exception {
		DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory
				.newInstance();
		DocumentBuilder documentBuilder = documentBuilderFactory
				.newDocumentBuilder();
		Document document = documentBuilder.newDocument();
		return document;
	}

	/**
	 * Method getRootElement
	 * 
	 * @param doc
	 *            Document
	 * @return Element
	 */
	public static Element getRootElement(Document doc) {
		return doc.getDocumentElement();
	}

	/**
	 * This method creates element Node. For example
	 * createElementNode(doc,"value"); It will create element like <value/>
	 * 
	 * @param doc
	 *            Node
	 * @param elementName
	 *            String
	 * @return Node
	 */
	public static Node createElementNode(Document doc, String elementName) {
		Element element = doc.createElement(elementName);
		return element;
	}

	/**
	 * This method created element text node.
	 * 
	 * createElementNode(doc,"value","7"); will create <value>7 </value>
	 * 
	 * @param doc
	 *            Node
	 * @param elementName
	 *            Element Name
	 * @param elementText
	 *            Element Text
	 * @return Node
	 */
	public static Node createElementNode(Document doc, String elementName,
			String elementText) {

		Element element = doc.createElement(elementName);
		Node txtNode = doc.createTextNode(elementText);
		element.appendChild(txtNode);
		return element;

	}

	/*
	 * CachedXPathApi cudn't read the latest version of Document. So used
	 * XPathApi for getfilter method.
	 */

	/**
	 * This method returns Node from DOM specified by XPath.
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @return Node
	 * @throws Exception
	 */
	public static Node getNode(Node contextNode, String xpath) throws Exception {
		return XPathAPI.selectSingleNode(contextNode, xpath);
	}

	/**
	 * This method returns group of Nodes from DOM specified by XPath.
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @return NodeList
	 * @throws Exception
	 */
	public static NodeList getNodes(Node contextNode, String xpath)
			throws Exception {
		return XPathAPI.selectNodeList(contextNode, xpath);
	}

	/**
	 * This method adds a Node to DOM object as specified by XPath.
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @param newNode
	 *            Node
	 * @return Node
	 * @throws Exception
	 */
	public static Node addNode(Node contextNode, String xpath, Node newNode)
			throws Exception {
		Node node = getNode(contextNode, xpath);
		if (node != null)
			node.appendChild(newNode);
		return newNode;
	}

	public static Document addNode(Document document, String name)
			throws Exception {
		Element rootElement = document.createElement(name);
		document.appendChild(rootElement);
		return document;
	}

	/**
	 * This method removes a Node from DOM Object
	 * 
	 * @param contextNode
	 *            Node
	 * @param xpath
	 *            String
	 * @return Node
	 * @throws Exception
	 */
	public static Node removeNode(Node contextNode, String xpath)
			throws Exception {
		Node node = getNode(contextNode, xpath);
		if (node != null) {
			Node parent = node.getParentNode();

			if (parent != null)
				parent.removeChild(node);
		}
		return node;
	}

	/**
	 * This method created Element with Attribute node
	 * 
	 * createAttributeNode(doc,"queue","name","Sale") will create <queue name="Sale"/>
	 * 
	 * @param doc
	 *            Document
	 * @param elementName
	 *            Element Node Name
	 * @param attributeName
	 *            Attribute Name
	 * @param attributeValue
	 *            Attribute Value
	 * @return Node
	 */
	public static Node createAttributeNode(Document doc, String elementName,
			String attributeName, String attributeValue) {

		Element element = (Element) createElementNode(doc, elementName);
		element.setAttribute(attributeName, attributeValue);
		return element;
	}

	/**
	 * This method converts DOM Object to String
	 * 
	 * @param doc
	 *            Document
	 * @return String
	 * @throws Exception
	 */
	public static String convertDOMtoString(Document doc) throws Exception {
		String processedXML = null;

		//		   Transform the DOM tree into XML String
		TransformerFactory transFactory = TransformerFactory.newInstance();
		Transformer transformer = transFactory.newTransformer();
		DOMSource dSource = new DOMSource(doc);
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(dSource, sr);
		StringWriter anotherSW = (StringWriter) sr.getWriter();
		StringBuffer sBuffer = anotherSW.getBuffer();
		processedXML = sBuffer.toString();
		return processedXML;
	}

	//		public static String toString(Document newDoc)
	//		{
	//			String strDocument = "";
	//			if(newDoc != null)
	//			{
	//				try
	//				{
	//					OutputFormat format = new OutputFormat(newDoc);
	//					StringWriter strOut = new StringWriter();
	//					XMLSerializer XMLSerial = new org.apache.xml.serialize.XMLSerializer(strOut,format);
	//					XMLSerial.serialize(newDoc.getDocumentElement());
	//					strDocument = strOut.toString();
	//
	//				}
	//				catch (Exception exp)
	//				{
	//					log.error("Error Converting XML to String : ", exp);
	//				}
	//			}
	//			return strDocument;
	//		}
	//		
	// Added by Rajni 26 Feb 2008 10:00 PM

	private static Node createValueNode(Document responseDoc, Node node,

	String fieldName, String value) throws Exception {

		Element attr = (Element) FinanceFA_XMLUtilities.createAttributeNode(responseDoc,

		"Value", "Field", fieldName);

		attr.setAttribute("Name", value);

		Node txtNode = responseDoc.createTextNode(value);

		attr.appendChild(txtNode);

		node.appendChild(attr);

		return node;

	}

	private static Node createItemNode(Document responseDoc) throws Exception {

		Node item = FinanceFA_XMLUtilities.createElementNode(responseDoc, "Item");

		FinanceFA_XMLUtilities.addNode(responseDoc, "//Items", item);

		return item;

	}

	private static Node createHeaderNode(org.w3c.dom.Document responseDoc,

	String[] attributes) throws Exception {

		Node header = FinanceFA_XMLUtilities.createElementNode(responseDoc, "Header");

		FinanceFA_XMLUtilities.addNode(responseDoc, "/Items", header);

		for (int i = 0; i < attributes.length; i++) {

			Node val = FinanceFA_XMLUtilities.createElementNode(responseDoc, "Value",

			attributes[i]);

			FinanceFA_XMLUtilities.addNode(responseDoc, "//Header", val);

		}

		return responseDoc;

	}

	public static Document getDocumentRequesterCountry(ArrayList alUsersCFS,

	Hashtable htFields) throws Exception {

		log.debug("List in country is:" + alUsersCFS);

		// String

		// pwID=((Attribute)((Hashtable)alUsersCFS.get(0)).get(Constants.LDAP_ATTRIBUTE_PWID)).get(0).toString();

		// String

		// country=((Attribute)((Hashtable)alUsersCFS.get(0)).get(Constants.LDAP_ATTRIBUTE_COUNTRY)).get(0).toString();

		// String

		// userName=((Attribute)((Hashtable)alUsersCFS.get(0)).get(Constants.LDAP_ATTRIBUTE_NAME)).get(0).toString();

		// log.debug("pw is is:"+pwID);

		log.debug("XML conversion Method:");

		org.w3c.dom.Document doc = getDocumentInstance("<Items LimitExceeded='0'></Items>");

		/*
		 * 
		 * Node header = createElementNode(doc, "Header"); XMLUtil.addNode(doc,
		 * 
		 * "/Items", header); Node val = createElementNode(doc,
		 * 
		 * "Value","PeopleWiseId"); XMLUtil.addNode(doc, "//Header", val); val =
		 * 
		 * createElementNode(doc, "Value","User Name"); XMLUtil.addNode(doc,
		 * 
		 * "//Header", val); val = createElementNode(doc, "Value","Country");
		 * 
		 * XMLUtil.addNode(doc, "//Header", val);
		 * 
		 */

		// for displaying values
		//createHeaderNode(doc, new String[] { "PeopleWiseId", "User Name","Country" });
		//createHeaderNode(doc, new String[] { "User Name","Country" });
		createHeaderNode(doc, new String[] { "PeopleWiseId", "User Name",
				"Country" });
		//createHeaderNode(doc, new String[] { "User Name","Country" });
		// Create Item Nodes.....
		if (alUsersCFS != null && alUsersCFS.size() > 0) {
			Hashtable htFieldValues = (Hashtable) alUsersCFS.get(0);

			Set keySet = htFields.keySet();
			Iterator it = keySet.iterator();

			//int i = 0;
			Node node = createItemNode(doc);
			while (it.hasNext()) {

				String key = (String) it.next();
				String element = (String) htFields.get(key);
				String value = htFieldValues.get(key).toString();

				log.debug("element :" + element);
				log.debug("value :" + value);

				createValueNode(doc, node, element, (value.substring(value
						.indexOf(":") + 1)).trim());

			}

		}

		// Node itemNode = XMLUtil.createElementNode(doc, "Item");

		// XMLUtil.addNode(doc, "//Items", itemNode);

		//    

		// Element attr = (Element) XMLUtil.createAttributeNode(doc,"Value",

		// "Field", "CD_peoplewiseidofdocumentrequestor");

		// attr.setAttribute("Name", pwID);

		// Node txtNode = doc.createTextNode(pwID);

		// attr.appendChild(txtNode);

		// itemNode.appendChild(attr);

		//          

		// log.debug("pwid is:"+itemNode.appendChild(attr));

		//          

		// attr = (Element) XMLUtil.createAttributeNode(doc,"Value", "Field",

		// "CD_nameofdocumentrequestor");

		// attr.setAttribute("Name", userName);

		// txtNode = doc.createTextNode(userName);

		// attr.appendChild(txtNode);

		// itemNode.appendChild(attr);

		//          

		// log.debug("userName is :"+itemNode.appendChild(attr));

		//          

		// attr = (Element) XMLUtil.createAttributeNode(doc,"Value", "Field",

		// "CD_nameofdocumentrequestor");

		// attr.setAttribute("Name", country);

		// txtNode = doc.createTextNode(country);

		// attr.appendChild(txtNode);

		// itemNode.appendChild(attr);

		//          

		// log.debug("country is :"+itemNode.appendChild(attr));

		return doc;

	}
	
	public static boolean prepareTasksXML(ScenarioDTO scenarioDTO,
			LinkedHashMap milestoneTasksMap) {
		log.debug("[Enter prepareTasksXML] ");
		boolean success = false;
		String taskDetailsXML = null;
		Element rootElement = null;
		try {

			if (milestoneTasksMap == null || milestoneTasksMap.size() == 0) {
				log.info("No task found for the scenario");
				taskDetailsXML = "";
			} else {

				/* Create the task details xml */
				Document taskDetailsDoc = null;

				/* Add the root element */
				taskDetailsDoc = FinanceFA_XMLUtilities.getDocumentInstance();
				rootElement = taskDetailsDoc.createElement("TaskDetails");
				taskDetailsDoc.appendChild(rootElement);

				Iterator iterator = milestoneTasksMap.entrySet().iterator();

				while (iterator.hasNext()) {
					Map.Entry entry = (Map.Entry) iterator.next();
					Integer scenarioMilestoneId = (Integer) entry.getKey();

					Element milestoneElement = (Element) taskDetailsDoc
							.createElement("Milestone");
					milestoneElement.setAttribute("ScenarioMilestoneID",
							scenarioMilestoneId + "");

					Element taskElement = null;
					Object obj = entry.getValue();
					if (obj instanceof ArrayList) {
						ArrayList tasksList = (ArrayList) obj;

						for (int i = 0; i < tasksList.size(); i++) {
							TaskDTO taskDTO = (TaskDTO) tasksList.get(i);
							log.debug("each task dto :" + taskDTO);

							taskElement = (Element) taskDetailsDoc
									.createElement("Task");

							/* Add attribute */
							taskElement.setAttribute("sid", (i + 1) + "");

							/* Add Node Id */
							Element element = (Element) taskDetailsDoc
									.createElement("Id");
							element
									.appendChild(taskDetailsDoc
											.createTextNode((taskDTO
													.getTask_id() == null ? ""
													: (taskDTO.getTask_id())
															+ "")));
							taskElement.appendChild(element);

							/* Add Node Name */
							element = (Element) taskDetailsDoc
									.createElement("Name");
							element
									.appendChild(taskDetailsDoc
											.createCDATASection((taskDTO
													.getTask_name() == null ? ""
													: taskDTO.getTask_name())));
							taskElement.appendChild(element);

							/* Add Node Order */
							element = (Element) taskDetailsDoc
									.createElement("Order");
							element
									.appendChild(taskDetailsDoc
											.createTextNode((taskDTO
													.getTask_order() == null ? ""
													: (taskDTO.getTask_order() + ""))));
							taskElement.appendChild(element);

							/* Add Node Description */
							element = (Element) taskDetailsDoc
									.createElement("Description");
							element.appendChild(taskDetailsDoc
									.createCDATASection((taskDTO
											.getTask_description() == null ? ""
											: taskDTO.getTask_description())));
							taskElement.appendChild(element);

							/* Add Node ScenarioId */
							element = (Element) taskDetailsDoc
									.createElement("ScenarioId");
							element
									.appendChild(taskDetailsDoc
											.createTextNode(taskDTO
													.getScenario_id() == null ? ""
													: (taskDTO.getScenario_id() + "")));
							taskElement.appendChild(element);

							/* Add Node Status */
							element = (Element) taskDetailsDoc
									.createElement("Status");
							element.appendChild(taskDetailsDoc
									.createTextNode("N"));
							taskElement.appendChild(element);

							/* Add Node LastUpdatedDate */
							element = (Element) taskDetailsDoc
									.createElement("LastUpdatedDate");
							element.appendChild(taskDetailsDoc
									.createTextNode(""));

							/* Add to task element node */
							taskElement.appendChild(element);

							/* Add task element node to milestone element node */
							milestoneElement.appendChild(taskElement);
						}
					} else {
						log
								.error("Scenario Id value is not an instance of ArrayList");
						return false;
					}

					/* Add task element node to milestone element node */
					milestoneElement.appendChild(taskElement);

					/* Add milestone element node to root element node */
					rootElement.appendChild(milestoneElement);
				}
				taskDetailsXML = FinanceFA_XMLUtilities
						.convertDOMtoString(taskDetailsDoc);
			}
			log.debug("Task details XML is [" + taskDetailsXML + "]");
			scenarioDTO.setTaskDetailsXML(taskDetailsXML);
			success = true;
		} catch (Exception ex) {
			log.error(
					"Exception occured while preparing the tasks xml for scenario id "
							+ scenarioDTO.getScenario_id(), ex);
		}
		return success;
	}

	public static String prepareProcessNotificationDetailsXML(
			ScenarioDTO scenarioDTO) {
		log.debug("[Enter prepareProcessNotificationDetailsXML] ");
		
		Element rootElement = null;
		String notificationDetailsXML = null;
		ArrayList notificationsList = scenarioDTO.getProcessNotificationList();
		try {

			if (notificationsList == null || notificationsList.size() == 0) {
				log.info("No process notifications configured.");
				return "";
			}

			/* Get the first notification dto */
			NotificationDTO notificationDTO = (NotificationDTO) notificationsList.get(0);
			
			/* Create the task details xml */
			Document notificationDetailsDoc = null;

			/* Add the root element */
			notificationDetailsDoc = FinanceFA_XMLUtilities
					.getDocumentInstance();
			rootElement = notificationDetailsDoc
					.createElement("NotificationDetails");

			/* Add attribute */
			rootElement.setAttribute("Category", notificationDTO.getNotification_category());
			notificationDetailsDoc.appendChild(rootElement);

			Element notificationElement = null;
			int notificationCount = notificationsList.size();
			int sid = 1;
			boolean isSLANodeInserted = false;
			
			for (int i = 0; i < notificationCount; i++) {
				notificationDTO = (NotificationDTO) notificationsList
						.get(i);
				log.debug("each notification dto :" + notificationDTO);
				
				// Insert a sla node when we get an first escalation type dto
				String type = notificationDTO.getNotification_type();
				if (type != null && type.equalsIgnoreCase("Escalation")
						&& isSLANodeInserted == false) {
					notificationElement = getProcessSLANotificationNode(
							scenarioDTO, notificationDetailsDoc, sid);
					sid++;

					/* Add notification element node to root element node */
					rootElement.appendChild(notificationElement);
					isSLANodeInserted = true;
				}

				notificationElement = (Element) notificationDetailsDoc
						.createElement("Notification");

				/* Add attribute */
				notificationElement.setAttribute("SID", sid + "");
				sid++;
				
				/* Add Node Type */
				Element element = (Element) notificationDetailsDoc
						.createElement("Type");
				element
						.appendChild(notificationDetailsDoc
								.createTextNode((notificationDTO
										.getNotification_type() == null ? ""
										: notificationDTO
												.getNotification_type())));
				notificationElement.appendChild(element);

				/* Add Node Level */
				element = (Element) notificationDetailsDoc
						.createElement("Level");
				element
						.appendChild(notificationDetailsDoc
								.createTextNode((notificationDTO.getNotification_level() == null ? ""
										: notificationDTO.getNotification_level().toString())));
				notificationElement.appendChild(element);

				/* Add Node Offset */
				element = (Element) notificationDetailsDoc
						.createElement("Offset");
				element.appendChild(notificationDetailsDoc
						.createTextNode((notificationDTO.getOffset() == null ? ""
								: (notificationDTO.getOffset() + ""))));
				notificationElement.appendChild(element);

				/* Add Node To */
				element = (Element) notificationDetailsDoc
						.createElement("To");
				element
						.appendChild(notificationDetailsDoc
								.createCDATASection((notificationDTO
										.getNotification_to() == null ? ""
										: notificationDTO.getNotification_to())));
				notificationElement.appendChild(element);

				/* Add Node CC */
				element = (Element) notificationDetailsDoc
						.createElement("CC");
				element.appendChild(notificationDetailsDoc
						.createCDATASection(notificationDTO.getNotification_cc() == null ? ""
								: (notificationDTO.getNotification_cc())));
				notificationElement.appendChild(element);

				/* Add Node BCC */
				element = (Element) notificationDetailsDoc
						.createElement("BCC");
				element.appendChild(notificationDetailsDoc.createCDATASection(notificationDTO.getNotification_bcc() == null ? ""
						: (notificationDTO.getNotification_bcc())));
				notificationElement.appendChild(element);

				/* Add Node IsTimerExpired */
				element = (Element) notificationDetailsDoc
						.createElement("IsTimerExpired");
				element.appendChild(notificationDetailsDoc.createTextNode("false"));
				notificationElement.appendChild(element);
				
				/* Add Node TimerNotificationIsEnabled */
				element = (Element) notificationDetailsDoc
						.createElement("TimerNotificationIsEnabled");
				Character isEnabled = notificationDTO
						.getNotification_email_is_enabled();
				String isEnabledStr;
				if (isEnabled != null
						&& "Y".equalsIgnoreCase(isEnabled.toString())) {
					isEnabledStr = "true";
				} else {
					isEnabledStr = "false";
				}
				element.appendChild(notificationDetailsDoc
						.createTextNode(isEnabledStr));
				notificationElement.appendChild(element);
				
				/* Add notification element node to root element node*/
				rootElement.appendChild(notificationElement);
			}

			if(!isSLANodeInserted) {
				notificationElement = getProcessSLANotificationNode(scenarioDTO, notificationDetailsDoc, sid);
				sid++;
				
				/* Add notification element node to root element node*/
				rootElement.appendChild(notificationElement);
			}
			notificationDetailsXML = FinanceFA_XMLUtilities
					.convertDOMtoString(notificationDetailsDoc);
			log.debug("Notification details XML is [" + notificationDetailsXML + "]");
			
		} catch (Exception ex) {
			log.error("Exception occured while preparing the process notification details xml", ex);
		}
		return notificationDetailsXML;
	}

	private static Element getProcessSLANotificationNode(
			ScenarioDTO scenarioDTO, Document notificationDetailsDoc, int sid) {
		Element notificationElement = (Element) notificationDetailsDoc
				.createElement("Notification");

		/* Add attribute */
		notificationElement.setAttribute("SID", sid + "");

		/* Add Node Type */
		Element element = (Element) notificationDetailsDoc
				.createElement("Type");
		element.appendChild(notificationDetailsDoc.createTextNode("SLAExpired"));
		notificationElement.appendChild(element);

		/* Add Node Level */
		element = (Element) notificationDetailsDoc.createElement("Level");
		element.appendChild(notificationDetailsDoc.createTextNode("1"));
		notificationElement.appendChild(element);

		/* Add Node Offset */
		element = (Element) notificationDetailsDoc.createElement("Offset");
		if (scenarioDTO.getProcess_sla() == null) {
			log.warn("Process SLA offset for Scenario Id "
					+ scenarioDTO.getScenario_id() + " is null");
		}
		element.appendChild(notificationDetailsDoc
				.createTextNode((scenarioDTO.getProcess_sla() == null ? ""
						: (scenarioDTO.getProcess_sla() + ""))));
		notificationElement.appendChild(element);

		/* Add Node To */
		element = (Element) notificationDetailsDoc.createElement("To");
		element.appendChild(notificationDetailsDoc.createTextNode(""));
		notificationElement.appendChild(element);

		/* Add Node CC */
		element = (Element) notificationDetailsDoc.createElement("CC");
		element.appendChild(notificationDetailsDoc.createTextNode(""));
		notificationElement.appendChild(element);

		/* Add Node BCC */
		element = (Element) notificationDetailsDoc.createElement("BCC");
		element.appendChild(notificationDetailsDoc.createTextNode(""));
		notificationElement.appendChild(element);

		/* Add Node IsTimerExpired */
		element = (Element) notificationDetailsDoc
				.createElement("IsTimerExpired");
		element.appendChild(notificationDetailsDoc.createTextNode("false"));
		notificationElement.appendChild(element);

		/* Add Node TimerNotificationIsEnabled */
		element = (Element) notificationDetailsDoc
				.createElement("TimerNotificationIsEnabled");
		element.appendChild(notificationDetailsDoc.createTextNode("false"));
		notificationElement.appendChild(element);
		return notificationElement;
	}

	private static Element getMilestoneSLANotificationNode(
			MilestoneDTO milestoneDTO, Document notificationDetailsDoc, int sid) {
		Element notificationElement = (Element) notificationDetailsDoc
				.createElement("Notification");

		/* Add attribute */
		notificationElement.setAttribute("SID", sid + "");

		/* Add Node Type */
		Element element = (Element) notificationDetailsDoc
				.createElement("Type");
		element.appendChild(notificationDetailsDoc.createTextNode("SLAExpired"));
		notificationElement.appendChild(element);

		/* Add Node Level */
		element = (Element) notificationDetailsDoc.createElement("Level");
		element.appendChild(notificationDetailsDoc.createTextNode("1"));
		notificationElement.appendChild(element);

		/* Add Node Offset */
		element = (Element) notificationDetailsDoc.createElement("Offset");
		if (milestoneDTO.getMilestone_sla() == null) {
			log.warn("Milestone SLA offset for Scenario Id "
					+ milestoneDTO.getMilestone_sla() + " is null");
		}
		element.appendChild(notificationDetailsDoc
				.createTextNode((milestoneDTO.getMilestone_sla() == null ? ""
						: (milestoneDTO.getMilestone_sla() + ""))));
		notificationElement.appendChild(element);

		/* Add Node To */
		element = (Element) notificationDetailsDoc.createElement("To");
		element.appendChild(notificationDetailsDoc.createTextNode(""));
		notificationElement.appendChild(element);

		/* Add Node CC */
		element = (Element) notificationDetailsDoc.createElement("CC");
		element.appendChild(notificationDetailsDoc.createTextNode(""));
		notificationElement.appendChild(element);

		/* Add Node BCC */
		element = (Element) notificationDetailsDoc.createElement("BCC");
		element.appendChild(notificationDetailsDoc.createTextNode(""));
		notificationElement.appendChild(element);

		/* Add Node IsTimerExpired */
		element = (Element) notificationDetailsDoc
				.createElement("IsTimerExpired");
		element.appendChild(notificationDetailsDoc.createTextNode("false"));
		notificationElement.appendChild(element);

		/* Add Node TimerNotificationIsEnabled */
		element = (Element) notificationDetailsDoc
				.createElement("TimerNotificationIsEnabled");
		element.appendChild(notificationDetailsDoc.createTextNode("false"));
		notificationElement.appendChild(element);
		return notificationElement;
	}

	
	public static String prepareMilestoneDetailsXML(ScenarioDTO scenarioDTO, String[] returnArray) {
		log.debug("[Enter prepareMilestoneDetailsXML] ");

		Element rootElement = null;
		String milestoneDetailsXML = null;

		try {

			// Get the milestone array list
			ArrayList milestoneList = scenarioDTO.getMilestoneList();
			if (milestoneList == null || milestoneList.size() == 0) {
				log.info("No milestone configured for the scenario.");
				return "";
			}

			/*
			 * I have to put the is active check for milestone
			 */

			/* Create the milestone details xml */
			Document xmlDoc = null;

			/* Add the root element */
			xmlDoc = FinanceFA_XMLUtilities.getDocumentInstance();
			rootElement = xmlDoc.createElement("MilestoneDetails");
			xmlDoc.appendChild(rootElement);
			
			Element mElement = null;
			int milestoneCount = milestoneList.size();

			for (int i = 0; i < milestoneCount; i++) {
				MilestoneDTO eachDTO = (MilestoneDTO) milestoneList.get(i);
				log.debug("each milestone dto :" + eachDTO);

				mElement = (Element) xmlDoc.createElement("Milestone");

				/* Add attribute */
				mElement.setAttribute("ScenarioMilestoneID", (eachDTO
						.getScenario_milestone_id() == null ? "" : (eachDTO
						.getScenario_milestone_id() + "")));

				/* Add Node Name */
				Element element = (Element) xmlDoc.createElement("Name");
				element.appendChild(xmlDoc.createTextNode((eachDTO
						.getMilestone_name() == null ? "" : (eachDTO
						.getMilestone_name())
						+ "")));
				mElement.appendChild(element);

				/* Add Node Type */
				element = (Element) xmlDoc.createElement("Type");
				element.appendChild(xmlDoc.createTextNode((eachDTO
						.getMilestone_type() == null ? "" : eachDTO
						.getMilestone_type())));
				mElement.appendChild(element);

				/* Add Node Order */
				element = (Element) xmlDoc.createElement("Order");
				element.appendChild(xmlDoc.createTextNode((eachDTO
						.getMilestone_order() == null ? "" : (eachDTO
						.getMilestone_order() + ""))));
				mElement.appendChild(element);

				/* Add Node ID */
				element = (Element) xmlDoc.createElement("ID");
				element.appendChild(xmlDoc.createTextNode((eachDTO
						.getMilestone_id() == null ? "" : (eachDTO
						.getMilestone_id() + ""))));
				mElement.appendChild(element);

				/* Add Node OwnerSSFID */
				element = (Element) xmlDoc.createElement("OwnerSSFID");
				element.appendChild(xmlDoc.createTextNode(""));
				mElement.appendChild(element);

				/* Add Node OwnerRole */
				element = (Element) xmlDoc.createElement("OwnerRole");
				element.appendChild(xmlDoc.createTextNode(eachDTO
						.getMilestone_role() == null ? "" : (eachDTO
						.getMilestone_role())));
				mElement.appendChild(element);

				/* Add Node RestSLA */
				element = (Element) xmlDoc.createElement("RestSLA");
				element.appendChild(xmlDoc.createTextNode(""));
				mElement.appendChild(element);

				/* Add Node Offset */
				element = (Element) xmlDoc.createElement("Offset");
				element.appendChild(xmlDoc.createTextNode(eachDTO
						.getMilestone_sla() == null ? "" : (eachDTO
						.getMilestone_sla())));
				mElement.appendChild(element);

				/* Add Node ScenarioMilestoneDesc */
				element = (Element) xmlDoc
						.createElement("ScenarioMilestoneDesc");
				element.appendChild(xmlDoc.createCDATASection(eachDTO
						.getScenario_milestone_description() == null ? ""
						: (eachDTO.getScenario_milestone_description())));
				mElement.appendChild(element);

				/* Add notification element node to root element node*/
				rootElement.appendChild(mElement);

				/* Prepare the milestone notification details xml */
				prepareMilestoneNotificationDetailsXML(eachDTO);
			}

			milestoneDetailsXML = FinanceFA_XMLUtilities
					.convertDOMtoString(xmlDoc);
			log.debug("Milestone details XML is [" + milestoneDetailsXML + "]");
			log.debug("Adding milestone details xml to output array");
			FinanceFA_Utilities.setField(returnArray, 11, milestoneDetailsXML);
			
			String milestoneNotificationDetailsXML = FinanceFA_XMLUtilities
					.convertDOMtoString(milestoneNotificationDetailsDoc);
			log.debug("Milestone Notification details XML is ["
					+ milestoneNotificationDetailsXML + "]");
			log.debug("Adding milestone notification details xml to output array");
			FinanceFA_Utilities.setField(returnArray, 12, milestoneNotificationDetailsXML);
		} catch (Exception ex) {
			log.error("Exception occured while preparing the milestone details xml",
						ex);
		}
		return milestoneDetailsXML;
	}

	public static void prepareMilestoneNotificationDetailsXML(
			MilestoneDTO milestoneDTO) {
		try {
			ArrayList notificationsList = milestoneDTO.getNotificationList();
			if (notificationsList == null || notificationsList.size() == 0) {
					log.info("No notifications configured for milestone "
							+ milestoneDTO);
					return;
			}

			/* Get the first notification dto */
			NotificationDTO notificationDTO = (NotificationDTO) notificationsList.get(0);
			
			if (milestoneNotificationDetailsDoc == null) {

				/* First time this method is called */
				/* Add the root element */
				log.debug("First time called");
				milestoneNotificationDetailsDoc = FinanceFA_XMLUtilities
						.getDocumentInstance();
				milestoneNotificationDetailsRootElement = milestoneNotificationDetailsDoc
						.createElement("NotificationDetails");
				
				/* Add attribute */
				milestoneNotificationDetailsRootElement.setAttribute("Category", notificationDTO.getNotification_category());
				milestoneNotificationDetailsDoc.appendChild(milestoneNotificationDetailsRootElement);
			}
			
			Integer scenarioMilestoneId = milestoneDTO.getScenario_milestone_id();
			Element milestoneElement = (Element) milestoneNotificationDetailsDoc
					.createElement("Milestone");
			milestoneElement.setAttribute("ScenarioMilestoneID",
					scenarioMilestoneId + "");
			
			int notificationCount = notificationsList.size();
			int sid = 1;
			boolean isSLANodeInserted = false;
			Element notificationElement = null;
			
			for (int i = 0; i < notificationCount; i++) {
				notificationDTO = (NotificationDTO) notificationsList
						.get(i);
				log.debug("each notification dto :" + notificationDTO);
								
				// Insert a sla node when we get an first escalation type dto
				String type = notificationDTO.getNotification_type();
				if (type != null && type.equalsIgnoreCase("Escalation")
						&& isSLANodeInserted == false) {
					notificationElement = getMilestoneSLANotificationNode(
							milestoneDTO, milestoneNotificationDetailsDoc, sid);
					sid++;

					/* Add notification element node to root element node */
					milestoneElement.appendChild(notificationElement);
					isSLANodeInserted = true;
				}

				notificationElement = (Element) milestoneNotificationDetailsDoc
						.createElement("Notification");

				/* Add attribute */
				notificationElement.setAttribute("SID", sid + "");
				sid++;
				
				/* Add Node Id */
				Element element = (Element) milestoneNotificationDetailsDoc
						.createElement("Type");
				element
						.appendChild(milestoneNotificationDetailsDoc
								.createTextNode((notificationDTO
										.getNotification_type() == null ? ""
										: notificationDTO
												.getNotification_type())));
				notificationElement.appendChild(element);

				/* Add Node Name */
				element = (Element) milestoneNotificationDetailsDoc
						.createElement("Level");
				element
						.appendChild(milestoneNotificationDetailsDoc
								.createTextNode((notificationDTO.getNotification_level() == null ? ""
										: notificationDTO.getNotification_level().toString())));
				notificationElement.appendChild(element);

				/* Add Node Order */
				element = (Element) milestoneNotificationDetailsDoc
						.createElement("Offset");
				element.appendChild(milestoneNotificationDetailsDoc
						.createTextNode((notificationDTO.getOffset() == null ? ""
								: (notificationDTO.getOffset() + ""))));
				notificationElement.appendChild(element);

				/* Add Node Description */
				element = (Element) milestoneNotificationDetailsDoc
						.createElement("To");
				element
						.appendChild(milestoneNotificationDetailsDoc
								.createCDATASection((notificationDTO
										.getNotification_to() == null ? ""
										: notificationDTO.getNotification_to())));
				notificationElement.appendChild(element);

				/* Add Node ScenarioId */
				element = (Element) milestoneNotificationDetailsDoc
						.createElement("CC");
				element.appendChild(milestoneNotificationDetailsDoc
						.createCDATASection(notificationDTO.getNotification_cc() == null ? ""
								: (notificationDTO.getNotification_cc())));
				notificationElement.appendChild(element);

				/* Add Node BCC */
				element = (Element) milestoneNotificationDetailsDoc
						.createElement("BCC");
				element.appendChild(milestoneNotificationDetailsDoc.createCDATASection(notificationDTO.getNotification_bcc() == null ? ""
						: (notificationDTO.getNotification_bcc())));
				notificationElement.appendChild(element);

				/* Add Node IsTimerExpired */
				element = (Element) milestoneNotificationDetailsDoc
						.createElement("IsTimerExpired");
				element.appendChild(milestoneNotificationDetailsDoc.createTextNode("false"));
				notificationElement.appendChild(element);
				
				/* Add Node TimerNotificationIsEnabled */
				element = (Element) milestoneNotificationDetailsDoc
						.createElement("TimerNotificationIsEnabled");
				Character isEnabled = notificationDTO
						.getNotification_email_is_enabled();
				String isEnabledStr;
				if (isEnabled != null
						&& "Y".equalsIgnoreCase(isEnabled.toString())) {
					isEnabledStr = "true";
				} else {
					isEnabledStr = "false";
				}
				element.appendChild(milestoneNotificationDetailsDoc
						.createTextNode(isEnabledStr));
				notificationElement.appendChild(element);
				
				/* Add notification element node to root element node*/
				milestoneElement.appendChild(notificationElement);
			}

			if (!isSLANodeInserted) {
				notificationElement = getMilestoneSLANotificationNode(
						milestoneDTO, milestoneNotificationDetailsDoc, sid);
				sid++;

				/* Add notification element node to root element node */
				milestoneElement
						.appendChild(notificationElement);
			}
			milestoneNotificationDetailsRootElement.appendChild(milestoneElement);
			
		} catch (Exception ex) {
			log
					.error(
							"Exception occured while preparing the milestone details xml",
							ex);
		}
	}

}