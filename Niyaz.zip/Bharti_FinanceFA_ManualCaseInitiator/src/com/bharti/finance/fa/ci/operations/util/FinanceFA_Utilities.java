/*
 * Created on Jul 12, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioUnitDTO;

/**
 * This class contains some Finance revenue specific utilities methods
 * 
 * @author Harisha
 * 
 * @viz.diagram Finance_Utilities.tpx
 */
public class FinanceFA_Utilities extends Utilities {

	public static Logger log = Logger.getLogger(FinanceFA_Utilities.class);
	public static String insertSQL = "";
	/**
	 * @param exceptionLog
	 * @return
	 */
	public static ArrayList getScenarioUnitsFromXMLString(String exceptionLog) {
		
		/* Load XML file */
		Document doc = null;
		try {
			doc = FinanceFA_XMLUtilities.getDocumentInstance(exceptionLog);
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		if(doc == null) {
			log.error("Error occurred while parsing the xml file.");
			return null;
		}
		
		/* Returns a list of all group-name elements */
		NodeList caseList = doc.getElementsByTagName("case");
		ArrayList scenarioUnitList = new ArrayList();
		
		/* Check each emailTypeList */
		int numCaseList = caseList.getLength();
		for (int i=0; i<numCaseList; i++) {
			
			/* Get each node element*/
			Node groupName = (Node) caseList.item(i);
			
			/* Contains all the properties of single consolidation email.
			 * Associates the name of property as its key and value of that property 
			 * as its value.  
			 */
			HashMap hm = new HashMap();
			ScenarioUnitDTO scenarioUnitDTO = new ScenarioUnitDTO();
			
			/* Retrieves values of the node attributes */
			String id = groupName.getAttributes().getNamedItem("id").getNodeValue().trim();
			log.debug("id:"+id);
									
			Element element = (Element)groupName;
			
			/* Returns a list of all property elements */
			NodeList groupPropertyList = element.getElementsByTagName("property");
			
			int numPropertyList = groupPropertyList.getLength();
			for(int j=0; j<numPropertyList; j++) {
				Node property = groupPropertyList.item(j);
				String propName = property.getAttributes().getNamedItem("name").getNodeValue().trim();
				String propValue = property.getAttributes().getNamedItem("value").getNodeValue().trim();
				hm.put(propName, propValue);				
			}
				
			/* Print the data read from xml file */
			Iterator iterator = hm.entrySet().iterator();
			log.debug("For case [" + i + "] id [" + id + "]: Displaying all properties " +
					"from xml file");
			while (iterator.hasNext()) {
				Map.Entry entry = (Map.Entry) iterator.next();
				log.debug("Property name [" + entry.getKey() + "] value [" + entry.getValue() + "]");
			}
			
			/* 
			 * Examines all of the Map parameters to see if any match a bean 
			 * property (i.e., a setXxx method) in the object. If so, the map 
			 * parameter value is passed to that method. If the method expects
			 * an int, Integer, double, Double, or any of the other primitive or 
			 * wrapper types, parsing and conversion is done automatically. 
			 * If the request parameter value is malformed (cannot be converted 
			 * into the expected type), numeric properties are assigned zero and 
			 * boolean properties are assigned false: no exception is thrown.
			 */
			Utilities.populateBean(scenarioUnitDTO, hm);
			scenarioUnitList.add(scenarioUnitDTO);
		}
		log.debug("Scenario Unit list is:"+scenarioUnitList.size());	
		return scenarioUnitList;
	}
	
	/**
	 * @param start_date
	 * @param frequency_id
	 * @return
	 */
	public static Date getNewDate(Date date, Integer frequency_id) {
		Calendar newCal = Calendar.getInstance();
		newCal.setTimeInMillis(date.getTime());
		
		if (frequency_id.intValue() == 1) { //Dialy
			log.debug("It is a dialy process");
			newCal.add(Calendar.DAY_OF_MONTH, 1);
			
		} else if (frequency_id.intValue() == 2) { //Monthly
			log.debug("It is a monthly process");
			newCal.add(Calendar.MONTH, 1);
			
		} else if (frequency_id.intValue() == 3) { //Weekly
			log.debug("It is a Weekly process");
			newCal.add(Calendar.WEEK_OF_MONTH, 1);
			
		} else if (frequency_id.intValue() == 4) { //Fortnightly
			log.debug("It is a Fortnightly process");
			newCal.add(Calendar.WEEK_OF_MONTH, 2);
		}
		return newCal.getTime();
	}
	
	/**
	 * Checks whether the <code>arr</code> is sorted in ascending order or not
	 * 
	 * @param arr
	 *            array to check
	 * @return -1 if array is sorted in ascending order; otherwise index of the
	 *         array where mismatch occured. For example: if array element at
	 *         3rd and 4th position is not in order; then it returns 3.
	 */
	public static int isSortedDateArray(Timestamp[] arr) {
		boolean isSorted = false;
		if (arr != null) {
			int numArr = arr.length;
			for (int i = 0; i < (numArr - 1); i++) {
				if (arr[i].compareTo(arr[i + 1]) <= 0) {
					isSorted = true;
				} else {
					isSorted = false;
					return i;
				}
			}
		}
		log.debug("Array is sorted in ascending order flag :" + isSorted);
		return -1;
	}
	
	/**
	 * Inserts the <code>value</code> into the <code>array</code> at the
	 * position <code>position</code>.
	 * 
	 * @param array
	 * @param position
	 * @param value
	 * @return
	 * @throws ArrayIndexOutOfBoundsException
	 */
	public static String[] setField(String[] array, int index, String value)
			throws ArrayIndexOutOfBoundsException {
		array[index] = value;
		log.info("-------------- Array Index [" + index + "] value [" + value
				+ "] added to output array");
		return array;
	}

	public static void main(String[] args) {
//		Timestamp[] arr = new Timestamp[4];
//		arr[0] = new Timestamp(109,8,19,18,40,0,0);
//		arr[1] = new Timestamp(109,8,19,18,50,0,0);
//		arr[2] = new Timestamp(109,8,19,19,20,0,0);
//		arr[3] = new Timestamp(109,8,20,19,20,0,0);
//		System.out.println("Hi");
//		System.out.println(displayObjectArray(arr));
//		System.out.println(isSortedDateArray(arr));
	}

	
}
