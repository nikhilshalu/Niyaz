/*
 * Created on Jul 8, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util.mapper;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import org.apache.log4j.Logger;

import com.bharti.finance.fa.ci.operations.FinanceFA_CIOperations;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Utilities;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_XMLUtilities;
import com.bharti.finance.fa.ci.operations.util.dto.NotificationDTO;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioDTO;

/**
 * @author Harisha
 * 
 * TODO To change the template for this generated type comment go to Window -
 * Preferences - Java - Code Style - Code Templates
 * @viz.diagram NotificationMapper.tpx
 */
public class NotificationMapper {

	public static Logger log = Logger.getLogger(NotificationMapper.class);

	private Integer slaCalculationId;

	private String startTime;

	private String endTime;

	/**
	 * @param slaTypeId
	 * @param slaCalculationId
	 * @param startTime
	 * @param endTime
	 */
	public NotificationMapper(Integer slaCalculationId,
			String startTime, String endTime) {
		super();
		this.slaCalculationId = slaCalculationId;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public NotificationMapper() {
		// TODO Auto-generated constructor stub
	}

	public void setWorkflowFields(ArrayList notifications, Date relativeDate,
			HashMap htTimers, HashMap htTO,
			HashMap htCC, HashMap htBCC,
			HashMap htEmailIsEnabled) {
		
		if (notifications != null) {
			for (int i = 0; i < notifications.size(); i++) {
				NotificationDTO notification = (NotificationDTO) notifications
						.get(i);
				
				/*
				 * Prepare the Timer Name for every process and milestone's
				 * escalation and reminders. For example: 
				 * Process first Escalation = PE1 
				 * Milestone with scenario Id 10's first Escalation = M10E1 
				 * Milestone with scenario Id 15's second Reminder = M15R2
				 */
				String name = "";
				if (notification.getNotification_category().equalsIgnoreCase(
						FinanceFA_Constants.STRING_PROCESS)) {
					name = FinanceFA_Constants.PROCESS;
					
				} else {
					name = FinanceFA_Constants.MILESTONE
							+ notification.getScenario_milestone_id();
				}

				if (notification.getNotification_type().equalsIgnoreCase(
						FinanceFA_Constants.STRING_ESCALATION)) {
					name = name + FinanceFA_Constants.ESCALATION
							+ notification.getNotification_level();

				} else if (notification.getNotification_type()
						.equalsIgnoreCase(FinanceFA_Constants.STRING_REMINDER)) {
					name = name + FinanceFA_Constants.REMINDER
							+ notification.getNotification_level();
				}
				
				FinanceFA_CIOperations financeOp = new FinanceFA_CIOperations();
				log.debug("Calculating the "
						+ notification.getNotification_category() + " "
						+ notification.getNotification_type() + " date");

				Date[] tempDate = financeOp.calculateSLA(notification
						.getOffset(), relativeDate, 2, slaCalculationId
						.intValue(), startTime, endTime);
				if (tempDate != null) {
					htTimers.put(name, tempDate[0]);
				}

				htTO.put(name, (notification.getNotification_to() == null ? ""
						: notification.getNotification_to()));
				htCC.put(name, (notification.getNotification_cc() == null ? ""
						: notification.getNotification_cc()));
				htBCC.put(name, (notification.getNotification_bcc() == null ? ""
						: notification.getNotification_bcc()));
				htEmailIsEnabled
						.put(
								name,
								(notification
										.getNotification_email_is_enabled() == null ? ""
										: notification
												.getNotification_email_is_enabled()
												+ ""));
			}
		}
	}
	
	public void setWorkflowFields(ScenarioDTO scenarioDTO, String[] returnArray) {
		
		String processNotificationDetailsXML = FinanceFA_XMLUtilities
				.prepareProcessNotificationDetailsXML(scenarioDTO);
		log.info("Notification details XML is [" + processNotificationDetailsXML + "]");

		log.debug("Adding process notification details xml to output array");
		FinanceFA_Utilities.setField(returnArray, 14, processNotificationDetailsXML);
	}
}
