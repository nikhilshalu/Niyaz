/*
 * Created on Jun 10, 2009
 *
 */
package com.bharti.finance.fa.ci.operations.util.manager;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.sql.Types;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.fa.common.operations.util.manager.ExternalDBManager;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Utilities;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_XMLUtilities;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioUnitDTO;
import com.bharti.finance.fa.ci.operations.util.dto.TaskDTO;
import com.bharti.finance.fa.ci.operations.util.dto.MilestoneDTO;
import com.bharti.finance.fa.ci.operations.util.dto.NotificationDTO;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioDTO;

/**
 * Handles all the database related operations.
 * @author Harisha
 * 
 * @viz.diagram Finance_ExternalDBManager.tpx
 */
public class FinanceFA_ExternalDBManager extends ExternalDBManager {

	public static Logger log = Logger
			.getLogger(FinanceFA_ExternalDBManager.class);

	private LinkedHashMap scenariosMap = null;

	private LinkedHashMap scenarioMilestonesMap = null;
	
	private LinkedHashMap scenarioTasksMap = null;

	private Connection dbconn = null;

	private StringBuffer allCaseLaunchCldrIds = new StringBuffer();

	private StringBuffer allScenarioIds = new StringBuffer();
	
	private StringBuffer allActiveMilestoneIds = new StringBuffer();

	private SimpleDateFormat simDate = new SimpleDateFormat(
			FinanceFA_Constants.DATE_PATTERN);

	
	public FinanceFA_ExternalDBManager(int application) {
		super(application);
	}

	/**
	 * @return Returns the dbconn.
	 */
	public Connection getDbconn() {
		return dbconn;
	}

	/*
	 * @see com.bharti.operations.util.manager.ExternalDBManager#getDbConnection()
	 *      Connects to the database using the credentials mentioned in the
	 *      property file
	 */
	public Connection getDbConnection() {
		log.debug("[Entry getDbConnection]");

		String db2URL = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_URL"));
		String db2User = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_ID"));
		String db2pwd = Base64.decrypt(PropertyLoader.props
				.getProperty("DATABASE_USER_PASSWORD"));

		dbconn = getDbConnection(db2URL, db2User, db2pwd);
		log.debug("[Exit getDbConnection]");
		return dbconn;
	}

	/**
	 * Retrieves all scenario from the database whose status is not 'S'(means
	 * Success) and whose start date is less than or equal to system current
	 * time.
	 * 
	 * @return array list of active scenarios ScenarioDTO bean
	 */
	public ArrayList getActiveCalendarScenarios() {
		log.debug("[Enter getActiveCalendarScenarios]");

		/* Get the active scenarios */
		log.debug("Getting the active scenario details");
		scenariosMap = getScenarioDetails();

		// If no records are found in the database
		if (scenariosMap == null || scenariosMap.size() == 0) {
			log.info("No Active Calendar Scenarios found.");
			return null;
		}

		displayAllMaps();

		/* Get the active scenarios milestone information */
		log.debug("Getting the active scenarios milestone details");
		scenarioMilestonesMap = getScenarioMilestones(allCaseLaunchCldrIds
				.toString());

		displayAllMaps();

		/* Get all escalation and reminder details of process and milestones */
		log
				.debug("Getting all escalation and reminder details of process and milestones");
		getNotificationDetails(allCaseLaunchCldrIds.toString());
		
		/* Get milestone task details */
		log.debug("Getting all milestones task details");
		getMilestoneTaskDetails();

		displayAllMaps();
		
		/* Update all scenario dto with its corresponding milestone dtos */
		ArrayList activeScenarioList = prepareScenarioDTOListWithMilestones();

		displayActiveScenarioList(activeScenarioList);

		log.debug("[Exit getActiveCalendarScenarios]");
		return activeScenarioList;
	}
	
	/**
	 * Retrieves the scenario from the database whose scenario id matches the
	 * <code>scenarioId</code>
	 * 
	 * @return array list of active scenarios ScenarioDTO bean
	 */
	public ArrayList getCalendarScenario(int scenarioId) throws IllegalArgumentException {
		log.debug("[Enter getCalendarScenario]");

		/* Get the active scenarios */
		log.debug("Getting the scenario details");
		scenariosMap = getScenarioDetails(scenarioId);

		// If no records are found in the database
		if (scenariosMap == null || scenariosMap.size() == 0) {
			String errorMsg = "No Scenario with scenario id [" + scenarioId
					+ "] found.";
			log.error(errorMsg);
			throw new IllegalArgumentException(errorMsg);
		}

		displayAllMaps();

		/* Get the active scenarios milestone information */
		log.debug("Getting the active scenarios milestone details");
		scenarioMilestonesMap = getScenarioActiveMilestones(allCaseLaunchCldrIds
				.toString());

		displayAllMaps();

		/* Get all escalation and reminder details of process and milestones */
		log.debug("Getting all escalation and reminder details of process and milestones");
		getActiveNotificationDetails(allCaseLaunchCldrIds.toString(), allActiveMilestoneIds);
		
		/* Get milestone task details */
		log.debug("Getting active milestones task details");
		getActiveMilestoneTaskDetails(allActiveMilestoneIds);

		displayAllMaps();
		
		/* Update all scenario dto with its corresponding milestone dtos */
		ArrayList activeScenarioList = prepareScenarioDTOListWithMilestones();

		displayActiveScenarioList(activeScenarioList);

		log.debug("[Exit getActiveCalendarScenarios]");
		return activeScenarioList;
	}

	private void getActiveMilestoneTaskDetails(StringBuffer allActiveMilestoneIds) {
		log.debug("[Enter getActiveMilestoneTaskDetails]: allActiveMilestoneIds:"
				+ allActiveMilestoneIds);

		log.debug("Fetching the task details of only active milestones ["
				+ allActiveMilestoneIds + "]");
		boolean success = false;
		try {
			String sql = "SELECT SCENARIO_ID, SCENARIO_MILESTONE_ID, task_master.TASK_ID, TASK_NAME, TASK_ORDER, TASK_DESCRIPTION FROM FN_FA_TBL_TASK_MASTER task_master INNER JOIN (SELECT SCENARIO_ID, SCENARIO_MILESTONE_ID, TASK_ID, TASK_ORDER, TASK_DESCRIPTION FROM FN_FA_TBL_MILESTONE_TASK_MAPPING task_mapping where LOWER(task_mapping.IS_ACTIVE)='y' and task_mapping.SCENARIO_MILESTONE_ID in ("
					+ allActiveMilestoneIds
					+ ")) tasks ON task_master.TASK_ID = tasks.TASK_ID ORDER BY SCENARIO_ID, SCENARIO_MILESTONE_ID, TASK_ORDER";
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			Integer prevScenarioId = null;
			Integer currentScenarioId = null;

			Integer prevScenarioMilestoneId = null;
			Integer currentScenarioMilestoneId = null;

			ArrayList taskList = new ArrayList();
			LinkedHashMap milestoneTasksMap = new LinkedHashMap();

			int count = 0;
			
			scenarioTasksMap = new LinkedHashMap();

			while (rs.next()) {
				count++;
				TaskDTO taskDTO = new TaskDTO();

				currentScenarioId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_SCENARIO_ID));
				currentScenarioMilestoneId = new Integer(
						rs.getInt(FinanceFA_Constants.STRING_SCENARIO_MILESTONE_ID));

				if (prevScenarioMilestoneId != null
						&& !(currentScenarioMilestoneId.equals(prevScenarioMilestoneId))) {
					log.debug("changed "+ currentScenarioMilestoneId+"   "+taskList.size());
					milestoneTasksMap.put(prevScenarioMilestoneId, taskList);
					taskList = new ArrayList();
				}
				
				if (prevScenarioId != null
						&& !(currentScenarioId.equals(prevScenarioId))) {
					
					/* Get the size of task list before initializing */
					int taskListSize = taskList.size();
					log.info("Scenario Id [" + prevScenarioId
							+ "]: Scenario milestone id ["
							+ prevScenarioMilestoneId + " has " + taskListSize
							+ " task(s).");
										
					scenarioTasksMap.put(prevScenarioId, milestoneTasksMap);
					milestoneTasksMap = new LinkedHashMap();
					taskList = new ArrayList();
				}

				prevScenarioId = currentScenarioId;
				prevScenarioMilestoneId = currentScenarioMilestoneId;

				/*
				 * For every database record store all column values in an Map.
				 * i.e., column name as key and column value has value so that
				 * the map can be used to populate the DTO or bean object
				 * directly without having to set each property of bean object.
				 */
				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getObject(j));
					}
				}

				/* Print the data read from database */
				if (log.isDebugEnabled()) {
					Iterator iterator = hm.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						log.debug("Property name [" + entry.getKey()
								+ "] value [" + entry.getValue() + "]");
					}
					log.debug("--------------------------------------------");
				}
				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(taskDTO, hm);
				taskList.add(taskDTO);
			}
						
			if (currentScenarioId != null) {
				log.debug("changed "+ currentScenarioMilestoneId+"   "+taskList.size());
				milestoneTasksMap.put(prevScenarioMilestoneId, taskList);
				scenarioTasksMap.put(prevScenarioId, milestoneTasksMap);

				/* Get the size of task list before initializing */
				int taskListSize = taskList.size();
				log.info("Scenario Id [" + prevScenarioId
						+ "]: Scenario milestone id ["
						+ prevScenarioMilestoneId + " has " + taskListSize
						+ " task(s).");
				milestoneTasksMap = new LinkedHashMap();
				taskList = new ArrayList();
			}
			log.info(count + " row(s) retrieved from database");
			log.debug(scenarioTasksMap.size()+" scenarios tasks found");
			
			displayTaskDetails();						
			success = true;
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active milestones task details. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getActiveMilestoneTaskDetails]");
	}
	
	private void getMilestoneTaskDetails() {

		log.debug("[Enter getMilestoneTaskDetails]");

		boolean success = false;
		try {
			String sql = PropertyLoader.props.getProperty("SQL_GET_MILESTONES_TASK_DETAILS");
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			pstmt.setString(1, allScenarioIds.toString());
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			Integer prevScenarioId = null;
			Integer currentScenarioId = null;

			Integer prevScenarioMilestoneId = null;
			Integer currentScenarioMilestoneId = null;

			ArrayList taskList = new ArrayList();
			LinkedHashMap milestoneTasksMap = new LinkedHashMap();

			int count = 0;
			
			scenarioTasksMap = new LinkedHashMap();

			while (rs.next()) {
				count++;
				TaskDTO taskDTO = new TaskDTO();

				currentScenarioId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_SCENARIO_ID));
				currentScenarioMilestoneId = new Integer(
						rs.getInt(FinanceFA_Constants.STRING_SCENARIO_MILESTONE_ID));

				if (prevScenarioMilestoneId != null
						&& !(currentScenarioMilestoneId.equals(prevScenarioMilestoneId))) {
					log.debug("changed "+ currentScenarioMilestoneId+"   "+taskList.size());
					milestoneTasksMap.put(prevScenarioMilestoneId, taskList);
					taskList = new ArrayList();
				}
				
				if (prevScenarioId != null
						&& !(currentScenarioId.equals(prevScenarioId))) {
					
					/* Get the size of task list before initializing */
					int taskListSize = taskList.size();
					log.info("Scenario Id [" + prevScenarioId
							+ "]: Scenario milestone id ["
							+ prevScenarioMilestoneId + " has " + taskListSize
							+ " task(s).");
										
					scenarioTasksMap.put(prevScenarioId, milestoneTasksMap);
					milestoneTasksMap = new LinkedHashMap();
					taskList = new ArrayList();
				}

				prevScenarioId = currentScenarioId;
				prevScenarioMilestoneId = currentScenarioMilestoneId;

				/*
				 * For every database record store all column values in an Map.
				 * i.e., column name as key and column value has value so that
				 * the map can be used to populate the DTO or bean object
				 * directly without having to set each property of bean object.
				 */
				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getObject(j));
					}
				}

				/* Print the data read from database */
				if (log.isDebugEnabled()) {
					Iterator iterator = hm.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						log.debug("Property name [" + entry.getKey()
								+ "] value [" + entry.getValue() + "]");
					}
					log.debug("--------------------------------------------");
				}
				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(taskDTO, hm);
				taskList.add(taskDTO);
			}
						
			if (currentScenarioId != null) {
				log.debug("changed "+ currentScenarioMilestoneId+"   "+taskList.size());
				milestoneTasksMap.put(prevScenarioMilestoneId, taskList);
				scenarioTasksMap.put(prevScenarioId, milestoneTasksMap);

				/* Get the size of task list before initializing */
				int taskListSize = taskList.size();
				log.info("Scenario Id [" + prevScenarioId
						+ "]: Scenario milestone id ["
						+ prevScenarioMilestoneId + " has " + taskListSize
						+ " task(s).");
				milestoneTasksMap = new LinkedHashMap();
				taskList = new ArrayList();
			}
			log.info(count + " row(s) retrieved from database");
			log.debug(scenarioTasksMap.size()+" scenario found");
			
			displayTaskDetails();						
			success = true;
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getMilestoneTaskDetails]");
	}

	private void displayTaskDetails() {
		if (log.isDebugEnabled()) {
			try {
				log.debug("Displaying the tasks details");
				if (scenarioTasksMap != null && scenarioTasksMap.size() != 0) {
					Iterator iterator = scenarioTasksMap.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						LinkedHashMap mileTasksMap = (LinkedHashMap) entry
								.getValue();
						log.debug("Scenario id[" + entry.getKey() + "] has ["
								+ mileTasksMap.size() + "] milestones.");
						log.debug("scenario milestone ids are ["
								+ mileTasksMap.keySet() + "]");

						Iterator itr = mileTasksMap.entrySet().iterator();
						while (itr.hasNext()) {
							Map.Entry entry2 = (Map.Entry) itr.next();
							ArrayList tasksList = (ArrayList) entry2.getValue();
							log.debug("Scenario Milestone id["
									+ entry2.getKey() + "] has ["
									+ tasksList.size() + "] tasks.");
							for (int i = 0; i < tasksList.size(); i++) {
								TaskDTO taskDTO = (TaskDTO) tasksList.get(i);
								log.debug("Task Id [" + taskDTO.getTask_id()
										+ "] DTO " + taskDTO);
							}
						}
					}
				}
			} catch (Exception ex) {
				log.error("Error occured while displaying the task details",
						ex);
			}
		}
	}

	/**
	 * Displays all active scenarios details
	 * 
	 * @param activeScenarioList
	 *            array list of active scenarios ScenarioDTO bean
	 * 
	 */
	private void displayActiveScenarioList(ArrayList activeScenarioList) {
		try {
			log.info("Displaying active scenario list");
			
			if (activeScenarioList != null && activeScenarioList.size() != 0) {

				log.info("\t\tActive scenario list\t\t");
				log.info("---------------------------------------------------------");
				log.info("---------------------------------------------------------");
				log.info("Count |\t Scenario Id |\t Milestone Count\t| Process Notification Count\t| DTO");
				for (int i = 0; i < activeScenarioList.size(); i++) {
					log.info("---------------------------------------------------------");
					ScenarioDTO scenarioDTO = (ScenarioDTO) activeScenarioList
							.get(i);
					ArrayList milestoneList = scenarioDTO.getMilestoneList();
					ArrayList processNotificationList = scenarioDTO
							.getProcessNotificationList();
					log.info("["
							+ (i + 1)
							+ "] |\t "
							+ scenarioDTO.getScenario_id()
							+ " |\t "
							+ (milestoneList == null ? "No" : (milestoneList
									.size() + ""))
							+ " milestones |\t "
							+ (processNotificationList == null ? "No"
									: (processNotificationList.size() + ""))
							+ " notifications |\t " + scenarioDTO);
					if (milestoneList != null) {
						int milestoneCount = 1;
						for (int j = 0; j < milestoneList.size(); j++) {
							MilestoneDTO milestoneDTO = (MilestoneDTO) milestoneList
									.get(j);
							ArrayList notificationList = milestoneDTO
									.getNotificationList();
							log.info("---------------------------------------------------------");
							log.info("\t| Milestone Count["
									+ milestoneCount
									+ "] |\t Scenario Milestone Id ["
									+ milestoneDTO.getScenario_milestone_id()
									+ "] Milestone Notification Count ["
									+ (notificationList == null ? "No"
											: (notificationList.size() + ""))
									+ "] DTO: " + milestoneDTO);
							milestoneCount++;
						}
					}
				}
				log.info("---------------------------------------------------------");
			} else {
				log.info("Active scenario list is empty.");
			}
		} catch (Exception ex) {
			log.error(
					"Error occured while displaying all active scenarios details:"
							+ ex.getMessage(), ex);
		}
	}

	
	/**
	 * Adds all the milestones and its task xml to its specific scenario dto.
	 * 
	 * @return array list of active scenarios ScenarioDTO bean
	 */
	private ArrayList prepareScenarioDTOListWithMilestones() {
		log.debug("[Enter prepareScenarioDTOListWithMilestones]");
		Iterator iterator = null;
		ArrayList activeScenarioList = new ArrayList();

		if (scenariosMap != null && scenariosMap.size() != 0) {
			iterator = scenariosMap.entrySet().iterator();

			while (iterator.hasNext()) {
				Map.Entry entry = (Map.Entry) iterator.next();
				Integer caseLaunchCldrId = (Integer) entry.getKey();
				ScenarioDTO scenarioDTO = (ScenarioDTO) entry.getValue();
				
				/* Get the corresponding list of milestones */
				LinkedHashMap milestoneMap = (LinkedHashMap) scenarioMilestonesMap
						.get(caseLaunchCldrId);
				if (milestoneMap != null) {
					ArrayList milestoneList = new ArrayList(milestoneMap
							.values());
					log.debug("Case Launch Cldr Id:" + caseLaunchCldrId
							+ " has " + milestoneList.size() + " milestone(s)");
					scenarioDTO.setMilestoneList(milestoneList);

					/* Prepare the task xml for each scenario */
					Object obj = scenarioTasksMap.get(scenarioDTO
							.getScenario_id());
					if (obj instanceof LinkedHashMap) {
						LinkedHashMap milestoneTasksMap = (LinkedHashMap) obj;

						boolean flag = FinanceFA_XMLUtilities.prepareTasksXML(
								scenarioDTO, milestoneTasksMap);
						if (!flag) {
							log.error("Error occured while preparing the tasks xml for scenario "
									+ scenarioDTO
									+ ". Ignoring the task xml field, continuing with prepare remaining fields.");
						}
					} else {
						log.info("Unable to get the tasks details map. Scenario id "
								+ scenarioDTO.getScenario_id()
								+ " is not present in the scenarioTasksMap or No tasks present for the current scenario.");
					}

				} else {
					log.debug("No active milestone found for case launch cldr id "
							+ caseLaunchCldrId);
				}
				/* Add the scenario to active scenario list */
				activeScenarioList.add(scenarioDTO);
			}
		}
		log.debug("[Exit prepareScenarioDTOListWithMilestones]");
		return activeScenarioList;
	}

	/**
	 * @param milestoneTasksMap
	 * @param milestoneList
	 * @return
	 */
	private LinkedHashMap getActiveMilestoneTasks(
			LinkedHashMap milestoneTasksMap, ArrayList milestoneList) {
		log.debug("[Enter getActiveMilestoneTasks]");
		LinkedHashMap activeMilestoneTasksMap = new LinkedHashMap();
		log.debug("Fetching the active milestones task details from the map");
		if (milestoneList == null || milestoneList.size() == 0) {
			log.debug("Milestone list is empty");
			return null;
		}

		if (milestoneTasksMap == null || milestoneTasksMap.size() == 0) {
			log.debug("Milestone task map is empty");
			return null;
		}

		log.debug("Total "+milestoneTasksMap.size()+" milestone's task are present in the map");
		log.debug(milestoneTasksMap.size()+" active milestones are present");
		Iterator iterator = milestoneTasksMap.entrySet().iterator();
		int count = milestoneList.size();
		while (iterator.hasNext()) {
			Map.Entry entry = (Map.Entry) iterator.next();
			Integer scenarioMilestoneId = (Integer) entry.getKey();

			for (int i = 0; i < count; i++) {
				MilestoneDTO milestoneDTO = (MilestoneDTO) milestoneList.get(i);
				if (scenarioMilestoneId.equals(milestoneDTO
						.getScenario_milestone_id())) {
					log.debug("Scenario milestone id [" + scenarioMilestoneId
							+ "] matched");
					if (milestoneDTO.getMilestone_isactive() != null
							&& milestoneDTO.getMilestone_isactive().toString()
									.equalsIgnoreCase("y")) {
						log.debug("Scenario milestone id ["
								+ scenarioMilestoneId
								+ "] is active and inserted into updated tasks map");
						activeMilestoneTasksMap.put(entry.getKey(), entry
								.getValue());
					}
					break;
				}
			}
		}
		log.debug("Total number of active milestones ["
				+ activeMilestoneTasksMap.size() + "]");
		log.debug("[Exit getActiveMilestoneTasks]");
		return activeMilestoneTasksMap;
	}

	/**
	 * Displays the scenario details
	 */
	private void displayAllMaps() {
		log.debug("Displaying all scenarios");
		try {
			if(log.isDebugEnabled()) {
				int count = 1;
				Iterator iterator = null;
				if (scenariosMap != null && scenariosMap.size() != 0) {
					iterator = scenariosMap.entrySet().iterator();
					log.debug("\t\tAll Scenarios Map\t\t");
					log.debug("---------------------------------------------------------");
					log.debug("---------------------------------------------------------");
					log.debug("Count |\t Case Launch Cldr Id\t| DTO");
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						Integer caseLaunchCldrId = (Integer) entry.getKey();
		
						log.debug("---------------------------------------------------------");
						log.debug("[" + count + "] |\t " + caseLaunchCldrId + "\t  | "
								+ entry.getValue());
						count++;
					}
					log.debug("---------------------------------------------------------");
				} else {
					log.debug("Scenarios Map is empty.");
				}
		
				log.debug("Displaying all scenario milestones");
				if (scenarioMilestonesMap != null && scenarioMilestonesMap.size() != 0) {
					iterator = scenarioMilestonesMap.entrySet().iterator();
					count = 1;
					log.debug("\t\tAll Scenario Milestones Map\t\t");
					log.debug("---------------------------------------------------------");
					log.debug("---------------------------------------------------------");
					log.debug("Count |\t Case Launch Cldr Id\t| Milestones Count");
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						Integer caseLaunchCldrId = (Integer) entry.getKey();
						LinkedHashMap milestoneMap = (LinkedHashMap) entry.getValue();
						log.debug("---------------------------------------------------------");
						log.debug("[" + count + "] |\t " + caseLaunchCldrId + "\t  | "
								+ +milestoneMap.size() + " milestones");
		
						Iterator iterator2 = milestoneMap.entrySet().iterator();
						int milestoneCount = 1;
						while (iterator2.hasNext()) {
							Map.Entry entry2 = (Map.Entry) iterator2.next();
							log.debug("---------------------------------------------------------");
							log.debug("\t| [" + milestoneCount
									+ "] |\t Scenario Milestone Id [" + entry2.getKey()
									+ "] DTO " + (MilestoneDTO) entry2.getValue());
							milestoneCount++;
						}
						count++;
					}
					log.debug("---------------------------------------------------------");
				} else {
					log.debug("Scenario Milestones Map is empty.");
				}
				
				log.debug("Displaying all milestone tasks");
				if (scenarioTasksMap != null && scenarioTasksMap.size() != 0) {
					iterator = scenarioTasksMap.entrySet().iterator();
					count = 1;
					log.debug("\t\tAll Scenario Tasks Map\t\t");
					log.debug("---------------------------------------------------------");
					log.debug("---------------------------------------------------------");
					log.debug("Count |\t Scenario Id\t| Milestones Count");
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						Integer scenarioId = (Integer) entry.getKey();
						LinkedHashMap milestoneTasksMap = (LinkedHashMap) entry.getValue();
						log.debug("---------------------------------------------------------");
						log.debug("[" + count + "] |\t " + scenarioId + "\t  | "
								+ +milestoneTasksMap.size() + " milestones");
		
						Iterator iterator2 = milestoneTasksMap.entrySet().iterator();
						int milestoneCount = 1;
						while (iterator2.hasNext()) {
							Map.Entry entry2 = (Map.Entry) iterator2.next();
							ArrayList tasksList = (ArrayList) entry2.getValue();
							log.debug("---------------------------------------------------------");
							log.debug("\t| ["
									+ milestoneCount
									+ "] |\t Scenario Milestone Id ["
									+ entry2.getKey()
									+ "] Tasks Count  ["
									+ (tasksList != null ? tasksList
											.size() : 0) + "]");
							for(int i=0; i<tasksList.size(); i++) {
								TaskDTO taskDTO = (TaskDTO) tasksList.get(i);
								log.debug("\t\t| [" + (i + 1)
										+ "] |\t Task Id ["
										+ taskDTO.getTask_id() + "] DTO "
										+ taskDTO);
							}
							milestoneCount++;
						}
						count++;
					}
					log.debug("---------------------------------------------------------");
				} else {
					log.debug("Scenario Tasks Map is empty.");
				}
			}
		} catch (Exception ex) {
			log.error(
					"Error occured while displaying all active scenarios maps:"
							+ ex.getMessage(), ex);
		}
	}

	private LinkedHashMap getScenarioDetails(int scenarioId) {
		log.debug("[Enter getScenarioDetails]");
		scenariosMap = new LinkedHashMap();

		boolean success = false;
		try {
			String sql = PropertyLoader.props.getProperty("SQL_GET_SCENARIO_DETAILS");
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			pstmt.setInt(1, scenarioId);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			while (rs.next()) {
				ScenarioDTO scenarioDTO = new ScenarioDTO();
				
				Integer caseLaunchCldrId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID));

				Integer eachScenarioId = new Integer(rs.getInt(FinanceFA_Constants.STRING_SCENARIO_ID));
				
				MDC.put(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID,
						caseLaunchCldrId);
				MDC.put(FinanceFA_Constants.STRING_SCENARIO_ID, eachScenarioId);

				/* prepare a comma separated string of all case launch cldr ids */
				allCaseLaunchCldrIds.append(caseLaunchCldrId + ",");

				/* prepare a comma separated string of all case launch cldr ids */
				allScenarioIds.append(eachScenarioId + ",");

				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getString(j));
					}
				}

				/* Print the data read from database */
				if (log.isDebugEnabled()) {
					Iterator iterator = hm.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						log.debug("Property name [" + entry.getKey()
								+ "] value [" + entry.getValue() + "]");
					}
					log.debug("--------------------------------------------");
				}

				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(scenarioDTO, hm);
				scenariosMap.put(caseLaunchCldrId, scenarioDTO);
				
				MDC.remove(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID);
				MDC.remove(FinanceFA_Constants.STRING_SCENARIO_ID);
				
			}
			log.info(scenariosMap.size() + " row(s) retrieved from database");
			success = true;
			log.info("*********** " + scenariosMap.size()
					+ " scenarios found ***********");
			if (scenariosMap.size() > 0) {
				log.debug("Scenarios details are:" + scenariosMap + ".");
				log.debug("Comma separated list of active case launch cldr id:"
						+ allCaseLaunchCldrIds);
				log.debug("Comma separated list of active scenario id:"
						+ allScenarioIds);
			}

			/* Remove the last trailing comma */
			if (allCaseLaunchCldrIds.length() != 0) {
				allCaseLaunchCldrIds
						.deleteCharAt(allCaseLaunchCldrIds.length() - 1);
				log.debug("After removing the last comma allCaseLaunchCldrIds:"
						+ allCaseLaunchCldrIds);
			}
			if (allScenarioIds.length() != 0) {
				allScenarioIds.deleteCharAt(allScenarioIds.length() - 1);
				log.debug("After removing the last comma allScenarioIds:"
						+ allScenarioIds);
			}
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getScenarioDetails]");
		return scenariosMap;
	}

	private LinkedHashMap getScenarioDetails() {
		log.debug("[Enter getScenarioDetails]");
		scenariosMap = new LinkedHashMap();

		boolean success = false;
		try {
			String sql = "SELECT calendar.CASE_LAUNCH_CLDR_ID, calendar.SCENARIO_ID, calendar.START_DATE, calendar.status, calendar.WORKING_HRS_ID, calendar.exception_log, work.START_TIME, work.END_TIME, calendar.PROCESS_SLA, calendar.SLA_TYPE_ID, calendar.SLA_CALCULATION_ID, scenario.LAUNCH_TYPE_ID, scenario.FREQUENCY_ID, scenario.SCENARIO_TYPE_ID, scenarioType.WF_DEFINITION, scenario.SUBPROCESS_NAME, stream.STREAM_NAME, stream.STREAM_ID, process.PROCESS_ID, process.PROCESS_NAME, process.PROCESS_TEAM FROM FN_FA_TBL_CASE_LAUNCH_CLDR calendar, FN_FA_TBL_SCENARIO_MASTER scenario, FN_TBL_WORKING_HRS_MASTER_TABLE work, FN_TBL_SCENARIO_TYPE_MASTER scenarioType, FN_TBL_STREAM_MASTER stream, FN_FA_TBL_PROCESS_MASTER process where DATE(start_date) <= current date and (LOWER(status) <> LOWER('S') or status is null) and calendar.SCENARIO_ID = scenario.SCENARIO_ID and scenario.STREAM_ID = 2 and scenario.STREAM_ID = stream.STREAM_ID and LOWER(scenario.ISACTIVE) = LOWER('Y') and calendar.WORKING_HRS_ID = work.WORKING_HRS_ID and scenario.SCENARIO_TYPE_ID = scenarioType.SCENARIO_TYPE_ID and scenario.PROCESS_ID = process.PROCESS_ID ORDER BY calendar.CASE_LAUNCH_CLDR_ID";
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			while (rs.next()) {
				ScenarioDTO scenarioDTO = new ScenarioDTO();
				
				Integer caseLaunchCldrId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID));

				Integer scenarioId = new Integer(rs.getInt(FinanceFA_Constants.STRING_SCENARIO_ID));

				if (log.isDebugEnabled()) {
					MDC.put(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID, caseLaunchCldrId);
					MDC.put(FinanceFA_Constants.STRING_SCENARIO_ID, scenarioId);
				}

				/* prepare a comma separated string of all case launch cldr ids */
				allCaseLaunchCldrIds.append(caseLaunchCldrId + ",");

				/* prepare a comma separated string of all case launch cldr ids */
				allScenarioIds.append(scenarioId + ",");

				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getString(j));
					}
				}

				/* Print the data read from database */
				Iterator iterator = hm.entrySet().iterator();
				while (iterator.hasNext()) {
					Map.Entry entry = (Map.Entry) iterator.next();
					log.debug("Property name [" + entry.getKey() + "] value ["
							+ entry.getValue() + "]");
				}
				log.debug("--------------------------------------------");

				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(scenarioDTO, hm);
				scenariosMap.put(caseLaunchCldrId, scenarioDTO);
				
				if (log.isDebugEnabled()) {
					MDC.remove(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID);
					MDC.remove(FinanceFA_Constants.STRING_SCENARIO_ID);
				}
			}
			log.info(scenariosMap.size() + " row(s) retrieved from database");
			success = true;
			log.info("*********** " + scenariosMap.size()
					+ " active scenarios found ***********");
			if (scenariosMap.size() > 0) {
				log.debug("Scenarios details are:" + scenariosMap + ".");
				log.debug("Comma separated list of active case launch cldr id:"
						+ allCaseLaunchCldrIds);
				log.debug("Comma separated list of active scenario id:"
						+ allScenarioIds);
			}

			/* Remove the last trailing comma */
			if (allCaseLaunchCldrIds.length() != 0) {
				allCaseLaunchCldrIds
						.deleteCharAt(allCaseLaunchCldrIds.length() - 1);
				log.debug("After removing the last comma allCaseLaunchCldrIds:"
						+ allCaseLaunchCldrIds);
			}
			if (allScenarioIds.length() != 0) {
				allScenarioIds.deleteCharAt(allScenarioIds.length() - 1);
				log.debug("After removing the last comma allScenarioIds:"
						+ allScenarioIds);
			}
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getScenarioDetails]");
		return scenariosMap;
	}
	
	/**
	 * @param allCaseLaunchCldrIds
	 * @return
	 * 
	 */
	private LinkedHashMap getScenarioMilestones(
			String allCaseLaunchCldrIds) {
		log.debug("[Enter getScenarioMilestones]");
		scenarioMilestonesMap = new LinkedHashMap();

		boolean success = false;
		try {
			String sql = PropertyLoader.props.getProperty("SQL_GET_SCENARIO_MILESTONES");
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			pstmt.setString(1, allCaseLaunchCldrIds);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			LinkedHashMap milestoneMap = new LinkedHashMap();
			Integer currentCaseLaunchCldrId = null;
			Integer nextCaseLaunchCldrId = null;
			Integer scenarioMilestoneId = null;
			int count = 0;

			while (rs.next()) {
				count++;
				MilestoneDTO milestoneDTO = new MilestoneDTO();
				nextCaseLaunchCldrId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID));
				scenarioMilestoneId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_SCENARIO_MILESTONE_ID));

				if ((currentCaseLaunchCldrId != null)
						&& !(nextCaseLaunchCldrId
								.equals(currentCaseLaunchCldrId))) {

					// means for new CASE_LAUNCH_CLDR_ID
					// log.debug("means for new CASE_LAUNCH_CLDR_ID");
					scenarioMilestonesMap.put(currentCaseLaunchCldrId,
							milestoneMap);
					log.info("Case launch cldr id [" + currentCaseLaunchCldrId
							+ "] has [" + milestoneMap.size()
							+ "] milestone(s).");

					// Reset its value
					milestoneMap = new LinkedHashMap();
				}

				currentCaseLaunchCldrId = nextCaseLaunchCldrId;

				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getObject(j));
					}
				}

				/* Print the data read from database */
				if (log.isDebugEnabled()) {
					Iterator iterator = hm.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						log.debug("Property name [" + entry.getKey()
								+ "] value [" + entry.getValue() + "]");
					}
					log.debug("--------------------------------------------");
				}
				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(milestoneDTO, hm);
				milestoneMap.put(scenarioMilestoneId, milestoneDTO);
			}
			if (nextCaseLaunchCldrId != null) {

				// this is for the last row
				scenarioMilestonesMap
						.put(currentCaseLaunchCldrId, milestoneMap);
				log.info("Case launch cldr id [" + currentCaseLaunchCldrId
						+ "] has [" + milestoneMap.size() + "] milestone(s).");
			} else {
				log.info("No milestone details found. ResultSet is empty.");
			}
			success = true;
			log.info(count + " row(s) retrieved from database");
			log.debug(scenarioMilestonesMap.size()
					+ " scenario milestones found.");
			log.debug("Scenarios Milestone details are:"
					+ scenarioMilestonesMap + ".");
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getScenarioMilestones]");
		return scenarioMilestonesMap;
	}

	/**
	 * @param allCaseLaunchCldrIds
	 * @return
	 * 
	 */
	private LinkedHashMap getScenarioActiveMilestones(
			String allCaseLaunchCldrIds) {
		log.debug("[Enter getScenarioActiveMilestones]");
		scenarioMilestonesMap = new LinkedHashMap();

		boolean success = false;
		try {
			String sql = PropertyLoader.props.getProperty("SQL_GET_SCENARIO_ACTIVE_MILESTONES");
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			pstmt.setString(1, allCaseLaunchCldrIds);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			LinkedHashMap milestoneMap = new LinkedHashMap();
			Integer currentCaseLaunchCldrId = null;
			Integer nextCaseLaunchCldrId = null;
			Integer scenarioMilestoneId = null;
			int count = 0;

			while (rs.next()) {
				count++;
				MilestoneDTO milestoneDTO = new MilestoneDTO();
				nextCaseLaunchCldrId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID));
				scenarioMilestoneId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_SCENARIO_MILESTONE_ID));
				
				/* prepare a comma separated string of all active milestone ids */
				allActiveMilestoneIds.append(scenarioMilestoneId + ",");

				if ((currentCaseLaunchCldrId != null)
						&& !(nextCaseLaunchCldrId
								.equals(currentCaseLaunchCldrId))) {

					// means for new CASE_LAUNCH_CLDR_ID
					// log.debug("means for new CASE_LAUNCH_CLDR_ID");
					scenarioMilestonesMap.put(currentCaseLaunchCldrId,
							milestoneMap);
					log.info("Case launch cldr id [" + currentCaseLaunchCldrId
							+ "] has [" + milestoneMap.size()
							+ "] milestone(s).");

					// Reset its value
					milestoneMap = new LinkedHashMap();
				}

				currentCaseLaunchCldrId = nextCaseLaunchCldrId;

				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getObject(j));
					}
				}

				/* Print the data read from database */
				if (log.isDebugEnabled()) {
					Iterator iterator = hm.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						log.debug("Property name [" + entry.getKey()
								+ "] value [" + entry.getValue() + "]");
					}
					log.debug("--------------------------------------------");
				}
				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(milestoneDTO, hm);
				milestoneMap.put(scenarioMilestoneId, milestoneDTO);
			}
			if (nextCaseLaunchCldrId != null) {

				// this is for the last row
				scenarioMilestonesMap
						.put(currentCaseLaunchCldrId, milestoneMap);
				log.info("Case launch cldr id [" + currentCaseLaunchCldrId
						+ "] has [" + milestoneMap.size() + "] milestone(s).");
			} else {
				log.info("No milestone details found. ResultSet is empty.");
			}
			
			/* Remove the last trailing comma */
			if (allActiveMilestoneIds.length() != 0) {
				allActiveMilestoneIds
						.deleteCharAt(allActiveMilestoneIds.length() - 1);
				log.debug("After removing the last comma allActiveMilestoneIds:"
						+ allActiveMilestoneIds);
			}
			success = true;
			log.info(count + " row(s) retrieved from database");
			log.debug(scenarioMilestonesMap.size()
					+ " scenario active milestones found.");
			log.debug("Scenarios Milestone details are:"
					+ scenarioMilestonesMap + ".");
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for scenario active milestones. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getScenarioActiveMilestones]");
		return scenarioMilestonesMap;
	}

	/**
	 * @param string
	 */
	private void getNotificationDetails(String allCaseLaunchCldrIds) {
		log.debug("[Enter getNotificationDetails]");

		boolean success = false;
		try {
			String sql = PropertyLoader.props.getProperty("SQL_GET_NOTIFICATION");
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			pstmt.setString(1, allCaseLaunchCldrIds);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			Integer prevCaseLaunchCldrId = null;
			Integer currentCaseLaunchCldrId = null;

			String prevNotificationCategory = null;
			String currentNotificationCategory = null;

			Integer prevScenarioMilestoneId = null;
			Integer currentScenarioMilestoneId = null;

			ArrayList notificationList = null;
			int count = 0;

			while (rs.next()) {
				count++;
				NotificationDTO notificationDTO = new NotificationDTO();

				currentCaseLaunchCldrId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID));
				currentScenarioMilestoneId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_SCENARIO_MILESTONE_ID));
				currentNotificationCategory = rs
						.getString(FinanceFA_Constants.STRING_NOTIFICATION_CATEGORY);

				if ((!(currentCaseLaunchCldrId.equals(prevCaseLaunchCldrId)))
						|| !(currentNotificationCategory
								.equals(prevNotificationCategory))
						|| !(currentScenarioMilestoneId
								.equals(prevScenarioMilestoneId))) {

					/* Get the size of notification list before initializing */
					if (prevCaseLaunchCldrId != null) {
						int notificationListSize = notificationList.size();
						log.info("Case Launch Cldr Id ["
										+ prevCaseLaunchCldrId
										+ "]: "
										+ (prevNotificationCategory
												.equalsIgnoreCase("Milestone") ? "Scenario Milestone Id:"
												+ prevScenarioMilestoneId
												: "") + " has "
										+ notificationListSize + " "
										+ prevNotificationCategory
										+ " notification(s).");
					}
					notificationList = new ArrayList();
					if (currentNotificationCategory.equalsIgnoreCase("Process")) {

						/*
						 * Get the scenario DTO object for the current case
						 * launch cldr id
						 */						
						Object objDTO = scenariosMap
								.get(currentCaseLaunchCldrId);
						if (objDTO != null || objDTO instanceof ScenarioDTO) {
							// log.debug("currentCaseLaunchCldrId:Process:"+currentScenarioMilestoneId);
							ScenarioDTO scenarioDTO = (ScenarioDTO) objDTO;
							scenarioDTO
									.setProcessNotificationList(notificationList);

						} else {
							log.error("Scenario DTO object for CaseLaunchCldrId "
											+ currentCaseLaunchCldrId
											+ " from scenarios map is null "
											+ "or not an instance of ScenarioDTO");
						}
					} else if (currentNotificationCategory
							.equalsIgnoreCase("Milestone")) {

						/*
						 * Get the milestone DTO object for the current case
						 * launch cldr id
						 */
						Object objDTO = scenarioMilestonesMap
								.get(currentCaseLaunchCldrId);
						if (objDTO != null) {
							// log.debug("currentCaseLaunchCldrId:"+currentCaseLaunchCldrId+":currentScenarioMilestoneId:Milestone:"+currentScenarioMilestoneId);
							// log.debug(objDTO.toString());
							MilestoneDTO milestoneDTO = (MilestoneDTO) (((LinkedHashMap) objDTO)
									.get(currentScenarioMilestoneId));
							if (milestoneDTO != null
									|| milestoneDTO instanceof MilestoneDTO) {
								milestoneDTO
										.setNotificationList(notificationList);
							} else {
								log.debug("Milestone DTO for the scenario milestone id ["
										+ currentScenarioMilestoneId
										+ "] not found for the current notifications; may be the milestone is inactive");
							}

						} else {
							log.debug("Milestone DTO object for CaseLaunchCldrId "
											+ currentCaseLaunchCldrId
											+ " from scenario milestones map is null "
											+ "or not an instance of MilestoneDTO");
						}
					}

				}

				prevCaseLaunchCldrId = currentCaseLaunchCldrId;
				prevNotificationCategory = currentNotificationCategory;
				prevScenarioMilestoneId = currentScenarioMilestoneId;

				/*
				 * For every database record store all column values in an Map.
				 * i.e., column name as key and column value has value so that
				 * the map can be used to populate the DTO or bean object
				 * directly without having to set each property of bean object.
				 */
				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getObject(j));
					}
				}

				/* Print the data read from database */
				if (log.isDebugEnabled()) {
					Iterator iterator = hm.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						log.debug("Property name [" + entry.getKey()
								+ "] value [" + entry.getValue() + "]");
					}
					log.debug("--------------------------------------------");
				}
				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(notificationDTO, hm);
				notificationList.add(notificationDTO);
			}
			log.info(count + " row(s) retrieved from database");
			success = true;
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getNotificationDetails]");
	}

	
	/**
	 * @param allActiveMilestoneIds 
	 * @param string
	 */
	private void getActiveNotificationDetails(String allCaseLaunchCldrIds, StringBuffer allActiveMilestoneIds) {
		log.debug("[Enter getActiveNotificationDetails]");

		boolean success = false;
		try {
			String sql = "SELECT NOTIFICATION_ID, CASE_LAUNCH_CLDR_ID, notification.SCENARIO_ID, NOTIFICATION_CATEGORY, NOTIFICATION_TYPE, NOTIFICATION_LEVEL, OFFSET, LAST_UPDATED_BY, LAST_UPDATED_DATE, NOTIFICATION_TO, NOTIFICATION_CC, NOTIFICATION_BCC, SCENARIO_MILESTONE_ID, NOTIFICATION_EMAIL_IS_ENABLED FROM FN_FA_TBL_CASE_LAUNCH_CLDR calendar INNER JOIN FN_FA_TBL_NOTIFICATION_MASTER notification ON calendar.SCENARIO_ID = notification.SCENARIO_ID where calendar.CASE_LAUNCH_CLDR_ID in (?) and (notification.SCENARIO_MILESTONE_ID in ("
					+ allActiveMilestoneIds.toString()
					+ ") or notification.SCENARIO_MILESTONE_ID is null) ORDER BY CASE_LAUNCH_CLDR_ID, SCENARIO_MILESTONE_ID, NOTIFICATION_CATEGORY, NOTIFICATION_TYPE DESC";
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			pstmt.setString(1, allCaseLaunchCldrIds);
			
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			Integer prevCaseLaunchCldrId = null;
			Integer currentCaseLaunchCldrId = null;

			String prevNotificationCategory = null;
			String currentNotificationCategory = null;

			Integer prevScenarioMilestoneId = null;
			Integer currentScenarioMilestoneId = null;

			ArrayList notificationList = null;
			int count = 0;

			while (rs.next()) {
				count++;
				NotificationDTO notificationDTO = new NotificationDTO();

				currentCaseLaunchCldrId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID));
				currentScenarioMilestoneId = new Integer(rs
						.getInt(FinanceFA_Constants.STRING_SCENARIO_MILESTONE_ID));
				currentNotificationCategory = rs
						.getString(FinanceFA_Constants.STRING_NOTIFICATION_CATEGORY);

				if ((!(currentCaseLaunchCldrId.equals(prevCaseLaunchCldrId)))
						|| !(currentNotificationCategory
								.equals(prevNotificationCategory))
						|| !(currentScenarioMilestoneId
								.equals(prevScenarioMilestoneId))) {

					/* Get the size of notification list before initializing */
					if (prevCaseLaunchCldrId != null) {
						int notificationListSize = notificationList.size();
						log.info("Case Launch Cldr Id ["
										+ prevCaseLaunchCldrId
										+ "]: "
										+ (prevNotificationCategory
												.equalsIgnoreCase("Milestone") ? "Scenario Milestone Id:"
												+ prevScenarioMilestoneId
												: "") + " has "
										+ notificationListSize + " "
										+ prevNotificationCategory
										+ " notification(s).");
					}
					notificationList = new ArrayList();
					if (currentNotificationCategory.equalsIgnoreCase("Process")) {

						/*
						 * Get the scenario DTO object for the current case
						 * launch cldr id
						 */						
						Object objDTO = scenariosMap
								.get(currentCaseLaunchCldrId);
						if (objDTO != null || objDTO instanceof ScenarioDTO) {
							// log.debug("currentCaseLaunchCldrId:Process:"+currentScenarioMilestoneId);
							ScenarioDTO scenarioDTO = (ScenarioDTO) objDTO;
							scenarioDTO
									.setProcessNotificationList(notificationList);

						} else {
							log.error("Scenario DTO object for CaseLaunchCldrId "
											+ currentCaseLaunchCldrId
											+ " from scenarios map is null "
											+ "or not an instance of ScenarioDTO");
						}
					} else if (currentNotificationCategory
							.equalsIgnoreCase("Milestone")) {

						/*
						 * Get the milestone DTO object for the current case
						 * launch cldr id
						 */
						Object objDTO = scenarioMilestonesMap
								.get(currentCaseLaunchCldrId);
						if (objDTO != null) {
							// log.debug("currentCaseLaunchCldrId:"+currentCaseLaunchCldrId+":currentScenarioMilestoneId:Milestone:"+currentScenarioMilestoneId);
							// log.debug(objDTO.toString());
							MilestoneDTO milestoneDTO = (MilestoneDTO) (((LinkedHashMap) objDTO)
									.get(currentScenarioMilestoneId));
							if (milestoneDTO != null
									|| milestoneDTO instanceof MilestoneDTO) {
								milestoneDTO
										.setNotificationList(notificationList);
							} else {
								log.debug("Milestone DTO for the scenario milestone id ["
										+ currentScenarioMilestoneId
										+ "] not found for the current notifications; may be the milestone is inactive");
							}

						} else {
							log.debug("Milestone DTO object for CaseLaunchCldrId "
											+ currentCaseLaunchCldrId
											+ " from scenario milestones map is null "
											+ "or not an instance of MilestoneDTO");
						}
					}

				}

				prevCaseLaunchCldrId = currentCaseLaunchCldrId;
				prevNotificationCategory = currentNotificationCategory;
				prevScenarioMilestoneId = currentScenarioMilestoneId;

				/*
				 * For every database record store all column values in an Map.
				 * i.e., column name as key and column value has value so that
				 * the map can be used to populate the DTO or bean object
				 * directly without having to set each property of bean object.
				 */
				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getObject(j));
					}
				}

				/* Print the data read from database */
				if (log.isDebugEnabled()) {
					Iterator iterator = hm.entrySet().iterator();
					while (iterator.hasNext()) {
						Map.Entry entry = (Map.Entry) iterator.next();
						log.debug("Property name [" + entry.getKey()
								+ "] value [" + entry.getValue() + "]");
					}
					log.debug("--------------------------------------------");
				}
				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(notificationDTO, hm);
				notificationList.add(notificationDTO);
			}
			log.info(count + " row(s) retrieved from database");
			success = true;
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getActiveNotificationDetails]");
	}

	
	/**
	 * @param scenarioDTO
	 * @return
	 * @throws Exception
	 */
	public ArrayList processActiveCalendarScenarios(ScenarioDTO scenarioDTO)
			throws Exception {
		log.debug("[Enter processActiveCalendarScenarios]");
		
		log.debug("Storing the future scenario configuration...");
		if (!FinanceFA_Constants.SCENARIO_FAILURE.equals(scenarioDTO.getStatus())) {
			storeScenarioFutureCalendar(scenarioDTO, FinanceFA_Constants.STRING_CRON);			
		} else {
			log.info("The status of the scenario is failure; hence we are not storing "
							+ "its future configuration");
		}
		return getScenarioUnits(scenarioDTO);

	}

	/**
	 * @param scenarioDTO
	 */
	private ArrayList getScenarioUnits(ScenarioDTO scenarioDTO) {
		log.debug("[Enter getScenarioUnits]");
		int launchTypeId = scenarioDTO.getLaunch_type_id().intValue();
		ArrayList scenarioUnitList = new ArrayList();
		log.debug("Case launch Cldr Id:" + scenarioDTO.getCase_launch_cldr_id()
				+ " Launch Type id:" + scenarioDTO.getLaunch_type_id());
		String sql = "";

		/*
		 * For failed scenario, read exception log and prepare the scenario unit
		 * list
		 */
		if (FinanceFA_Constants.SCENARIO_FAILURE.equals(scenarioDTO.getStatus())) {
			return getScenarioUnitsFromExceptionLog(scenarioDTO);
		}		

		if (launchTypeId == 1) {
			// for LOB
			log.debug("Launch type is L");
			sql = "SELECT lobmaster.LOB_ID, LOB_NAME FROM FN_FA_TBL_SCENARIO_LOB_MAPPING lobmapping JOIN FN_FA_TBL_LOB_MASTER lobmaster ON lobmapping.LOB_ID = lobmaster.LOB_ID where SCENARIO_ID = "
					+ scenarioDTO.getScenario_id()
					+ " order by lobmaster.LOB_ID";
			
		} else if (launchTypeId == 2) {
			// For PAN India
			log.debug("Launch type is PAN");
			ScenarioUnitDTO scenarioUnitDTO = new ScenarioUnitDTO();
			scenarioUnitList.add(scenarioUnitDTO);
			return scenarioUnitList;
			
		} else if (launchTypeId == 3) {
			// For OLC
			log.debug("Launch type is OLC");
			log.error("Launch Type Id for the Scenario Id "
					+ scenarioDTO.getScenario_id()
					+ " is wrongly configured to 3 (which means OLC operator level). Please change it.");
			
		} else if (launchTypeId == 4) {
			// For LC
			log.debug("Launch type is LC");
			sql = "select LOB_ID, LOB_NAME, circlemaster.CIRCLE_ID, CIRCLE_NAME from FN_FA_TBL_CIRCLE_MASTER circlemaster join (select lobcirclemapping.LOB_ID, LOB_NAME, CIRCLE_ID from FN_FA_TBL_LOB_CIRCLE_MAPPING lobcirclemapping join (SELECT lobmapping.LOB_ID, LOB_NAME FROM FN_FA_TBL_SCENARIO_LOB_MAPPING lobmapping JOIN FN_FA_TBL_LOB_MASTER lobmaster ON lobmapping.LOB_ID = lobmaster.LOB_ID where SCENARIO_ID = "
					+ scenarioDTO.getScenario_id()
					+ ") lobmapping on lobcirclemapping.LOB_ID = lobmapping.LOB_ID and STREAM_ID = "
					+ scenarioDTO.getStream_id()
					+ ") scenariolobcircle ON circlemaster.CIRCLE_ID = scenariolobcircle.CIRCLE_ID order by LOB_ID, circlemaster.CIRCLE_ID";
		} else {
			log.error("Unknown Launch Type Id for the Scenario Id "
					+ scenarioDTO.getScenario_id()
					+ ". Please change it correct one.");
		}
		boolean success = false;
		try {

			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			ResultSet rs = pstmt.executeQuery();
			ResultSetMetaData rsmd = rs.getMetaData();
			int numberOfColumns = rsmd.getColumnCount();
			log.debug("Number of columns in each selected record is:"
					+ numberOfColumns);

			while (rs.next()) {
				ScenarioUnitDTO scenarioUnitDTO = new ScenarioUnitDTO();

				LinkedHashMap hm = new LinkedHashMap();
				for (int j = 1; j <= numberOfColumns; j++) {
					if (rs.getObject(j) instanceof Time) {
						hm.put(rsmd.getColumnName(j).toLowerCase(), ""
								+ rs.getTime(j));
					} else {
						hm.put(rsmd.getColumnName(j).toLowerCase(), rs
								.getObject(j));
					}
				}

				/* Print the data read from database */
				Iterator iterator = hm.entrySet().iterator();
				while (iterator.hasNext()) {
					Map.Entry entry = (Map.Entry) iterator.next();
					log.debug("Property name [" + entry.getKey() + "] value ["
							+ entry.getValue() + "]");
				}
				log.debug("--------------------------------------------");

				/*
				 * Examines all of the Map parameters to see if any match a bean
				 * property (i.e., a setXxx method) in the object. If so, the
				 * map parameter value is passed to that method. If the method
				 * expects an int, Integer, double, Double, or any of the other
				 * primitive or wrapper types, parsing and conversion is done
				 * automatically. If the request parameter value is malformed
				 * (cannot be converted into the expected type), numeric
				 * properties are assigned zero and boolean properties are
				 * assigned false: no exception is thrown.
				 */
				Utilities.populateBean(scenarioUnitDTO, hm);
				scenarioUnitList.add(scenarioUnitDTO);
			}
			log.info(scenarioUnitList.size()
					+ " row(s) retrieved from database");
			success = true;
			log.debug(scenarioUnitList.size() + " scenario units found.");
			log.debug("Scenarios details are:" + scenarioUnitList + ".");
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for scenario units. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit getScenarioUnits]");
		return scenarioUnitList;
	}

	/**
	 * @param scenarioDTO
	 * @return
	 */
	private ArrayList getScenarioUnitsFromExceptionLog(ScenarioDTO scenarioDTO) {
		log.debug("Getting scenario units for case launch cldr id :"
				+ scenarioDTO.getCase_launch_cldr_id());
		ArrayList scenarioUnitList = new ArrayList();
		String exceptionLog = "";
		if (scenarioDTO.getException_log() != null) {
			// get the log
			exceptionLog = scenarioDTO.getException_log().toString();
			scenarioUnitList = FinanceFA_Utilities
					.getScenarioUnitsFromXMLString(exceptionLog);
		}
		return scenarioUnitList;
	}

	public int updateScenarioLaunchStatus(ScenarioDTO scenarioDTO,
			String updatedBy) {
		log.debug("[Enter updateScenarioLaunchStatus]");

		boolean success = false;
		int updatedRowCount = 0;
		try {
			String sql = "";
			if (scenarioDTO.getStatus()
					.equals(FinanceFA_Constants.SCENARIO_SUCESS)) {
				sql = "UPDATE FN_FA_TBL_CASE_LAUNCH_CLDR SET STATUS = 'S', UPDATED_BY = '"
						+ updatedBy
						+ "', UPDATE_DATE = CURRENT TIMESTAMP, EXCEPTION_LOG = null WHERE CASE_LAUNCH_CLDR_ID="
						+ scenarioDTO.getCase_launch_cldr_id();
			} else if (scenarioDTO.getStatus().equals(
					FinanceFA_Constants.SCENARIO_FAILURE)) {
				sql = "UPDATE FN_FA_TBL_CASE_LAUNCH_CLDR SET STATUS='F', UPDATED_BY = '"
						+ updatedBy
						+ "', UPDATE_DATE = CURRENT TIMESTAMP, EXCEPTION_LOG = '"
						+ scenarioDTO.getException_log()
						+ "' WHERE CASE_LAUNCH_CLDR_ID="
						+ scenarioDTO.getCase_launch_cldr_id();
			} else {
				log.error("Scenario status is not properly set");
				return 0;
			}
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);
			updatedRowCount = pstmt.executeUpdate();
			log.info(updatedRowCount + " row(s) updated in database");
			success = true;
		} catch (SQLException sqlEx) {
			log.error("SQL exception occured while updating the status."
					+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit updateScenarioLaunchStatus]");
		return updatedRowCount;
	}

	public void storeScenarioFutureCalendar(ScenarioDTO scenarioDTO,
			String updatedBy) throws Exception {
		log.debug("[Enter storeScenarioFutureCalendar]");

		/* Perform the following actions in a single transaction */
		try {
			log.debug("Transaction started");
			setAutoCommit(false);

			log.debug("Updating the Case Launch Cldr table...");
			Integer caseLaunchCldrId = updateCaseLaunchCldr(scenarioDTO, updatedBy);
			log.debug("New caseLaunchCldrId:" + caseLaunchCldrId);
			if (caseLaunchCldrId == null) {
				log.error("Unable to get the new case launch cldr id");
				throw new IllegalArgumentException(
						"Unable to get the new case launch cldr id");
			}

			if (caseLaunchCldrId.intValue() == -1) {
				log.info("Scenario is already present in the database; hence not inserting "
								+ "rows to case milestones cldr table");
			} else {
				// boolean updateStatus =
				// updateCaseMilestoneCldr(caseLaunchCldrId, scenarioDTO);
				log.debug("Updating the Case Milestone Cldr table...");
				updateCaseMilestoneCldr(caseLaunchCldrId, scenarioDTO);
			}
			persistData(true);
			setAutoCommit(true);
			log.info("Transaction successfully commited.");
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			try {
				persistData(false);
				log.error("Transaction rollbacked.");
			} catch (SQLException e1) {
				log.error(e1.getMessage(), e1);
			}
			throw e;
		}
	}

	/**
	 * @param caseLaunchCldrId
	 * @param scenarioDTO
	 * @return
	 * @throws ParseException
	 * @throws SQLException
	 */
	private boolean updateCaseMilestoneCldr(Integer caseLaunchCldrId,
			ScenarioDTO scenarioDTO) throws ParseException, SQLException {
		log.debug("[Enter updateCaseMilestoneCldr]");

		boolean success = false;
		int updatedRowCount = 0;
		try {
			String sql = "INSERT INTO FN_FA_TBL_CASE_MILESTONE_CLDR(SCENARIO_MILESTONE_ID, CASE_LAUNCH_CLDR_ID, MILESTONE_ID, MILESTONE_ORDER, DEFAULT_ROUTE_ID, MILESTONE_TYPE, MILESTONE_ROLE, MILESTONE_SLA, MILESTONE_ISACTIVE, ISMILESTONEROLE_CONDITIONAL, CONDITIONAL_VALUE, SUCCESSOR_ID, PREDECESSOR_ID, IS_ALERT_ENABLED, SCENARIO_MILESTONE_DESCRIPTION) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);

			ArrayList milestoneList = scenarioDTO.getMilestoneList();
			log.debug(milestoneList.size()
					+ " milestone details need to be inserted");
			int insertedCount = 0;
			for (int i = 0; i < milestoneList.size(); i++) {
				MilestoneDTO milestoneDTO = (MilestoneDTO) milestoneList.get(i);

				// Not null in database
				pstmt.setInt(1, milestoneDTO.getScenario_milestone_id()
						.intValue());

				// Not null in database
				pstmt.setInt(2, caseLaunchCldrId.intValue());

				// Not null in database
				pstmt.setInt(3, milestoneDTO.getMilestone_id().intValue());

				if (milestoneDTO.getMilestone_order() == null) {
					pstmt.setNull(4, Types.INTEGER);
				} else {
					pstmt.setInt(4, milestoneDTO.getMilestone_order()
							.intValue());
				}

				if (milestoneDTO.getDefault_route_id() == null) {
					pstmt.setNull(5, Types.INTEGER);
				} else {
					pstmt.setInt(5, milestoneDTO.getDefault_route_id()
							.intValue());
				}

				if (milestoneDTO.getMilestone_type() == null) {
					pstmt.setNull(6, Types.VARCHAR);
				} else {
					pstmt.setString(6, milestoneDTO.getMilestone_type());
				}

				if (milestoneDTO.getMilestone_role() == null) {
					pstmt.setNull(7, Types.VARCHAR);
				} else {
					pstmt.setString(7, milestoneDTO.getMilestone_role());
				}

				Date date = null;
				String newSLAStr = null;
				try {
					date = simDate.parse(milestoneDTO.getMilestone_sla());
					Date newSLADate = FinanceFA_Utilities.getNewDate(date, scenarioDTO
							.getFrequency_id());
					newSLAStr = simDate.format(newSLADate);
				} catch (ParseException e) {
					log.error(
							"Unable to parse the milestone sla string to date."
									+ e.getMessage(), e);
					throw e;
				}

				if (newSLAStr == null) {
					pstmt.setNull(8, Types.VARCHAR);
				} else {
					pstmt.setString(8, newSLAStr);
				}

				if (milestoneDTO.getMilestone_isactive() == null) {
					pstmt.setNull(9, Types.CHAR);
				} else {
					pstmt.setString(9, ""
							+ milestoneDTO.getMilestone_isactive().charValue());
				}

				if (milestoneDTO.getIsmilestonerole_conditional() == null) {
					pstmt.setNull(10, Types.VARCHAR);
				} else {
					pstmt.setString(10, milestoneDTO
							.getIsmilestonerole_conditional());
				}

				if (milestoneDTO.getConditional_value() == null) {
					pstmt.setNull(11, Types.VARCHAR);
				} else {
					pstmt.setString(11, milestoneDTO.getConditional_value());
				}

				if (milestoneDTO.getSuccessor_id() == null) {
					pstmt.setNull(12, Types.VARCHAR);
				} else {
					pstmt.setString(12, milestoneDTO.getSuccessor_id());
				}

				if (milestoneDTO.getPredecessor_id() == null) {
					pstmt.setNull(13, Types.VARCHAR);
				} else {
					pstmt.setString(13, milestoneDTO.getPredecessor_id());
				}

				if (milestoneDTO.getIs_alert_enabled() == null) {
					pstmt.setNull(14, Types.VARCHAR);
				} else {
					pstmt.setString(14, milestoneDTO.getIs_alert_enabled());
				}

				if (milestoneDTO.getScenario_milestone_description() == null) {
					pstmt.setNull(15, Types.VARCHAR);
				} else {
					pstmt.setString(15, milestoneDTO
							.getScenario_milestone_description());
				}

				updatedRowCount = pstmt.executeUpdate();
				log.info(updatedRowCount + " row(s) inserted into database.");

				insertedCount++;
			}
			log.debug(insertedCount
					+ " milestone details inserted into database.");
			success = true;
		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
			throw sqlEx;
		} finally {
			log.info("Execution Status of Query:" + success);
		}
		log.debug("[Exit updateCaseMilestoneCldr]");
		return false;
	}

	/**
	 * @param scenarioDTO
	 * @param updatedBy 
	 * @return
	 * @throws SQLException
	 * @throws ParseException
	 */
	private Integer updateCaseLaunchCldr(ScenarioDTO scenarioDTO, String updatedBy)
			throws SQLException, ParseException {
		log.debug("[Enter updateCaseLaunchCldr]");

		// Insert Case calendar details and store ScenarioId and Start Date in
		// local variable
		boolean success = false;
		int updatedRowCount = 0;
		Integer caseLaunchCldrId = null;
		try {
			Date newStartDate = FinanceFA_Utilities.getNewDate(new Date(scenarioDTO
					.getStart_date().getTime()), scenarioDTO.getFrequency_id());

			boolean isRecordAlreadyInserted = checkAvailability(scenarioDTO,
					newStartDate);
			log.debug("isRecordAlreadyInserted:" + isRecordAlreadyInserted);

			if (!isRecordAlreadyInserted) {
				Date newSLADate = null;
				String newSLAStr = null;
				if (scenarioDTO.getScenario_type_id().intValue() == 1
						|| scenarioDTO.getScenario_type_id().intValue() == 3) {

					Date date = null;

					try {
						date = simDate.parse(scenarioDTO.getProcess_sla());
						newSLADate = FinanceFA_Utilities.getNewDate(date, scenarioDTO
								.getFrequency_id());
						newSLAStr = simDate.format(newSLADate);
					} catch (ParseException e) {
						log.error(e.getMessage(), e);
						throw e;
					}
				}
				String sql = "INSERT INTO FN_FA_TBL_CASE_LAUNCH_CLDR(SCENARIO_ID, START_DATE, STATUS, UPDATE_DATE, UPDATED_BY, WORKING_HRS_ID, PROCESS_SLA, SLA_TYPE_ID, SLA_CALCULATION_ID) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?)";

				log.debug("SQL Query is :" + sql);

				PreparedStatement pstmt = dbconn.prepareStatement(sql);

				// Not null in database
				pstmt.setInt(1, scenarioDTO.getScenario_id().intValue());

				if (newStartDate == null) {
					log.warn("Start_date field is null; hence inserting null to database");
					pstmt.setNull(2, Types.TIMESTAMP);
				} else {
					pstmt.setTimestamp(2, new Timestamp(newStartDate
									.getTime()));
				}

				pstmt.setString(3, "N");

				pstmt.setTimestamp(4, new Timestamp(new Date().getTime()));

				pstmt.setString(5, updatedBy);

				if (scenarioDTO.getWorking_hrs_id() == null) {
					pstmt.setNull(6, Types.INTEGER);
				} else {
					pstmt.setInt(6, scenarioDTO.getWorking_hrs_id().intValue());
				}

				if (newSLAStr == null) {
					pstmt.setNull(7, Types.VARCHAR);
				} else {
					pstmt.setString(7, newSLAStr);
				}

				if (scenarioDTO.getSla_type_id() == null) {
					pstmt.setNull(8, Types.INTEGER);
				} else {
					pstmt.setInt(8, scenarioDTO.getSla_type_id().intValue());
				}

				if (scenarioDTO.getSla_calculation_id() == null) {
					pstmt.setNull(9, Types.INTEGER);
				} else {
					pstmt.setInt(9, scenarioDTO.getSla_calculation_id()
							.intValue());
				}

				updatedRowCount = pstmt.executeUpdate();
				log.info(updatedRowCount + " row(s) inserted in database");

				// Select the case launch calendar id wrt scenarioId and
				// StartDate
				log.debug("Querying for new case launch cldr id");
				sql = "SELECT CASE_LAUNCH_CLDR_ID FROM FN_FA_TBL_CASE_LAUNCH_CLDR where SCENARIO_ID="
						+ scenarioDTO.getScenario_id()
						+ " and start_date='"
						+ new Timestamp(newStartDate.getTime()) + "'";
				log.debug("SQL Query is :" + sql);
				pstmt = dbconn.prepareStatement(sql);
				ResultSet rs = pstmt.executeQuery();
				while (rs.next()) {
					caseLaunchCldrId = new Integer(rs
							.getInt(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID));
				}
				log.debug("New caseLaunchCldrId:" + caseLaunchCldrId);
			} else {
				log
						.info("Scenario with new start date "
								+ newStartDate
								+ " is already present in the database; hence we are not storing future configuration");
				caseLaunchCldrId = new Integer(-1);
			}
			success = true;
		} catch (SQLException sqlEx) {
			log.error("SQL exception occured while updating the status."
					+ sqlEx.getMessage(), sqlEx);
			success = false;
			throw sqlEx;
		} finally {
			log.info("Execution Status of Query:" + success);
		}
		log.debug("[Exit updateCaseLaunchCldr]");
		return caseLaunchCldrId;
	}

	/**
	 * @param scenarioDTO
	 * @param newStartDate
	 * @return
	 */
	private boolean checkAvailability(ScenarioDTO scenarioDTO, Date newStartDate) {

		log.debug("[Enter checkAvailability]");

		boolean success = false;
		boolean isRecordAlreadyInserted = false;
		try {

			// prepare select query
			Calendar startCal = Calendar.getInstance();
			startCal.setTime(newStartDate);
			Calendar endCal = Calendar.getInstance();
			endCal.setTime(newStartDate);

			int frequencyId = scenarioDTO.getFrequency_id().intValue();
			String selectSQL = "SELECT CASE_LAUNCH_CLDR_ID FROM FN_FA_TBL_CASE_LAUNCH_CLDR "
					+ "WHERE SCENARIO_ID="
					+ scenarioDTO.getScenario_id()
					+ " and ";

			if (frequencyId == 1) { // Dialy
				log.debug("It is a dialy process");
				selectSQL += "DATE(START_DATE)=DATE('"
						+ new Timestamp(newStartDate.getTime()) + "')";

			} else if (frequencyId == 2) { // Monthly
				log.debug("It is a monthly process");
				startCal.set(startCal.get(Calendar.YEAR), startCal
						.get(Calendar.MONTH), 1);
				endCal.set(endCal.get(Calendar.YEAR), endCal
						.get(Calendar.MONTH), endCal
						.getActualMaximum(Calendar.DATE));
				selectSQL += "DATE(START_DATE)>=DATE('"
						+ new Timestamp(startCal.getTime().getTime())
						+ "') and " + "DATE(START_DATE)<=DATE('"
						+ new Timestamp(endCal.getTime().getTime()) + "')";

			} else if (frequencyId == 3) { // Weekly
			// startCal.set(startCal.get(Calendar.YEAR), startCal
			// .get(Calendar.MONTH), 1);
			// endCal.set(endCal.get(Calendar.YEAR), endCal
			// .get(Calendar.MONTH), endCal
			// .getActualMaximum(Calendar.DATE));
			// insertSQL += "DATE(START_DATE)>=DATE('"+new
			// Timestamp(startCal.getTime().getTime())+"') and " +
			// "DATE(START_DATE)<=DATE('"+new
			// Timestamp(endCal.getTime().getTime())+"')";

			} else if (frequencyId == 4) { // Fortnightly
			// startCal.set(startCal.get(Calendar.YEAR), startCal
			// .get(Calendar.MONTH), 1);
			// endCal.set(endCal.get(Calendar.YEAR), endCal
			// .get(Calendar.MONTH), endCal
			// .getActualMaximum(Calendar.DATE));
			// insertSQL += "DATE(START_DATE)>=DATE('"+new
			// Timestamp(startCal.getTime().getTime())+"') and " +
			// "DATE(START_DATE)<=DATE('"+new
			// Timestamp(endCal.getTime().getTime())+"')";

			}

			log.debug("SQL Query is :" + selectSQL);

			PreparedStatement pstmt = dbconn.prepareStatement(selectSQL);
			ResultSet rs = pstmt.executeQuery();

			if (rs.next() == false) {
				log.info("No scenario found on new date range ");
				isRecordAlreadyInserted = false;
			} else {
				log.info("Scenario Case launch Cldr id:" + rs.getString(1)
						+ " already present");
				isRecordAlreadyInserted = true;
			}
			success = true;

		} catch (SQLException sqlEx) {
			log.error(
					"SQL exception occured while searching for active scenarios. "
							+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					// dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit checkAvailability]");
		return isRecordAlreadyInserted;
	}

	public ArrayList getCalendarInfo() {
		return null;

	}

	public java.util.ArrayList publishCalendar() {
		return null;

	}

	/**
	 * @param scenarioDTO
	 * @return
	 */
	public boolean updateScenarioSLADates(ScenarioDTO scenarioDTO) {
		log.debug("[Enter updateScenarioSLADates]");

		boolean success = false;
		int updatedRowCount = 0;
		try {
			String sql = "";

			/* Update process sla date if changed */
			Date processSlaDate_DB = null;
			try {
				processSlaDate_DB = simDate.parse(scenarioDTO.getProcess_sla());
			} catch (ParseException e) {
				log.error(
						"Error occured while parsing the process sla. It should be in "
								+ FinanceFA_Constants.DATE_PATTERN
								+ "format.", e);
			}
			if ((processSlaDate_DB != null)
					&& (processSlaDate_DB.equals(new Date(scenarioDTO
							.getProcess_sla_date().getTime())))) {
				log.debug("Process sla date has not been changed hence not updating in the database");
			} else {
				String newProcessSLADate = simDate.format(scenarioDTO.getProcess_sla_date());
				sql = "UPDATE FN_FA_TBL_CASE_LAUNCH_CLDR SET PROCESS_SLA = '"
						+ newProcessSLADate
						+ "' WHERE CASE_LAUNCH_CLDR_ID = "
						+ scenarioDTO.getCase_launch_cldr_id();
				log
						.debug("Process sla date has been changed hence updating it in the database");

				log.debug("SQL Query is :" + sql);

				PreparedStatement pstmt = dbconn.prepareStatement(sql);
				updatedRowCount = pstmt.executeUpdate();
				log.info(updatedRowCount + " row(s) updated in database");

			}

			/* Update milestone sla date if changed */
			ArrayList milestoneList = scenarioDTO.getMilestoneList();

			sql = "UPDATE FN_FA_TBL_CASE_MILESTONE_CLDR SET MILESTONE_SLA = ? WHERE CASE_LAUNCH_CLDR_ID = ? AND SCENARIO_MILESTONE_ID = ?";

			log.debug("SQL Query is :" + sql);

			PreparedStatement pstmt = dbconn.prepareStatement(sql);

			for (int i = 0; i < milestoneList.size(); i++) {
				MilestoneDTO milestoneDTO = (MilestoneDTO) milestoneList.get(i);
				log.debug("For milestone: Case_launch_cldr_id:"
						+ milestoneDTO.getCase_launch_cldr_id()
						+ " Scenario_milestone_id:"
						+ milestoneDTO.getScenario_milestone_id());

				Date milestoneSlaDate_DB = null;
				try {
					milestoneSlaDate_DB = simDate.parse(milestoneDTO
							.getMilestone_sla());
				} catch (ParseException e) {
					log.error(
							"Error occured while parsing the milestone sla. It should be in "
									+ FinanceFA_Constants.DATE_PATTERN
									+ "format.", e);
				}
				if (milestoneSlaDate_DB != null
						&& (milestoneSlaDate_DB.equals(new Date(milestoneDTO
								.getMilestone_sla_date().getTime())))) {
					log.debug("Milestone sla date has not been changed hence not updating in the database");
				} else {
					log.debug("Milestone sla date has been changed hence updating it in the database");

					String newMilestoneSLADate = simDate.format(milestoneDTO.getMilestone_sla_date());
					pstmt.setString(1, newMilestoneSLADate);
					pstmt.setInt(2, milestoneDTO.getCase_launch_cldr_id()
							.intValue());
					pstmt.setInt(3, milestoneDTO.getScenario_milestone_id()
							.intValue());
					updatedRowCount = pstmt.executeUpdate();
					log.info(updatedRowCount + " row(s) updated in database");
				}
			}

			success = true;
		} catch (SQLException sqlEx) {
			log.error("SQL exception occured while updating the status."
					+ sqlEx.getMessage(), sqlEx);
			success = false;
		} finally {
			try {
				if (dbconn != null) {
					if (success) {
						dbconn.commit();
					} else {
						dbconn.rollback();
					}
					//dbconn.close();
				}
				log.info("Execution Status of Query:" + success);
			} catch (SQLException ex) {
				success = false;
			}
		}
		log.debug("[Exit updateScenarioSLADates]");
		return success;
	}
	
	public static void main(String args[]) {
		if (false) {
			new FinanceFA_ExternalDBManager(0).getActiveMilestoneTasks(null,
					null);
		}
	}
}
