/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util.dto;

import java.sql.Timestamp;
import java.util.ArrayList;

/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @viz.diagram MilestoneDTO.tpx
 */
public class MilestoneDTO {
	private Integer scenario_milestone_id 		= new Integer(-1);
	private String scenario_milestone_description		= "";
	private Integer case_launch_cldr_id 		= new Integer(-1);
	private Integer milestone_id 				= new Integer(-1);
	private String milestone_name				= "";

	private Integer milestone_order 			= new Integer(-1);
	private Integer default_route_id			= new Integer(-1);
	private String milestone_type				= "";
	private String milestone_role				= "";
	private String milestone_sla				= "";
	private String ismilestonerole_conditional	= "";
	private String conditional_value			= "";
	private String successor_id					= "";
	private String predecessor_id				= "";
	private String is_alert_enabled				= "";
	private Character milestone_isactive		= new Character('N');
	
	ArrayList notificationList;
	
	private Timestamp milestone_sla_date;
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("scenario_milestone_id:[" + getScenario_milestone_id() + "] ")
							.append("case_launch_cldr_id:[" + getCase_launch_cldr_id() + "] ")
							.append("milestone_id:[" + getMilestone_id() + "] ")
							.append("milestone_name:[" + getMilestone_name() + "] ")
							.append("scenario_milestone_description:[" + getScenario_milestone_description() + "] ")
							.append("milestone_order:[" + getMilestone_order() + "] ")
							.append("default_route_id:[" + getDefault_route_id() + "] ")
							.append("milestone_type:[" + getMilestone_type() + "] ")
							.append("milestone_role:[" + getMilestone_role() + "] ")
							.append("milestone_sla:[" + getMilestone_sla() + "] ")
							.append("ismilestonerole_conditional:[" + getIsmilestonerole_conditional() + "] ")
							.append("conditional_value:[" + getConditional_value() + "] ")
							.append("successor_id:[" + getSuccessor_id() + "] ")	
							.append("predecessor_id:[" + getPredecessor_id() + "] ")
							.append("is_alert_enabled:[" + getIs_alert_enabled() + "] ")
							.append("milestone_isactive:[" + getMilestone_isactive() + "] ");
/*		if(notificationList != null) {
			buf.append("\nNotification List: Size:"+notificationList.size()+"\n");
			for(int i=0; i<notificationList.size(); i++) {
				buf.append("\tDTO["+i+"]:" + notificationList.get(i) + "\n");
			}
		}
*/		return buf.toString();
	}

	
	
	/**
	 * @return Returns the is_alert_enabled.
	 */
	public String getIs_alert_enabled() {
		return is_alert_enabled;
	}
	/**
	 * @param is_alert_enabled The is_alert_enabled to set.
	 */
	public void setIs_alert_enabled(String is_alert_enabled) {
		this.is_alert_enabled = is_alert_enabled;
	}
	/**
	 * @return Returns the milestone_sla_date.
	 */
	public Timestamp getMilestone_sla_date() {
		return milestone_sla_date;
	}
	/**
	 * @param milestone_sla_date The milestone_sla_date to set.
	 */
	public void setMilestone_sla_date(Timestamp milestone_sla_date) {
		this.milestone_sla_date = milestone_sla_date;
	}
	/**
	 * @return Returns the milestone_isactive.
	 */
	public Character getMilestone_isactive() {
		return milestone_isactive;
	}
	/**
	 * @param milestone_isactive The milestone_isactive to set.
	 */
	public void setMilestone_isactive(Character milestone_isactive) {
		this.milestone_isactive = milestone_isactive;
	}
	/**
	 * @return Returns the scenario_milestone_description.
	 */
	public String getScenario_milestone_description() {
		return scenario_milestone_description;
	}
	/**
	 * @param scenario_milestone_description The scenario_milestone_description to set.
	 */
	public void setScenario_milestone_description(
			String scenario_milestone_description) {
		this.scenario_milestone_description = scenario_milestone_description;
	}
	
	/**
	 * @return Returns the milestone_name.
	 */
	public String getMilestone_name() {
		return milestone_name;
	}
	/**
	 * @param milestone_name The milestone_name to set.
	 */
	public void setMilestone_name(String milestone_name) {
		this.milestone_name = milestone_name;
	}
	/**
	 * @return Returns the case_launch_cldr_id.
	 */
	public Integer getCase_launch_cldr_id() {
		return case_launch_cldr_id;
	}
	/**
	 * @param case_launch_cldr_id The case_launch_cldr_id to set.
	 */
	public void setCase_launch_cldr_id(Integer case_launch_cldr_id) {
		this.case_launch_cldr_id = case_launch_cldr_id;
	}
	/**
	 * @return Returns the conditional_value.
	 */
	public String getConditional_value() {
		return conditional_value;
	}
	/**
	 * @param conditional_value The conditional_value to set.
	 */
	public void setConditional_value(String conditional_value) {
		this.conditional_value = conditional_value;
	}
	/**
	 * @return Returns the default_route_id.
	 */
	public Integer getDefault_route_id() {
		return default_route_id;
	}
	/**
	 * @param default_route_id The default_route_id to set.
	 */
	public void setDefault_route_id(Integer default_route_id) {
		this.default_route_id = default_route_id;
	}
	
	/**
	 * @return Returns the ismilestonerole_conditional.
	 */
	public String getIsmilestonerole_conditional() {
		return ismilestonerole_conditional;
	}
	/**
	 * @param ismilestonerole_conditional The ismilestonerole_conditional to set.
	 */
	public void setIsmilestonerole_conditional(
			String ismilestonerole_conditional) {
		this.ismilestonerole_conditional = ismilestonerole_conditional;
	}
	/**
	 * @return Returns the milestone_id.
	 */
	public Integer getMilestone_id() {
		return milestone_id;
	}
	/**
	 * @param milestone_id The milestone_id to set.
	 */
	public void setMilestone_id(Integer milestone_id) {
		this.milestone_id = milestone_id;
	}
	/**
	 * @return Returns the milestone_order.
	 */
	public Integer getMilestone_order() {
		return milestone_order;
	}
	/**
	 * @param milestone_order The milestone_order to set.
	 */
	public void setMilestone_order(Integer milestone_order) {
		this.milestone_order = milestone_order;
	}
	/**
	 * @return Returns the milestone_role.
	 */
	public String getMilestone_role() {
		return milestone_role;
	}
	/**
	 * @param milestone_role The milestone_role to set.
	 */
	public void setMilestone_role(String milestone_role) {
		this.milestone_role = milestone_role;
	}
	/**
	 * @return Returns the milestone_sla.
	 */
	public String getMilestone_sla() {
		return milestone_sla;
	}
	/**
	 * @param milestone_sla The milestone_sla to set.
	 */
	public void setMilestone_sla(String milestone_sla) {
		this.milestone_sla = milestone_sla;
	}
	/**
	 * @return Returns the milestone_type.
	 */
	public String getMilestone_type() {
		return milestone_type;
	}
	/**
	 * @param milestone_type The milestone_type to set.
	 */
	public void setMilestone_type(String milestone_type) {
		this.milestone_type = milestone_type;
	}
	/**
	 * @return Returns the notificationList.
	 */
	public ArrayList getNotificationList() {
		return notificationList;
	}
	/**
	 * @param notificationList The notificationList to set.
	 */
	public void setNotificationList(ArrayList notificationList) {
		this.notificationList = notificationList;
	}
	/**
	 * @return Returns the predecessor_id.
	 */
	public String getPredecessor_id() {
		return predecessor_id;
	}
	/**
	 * @param predecessor_id The predecessor_id to set.
	 */
	public void setPredecessor_id(String predecessor_id) {
		this.predecessor_id = predecessor_id;
	}
	/**
	 * @return Returns the scenario_milestone_id.
	 */
	public Integer getScenario_milestone_id() {
		return scenario_milestone_id;
	}
	/**
	 * @param scenario_milestone_id The scenario_milestone_id to set.
	 */
	public void setScenario_milestone_id(Integer scenario_milestone_id) {
		this.scenario_milestone_id = scenario_milestone_id;
	}
	/**
	 * @return Returns the successor_id.
	 */
	public String getSuccessor_id() {
		return successor_id;
	}
	/**
	 * @param successor_id The successor_id to set.
	 */
	public void setSuccessor_id(String successor_id) {
		this.successor_id = successor_id;
	}
}
