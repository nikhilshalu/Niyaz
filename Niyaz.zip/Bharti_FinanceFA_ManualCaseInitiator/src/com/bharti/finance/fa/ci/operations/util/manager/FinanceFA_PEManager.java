/*
 * Created on Jun 10, 2009
 *
 */
package com.bharti.finance.fa.ci.operations.util.manager;

import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.manager.PEManager;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_XMLUtilities;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioUnitDTO;
import com.bharti.finance.fa.ci.operations.util.mapper.ScenarioMapper;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioDTO;
import com.filenet.api.events.Subscription;

import filenet.vw.api.VWException;

/**
 * Handles all the Process engine related operations.
 * 
 * @author Harisha
 * 
 * @viz.diagram Finance_PEManager.tpx
 */
public class FinanceFA_PEManager extends PEManager {

	public static Logger log = Logger.getLogger(FinanceFA_PEManager.class);

	public static int totalLaunchedWorkflowsCount = 0;

	public static int totalFailedWorkflowsCount = 0;

	private Element rootElement = null;
	
	long delayMilliSeconds = -1;

	/**
	 * @param application
	 * @param userId
	 * @param password
	 * @throws MalformedURLException
	 * @throws VWException
	 * @throws ClassNotFoundException
	 */
	public FinanceFA_PEManager(int application, String userId, String password,
			Subscription sub) throws MalformedURLException, VWException,
			ClassNotFoundException {
		super(application, userId, password, sub);
		
		String delayStr = PropertyLoader.props
				.getProperty("DELAY_IN_MILLISECONDS");
		log.debug("The value of [DELAY_IN_MILLISECONDS] from the properties file is ["
				+ delayStr + "]");
		try {
			delayMilliSeconds = Long.parseLong(delayStr);
			
		} catch (NumberFormatException e) {
			log.error("Unable to parse the delay [" + delayStr
					+ "] to numeric value." + e.getMessage(), e);
		}		
	}

	/**
	 * Launches the <code>scenarioUnitList</code>'s size number of workflows
	 * for the scenario <code>scenarioDTO</code>
	 * <p>
	 * If exception occurs while launching an unit of workflow then it will
	 * prepare an XML exception log containing its details. Finally if atleast
	 * one unit of workflow launch is failed then it changes the status of that scenario to 'F'
	 * (meaning failure) and update the exception log. On next launch of
	 * scheduler, it will launch only those unit of workflow which are present in
	 * that exception log.
	 * 
	 * @param scenarioDTO
	 *            Scenario to be launched
	 * @param scenarioUnitList
	 *            Number of workflows to be launched. Each ScenarioUnit contains
	 *            information about LOB, circle and operator
	 * @throws Exception
	 */
	public void launchScenario(ScenarioDTO scenarioDTO,
			ArrayList scenarioUnitList) throws Exception {

		if (scenarioUnitList == null || scenarioUnitList.size() == 0) {
			log.error("Number of workflow unit to be launched is zero or scenarioUnitList is null");
			return;
		}
//		int launchTypeId = scenarioDTO.getLaunch_type_id().intValue();
		int failedWorkflowsCount = 0;

		/* Create the exception log */
		Document exceptionLogDoc = null;
		
		scenarioDTO.setStatus(FinanceFA_Constants.SCENARIO_SUCESS);

		Map map = scenarioDTO.getWorkflowFieldMap();
		log.debug("---->Lauching [" + scenarioUnitList.size()
				+ "] workflows for case launch cldr id "
				+ scenarioDTO.getCase_launch_cldr_id());
		for (int count = 0; count < scenarioUnitList.size(); count++) {

			log.debug("count=" + count);
			ScenarioUnitDTO scenarioUnitDTO = (ScenarioUnitDTO) scenarioUnitList
					.get(count);
			map.put(ScenarioMapper.LOBID_NAME, scenarioUnitDTO.getLob_id());
			map.put(ScenarioMapper.LOBNAME_NAME, scenarioUnitDTO.getLob_name());
			map.put(ScenarioMapper.CIRCLEID_NAME, scenarioUnitDTO
					.getCircle_id());
			map.put(ScenarioMapper.CIRCLENAME_NAME, scenarioUnitDTO
					.getCircle_name());

			// log.debug("map size:" + map.size());
			String fields[] = new String[map.size()];
			Object values[] = new Object[map.size()];
			Set keySet = map.keySet();
			Iterator it = keySet.iterator();

			// log.info(map.size() + " workflow fields need to be initialized");
			int mapCount = 0;
			while (it.hasNext()) {
				fields[mapCount] = (String) it.next();
				values[mapCount] = map.get(fields[mapCount]);

				log.debug("Field [" + mapCount + "] Name (" + fields[mapCount]
						+ ") Value (" + values[mapCount] + ")");
				mapCount++;
			}

			try {
				launchWorkflow(fields, values, scenarioDTO.getWf_definition());
				totalLaunchedWorkflowsCount++;
				
				/* Pause the execution for specified time */
				if (delayMilliSeconds > 0) {
					log.debug("Pausing the execution for [" + delayMilliSeconds
							+ "] milli second(s).");
					Thread.sleep(delayMilliSeconds);
				}
						
			} catch (Exception e) {
				log.error(e.getMessage(), e);
				scenarioDTO.setStatus(FinanceFA_Constants.SCENARIO_FAILURE);
				failedWorkflowsCount++;
				exceptionLogDoc = addScenarioUnitToExceptionLog(
						exceptionLogDoc, scenarioUnitDTO, failedWorkflowsCount);
				totalFailedWorkflowsCount++;
			}
		}

		log.info("---------------------------------------------------------");
		if (!scenarioDTO.getStatus().equals(FinanceFA_Constants.SCENARIO_FAILURE)) {
			scenarioDTO.setStatus(FinanceFA_Constants.SCENARIO_SUCESS);
			log.info("Scenario with case launch cldr id :"
					+ scenarioDTO.getCase_launch_cldr_id()
					+ ": Successfully launched " + scenarioUnitList.size()
					+ " workflows.");
		} else {
			scenarioDTO.setException_log(FinanceFA_XMLUtilities
					.convertDOMtoString(exceptionLogDoc));
			log.info("Scenario with case launch cldr id :"
					+ scenarioDTO.getCase_launch_cldr_id()
					+ ": Successfully launched "
					+ (scenarioUnitList.size() - failedWorkflowsCount)
					+ " workflows. Failed to launch " + failedWorkflowsCount
					+ " workflows.");
		}
		log.info("---------------------------------------------------------");
		log.debug("Final exception log xml:"
				+ FinanceFA_XMLUtilities.convertDOMtoString(exceptionLogDoc));
	}

	/**
	 * @param count
	 * @param exceptionLog
	 * @param scenarioUnitDTO
	 * @throws Exception
	 */
	private Document addScenarioUnitToExceptionLog(Document exceptionLogDoc,
			ScenarioUnitDTO scenarioUnitDTO, int index) throws Exception {
		// XMLUtil.addNode(exceptionLog, "//" ,
		// XMLUtil.createAttributeNode(exceptionLog, "case", "id", index+""));

		if (exceptionLogDoc == null) {
			// first time, create the root node
			log.debug("first time");
			exceptionLogDoc = FinanceFA_XMLUtilities.getDocumentInstance();
			rootElement = exceptionLogDoc.createElement("exceptions");
			exceptionLogDoc.appendChild(rootElement);
		}

		Element caseElement = (Element) exceptionLogDoc.createElement("case");
		caseElement.setAttribute("id", index + "");

		Element element = (Element) exceptionLogDoc.createElement("property");
		element.setAttribute("name", "lob_id");
		element.setAttribute("value", scenarioUnitDTO.getLob_id().toString());
		caseElement.appendChild(element);

		element = (Element) exceptionLogDoc.createElement("property");
		element.setAttribute("name", "lob_name");
		element.setAttribute("value", scenarioUnitDTO.getLob_name().toString());
		caseElement.appendChild(element);

		element = (Element) exceptionLogDoc.createElement("property");
		element.setAttribute("name", "circle_id");
		element
				.setAttribute("value", scenarioUnitDTO.getCircle_id()
						.toString());
		caseElement.appendChild(element);

		element = (Element) exceptionLogDoc.createElement("property");
		element.setAttribute("name", "circle_name");
		element.setAttribute("value", scenarioUnitDTO.getCircle_name()
				.toString());
		caseElement.appendChild(element);

		element = (Element) exceptionLogDoc.createElement("property");
		element.setAttribute("name", "operator_id");
		element.setAttribute("value", scenarioUnitDTO.getOperator_id()
				.toString());
		caseElement.appendChild(element);

		element = (Element) exceptionLogDoc.createElement("property");
		element.setAttribute("name", "operator_name");
		element.setAttribute("value", scenarioUnitDTO.getOperator_name()
				.toString());
		caseElement.appendChild(element);

		// add to case node to root element
		log.debug("rootElement.hasChildNodes():" + rootElement.hasChildNodes());
		rootElement.appendChild(caseElement);
		log.debug("each time:" + FinanceFA_XMLUtilities.convertDOMtoString(exceptionLogDoc));
		return exceptionLogDoc;
	}

}