/*
 * Created on Jun 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util.dto;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @viz.diagram ScenarioDTO.tpx
 */
public class ScenarioDTO {
	
	public static Logger log = Logger.getLogger(ScenarioDTO.class);
	
	private Integer case_launch_cldr_id 	= new Integer(-1);
	private Integer scenario_id 			= new Integer(-1);
	private Timestamp start_date;
	private String start_time				= "";
	private String end_time					= "";
	private String process_sla				= "";
	private Integer sla_type_id 			= new Integer(-1);
	private Integer sla_calculation_id 		= new Integer(-1);
	private Integer launch_type_id 			= new Integer(-1);
	private Integer frequency_id 			= new Integer(-1);
	private Integer scenario_type_id 		= new Integer(-1);
	private String wf_definition			= "";
	private Integer process_id 				= new Integer(-1);
	private String process_name				= "";
	private String subprocess_name			= "";
	private String process_team				= "";
	private String stream_name				= "";
	private Integer stream_id				= new Integer(-1);
	private Character status				= new Character('N');
	private String exception_log			= "";
	private Integer working_hrs_id 			= new Integer(-1);
	
	private ArrayList processNotificationList;
	private ArrayList milestoneList;
	private String taskDetailsXML			= "";
	
	// Contains workflow fields
	private Map workflowFieldMap = new HashMap();	
	
	private Timestamp process_sla_date;
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("case_launch_cldr_id:[" + getCase_launch_cldr_id() + "] ")
							.append("scenario_id:[" + getScenario_id() + "] ")
							.append("start_date:[" + getStart_date() + "] ")
							.append("start_time:[" + getStart_time() + "] ")
							.append("end_time:[" + getEnd_time() + "] ")
							.append("process_sla:[" + getProcess_sla() + "] ")
							.append("sla_type_id:[" + getSla_type_id() + "] ")
							.append("sla_calculation_id:[" + getSla_calculation_id() + "] ")
							.append("launch_type_id:[" + getLaunch_type_id() + "] ")
							.append("frequency_id:[" + getFrequency_id() + "] ")
							.append("scenario_type_id:[" + getScenario_type_id() + "] ")
							.append("wf_definition:[" + getWf_definition() + "] ")	
							.append("process_id:[" + getProcess_id() + "] ")	
							.append("process_team:[" + getProcess_team() + "] ")		
							.append("process_name:[" + getProcess_name() + "] ")
							.append("subprocess_name:[" + getSubprocess_name() + "] ")
							.append("stream_name:[" + getStream_name() + "] ")
							.append("stream_id:[" + getStream_id() + "] ")
							.append("status:[" + getStatus() + "] ");
		
/*		if(processNotificationList != null) {
			buf.append("\nProcess Notification List: Size:"+processNotificationList.size()+"\n");
			for(int i=0; i<processNotificationList.size(); i++) {
				buf.append("\tDTO["+i+"]:"+processNotificationList.get(i)+"\n");
			}
		}
		
		if(milestoneList != null) {
			buf.append("\nMilestone List: Size:"+milestoneList.size()+"\n");
			for(int i=0; i<milestoneList.size(); i++) {
				buf.append("\tDTO["+i+"]:"+milestoneList.get(i)+"\n");
			}
		}
*/		return buf.toString();
	}
	
	
	public void setWorkflowFieldValue(String field, Object value) {   
		workflowFieldMap.put(field,value);
		log.debug("Added [" + field + "] with value [" + value + "] to Map");
	}
	public Object getWorkflowFieldValue(String field) {  
		return workflowFieldMap.get(field);
	}
	
	public Map getWorkflowFieldMap() {
		return workflowFieldMap;
	}
	
	
	
	
	public String getTaskDetailsXML() {
		return taskDetailsXML;
	}


	public void setTaskDetailsXML(String taskDetailsXML) {
		this.taskDetailsXML = taskDetailsXML;
	}


	/**
	 * @return Returns the process_sla_date.
	 */
	public Timestamp getProcess_sla_date() {
		return process_sla_date;
	}
	/**
	 * @param process_sla_date The process_sla_date to set.
	 */
	public void setProcess_sla_date(Timestamp process_sla_date) {
		this.process_sla_date = process_sla_date;
	}
	/**
	 * @return Returns the working_hrs_id.
	 */
	public Integer getWorking_hrs_id() {
		return working_hrs_id;
	}
	/**
	 * @param working_hrs_id The working_hrs_id to set.
	 */
	public void setWorking_hrs_id(Integer working_hrs_id) {
		this.working_hrs_id = working_hrs_id;
	}
	/**
	 * @return Returns the exception_log.
	 */
	public String getException_log() {
		return exception_log;
	}
	/**
	 * @param exception_log The exception_log to set.
	 */
	public void setException_log(String exception_log) {
		this.exception_log = exception_log;
	}
	/**
	 * @return Returns the status.
	 */
	public Character getStatus() {
		return status;
	}
	/**
	 * @param status The status to set.
	 */
	public void setStatus(Character status) {
		this.status = status;
	}
	/**
	 * @return Returns the process_id.
	 */
	public Integer getProcess_id() {
		return process_id;
	}
	/**
	 * @param process_id The process_id to set.
	 */
	public void setProcess_id(Integer process_id) {
		this.process_id = process_id;
	}
	/**
	 * @return Returns the process_name.
	 */
	public String getProcess_name() {
		return process_name;
	}
	/**
	 * @param process_name The process_name to set.
	 */
	public void setProcess_name(String process_name) {
		this.process_name = process_name;
	}
	/**
	 * @return Returns the process_team.
	 */
	public String getProcess_team() {
		return process_team;
	}
	/**
	 * @param process_team The process_team to set.
	 */
	public void setProcess_team(String process_team) {
		this.process_team = process_team;
	}
	/**
	 * @return Returns the stream_id.
	 */
	public Integer getStream_id() {
		return stream_id;
	}
	/**
	 * @param stream_id The stream_id to set.
	 */
	public void setStream_id(Integer stream_id) {
		this.stream_id = stream_id;
	}
	/**
	 * @return Returns the stream_name.
	 */
	public String getStream_name() {
		return stream_name;
	}
	/**
	 * @param stream_name The stream_name to set.
	 */
	public void setStream_name(String stream_name) {
		this.stream_name = stream_name;
	}
	/**
	 * @return Returns the scenario_type_id.
	 */
	public Integer getScenario_type_id() {
		return scenario_type_id;
	}
	/**
	 * @param scenario_type_id The scenario_type_id to set.
	 */
	public void setScenario_type_id(Integer scenario_type_id) {
		this.scenario_type_id = scenario_type_id;
	}
	/**
	 * @return Returns the case_launch_cldr_id.
	 */
	public Integer getCase_launch_cldr_id() {
		return case_launch_cldr_id;
	}
	/**
	 * @param case_launch_cldr_id The case_launch_cldr_id to set.
	 */
	public void setCase_launch_cldr_id(Integer case_launch_cldr_id) {
		this.case_launch_cldr_id = case_launch_cldr_id;
	}
	/**
	 * @return Returns the end_time.
	 */
	public String getEnd_time() {
		return end_time;
	}
	/**
	 * @param end_time The end_time to set.
	 */
	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}
	/**
	 * @return Returns the frequency_id.
	 */
	public Integer getFrequency_id() {
		return frequency_id;
	}
	/**
	 * @param frequency_id The frequency_id to set.
	 */
	public void setFrequency_id(Integer frequency_id) {
		this.frequency_id = frequency_id;
	}
	/**
	 * @return Returns the launch_type_id.
	 */
	public Integer getLaunch_type_id() {
		return launch_type_id;
	}
	/**
	 * @param launch_type_id The launch_type_id to set.
	 */
	public void setLaunch_type_id(Integer launch_type_id) {
		this.launch_type_id = launch_type_id;
	}
	/**
	 * @return Returns the milestoneList.
	 */
	public ArrayList getMilestoneList() {
		return milestoneList;
	}
	/**
	 * @param milestoneList The milestoneList to set.
	 */
	public void setMilestoneList(ArrayList milestoneList) {
		this.milestoneList = milestoneList;
	}
	
	/**
	 * @return Returns the process_sla.
	 */
	public String getProcess_sla() {
		return process_sla;
	}
	/**
	 * @param process_sla The process_sla to set.
	 */
	public void setProcess_sla(String process_sla) {
		this.process_sla = process_sla;
	}
	/**
	 * @return Returns the processNotificationList.
	 */
	public ArrayList getProcessNotificationList() {
		return processNotificationList;
	}
	/**
	 * @param processNotificationList The processNotificationList to set.
	 */
	public void setProcessNotificationList(ArrayList processNotificationList) {
		this.processNotificationList = processNotificationList;
	}
	/**
	 * @return Returns the scenario_id.
	 */
	public Integer getScenario_id() {
		return scenario_id;
	}
	/**
	 * @param scenario_id The scenario_id to set.
	 */
	public void setScenario_id(Integer scenario_id) {
		this.scenario_id = scenario_id;
	}
	/**
	 * @return Returns the sla_calculation_id.
	 */
	public Integer getSla_calculation_id() {
		return sla_calculation_id;
	}
	/**
	 * @param sla_calculation_id The sla_calculation_id to set.
	 */
	public void setSla_calculation_id(Integer sla_calculation_id) {
		this.sla_calculation_id = sla_calculation_id;
	}
	/**
	 * @return Returns the sla_type_id.
	 */
	public Integer getSla_type_id() {
		return sla_type_id;
	}
	/**
	 * @param sla_type_id The sla_type_id to set.
	 */
	public void setSla_type_id(Integer sla_type_id) {
		this.sla_type_id = sla_type_id;
	}
	/**
	 * @return Returns the start_date.
	 */
	public Timestamp getStart_date() {
		return start_date;
	}
	/**
	 * @param start_date The start_date to set.
	 */
	public void setStart_date(Timestamp start_date) {
		this.start_date = start_date;
	}
	/**
	 * @return Returns the start_time.
	 */
	public String getStart_time() {
		return start_time;
	}
	/**
	 * @param start_time The start_time to set.
	 */
	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}
	/**
	 * @return Returns the subprocess_name.
	 */
	public String getSubprocess_name() {
		return subprocess_name;
	}
	/**
	 * @param subprocess_name The subprocess_name to set.
	 */
	public void setSubprocess_name(String subprocess_name) {
		this.subprocess_name = subprocess_name;
	}
	/**
	 * @return Returns the wf_definition.
	 */
	public String getWf_definition() {
		return wf_definition;
	}
	/**
	 * @param wf_definition The wf_definition to set.
	 */
	public void setWf_definition(String wf_definition) {
		this.wf_definition = wf_definition;
	}
}
