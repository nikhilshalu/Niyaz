/*
 * Created on Jul 3, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util.mapper;

import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.Utilities;
import com.bharti.finance.fa.ci.operations.FinanceFA_CIOperations;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Utilities;
import com.bharti.finance.fa.ci.operations.util.dto.NotificationDTO;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioDTO;

/**
 * @author Harisha
 * 
 * @viz.diagram ScenarioMapper.tpx
 */
public class ScenarioMapper {

	public static Logger log = Logger.getLogger(ScenarioMapper.class);

	public static final String CASELAUNCHCLDID_NAME = "FnFA_CaseLaunchCldID";

	public static final String SCENARIOTYPEID_NAME = "FnFA_ScenarioTypeID";

	public static final String SCENARIOID_NAME = "FnFA_ScenarioID";

	public static final String STARTDATE_NAME = "FnFA_StartDate";
	
	public static final String CASECREATECHANNEL_NAME = "FnFA_CaseCreationChannel";

	public static final String STREAMNAME_NAME = "FnFA_StreamName";

	public static final String CIRCLENAME_NAME = "FnFA_CircleName";

	public static final String LOBNAME_NAME = "FnFA_LOBName";

	public static final String PROCESSSLA_NAME = "FnFA_ProcessSLA";

	public static final String STREAMID_NAME = "FnFA_StreamID";

	public static final String CIRCLEID_NAME = "FnFA_CircleID";

	public static final String LOBID_NAME = "FnFA_LOBID";

	public static final String SUBPROCESS_NAME = "FnFA_SubProcess";

	public static final String PROCESS_NAME = "FnFA_Process";

	public static final String PROCESSID_NAME = "FnFA_ProcessID";

	// notification fields
	public static final String ALLTIMERNAMEARRAY_NAME = "FnFA_AllTimerNameArray";

	public static final String ALLTIMERDATEARRAY_NAME = "FnFA_AllTimerDateArray";

	public static final String ISTIMERNOTIFICATIONFIREDARRAY_NAME = "FnFA_IsTimerNoticeFiredArray";

	public static final String ALLTIMERTO_NAME = "FnFA_AllTimerTO";

	public static final String ALLTIMERCC_NAME = "FnFA_AllTimerCC";

	public static final String ALLTIMERBCC_NAME = "FnFA_AllTimerBCC";

	public static final String TIMERNOTIFICATIONISENABLEDARRAY_NAME = "FnFA_TimerNoticeIsEnabledArray";
	
	public static final String TASKDETAILSXML_NAME = "FnFA_MilestoneTasksXML";

	/**
	 * @param scenarioDTO
	 */
	public void setWorkflowFields(ScenarioDTO scenarioDTO) {
		log.debug("[Enter setWorkflowFields]");
		try {
			log.debug("Setting workflow fields for Case launch Cldr Id:"
					+ scenarioDTO.getCase_launch_cldr_id());
			HashMap htTimers = new HashMap();
			HashMap htTO = new HashMap();
			HashMap htCC = new HashMap();
			HashMap htBCC = new HashMap();
			HashMap htEmailIsEnabled = new HashMap();
			
			scenarioDTO.setWorkflowFieldValue(CASELAUNCHCLDID_NAME, scenarioDTO
					.getCase_launch_cldr_id());
			scenarioDTO.setWorkflowFieldValue(SCENARIOTYPEID_NAME, scenarioDTO
					.getScenario_type_id());
			scenarioDTO.setWorkflowFieldValue(STARTDATE_NAME, scenarioDTO
					.getStart_date());
			scenarioDTO.setWorkflowFieldValue(SCENARIOID_NAME, scenarioDTO
					.getScenario_id());
			scenarioDTO.setWorkflowFieldValue(CASECREATECHANNEL_NAME,
					new Integer(1));
			scenarioDTO.setWorkflowFieldValue(STREAMNAME_NAME, scenarioDTO
					.getStream_name());
			
			scenarioDTO.setWorkflowFieldValue(STREAMID_NAME, scenarioDTO
					.getStream_id());
			
			scenarioDTO.setWorkflowFieldValue(SUBPROCESS_NAME, scenarioDTO
					.getSubprocess_name());
			scenarioDTO.setWorkflowFieldValue(PROCESS_NAME, scenarioDTO
					.getProcess_name());
			scenarioDTO.setWorkflowFieldValue(PROCESSID_NAME, scenarioDTO
					.getProcess_id());
			scenarioDTO.setWorkflowFieldValue(TASKDETAILSXML_NAME, scenarioDTO
					.getTaskDetailsXML());

			/*
			 * Calculate the sla date and if it is modified then retain the 
			 * time 
			 */
			FinanceFA_CIOperations financeOp = new FinanceFA_CIOperations();
			log.debug("Checking the Process sla date "
					+ scenarioDTO.getProcess_sla());
			Date[] tempDate = financeOp.calculateSLA(scenarioDTO
					.getProcess_sla(), null, scenarioDTO.getSla_type_id()
					.intValue(),
					scenarioDTO.getSla_calculation_id().intValue(), scenarioDTO
							.getStart_time(), scenarioDTO.getEnd_time());

			if (tempDate != null) {
				try {
					SimpleDateFormat simDate = new SimpleDateFormat(
							FinanceFA_Constants.DATE_PATTERN);
					Date processSlaDate_DB = simDate.parse(scenarioDTO.getProcess_sla());
					if(processSlaDate_DB.equals(tempDate[0])) {
						log.debug("Process sla not changed");
						
					} else {
						log.debug("Process sla has been changed. Process sla in database is:"
								+ processSlaDate_DB
								+ " and after altering:" + tempDate[0]);
						log.debug("Reverting the time field of new process sla to that of process sla in database.");
						Calendar newCal = Calendar.getInstance();
						newCal.setTime(tempDate[0]);

						Calendar dbCal = Calendar.getInstance();
						dbCal.setTime(processSlaDate_DB);

						newCal.set(newCal.get(Calendar.YEAR), newCal
								.get(Calendar.MONTH),
								newCal.get(Calendar.DATE), dbCal
										.get(Calendar.HOUR_OF_DAY), dbCal
										.get(Calendar.MINUTE), dbCal
										.get(Calendar.SECOND));

						tempDate[0] = newCal.getTime();
						log.debug("After changing the time field, new process sla is:"
										+ tempDate[0]);
					}
				} catch (ParseException e) {
					log.error(
							"Error occured while parsing the process sla. It should be in "
									+ FinanceFA_Constants.DATE_PATTERN
									+ "format.", e);
				}

				// Used to update the current scenario sla
				scenarioDTO.setProcess_sla_date(new Timestamp(tempDate[0].getTime()));
				scenarioDTO.setWorkflowFieldValue(PROCESSSLA_NAME, tempDate[0]);
				
				NotificationMapper notificationMapper = new NotificationMapper(
						scenarioDTO.getSla_calculation_id(), scenarioDTO
								.getStart_time(), scenarioDTO.getEnd_time());
				
				notificationMapper.setWorkflowFields(scenarioDTO
						.getProcessNotificationList(), tempDate[0], htTimers,
						htTO, htCC, htBCC, htEmailIsEnabled);
			}

			MilestoneMapper milestoneMapper = new MilestoneMapper(scenarioDTO
					.getSla_type_id(), scenarioDTO.getSla_calculation_id(),
					scenarioDTO.getStart_time(), scenarioDTO.getEnd_time());
			milestoneMapper.setWorkflowFields(scenarioDTO, htTimers, htTO,
					htCC, htBCC, htEmailIsEnabled);

			setTimerFields(scenarioDTO, htTimers, htTO, htCC, htBCC,
					htEmailIsEnabled);

		} catch (Exception ex) {
			log.error(
					"Error occured while mapping the DTO fields to workflow fields for "
							+ "Case Launch Cldr Id ["
							+ scenarioDTO.getCase_launch_cldr_id() + "]:"
							+ ex.getMessage(), ex);
		}
		log.debug("[Exit setWorkflowFields]");
	}

	
	/**
	 * Sets the scenario related information to workflow fields.
	 * <p>
	 * This method will be called for manual case creation process.
	 * Fields to return to workflow will be stored in an String array at
	 * specific index.
	 * The order of fields in returned array is:
	 * <pre>
	 * 		<b>Index</b>	<b>workflow field</b>
	 * 		0	FnFA_CScenarioMilestoneID
	 *		1	FnFA_CMilestoneOwnerRole
	 *		2	FnFA_CMilestoneName
	 *		3	FnFA_CMilestoneID
	 *		4	FnFA_CMilestoneType
	 *		5	FnFA_CMilestoneOrder
	 *		6	FnFA_CMilestoneDescription
	 *		7	FnFA_CMilestoneSLA
	 *		8	FnFA_CaseLaunchCldID
	 *		9	FnFA_CMilestoneTimerDate
	 *		10	FnFA_MilestoneTasksXML
	 *		11	FnFA_MilestoneDetailsXML
	 *		12	FnFA_MilestoneTimerDetailsXML
	 *		13	FnFA_CProcessTimerDate
	 *		14	FnFA_ProcessNotificationXML
	 *		15	FnFA_ScenarioTypeID
	 *		16	FnFA_SLATypeID
	 *		17	FnFA_SLACalculationID
	 *		18	FnFA_OfficeStartTime
	 *		19	FnFA_OfficeEndTime
	 *		20	FnFA_ProcessSLA
	 * </pre>
	 * 
	 * @param scenarioDTO
	 * @param wfReturnData
	 * @throws Exception 
	 */
	public String[] setWorkflowFields(ScenarioDTO scenarioDTO, int wfReturnData)
			throws Exception {
		log.debug("[Enter setWorkflowFields]");
		String[] returnArray = new String[21];
		FinanceFA_Utilities.initializeEmptyArray(returnArray);
		
		try {
			log.debug("Maping workflow fields for Case launch Cldr Id:"
					+ scenarioDTO.getCase_launch_cldr_id());

			log.debug("Adding case launch cldr id to output array");
			FinanceFA_Utilities.setField(returnArray, 8, scenarioDTO
					.getCase_launch_cldr_id()
					+ "");
			
			log.debug("Adding milestone task xml to output array");
			FinanceFA_Utilities.setField(returnArray, 10, scenarioDTO
					.getTaskDetailsXML());
			
			log.debug("Adding scenario type id to output array");
			FinanceFA_Utilities.setField(returnArray, 15, scenarioDTO
					.getScenario_type_id()
					+ "");
			
			log.debug("Adding sla type id to output array");
			FinanceFA_Utilities.setField(returnArray, 16, scenarioDTO
					.getSla_type_id()
					+ "");
			
			log.debug("Adding sla calculation id to output array");
			FinanceFA_Utilities.setField(returnArray, 17, scenarioDTO
					.getSla_calculation_id()
					+ "");
			
			log.debug("Adding office start time to output array");
			FinanceFA_Utilities.setField(returnArray, 18, scenarioDTO
					.getStart_time());
			
			log.debug("Adding office end time to output array");
			FinanceFA_Utilities.setField(returnArray, 19, scenarioDTO
					.getEnd_time());

			HashMap htTimers = new HashMap();
			HashMap htTO = new HashMap();
			HashMap htCC = new HashMap();
			HashMap htBCC = new HashMap();
			HashMap htEmailIsEnabled = new HashMap();

			/* Calculate the process sla date */
			FinanceFA_CIOperations financeOp = new FinanceFA_CIOperations();
			log.debug("Calculating the Process sla date for the offset "
					+ scenarioDTO.getProcess_sla());
			Date[] tempDate = financeOp.calculateSLA(scenarioDTO
					.getProcess_sla(), null, scenarioDTO.getSla_type_id()
					.intValue(),
					scenarioDTO.getSla_calculation_id().intValue(), scenarioDTO
							.getStart_time(), scenarioDTO.getEnd_time());

			if (tempDate != null) {

				// Used to update the current scenario sla
				scenarioDTO.setProcess_sla_date(new Timestamp(tempDate[0]
						.getTime()));
				String processSLADateStr = FinanceFA_Utilities.dateToString(
						tempDate[0]);
				log.debug("Adding process sla date to output array");
				FinanceFA_Utilities
						.setField(returnArray, 20, processSLADateStr);

				/* Get the first process timer date */
				getFirstProcessTimerDate(scenarioDTO, tempDate[0], returnArray,
						financeOp);

				/* Map the process notification fields */
				NotificationMapper notificationMapper = null;
				if (wfReturnData == FinanceFA_Constants.WF_RETURN_ARRAY_DATA) {

					notificationMapper = new NotificationMapper(scenarioDTO
							.getSla_calculation_id(), scenarioDTO
							.getStart_time(), scenarioDTO.getEnd_time());
					notificationMapper.setWorkflowFields(scenarioDTO
							.getProcessNotificationList(), tempDate[0],
							htTimers, htTO, htCC, htBCC, htEmailIsEnabled);

				} else if (wfReturnData == FinanceFA_Constants.WF_RETURN_XML_DATA) {

					notificationMapper = new NotificationMapper();
					notificationMapper.setWorkflowFields(scenarioDTO,
							returnArray);
				}
			}

			/* Map the milestone fields */
			MilestoneMapper milestoneMapper = new MilestoneMapper(scenarioDTO
					.getSla_type_id(), scenarioDTO.getSla_calculation_id(),
					scenarioDTO.getStart_time(), scenarioDTO.getEnd_time());

			/* Map the workflow fields in array format */
			if (wfReturnData == FinanceFA_Constants.WF_RETURN_ARRAY_DATA) {
				milestoneMapper.setWorkflowFields(scenarioDTO, htTimers, htTO,
						htCC, htBCC, htEmailIsEnabled);

			} else if (wfReturnData == FinanceFA_Constants.WF_RETURN_XML_DATA) {

				/* Map the workflow fields in xml format */
				milestoneMapper.setWorkflowFields(scenarioDTO, returnArray);
			}

		} catch (Exception ex) {
			log.error(
					"Error occured while mapping the DTO fields to workflow fields for "
							+ "Case Launch Cldr Id ["
							+ scenarioDTO.getCase_launch_cldr_id() + "]:"
							+ ex.getMessage(), ex);
			throw ex;
		}
		log.debug("[Exit setWorkflowFields]");
		return returnArray;
	}

	private void getFirstProcessTimerDate(ScenarioDTO scenarioDTO,
			Date processSLADate, String[] returnArray, FinanceFA_CIOperations financeOp) throws Exception {
		
		log.debug("[Enter getFirstProcessTimerDate]");
		
		String processSLADateStr = FinanceFA_Utilities
				.dateToString(processSLADate);
		
		ArrayList notificationsList = scenarioDTO.getProcessNotificationList();
		if (notificationsList != null) {
			if (notificationsList.size() == 0) {
				log.info("No process notifications configured.");

				/* First process timer date is same as process sla date */
				log.debug("Adding process first timer date to output array");
				FinanceFA_Utilities
						.setField(returnArray, 13, processSLADateStr);
			} else {

				/* Get the first notification dto */
				NotificationDTO notificationDTO = (NotificationDTO) notificationsList
						.get(0);
				
				/*
				 * If first notification is a reminder then we have to calculate its exact 
				 * expiration date otherwise(means escalation) then first timer to start will be 
				 * sla timer 
				 */
				if ("Reminder".equalsIgnoreCase(notificationDTO
						.getNotification_type())) {
					Date[] timerDate = financeOp.calculateSLA(notificationDTO
							.getOffset(), processSLADate, scenarioDTO
							.getSla_type_id().intValue(), scenarioDTO
							.getSla_calculation_id().intValue(), scenarioDTO
							.getStart_time(), scenarioDTO.getEnd_time());
					log.debug("Adding process first timer date to output array");
					FinanceFA_Utilities.setField(returnArray, 13,
							FinanceFA_Utilities.dateToString(timerDate[0]));
				} else {
					log.debug("Adding process first timer date to output array");
					FinanceFA_Utilities.setField(returnArray, 13, processSLADateStr);
				}
			}
		} else {

			/* First process timer date is same as process sla date */
			log.debug("Adding process first timer date to output array");
			FinanceFA_Utilities.setField(returnArray, 13, processSLADateStr);
		}
		log.debug("[Exit getFirstProcessTimerDate]");
	}


	private void setTimerFields(ScenarioDTO scenarioDTO, HashMap htTimers,
			HashMap htTO, HashMap htCC, HashMap htBCC, HashMap htEmailIsEnabled) {
		log.debug("[Enter setTimerFields]");
		try {
			String[] allTimerNameArray = new String[htTimers.size()];
			Date[] allTimerDateArray = new Date[htTimers.size()];
			Boolean[] isTimerNotificationFiredArray = new Boolean[htTimers
					.size()];
			String[] allTimerTO = new String[htTimers.size()];
			String[] allTimerCC = new String[htTimers.size()];
			String[] allTimerBCC = new String[htTimers.size()];
			Boolean[] timerNotificationIsEnabledArray = new Boolean[htTimers
					.size()];

			log.debug("Sorting the map based on time of sla dates");
			ArrayList outputList = sortMap(htTimers);
			int count = 0;
			count = outputList.size();
			while (count > 0) {
				Map.Entry entry = (Map.Entry) outputList.get(--count);
				log.debug("Key:" + entry.getKey() + " \tValue:"
						+ entry.getValue());
				
				allTimerNameArray[count] = (String) entry.getKey();
				allTimerDateArray[count] = (Date) entry.getValue();

				isTimerNotificationFiredArray[count] = new Boolean(false);
				allTimerTO[count] = htTO.get(entry.getKey()).toString();
				allTimerCC[count] = htCC.get(entry.getKey()).toString();
				allTimerBCC[count] = htBCC.get(entry.getKey()).toString();
				
				timerNotificationIsEnabledArray[count] = (("Y")
						.equalsIgnoreCase(htEmailIsEnabled.get(entry.getKey())
								.toString()) ? new Boolean(true) : new Boolean(
						false));

			}
			log.debug("Setting allTimerNameArray:"
					+ Utilities.displayArray(allTimerNameArray));
			scenarioDTO.setWorkflowFieldValue(ALLTIMERNAMEARRAY_NAME,
					allTimerNameArray);

			log.debug("Setting allTimerDateArray:"
					+ Utilities.displayObjectArray(allTimerDateArray));
			scenarioDTO.setWorkflowFieldValue(ALLTIMERDATEARRAY_NAME,
					allTimerDateArray);

			log.debug("Setting isTimerNotificationFiredArray:"
					+ Utilities
							.displayObjectArray(isTimerNotificationFiredArray));
			scenarioDTO.setWorkflowFieldValue(
					ISTIMERNOTIFICATIONFIREDARRAY_NAME,
					isTimerNotificationFiredArray);

			log.debug("Setting allTimerTO:"
					+ Utilities.displayObjectArray(allTimerTO));
			scenarioDTO.setWorkflowFieldValue(ALLTIMERTO_NAME, allTimerTO);

			log.debug("Setting allTimerCC:"
					+ Utilities.displayObjectArray(allTimerCC));
			scenarioDTO.setWorkflowFieldValue(ALLTIMERCC_NAME, allTimerCC);

			log.debug("Setting allTimerBCC:"
					+ Utilities.displayObjectArray(allTimerBCC));
			scenarioDTO.setWorkflowFieldValue(ALLTIMERBCC_NAME, allTimerBCC);

			log.debug("Setting timerNotificationIsEnabledArray:"
							+ Utilities
									.displayObjectArray(timerNotificationIsEnabledArray));
			scenarioDTO.setWorkflowFieldValue(
					TIMERNOTIFICATIONISENABLEDARRAY_NAME,
					timerNotificationIsEnabledArray);
		} catch (Exception ex) {
			log.error(
					"Error occured while mapping the DTO's timer fields to workflow fields for "
							+ "Case Launch Cldr Id ["
							+ scenarioDTO.getCase_launch_cldr_id() + "]:"
							+ ex.getMessage(), ex);
		}
		log.debug("[Exit setTimerFields]");
	}

	public ArrayList sortMap(Map map) {
		ArrayList outputList = null;
		int count = 0;
		Set set = null;
		Map.Entry[] entries = null;
		// Logic:
		// get a set from Map
		// Build a Map.Entry[] from set
		// Sort the list using Arrays.sort
		// Add the sorted Map.Entries into arrayList and return

		set = (Set) map.entrySet();
		Iterator iterator = set.iterator();
		entries = new Map.Entry[set.size()];
		while (iterator.hasNext()) {
			entries[count++] = (Map.Entry) iterator.next();
		}

		// Sort the entries with your own comparator for the values:
		Arrays.sort(entries, new Comparator() {
			// public int compareTo(Object lhs, Object rhs) {
			// Map.Entry le = (Map.Entry) lhs;
			// Map.Entry re = (Map.Entry) rhs;
			// return ((Comparable) le.getValue()).compareTo((Comparable) re
			// .getValue());
			// }

			public int compare(Object lhs, Object rhs) {
				Map.Entry le = (Map.Entry) lhs;
				Map.Entry re = (Map.Entry) rhs;
				return ((Comparable) le.getValue()).compareTo((Comparable) re
						.getValue());
			}
		});
		outputList = new ArrayList();
		for (int i = 0; i < entries.length; i++) {
			outputList.add(entries[i]);
		}
		return outputList;
	}
}
