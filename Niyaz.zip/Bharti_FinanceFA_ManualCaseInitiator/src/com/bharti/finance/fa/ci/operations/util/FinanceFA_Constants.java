/*
 * Created on Jul 12, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util;

import com.bharti.fa.common.operations.util.Constants;

/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @viz.diagram Finance_Constants.tpx
 */
public class FinanceFA_Constants extends Constants {

	public static final Character SCENARIO_NOTLAUNCHED = new Character('N');

	public static final Character SCENARIO_SUCESS = new Character('S');

	public static final Character SCENARIO_FAILURE = new Character('F');
	
	public static final String STRING_CASE_LAUNCH_CLDR_ID = "CASE_LAUNCH_CLDR_ID";
	
	public static final String STRING_SCENARIO_ID = "SCENARIO_ID";
	
	public static final String STRING_SCENARIO_MILESTONE_ID = "SCENARIO_MILESTONE_ID";
	
	public static final String STRING_NOTIFICATION_CATEGORY = "NOTIFICATION_CATEGORY";
	
	public static final String STRING_CRON = "CRON";
	
	public static final String STRING_PROCESS = "Process";
	
	public static final String DATE_PATTERN = "yyyy-MM-dd HH:mm:ss";
	
	public static final int WF_RETURN_ARRAY_DATA = 1;
	
	public static final int WF_RETURN_XML_DATA = 2;
}