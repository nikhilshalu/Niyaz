/*
 * Created on Jun 10, 2009
 *
 */
package com.bharti.finance.fa.ci.operations;

import java.util.Properties;

import org.apache.log4j.Logger;

import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.Utilities;

/**
 * The <code>CaseInitiator</code> class initiates the case launch process.
 * <p>
 * This class will be called by the cronjob scheduler. It initializes the log4j
 * and custom property file and calls the FinanceFAOperations
 * <code>initiateCase</code> method which processes the request.
 * 
 * @author Harisha Achar
 * @viz.diagram CaseInitiator.tpx
 */
public class CaseInitiator {

	public static Logger log = Logger.getLogger(CaseInitiator.class);

	private static String file_separator;

	static {

		/* Load Log4j property file */
		file_separator = System.getProperty("file.separator");
		String propPath = "config" + file_separator + "xml" + file_separator
				+ "FinanceFA_log4j.xml";

		PropertyLoader.loadLog4jXML(propPath);

		log.info("*********** Case Initiator Scheduler started ***********");

		/* Load custom property file */
		log.debug("Loading property file.....");
		Properties prop = null;
		propPath = "config" + file_separator + "properties" + file_separator
				+ "FinanceFA_Components.properties";
		try {
			prop = PropertyLoader.loadPropertiesFromFile(propPath);
		} catch (IllegalArgumentException e) {
			log.error("Error occured while loading property file."
					+ e.getMessage(), e);
		}
		if (prop == null) {
			log.error("Unable to load Custom property file");
		}
	}

	/**
	 * Calls the FinanceOperations <code>initiateCase</code> method which
	 * processes the request.
	 * 
	 * @param args
	 *            Command line arguments
	 */
	public static void main(String[] args) {
		log.debug("[Enter main]: args [" + Utilities.displayArray(args) + "]");

		FinanceFA_CIOperations fnOperations = new FinanceFA_CIOperations();
		boolean success = fnOperations.initiateCase(args);
		log.debug("Scheduler execution completed. Status:" + success);
		if(success) {
			log.info("*********** Case Launch process completed successfully *********** ");
		} else {
			log.info("*********** Error occurred in the case launch process *********** ");
		}
		log.debug("[Exit main]");
	}
}
