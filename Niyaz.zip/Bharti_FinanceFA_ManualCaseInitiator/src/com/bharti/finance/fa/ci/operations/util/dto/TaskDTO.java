package com.bharti.finance.fa.ci.operations.util.dto;

public class TaskDTO {
	private Integer scenario_id 				= new Integer(-1);
	private Integer scenario_milestone_id 		= new Integer(-1);
	private Integer task_id						= new Integer(-1);
	private String task_name					= "";
	private Integer task_order			 		= new Integer(-1);
	private String task_description				= "";
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("scenario_id:[" + getScenario_id() + "] ")
							.append("scenario_milestone_id:[" + getScenario_milestone_id() + "] ")
							.append("task_id:[" + getTask_id() + "] ")
							.append("task_name:[" + getTask_name() + "] ")
							.append("task_order:[" + getTask_order() + "] ")
							.append("task_description:[" + getTask_description() + "] ");
		return buf.toString();
	}
	
	public String getTask_name() {
		return task_name;
	}
	public void setTask_name(String task_name) {
		this.task_name = task_name;
	}
	public Integer getScenario_id() {
		return scenario_id;
	}
	public void setScenario_id(Integer scenario_id) {
		this.scenario_id = scenario_id;
	}
	public Integer getScenario_milestone_id() {
		return scenario_milestone_id;
	}
	public void setScenario_milestone_id(Integer scenario_milestone_id) {
		this.scenario_milestone_id = scenario_milestone_id;
	}
	public String getTask_description() {
		return task_description;
	}
	public void setTask_description(String task_description) {
		this.task_description = task_description;
	}
	public Integer getTask_id() {
		return task_id;
	}
	public void setTask_id(Integer task_id) {
		this.task_id = task_id;
	}
	public Integer getTask_order() {
		return task_order;
	}
	public void setTask_order(Integer task_order) {
		this.task_order = task_order;
	}	
}
