/*
 * Created on Jun 10, 2009
 *
 */
package com.bharti.finance.fa.ci.operations.util.dto;

/**
 * @author Harisha
 * @viz.diagram NotificationDTO.tpx
 *
 */
public class NotificationDTO {
	private Integer notification_id 		= new Integer(-1);
	private Integer scenario_id 			= new Integer(-1);
	private Integer scenario_milestone_id 	= new Integer(-1);
	private String notification_category	= "";
	private String notification_type		= "";
	private Integer notification_level 		= new Integer(-1);
	private String offset 					= "";
	private String notification_to			= "";
	private String notification_cc			= "";
	private String notification_bcc			= "";
	private Character notification_email_is_enabled		= new Character('N');
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("notification_id:[" + getNotification_id() + "] ")
							.append("scenario_id:[" + getScenario_id() + "] ")
							.append("scenario_milestone_id:[" + getScenario_milestone_id() + "] ")
							.append("notification_category:[" + getNotification_category() + "] ")
							.append("notification_type:[" + getNotification_type() + "] ")
							.append("notification_level:[" + getNotification_level() + "] ")
							.append("offset:[" + getOffset() + "] ")
							.append("notification_to:[" + getNotification_to() + "] ")
							.append("notification_cc:[" + getNotification_cc() + "] ")
							.append("notification_bcc:[" + getNotification_bcc() + "] ")
							.append("notification_email_is_enabled:[" + getNotification_email_is_enabled() + "] ");
		return buf.toString();
	}
	
		
	
	public String getNotification_bcc() {
		return notification_bcc;
	}



	public void setNotification_bcc(String notification_bcc) {
		this.notification_bcc = notification_bcc;
	}



	/**
	 * @return Returns the notification_email_is_enabled.
	 */
	public Character getNotification_email_is_enabled() {
		return notification_email_is_enabled;
	}
	/**
	 * @param notification_email_is_enabled The notification_email_is_enabled to set.
	 */
	public void setNotification_email_is_enabled(
			Character notification_email_is_enabled) {
		this.notification_email_is_enabled = notification_email_is_enabled;
	}
	/**
	 * @return Returns the notification_category.
	 */
	public String getNotification_category() {
		return notification_category;
	}
	/**
	 * @param notification_category The notification_category to set.
	 */
	public void setNotification_category(String notification_category) {
		this.notification_category = notification_category;
	}
	/**
	 * @return Returns the notification_cc.
	 */
	public String getNotification_cc() {
		return notification_cc;
	}
	/**
	 * @param notification_cc The notification_cc to set.
	 */
	public void setNotification_cc(String notification_cc) {
		this.notification_cc = notification_cc;
	}
	/**
	 * @return Returns the notification_id.
	 */
	public Integer getNotification_id() {
		return notification_id;
	}
	/**
	 * @param notification_id The notification_id to set.
	 */
	public void setNotification_id(Integer notification_id) {
		this.notification_id = notification_id;
	}
	/**
	 * @return Returns the notification_level.
	 */
	public Integer getNotification_level() {
		return notification_level;
	}
	/**
	 * @param notification_level The notification_level to set.
	 */
	public void setNotification_level(Integer notification_level) {
		this.notification_level = notification_level;
	}
	/**
	 * @return Returns the notification_to.
	 */
	public String getNotification_to() {
		return notification_to;
	}
	/**
	 * @param notification_to The notification_to to set.
	 */
	public void setNotification_to(String notification_to) {
		this.notification_to = notification_to;
	}
	/**
	 * @return Returns the notification_type.
	 */
	public String getNotification_type() {
		return notification_type;
	}
	/**
	 * @param notification_type The notification_type to set.
	 */
	public void setNotification_type(String notification_type) {
		this.notification_type = notification_type;
	}
	/**
	 * @return Returns the offset.
	 */
	public String getOffset() {
		return offset;
	}
	/**
	 * @param offset The offset to set.
	 */
	public void setOffset(String offset) {
		this.offset = offset;
	}
	/**
	 * @return Returns the scenario_id.
	 */
	public Integer getScenario_id() {
		return scenario_id;
	}
	/**
	 * @param scenario_id The scenario_id to set.
	 */
	public void setScenario_id(Integer scenario_id) {
		this.scenario_id = scenario_id;
	}
	/**
	 * @return Returns the scenario_milestone_id.
	 */
	public Integer getScenario_milestone_id() {
		return scenario_milestone_id;
	}
	/**
	 * @param scenario_milestone_id The scenario_milestone_id to set.
	 */
	public void setScenario_milestone_id(Integer scenario_milestone_id) {
		this.scenario_milestone_id = scenario_milestone_id;
	}
}
