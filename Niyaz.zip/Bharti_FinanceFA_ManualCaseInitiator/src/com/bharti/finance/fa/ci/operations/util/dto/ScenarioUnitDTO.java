/*
 * Created on Jul 10, 2009
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.bharti.finance.fa.ci.operations.util.dto;

/**
 * @author Harisha
 *
 * TODO To change the template for this generated type comment go to
 * Window - Preferences - Java - Code Style - Code Templates
 * @viz.diagram ScenarioUnitDTO.tpx
 */
public class ScenarioUnitDTO {
	private Integer lob_id 			= new Integer(-1);
	private String lob_name			= "";
	private Integer circle_id 		= new Integer(-1);
	private String circle_name 		= "";
	private Integer operator_id 	= new Integer(-1);
	private String operator_name	= "";
	
	
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	public String toString() {
		StringBuffer buf = new StringBuffer().append("lob_id:[" + getLob_id() + "] ")
						.append("lob_name:[" + getLob_name() + "] ")
						.append("circle_id:[" + getCircle_id() + "] ")
						.append("circle_name:[" + getCircle_name() + "] ")
						.append("operator_id:[" + getOperator_id() + "] ")
						.append("operator_name:[" + getOperator_name() + "] ");
		return buf.toString();
	}
	/**
	 * @return Returns the circle_id.
	 */
	public Integer getCircle_id() {
		return circle_id;
	}
	/**
	 * @param circle_id The circle_id to set.
	 */
	public void setCircle_id(Integer circle_id) {
		this.circle_id = circle_id;
	}
	/**
	 * @return Returns the circle_name.
	 */
	public String getCircle_name() {
		return circle_name;
	}
	/**
	 * @param circle_name The circle_name to set.
	 */
	public void setCircle_name(String circle_name) {
		this.circle_name = circle_name;
	}
	/**
	 * @return Returns the lob_id.
	 */
	public Integer getLob_id() {
		return lob_id;
	}
	/**
	 * @param lob_id The lob_id to set.
	 */
	public void setLob_id(Integer lob_id) {
		this.lob_id = lob_id;
	}
	/**
	 * @return Returns the lob_name.
	 */
	public String getLob_name() {
		return lob_name;
	}
	/**
	 * @param lob_name The lob_name to set.
	 */
	public void setLob_name(String lob_name) {
		this.lob_name = lob_name;
	}
	/**
	 * @return Returns the operator_id.
	 */
	public Integer getOperator_id() {
		return operator_id;
	}
	/**
	 * @param operator_id The operator_id to set.
	 */
	public void setOperator_id(Integer operator_id) {
		this.operator_id = operator_id;
	}
	/**
	 * @return Returns the operator_name.
	 */
	public String getOperator_name() {
		return operator_name;
	}
	/**
	 * @param operator_name The operator_name to set.
	 */
	public void setOperator_name(String operator_name) {
		this.operator_name = operator_name;
	}
}
