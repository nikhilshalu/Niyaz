/*
 * Created on Jun 10, 2009
 *
 */
package com.bharti.finance.fa.ci.operations;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.apache.log4j.Logger;
import org.apache.log4j.MDC;

import com.bharti.fa.common.operations.util.Base64;
import com.bharti.fa.common.operations.util.PropertyLoader;
import com.bharti.fa.common.operations.util.manager.EscalationManager;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Constants;
import com.bharti.finance.fa.ci.operations.util.FinanceFA_Utilities;
import com.bharti.finance.fa.ci.operations.util.manager.FinanceFA_ExternalDBManager;
import com.bharti.finance.fa.ci.operations.util.manager.FinanceFA_PEManager;
import com.bharti.finance.fa.ci.operations.util.mapper.ScenarioMapper;
import com.bharti.finance.fa.ci.operations.util.dto.MilestoneDTO;
import com.bharti.finance.fa.ci.operations.util.dto.ScenarioDTO;

/**
 * The <code>FinanceOperations</code> class manages the case launch process.
 * <p>
 * This class is responsible for retrieving the active scenario list from the
 * database and then it prepares all the necessary workflow fields and processes
 * those scenarios.
 * 
 * @author Harisha Achar
 * @viz.diagram FinanceOperations.tpx
 */
public class FinanceFA_CIOperations {

	private static String holidayXMLPath;

	public static Logger log = Logger.getLogger(FinanceFA_CIOperations.class);

	/**
	 * Retrieves the active scenario list from the database and then it prepares
	 * all the necessary workflow fields and processes those scenarios.
	 * 
	 * @param 	args
	 * 			Command line arguments
	 * @return	true if case launch process is successfull otherwise false
	 */
	public boolean initiateCase(String[] args) {
		log.debug("[Enter initiateCase]: args [" + FinanceFA_Utilities.displayArray(args)
				+ "]");
		boolean success = false;
		FinanceFA_ExternalDBManager dbManager = null;

		try {
			
			/* Get database connection */
			log.debug("Retrieving the active scenario list from database.");
			dbManager = new FinanceFA_ExternalDBManager(
					FinanceFA_Constants.APPLICATION_STANDALONE);
			dbManager.getDbConnection();

			/* Get the active scenarios */
			ArrayList activeScenarioList = dbManager
					.getActiveCalendarScenarios();
			if (activeScenarioList != null) {
				log.debug("*********** " + activeScenarioList.size()
						+ " active scenarios found ***********");
			}

			/* If no active scenarios are found in the database */
			if (activeScenarioList == null || activeScenarioList.size() == 0) {
				log.info("*********** No Active Calendar Scenarios found ***********");
				return true;
			}

			/* Prepare workflow fields from the active scenario list */
			log.debug("Preparing workflow fields from the active scenario list");
			prepareWorkflowFields(activeScenarioList);

			success = processActiveCalendarScenarios(dbManager, activeScenarioList);
		} catch (Exception ex) {
			log.error("Error occured while initiating the cases."
					+ ex.getMessage(), ex);
			success = false;
		} finally {

			/* Close the database connection */
			dbManager.closeDbConnection();
			log.debug("Database connection closed successfully.");
		}
		log.debug("[Exit initiateCase]");
		return success;
	}

	/**
	 * Processes the active scenario list. It stores the active scenario's
	 * future configuration in the database. It then launches workflow for those
	 * scenarios and updates the scenarios launch status and its sla dates
	 * accordingly.
	 * 
	 * @param dbManager
	 *            database connection object
	 * @param activeScenarioList
	 *            array list of active scenarios ScenarioDTO bean
	 * @return true if successfully processes the active scenario list otherwise
	 *         false
	 */
	private boolean processActiveCalendarScenarios(
			FinanceFA_ExternalDBManager dbManager, ArrayList activeScenarioList) {
		log.debug("[Enter processActiveCalendarScenarios]");

		boolean success = true;
		boolean isOrdered = false;
		FinanceFA_PEManager peMgr = null;
		log.info("Active scenarioList size:" + activeScenarioList.size());
		try {
			
			/*
			 * Get the Process Engine session.
			 * 
			 * On Exception: If unable to get the PE session then log the error
			 * and stop processing; thus the active scenarios status will still
			 * be 'N' (meaning not launched). During next scheduler launch, it
			 * will once again try to launch those scenarios.
			 */
			String bpmUser = Base64.decrypt(PropertyLoader.props
					.getProperty("BPM_USER_ID"));
			String bpmPwd = Base64.decrypt(PropertyLoader.props
					.getProperty("BPM_USER_PASSWORD"));
			peMgr = new FinanceFA_PEManager(FinanceFA_Constants.APPLICATION_STANDALONE,
					bpmUser, bpmPwd, null);

			/* Process each active scenario */
			for (int i = 0; i < activeScenarioList.size(); i++) {
				ScenarioDTO scenarioDTO = (ScenarioDTO) activeScenarioList
						.get(i);
				
				/* Insert the MDC checkpoints */
				MDC.put(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID, scenarioDTO
						.getCase_launch_cldr_id());
				MDC.put(FinanceFA_Constants.STRING_SCENARIO_ID, scenarioDTO
						.getScenario_id());
				
				isOrdered = checkSLAOrderOfLaunchConfiguration(scenarioDTO);
				if(isOrdered == false) {
					log.error("Unable to process the scenario. Its milestone sla and process sla are not in sorted order. Continuing with next scenario.");
					success = false;
					continue;
				}
				
				/*
				 * Store active scenario's future configuration in calendar
				 * table and get number of scenario units(workflows) to be
				 * launched for each active scenario.
				 * 
				 * On Exception: The storing future configuration process in
				 * multiple tables is done in transaction.
				 * 
				 * Scenario 1: On any exception during storing; transaction will
				 * be rollbacked and status will still be 'N' (meaning not
				 * launched) for current scenario and continues processing for
				 * next scenario.
				 * 
				 * Scenario 2: If future configuration storing process is
				 * sucessfull and then if any exception occurs; then status will
				 * be changed to 'F' (meaning failure). Next time when scheduler
				 * processes this scenario, it will check whether the future
				 * configuration is already stored for this scenarion or not; if
				 * already present then it won't inserts.
				 */
				ArrayList scenarioUnitList;
				try {
					scenarioUnitList = dbManager
							.processActiveCalendarScenarios(scenarioDTO);
					if (scenarioUnitList == null || scenarioUnitList.size() == 0) {
						log.error("Unable to launch the workflow for scenario "
								+ scenarioDTO
								+ ". Number of workflow unit to be launched is zero or scenarioUnitList is null. Continuing with next active scenario.");
						continue;
					}
					
					/* Check the sla sort order of future configuration */
					checkSLAOrderOfFutureConfiguration(scenarioDTO);
				} catch (Exception e2) {
					log.error(
							"Error occured while processing the active scenario list."
									+ e2.getMessage(), e2);
					success = false;
					continue;
				}
				
				
				/* Launch workflow */
				try {
					peMgr.launchScenario(scenarioDTO, scenarioUnitList);
				} catch (Exception e) {
					log.error(
							"Error occured while launching the workflow for active scenarios"
									+ e.getMessage(), e);
					success = false;
				}

				/* Update the status of processed scenarios */
				int updatedRowCount = dbManager.updateScenarioLaunchStatus(
						scenarioDTO, FinanceFA_Constants.STRING_CRON);
				
				/* Update the sla dates of the processed scenarios if modified */
				dbManager.updateScenarioSLADates(scenarioDTO);
				if (updatedRowCount == 0) {
					log.error("Unable to update the status of scenario");
				}
				
				/* Remove the MDC checkpoints */
				MDC.remove(FinanceFA_Constants.STRING_CASE_LAUNCH_CLDR_ID);
				MDC.remove(FinanceFA_Constants.STRING_SCENARIO_ID);
			}
			log
					.info("---------------------------------------------------------");
			log.info("Total " + FinanceFA_PEManager.totalLaunchedWorkflowsCount
					+ " number of workflows launched successfully.");

			log.info("Total " + FinanceFA_PEManager.totalFailedWorkflowsCount
					+ " number of workflows failed to launch.");
			log
					.info("---------------------------------------------------------");
			
		} catch (Exception e1) {
			log.fatal(
					"Exception occured while processing the active scenarios list."
							+ e1.getMessage(), e1);
			success = false;
		} finally {

			/* End the Process Engine Session */
			if (peMgr != null) {
				peMgr.closePESession();
				log.debug("PE session logged off successfully.");
			}
		}
		log.debug("[Exit processActiveCalendarScenarios]");
		return success;
	}

	/**
	 * Checks whether the sla dates of scenario future configuration's milestone
	 * sla and its process sla are in sorted order or not. These sla date should
	 * be:
	 * 
	 * <pre>
	 *    Milestone 1 sla date &lt;= Milestone 2 sla date &lt;= .... &lt;= Process sla
	 * </pre>
	 * 
	 * @param scenarioDTO
	 * @return
	 */
	private boolean checkSLAOrderOfFutureConfiguration(ScenarioDTO scenarioDTO) {
		log.debug("[Enter checkSLAOrderOfFutureConfiguration]");
		boolean isOrdered = false;
		Date date = null;
		
		try {
			SimpleDateFormat simDate = new SimpleDateFormat(
					FinanceFA_Constants.DATE_PATTERN);
			ArrayList milestoneList = scenarioDTO.getMilestoneList();
			if (milestoneList != null) {
				Timestamp[] allSLAArray = new Timestamp[milestoneList.size() + 1];

				/* Insert all milestone's sla */
				int numMilestones = milestoneList.size();
				int mIndex = 0;
				for (; mIndex < numMilestones; mIndex++) {
					
					try {
						date = simDate.parse(((MilestoneDTO) milestoneList
								.get(mIndex)).getMilestone_sla());
						Date newSLADate = FinanceFA_Utilities.getNewDate(date, scenarioDTO
								.getFrequency_id());
						allSLAArray[mIndex] = new Timestamp(newSLADate.getTime());
						allSLAArray[mIndex].setNanos(0);
					} catch (ParseException e) {
						log.error(
								"Unable to parse the milestone sla string to date."
										+ e.getMessage(), e);
					}
				}

				/* Insert the process sla */
				try {
					date = simDate.parse(scenarioDTO.getProcess_sla());
					Date newSLADate = FinanceFA_Utilities.getNewDate(date, scenarioDTO
							.getFrequency_id());
					allSLAArray[mIndex] = new Timestamp(newSLADate.getTime());
					allSLAArray[mIndex].setNanos(0);
				} catch (ParseException e) {
					log.error(
							"Unable to parse the milestone sla string to date."
									+ e.getMessage(), e);
				}
				log
						.debug("SLA Array containing milestone sla and process sla is :"
								+ FinanceFA_Utilities
										.displayObjectArray(allSLAArray));
				int index = FinanceFA_Utilities.isSortedDateArray(allSLAArray);
				if (index == -1) {
					log
							.debug("All milestone's sla and process sla is in sorted order.");
					isOrdered = true;
				} else {
					StringBuffer buf = new StringBuffer(
							"Milestone sla and process sla for the following scenario are not in sorted order. ")
							.append("\n\nScenario ID: ")
							.append(scenarioDTO.getScenario_id())
							.append("\nProcess Name: ")
							.append(scenarioDTO.getProcess_name())
							.append("\nSubProcess Name: ")
							.append(scenarioDTO.getSubprocess_name())
							.append("\nCase Launch Cldr Id: ")
							.append(scenarioDTO.getCase_launch_cldr_id())
							.append("\nStart date: ")
							.append(scenarioDTO.getStart_date())
							.append("\nAll sla array: [")
							.append(
									FinanceFA_Utilities
											.displayObjectArray(allSLAArray))
							.append("]\n\nFirst difference in the array is: Milestone [")
							.append((index + 1))
							.append("]'s sla date [")
							.append(allSLAArray[index])
							.append("] is greater than ")
							.append(
									(allSLAArray.length == (index + 2) ? "Process"
											: "Milestone [" + (index + 2) + "]"))
							.append("'s sla date [" + allSLAArray[index + 1])
							.append(
									"]. \nPlease take immediate action to correct the sla dates.")
							.append("\n\nRegards\nFileNet Team.");
					log.fatal(buf);
					isOrdered = false;
				}
			}
		} catch (Exception e) {
			log.error("Error occured while checking the order of sla dates."
					+ e.getMessage(), e);
		}
		log.debug("[Exit checkSLAOrderOfFutureConfiguration]");
		return isOrdered;
	}

	/**
	 * Checks the sla dates of scenario's milestone sla and its process sla.
	 * These sla date should be:
	 * 
	 * <pre>
	 *  Milestone 1 sla date &lt;= Milestone 2 sla date &lt;= .... &lt;= Process sla
	 * </pre>
	 * 
	 * @param scenarioDTO
	 * @return
	 */
	private boolean checkSLAOrderOfLaunchConfiguration(ScenarioDTO scenarioDTO) {
		log.debug("[Enter checkSLAOrderOfLaunchConfiguration]");
		boolean isOrdered = false;
		try {
			ArrayList milestoneList = scenarioDTO.getMilestoneList();
			if (milestoneList != null) {
				Timestamp[] allSLAArray = new Timestamp[milestoneList.size() + 1];

				/* Insert all milestone's sla */
				int numMilestones = milestoneList.size();
				int mIndex = 0;
				for (; mIndex < numMilestones; mIndex++) {
					allSLAArray[mIndex] = ((MilestoneDTO) milestoneList
							.get(mIndex)).getMilestone_sla_date();
					allSLAArray[mIndex].setNanos(0);
				}

				/* Insert the process sla */
				allSLAArray[mIndex] = scenarioDTO.getProcess_sla_date();
				allSLAArray[mIndex].setNanos(0);
				log
						.debug("SLA Array containing milestone sla and process sla is :"
								+ FinanceFA_Utilities
										.displayObjectArray(allSLAArray));
				int index = FinanceFA_Utilities.isSortedDateArray(allSLAArray);
				if (index == -1) {
					log
							.debug("All milestone's sla and process sla is in sorted order.");
					isOrdered = true;
				} else {
					StringBuffer buf = new StringBuffer(
							"Milestone sla and process sla for the following scenario are not in sorted order. ")
							.append("\n\nScenario ID: ")
							.append(scenarioDTO.getScenario_id())
							.append("\nProcess Name: ")
							.append(scenarioDTO.getProcess_name())
							.append("\nSubProcess Name: ")
							.append(scenarioDTO.getSubprocess_name())
							.append("\nCase Launch Cldr Id: ")
							.append(scenarioDTO.getCase_launch_cldr_id())
							.append("\nStart date: ")
							.append(scenarioDTO.getStart_date())
							.append("\nAll sla array: [")
							.append(FinanceFA_Utilities.displayObjectArray(allSLAArray))
							.append("]\n\nFirst difference in the array is: Milestone [")
							.append((index + 1))
							.append("]'s sla date [")
							.append(allSLAArray[index])
							.append("] is greater than ")
							.append((allSLAArray.length == (index + 2) ? "Process"
									: "Milestone [" + (index + 2) + "]"))
							.append("'s sla date [" + allSLAArray[index + 1])
							.append("]. \nPlease take immediate action to correct the sla dates.")
							.append("\n\nRegards\nFileNet Team.");
					log.fatal(buf);
					isOrdered = false;
				}
			}
		} catch (Exception e) {
			log.error("Error occured while checking the order of sla dates."
					+ e.getMessage(), e);
		}
		log.debug("[Exit checkSLAOrderOfLaunchConfiguration]");
		return isOrdered;
	}

	/**
	 * Prepare workflow fields for the active scenario list
	 * 
	 * @param activeScenarioList
	 *            array list of active scenarios ScenarioDTO bean
	 */
	private void prepareWorkflowFields(ArrayList activeScenarioList) {
		log.debug("[Enter prepareWorkflowFields]");
		for (int i = 0; i < activeScenarioList.size(); i++) {
			ScenarioDTO scenarioDTO = (ScenarioDTO) activeScenarioList.get(i);
			log.debug("Setting the workflow fields for Case Launch Cldr:"
					+ scenarioDTO.getCase_launch_cldr_id());
			ScenarioMapper scenarioMapper = new ScenarioMapper();
			scenarioMapper.setWorkflowFields(scenarioDTO);
		}
		log.debug("[Exit prepareWorkflowFields]");
	}

	/**
	 * Prepare workflow fields for the active scenario list
	 * 
	 * @param activeScenarioList
	 *            array list of active scenarios ScenarioDTO bean
	 * @return 
	 * @throws Exception 
	 */
	private String[] prepareWorkflowFields(ArrayList activeScenarioList,
			int wfReturnData) throws Exception {
		log.debug("[Enter prepareWorkflowFields]");
		
		String[] returnArray = null;
		for (int i = 0; i < activeScenarioList.size(); i++) {
			ScenarioDTO scenarioDTO = (ScenarioDTO) activeScenarioList.get(i);
			log.debug("Setting the workflow fields for Case Launch Cldr:"
					+ scenarioDTO.getCase_launch_cldr_id());
			ScenarioMapper scenarioMapper = new ScenarioMapper();
			returnArray = scenarioMapper.setWorkflowFields(scenarioDTO,
					wfReturnData);
		}
		log.debug("[Exit prepareWorkflowFields]");
		return returnArray;
	}
	
	/**
	 * Calculates the exact SLA expiration time for the given
	 * <code>slaMins</code> with respect to <code>relativeDate</code>,
	 * where SLA means Service Level Agreement in terms of hours.
	 * 
	 * <p>
	 * If <code>slaTypeId</code> is
	 * 
	 * <pre>
	 *       1: (Absolute) It checks the input date slaMins  whether it is 
	 *  	               	within office working time; if not returns the next office working day.
	 *                  	The slaMins should be in the format of 'yyyy-MM-dd HH:mm:ss'
	 *                  	For example: slaTypeId=1 and slaMins='2009-07-20 08:00:00'
	 *                  
	 *       2: (Relative) It returns the exact time of the day relative to relativeDate	date 
	 *                  	after slaMins number of minutes. Multiple sla minutes will be seperated 
	 *                  	by '|' delimeter. It can contain both positive(for escalation) and 
	 *                  	negative(for reminder) number. 
	 *                  	For example: slaTypeId=2 and slaMins=65|-100|35;
	 *                  
	 * </pre>
	 * 
	 * The SLA calculation process depends on the <code>slaCalculationId</code>
	 * which indicates whether Saturday or Sunday or Company holidays are
	 * consider as office working day. It can contain following values:
	 * 
	 * <pre>
	 *             		<b>Value</b>   <b>Office working days</b>
	 *              		1		Working Days
	 *             	 	2		Working Days+Saturday
	 *             	 	3		Working Days+Sunday
	 *             	 	4		Working Days+ Holidays
	 *             	 	5		Working Days+Saturday+Sunday
	 *             	 	6		Working Days+Saturday+Holidays
	 *             	 	7		Working Days+Sunday+Holidays
	 *             	 	8		Working Days+Saturday+Sunday+Holidays
	 *        
	 * </pre>
	 * 
	 * 
	 * @see com.bharti.fa.common.operations.util.manager.EscalationManager#calculateSLA()
	 * 
	 * @param slaMins
	 *            If slaTypeId is 1 then it contains the date whose next working
	 *            office time need to be calculated; Else if slaTypeId is 2 then
	 *            it contains sla offsets in terms of minutes need to be added
	 *            to relative date. Multiple sla minutes will be seperated by
	 *            '|' delimeter. It can contain both positive(for
	 *            escalation) and negative(for reminder) number.
	 * 
	 * @param relativeDate
	 *            contains either
	 *            <ul>
	 *            <li>relative date: then consider this to add the sla offset
	 *            <li>null or empty string: then consider current system time
	 *            to add the sla offset
	 *            </ul>
	 * 
	 * @param slaTypeId
	 *            if value is 1; it indicates <code>slaMins</code> is an
	 *            absolute date else if value is 2; it indicates
	 *            <code>slaMins</code> is an sla offset value.
	 * 
	 * @param slaCalculationId
	 *            indicates whether Saturday or Sunday or Company holidays
	 *            should be consider as office working day or not.
	 * 
	 * @param officeStartTime
	 *            Office start time. For night shift timings office start time
	 *            will be greater than the office end time. office time would be
	 *            represented in hh:mm:ss format; where hh=hours in 24 office
	 *            format mm=minutes and ss=seconds
	 * 
	 * @param officeEndTime
	 *            Office end time. For night shift timings office start time
	 *            will be greater than the office end time. office time would be
	 *            represented in hh:mm:ss format; where hh=hours in 24 office
	 *            format mm=minutes and ss=seconds
	 * 
	 * @return If slaTypeId is 1 then it returns the next working office
	 *         time(date array of size=1) with respect to <code>slaMins</code>;
	 *         Else if slaTypeId is 2 then it returns the exact sla expiration
	 *         time (date array of size=number of '|' seperated offset in
	 *         slaMins parameter) with respect to <code>slaMins</code>;
	 */
	public Date[] calculateSLA(String slaMins, Date relativeDate,
			int slaTypeId, int slaCalculationId, String officeStartTime,
			String officeEndTime) {

		EscalationManager escMng = new EscalationManager();
		Date[] slaExactDate = escMng.calculateSLA(slaMins, relativeDate,
				slaTypeId, slaCalculationId, officeStartTime, officeEndTime,
				FinanceFA_CIOperations.holidayXMLPath);
		return slaExactDate;
	}

	public static void main(String args[]) {
		String slaMins = "";

		while (true) {
			InputStreamReader isr = new InputStreamReader(System.in);
			BufferedReader inData = new BufferedReader(isr);
			System.out.print("Please enter the Number of SLA Hours :");
			try {
				slaMins = inData.readLine();
			} catch (IOException e) {
				e.printStackTrace();
			}
			// String[] str = new SCMOperations().calculateSLA(slaHour, "Oct 09
			// 15:28:03 2008");
			/*
			 * String[] str = new EscalationManager().calculateSLA(slaHour, "");
			 * for(int i=0; i<str.length; i++) System.out.println("The Exact
			 * SLA As String is :" + str[i]);
			 */
			// parseCompanyHolidayXML();
			SimpleDateFormat simDate = new SimpleDateFormat(
					"yyyy-MM-dd HH:mm:ss");
			Date offsetDate = null;
			try {
				offsetDate = simDate.parse("2009-07-20 08:00:00");
				System.out
						.println("For SLA offset date [" + offsetDate + "]: ");
			} catch (ParseException e) {
				System.out.println("For SLA offset date [" + offsetDate
						+ "]:Unable to parse the "
						+ "input CaseReceivedOnDate. It should be of format "
						+ "\"yyyy-MM-dd HH:mm:ss.SSS\"." + e.getMessage());
			}
			// Date[] str = new FinanceOperations().calculateSLA(slaMins,
			// offsetDate, 2, 1, "09:00:00", "18:00:00");

			// Date[] str = new FinanceOperations().calculateSLA(
			// slaMins, "July 13 09:00:03 2009", 1, 1, "09:00:00", "18:00:00");

			Date[] str = new FinanceFA_CIOperations().calculateSLA(slaMins,
					offsetDate, 2, 1, "09:00:00", "18:00:00");
			log.debug(str);
		}
	}
	
	/**
	 * Retrieves the active scenario list from the database and then it prepares
	 * all the necessary workflow fields and processes those scenarios.
	 * 
	 * @param holidayXMLPath
	 * 
	 * @param args
	 *            Command line arguments
	 * @return true if case launch process is successfull otherwise false
	 * @throws Exception
	 */
	public String[] getScenarioConfiguration(int scenarioId, int wfReturnData,
			String holidayXMLPath) throws Exception {
		if (log.isDebugEnabled()) {
			log.debug("[Enter getScenarioConfiguration]: scenarioId ["
					+ scenarioId + "] wfReturnData [" + wfReturnData
					+ "] holidayXMLPath [" + holidayXMLPath + "]");
		}
		boolean success = false;
		FinanceFA_ExternalDBManager dbManager = null;
		FinanceFA_CIOperations.holidayXMLPath = holidayXMLPath;
		String[] returnArray = null;

		try {

			/* Get database connection */
			log.debug("Retrieving the scenario details from database for scenario id ["
					+ scenarioId + "]");
			dbManager = new FinanceFA_ExternalDBManager(
					FinanceFA_Constants.APPLICATION_STANDALONE);
			dbManager.getDbConnection();

			/* Get the active scenarios */
			ArrayList activeScenarioList = dbManager
					.getCalendarScenario(scenarioId);
			
			/* If no active scenarios are found in the database */
			if (activeScenarioList == null || activeScenarioList.size() == 0) {
				log.info("*********** No Scenario details found ***********");
				return null;
			} else {
				log.debug("*********** " + activeScenarioList.size()
						+ " scenarios found ***********");
			}

			/* Prepare workflow fields from the active scenario list */
			log.debug("Preparing workflow fields from the active scenario list");
			returnArray = prepareWorkflowFields(activeScenarioList,
					wfReturnData);
			success = true;
		} catch (Exception ex) {
			log.error("Error occured while getting the scenario configuration."
					+ ex.getMessage(), ex);
			success = false;
			throw ex;
		} finally {

			/* Close the database connection */
			dbManager.closeDbConnection();
			log.debug("Database connection closed successfully.");
			log.info("Execution status is :"+success);
		}
		log.debug("[Exit getScenarioConfiguration]");
		return returnArray;
	}

}
